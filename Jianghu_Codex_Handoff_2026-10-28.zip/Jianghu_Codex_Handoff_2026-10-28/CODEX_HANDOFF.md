# Codex Handoff — Jianghu v2.08.9 in progress

## Objective
Continue from the attached Jianghu v2.08.8 source. Two tasks remain open: (1) diagnose and fix the reproducible full-world simulation slowdown at 34 disciples without weakening simulation behavior; (2) implement equipment-validation caching under the existing failing regression test. Do not claim a v2.08.9 release until both are verified.

## Read first
1. `README_FIRST_TH.md`
2. `REPORTS/STATUS_REPORT_TH.md`
3. `SOURCE/Jianghu_v2_08_8_AI_SOURCE/V2088_HANDOFF_TH.md`
4. `SOURCE/Jianghu_v2_08_8_AI_SOURCE/KNOWN_LIMITATIONS.md`
5. `SOURCE/Jianghu_v2_08_8_AI_SOURCE/tests/full_economy_scenario_v2088.cjs`
6. `SOURCE/Jianghu_v2_08_8_AI_SOURCE/tests/equipped_validation_cache_v2089.cjs`

The code project lives in `SOURCE/Jianghu_v2_08_8_AI_SOURCE/`. The `PLAYER/` HTML is a last-known-good v2.08.8 build, not a build containing the v2.08.9 fix.

## Verified starting point
- Build and `tests/verify_build_v205.cjs` pass for v2.08.8.
- Combat stats batch test passes.
- Inter-sect trade tests pass 8/8.
- Inter-sect market-only simulation passes 120 days × four seeds.
- Caravan route integration test passes.
- 20 disciples × 10 days + save continuation passes in 10.97 seconds.
- 34 disciples × 10 days timed out in the current harness after logging day 5/10; 34 × 30 days exceeded 125 seconds and logged through day 20/30 without a final result.
- `tests/equipped_validation_cache_v2089.cjs` currently fails at expected validation count 1 vs actual 2. This is a known failing regression test, not a passing feature.

## Task A — Diagnose full-world slowdown (do this first)
1. Reproduce with a bounded run and preserve logs:
   - `node tests/full_economy_scenario_v2088.cjs 20882001 20 10 1`
   - `node tests/full_economy_scenario_v2088.cjs 20882001 34 10 0`
2. Read `tests/full_economy_scenario_v2088.cjs` and `tests/inspect-engine.cjs` to understand day advancement and setup. Instrument per-day phase timing around actual engine functions; do not just increase timeout. Find the exact phase that grows/non-terminates after day 5 or around later days. Relevant files include `source/scripts/stage.js`, `progression.js`, `jianghu.js`, `sect-contributions.js`, and scheduled AI/movement/production jobs.
3. Add a small reproducible profiling/regression test before changing production behavior. Record before/after day timing and preserve semantic invariants: every day advances exactly once, NPCs still act, needs/cultivation/production/trade continue, accounting stays balanced, save/load continuation is deterministic.
4. Fix only the confirmed root cause. Do not disable AI, story, economy, movement, or NPCs to force a green test. Do not skip simulation days.
5. Verify 20 and 34 disciple scenarios, then extend the horizon (e.g. 20–30 days) with explicit timeout and final `SCENARIO_RESULT` evidence. Report any run that fails to finish as TIMEOUT, never PASS.

## Task B — Implement equipment-validation cache (TDD)
Current test: `tests/equipped_validation_cache_v2089.cjs`.
- RED currently: unchanged item is validated twice; expected once.
- Required behavior: unchanged equipment + unchanged relevant actor/item requirements reuses the last validation; durability set to 0 forces revalidation and removes the broken item from equipped slots immediately; the item remains in inventory.
- Inspect `source/scripts/progression.js` methods `canEquipItem()` and `sanitizeEquippedItems()` and all call sites/mutations before designing the cache. Cache invalidation must account for item id/slot/durability/compatibility/tier/minStageReq and actor path/realizationBand/trackOrdinal (or an equally safe fingerprint of all inputs that affect `canEquipItem`). A stale cache must never keep invalid equipment equipped. Avoid storing cache data in the save schema unless necessary; preferably ephemeral cache.
- Extend tests for changed path/stage, changed requirement, missing inventory item, and repaired/broken durability. Watch the test fail before implementation, then pass it and related gear/progression tests.
- Add a package script such as `test:equipped-cache` only if consistent with the repo's test conventions.

## Non-negotiable project constraints
- Preserve `source/scripts/human.js` byte-for-byte: expected SHA-256 `b230108298cae486c3dc6bf6698f0384ca67128b064ff3947f19fa6e5522328a`.
- Preserve `source/scripts/legacy.bundle.js` byte-for-byte: expected SHA-256 `605e8e3d9a2cf282f3be29dee6e124aeb5448af9b2f5ae005b147761404905b2`.
- Keep offline single-file HTML support and all 32 embedded script modules consistent with source.
- Preserve currency boundaries: intra-sect member trade uses contribution points; sect↔outsider and sect↔sect trade uses spirit stones; member↔outsider trade uses the member's personal spirit stones. Do not merge these ledgers.
- Keep the current save schema/envelope compatible unless a migration is explicitly tested.
- Do not delete tests or weaken assertions to get a pass.

## Verification commands
Run from `SOURCE/Jianghu_v2_08_8_AI_SOURCE/`:
```bash
node tests/equipped_validation_cache_v2089.cjs
node tests/combat_stats_batch_v2088.cjs
node tests/sect_network_trade_v2087.cjs
node tests/sect_network_simulation_v2087.cjs
node tests/caravan_route_economy_v2088.cjs
node tests/full_economy_scenario_v2088.cjs 20882001 20 10 1
node tests/full_economy_scenario_v2088.cjs 20882001 34 10 0
npm test
python3 tools/build.py
node tests/verify_build_v205.cjs
```

If a command is too slow, capture per-phase evidence and mark it incomplete; don't silently skip it. Update `STATUS_REPORT_TH.md`, test evidence, version metadata, and release notes only after actual verification. Use `2.08.8` as the base release; current work is not yet a verified `2.08.9` release.
