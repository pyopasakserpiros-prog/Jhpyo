# Jianghu Codex handoff — อ่านก่อนเริ่ม

นี่คือแพ็กส่งต่องานปัจจุบันเพื่อให้ Codex ทำต่อ ไม่ใช่การประกาศว่า v2.08.9 เสร็จแล้ว

## ไฟล์สำคัญ
- `PLAYER/Jianghu_Ascension_Myriad_Worlds_v2_08_8.html` — เกมออฟไลน์รุ่นล่าสุดที่ build/verify ผ่าน (v2.08.8)
- `SOURCE/Jianghu_v2_08_8_AI_SOURCE/` — ซอร์สทั้งหมด เอกสาร และชุดทดสอบ
- `REPORTS/STATUS_REPORT_TH.md` — รายงานภาษาไทยพร้อมสถานะผ่าน/ไม่ผ่าน
- `CODEX_HANDOFF.md` — คำสั่งงานสำหรับ Codex ภาษาอังกฤษ พร้อมข้อกำหนดและคำสั่งทดสอบ
- `REPORTS/verification-logs/` — หลักฐานจากคำสั่งทดสอบล่าสุด

## สถานะต้องทราบ
- ปัญหา performance: full-world 34 disciples ยัง timeout ในบาง run
- regression test แคชอุปกรณ์ `tests/equipped_validation_cache_v2089.cjs` ยัง FAIL เพราะ production cache ยังไม่ได้ implement
- ตลาดระหว่างสำนัก 120 วัน, caravan route, combat-stat batch, build verifier และ full-world 20 disciples/10 days ผ่าน
- อย่าเรียกงานนี้ว่า v2.08.9 release จนแก้และทดสอบสองรายการที่ค้างแล้ว

เริ่มด้วย `CODEX_HANDOFF.md` และ `REPORTS/STATUS_REPORT_TH.md`.
