'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs');
const E=World2026Engine,results=[],all=[];
const GOODS=['MAT_ORE_BLACK_IRON_1','MAT_HERB_DEW_GRASS_1','MAT_ORE_CINNABAR_1','MAT_HERB_JADE_LOTUS_2','MAT_HERB_MIST_ORCHID_2','MAT_HERB_CINDER_LEAF_1','MAT_HERB_BLOOD_GINSENG_3'];
function create(seed){const g=new Frontier(seed);g.establish();g.s.t=100;g.realm.ensureSectTradeState();g.s.realm.lastDay=5;g.s.realm.sectTrade.lastMarketDay=5;g.s.realm.sectTrade.networkLastDay=5;for(let i=0;i<g.s.realm.factions.length;i++){const f=g.s.realm.factions[i],delta=((seed+i*17)%61)-30;E.setSpiritStonesV140(f.cache,Math.max(50,Math.min(850,E.getSpiritStonesV140(f.cache)+delta)));const own=Object.keys(({CN:{MAT_HERB_JADE_LOTUS_2:1},SG:{MAT_HERB_MIST_ORCHID_2:1},IN:{MAT_HERB_CINDER_LEAF_1:1},JP:{MAT_HERB_CINDER_LEAF_1:1},VN:{MAT_HERB_BLOOD_GINSENG_3:1},RU:{MAT_HERB_MIST_ORCHID_2:1}})[f.id]||{})[0];if(own){const add=(seed+i)%3;if(add>0)g.add(f.cache,own,add,'SIMULATION_VARIANT_STOCK');}}return g;}
function day(g,d){g.s.t=d*20;g.realm.tickSectMarketDay(d);const state=g.s.realm.sectTrade;assert(state.networkStats.totalTrades>=0);assert(state.networkHistory.length<=60);assert(state.networkStats.totalTrades<=d*3);for(const f of g.s.realm.factions){const stones=E.getSpiritStonesV140(f.cache);assert(stones>=0,`${f.id} has negative stones at day ${d}`);assert(stones<=state.walletCap,`${f.id} exceeded wallet cap at day ${d}`);for(const id of GOODS){const qty=g.count(f.cache,id);assert(qty>=0,`${f.id}/${id} negative stock`);assert(qty<=state.stockCap,`${f.id}/${id} exceeded stock cap: ${qty}`);}}}
function digest(g){const s=g.s.realm.sectTrade;return JSON.stringify({networkStats:s.networkStats,networkHistory:s.networkHistory,networkCursor:s.networkCursor,networkLastDay:s.networkLastDay,lastMarketDay:s.lastMarketDay,factions:g.s.realm.factions.map(f=>({id:f.id,stones:E.getSpiritStonesV140(f.cache),stocks:GOODS.map(id=>[id,g.count(f.cache,id)])}))});}
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}

test('four seeds maintain bounded wallets and stocks through 120 market days with deterministic save continuation',()=>{
 for(const seed of [2087101,2087102,2087103,2087104]){
  const g=create(seed);for(let d=6;d<=60;d++)day(g,d);assert(g.s.realm.sectTrade.networkStats.totalTrades>0,`seed ${seed} should produce network trade`);const h=Frontier.load(g.serialize());for(let d=61;d<=120;d++){day(g,d);day(h,d);}assert.equal(digest(h),digest(g),`save continuation differs for seed ${seed}`);const row={seed,days:120,totalTrades:g.s.realm.sectTrade.networkStats.totalTrades,totalStones:g.s.realm.sectTrade.networkStats.totalStones,historyRetained:g.s.realm.sectTrade.networkHistory.length,wallets:g.s.realm.factions.map(f=>({id:f.id,stones:E.getSpiritStonesV140(f.cache)}))};all.push(row);console.log(JSON.stringify(row));
 }
});

fs.writeFileSync('evidence/sect-network-simulation-v2087.json',JSON.stringify({release:'2.08.7-autonomous-sect-network-market',pass:results.every(r=>r.pass),seeds:all,results},null,2));
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
process.exit(results.some(r=>!r.pass)?1:0);
