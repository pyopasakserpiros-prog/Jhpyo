require('./inspect-engine.cjs');const fs=require('fs'),assert=require('assert');const F=Frontier,E=World2026Engine,H=HumanCore;let checks=[];const fresh=fs.readFileSync('evidence/qa-fixture-v201.json','utf8');
const check=(v,m)=>{assert(v,m);checks.push(m);};
function game(){const g=F.load(fresh);for(const n of g.enemies)n.alive=false;for(const b of g.s.beasts)b.alive=false;for(const h of g.s.ecology.habitats)h.nextSpawnAt=1e8;g.s.campSupplies=0;g.s.activation=null;return g;}
function build(g,type,x,y){g.money(10000,'QA');g.s.wood=1000;g.add(g.bank,FrontierData.ORE,200,'QA');const r=g.place(type,x,y);assert(r.ok,r.reason);r.building.remaining=0;return r.building;}
// Each node activity, each garden activity and targeted gathering carry the appropriate HumanCore domain.
{
 const g=game(),n=g.heroes[0];build(g,'garden',1650,960);g.s.policy='resource';
 for(const o of g.options(n).filter(o=>o.id.startsWith('herb:')||o.id.startsWith('mine:')))check(o.activityId===(o.id.startsWith('herb:')?'herb':'mine'),'resource domain '+o.id);
 const plot=g.s.gardenPlots[0];check(g.plant(plot.id,'dew').ok,'plant uses actual seeds');const seed=g.s.seedStock.dew;check(!g.plant(plot.id,'dew').ok&&g.s.seedStock.dew===seed,'planting is guarded against duplicate consumption');
 const before=g.count(g.bank,FrontierData.HERB);g.advance(90);check(plot.growth>=FrontierData.CROPS.dew.growSeconds,'garden grows on the simulation clock');check(g.harvestGarden(plot.id).ok&&g.count(g.bank,FrontierData.HERB)>before,'harvest reaches bank material ledger');check(!g.harvestGarden(plot.id).ok,'same crop cannot be harvested twice');
 const node=g.s.nodes[0];n.stageLocal.x=node.x;n.stageLocal.y=node.y;const qty=node.qty;check(g.harvestNode(node.id,n.id).ok&&node.qty<qty,'wild gather depletes the resource node');
}
// Real alchemy jobs settle to real pill inventory AND sect bank storage, then a member consumes the effect.
{
 const g=game(),n=g.heroes[0],b=build(g,'alchemy',600,960),ep=g.endpoint(b);g.add(g.bank,'MAT_HERB_JADE_LOTUS_2',5,'QA');g.add(g.bank,FrontierData.HERB,10,'QA');
 check(g.fundOrder('REC1100_SUPPORT_QI').ok,'alchemy order reserves an escrow budget');const o=g.s.orders.at(-1);Object.assign(n.stageLocal,{x:ep.x,y:ep.y,orderId:o.id,mode:'idle',action:null,target:null,route:[]});const random=g.rng.next;g.rng.next=()=>0;
 check(g.startCommission(n)&&o.status==='working','alchemy starts a timed job');g.rng.next=random;check(!n.jianghu.ledgerV140.pillStacks.some(p=>p.recipeId===o.recipeId),'alchemy does not deliver before the finish tick');
 g.advance((o.finishTick+1)*20);check(o.status==='delivered','alchemy settles on the world clock');const pill=n.jianghu.ledgerV140.pillStacks.find(p=>p.recipeId===o.recipeId&&p.count>0);check(!!pill,'successful alchemy produces a usable pill');
 const bankPill=g.bank.jianghu.ledgerV140.pillStacks.find(p=>p.recipeId===o.recipeId&&p.count>0);check(!!bankPill,'sect-funded commission also delivers shareable pill stock to sect storage');
 const cs=g.combatSystem.ensure(n);cs.qi=0;g.combatSystem.tick(n,0);n.currentCityId=g.city;n.jianghu.busyProductionUntilTick=-1;check(E.consumePillFromLedgerV150(g.world,n.id,pill.id).ok&&cs.qi>0,'produced pill affects tactical combat Qi');
}
// Companions use canonical care item effects, not decorative inventory text.
{
 const g=game(),n=g.heroes[0],pet=g.s.realm.pets[0],ep=g.endpoint(g.built('hall'));pet.ownerId=n.id;pet.health=10;pet.hunger=70;pet.trust=20;Object.assign(n.stageLocal,{x:ep.x,y:ep.y,realmTarget:pet.id});const item={id:'QA_PET_REMEDY',nameTh:'อาหารฟื้นอสูร',count:1,effect:{healCompanion:20,trustGain:10}};n.jianghu.ledgerV140.beastItems.push(item);
 check(g.realm.finish(n,'careCompanion').success&&item.count===0&&pet.health===46&&pet.trust===33,'companion care consumes an item and applies its real heal/trust effects');
}
// Regional auction funds and physical ownership settle together.
{
 const g=game(),n=g.heroes[0],f=g.s.realm.factions[0];const envoy=g.realm.createEnvoy(f);const owner=g.realm.visitors[0];check(!!owner,'external faction creates a canonical NPC');
 const market=LivingJianghuSystem.MARKET;Object.assign(owner.stageLocal,{x:market.x,y:market.y});owner.stageLocal.envoy.phase='waiting';Object.assign(n.stageLocal,{x:market.x,y:market.y});const lot=g.realm.openAuction(owner);check(!!lot,'envoy opens an auction using its own equipment');const item=owner.jianghu.ledgerV140.equipmentItems.find(i=>i.id===lot.itemId);check(lot.minimum===(item.minimumBid||16),'regional minimum bid is honoured');E.addSpiritStonesV140(n,100);const balance=E.getSpiritStonesV140(n);check(g.realm.bid(n,lot.id).ok,'NPC bid reserves actual personal money');g.s.t=lot.closesAt;
 check(g.realm.closeAuction(lot)&&lot.delivered,'auction settles to a winner');check(n.jianghu.ledgerV140.equipmentItems.some(i=>i.id===item.id)&&!owner.jianghu.ledgerV140.equipmentItems.some(i=>i.id===item.id),'auction transfers the same physical equipment ID');check(E.getSpiritStonesV140(n)===balance-lot.price,'auction does not duplicate bidder funds');
}
// Every expanded material has a reachable local source and every manual has a combat classification.
{
 const X=JianghuExpansionV112,g=game(),sources=new Set([...g.s.nodes.map(n=>n.mat),...Object.values(FrontierData.CROPS).map(c=>c.matId)]);const walk=x=>{if(typeof x==='string'&&x.startsWith('MAT_'))sources.add(x);else if(x&&typeof x==='object')for(const v of Object.values(x))walk(v);};walk(X.expeditionTreasurePoolsV114);walk(X.fortuneLootPoolsV114);for(const b of [...X.beasts,...X.beastsV114])for(const p of b.partDrops||[])sources.add(p.matId);
 for(const m of X.materialsV114)check(sources.has(m.id),'expanded material source '+m.id);
 for(const a of X.manualsV112)check(!!g.combatSystem.classify(a),'manual combat role '+a.id);
}
fs.writeFileSync('evidence/qa-flows-v1.17.json',JSON.stringify({pass:true,checks:checks.length,details:checks},null,2));console.log('FLOWS_V117_PASS',checks.length);
