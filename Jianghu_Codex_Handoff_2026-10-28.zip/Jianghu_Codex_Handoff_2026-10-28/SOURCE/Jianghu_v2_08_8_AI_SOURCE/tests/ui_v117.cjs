/* Execute the actual UI startup and controls with offscreen Canvas + a minimal DOM (v1.17). */
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const C=require('./canvas-shim.cjs');
const root=path.resolve(__dirname,'..');require('./inspect-engine.cjs');
let lastMarkup="";
class El{
 set innerHTML(v){this._html=String(v);lastMarkup=this._html;}get innerHTML(){return this._html||"";}
 constructor(id=''){this.id=id;this.hidden=false;this.style={};this.dataset={};this.childNodes=[];this.attributes=[];this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this.listeners={};this.scrollTop=0;this.textContent='';this.value='';this.tagName='DIV';}
 setAttribute(k,v){const old=this.attributes.find(a=>a.name===k);if(old)old.value=String(v);else this.attributes.push({name:k,value:String(v)});}
 getAttribute(k){return this.attributes.find(a=>a.name===k)?.value??null;}
 hasAttribute(k){return this.getAttribute(k)!==null;}
 removeAttribute(k){this.attributes=this.attributes.filter(a=>a.name!==k);}
 addEventListener(k,v){(this.listeners[k]||=[]).push(v);}
 getBoundingClientRect(){return {width:430,height:720,left:0,top:0};}
 querySelectorAll(){return[];}querySelector(){return null;}closest(){return null;}
 appendChild(v){this.childNodes.push(v);}removeChild(v){this.childNodes=this.childNodes.filter(x=>x!==v);}get lastChild(){return this.childNodes.at(-1);}
 setPointerCapture(){}click(){this.onclick?.({target:this});}
}
const html=fs.readFileSync(path.join(root,'source/index.html'),'utf8'),els=new Map();for(const m of html.matchAll(/\bid="([^"]+)"/g))els.set('#'+m[1],new El(m[1]));
for(const key of ['#map','#minimap']){const cv=C.createCanvas(key==='#map'?430:156,key==='#map'?720:117),el=els.get(key);for(const k of ['addEventListener','getBoundingClientRect','setPointerCapture'])cv[k]=el[k].bind(el);cv.style={};els.set(key,cv);}
els.set('.ruler i',new El());els.set('#loading p',new El());
global.document={hidden:false,querySelector(s){assert(els.has(s),'Unknown startup DOM selector '+s);return els.get(s);},querySelectorAll(){return[];},addEventListener(){},createElement(tag){return tag==='canvas'?C.createCanvas(1,1):new El();}};
const stored=new Map();global.localStorage={getItem(k){return stored.get(k)||null;},setItem(k,v){stored.set(k,v);}};
global.window=global;window.addEventListener=()=>{};global.devicePixelRatio=1;global.location={search:'?fresh=1&qa=1'};global.Image=C.Image;global.matchMedia=()=>({matches:false});
const frames=[];global.requestAnimationFrame=fn=>{frames.push(fn);return frames.length;};
global.LivingArtAssets=JSON.parse(fs.readFileSync(path.join(root,'assets/art-manifest.json'),'utf8'));for(const [k,v] of Object.entries(LivingArtAssets.images))LivingArtAssets.images[k]='data:image/webp;base64,'+fs.readFileSync(path.resolve(root,'source',v)).toString('base64');
require('../source/scripts/living-art.js');
vm.runInThisContext(fs.readFileSync(path.join(root,'source/scripts/ui.js'),'utf8'),{filename:'ui.js'});
(async()=>{
 const start=Date.now();while(!global.JIANGHU&&Date.now()-start<30000)await new Promise(r=>setTimeout(r,100));
 assert(global.JIANGHU,'UI did not boot: '+els.get('#loading p').textContent);assert(els.get('#loading').hidden,'loading screen dismisses');
 const g=JIANGHU.game;assert.equal(g.heroes.length,2);assert.equal(g.s.version,11);assert.equal(Object.keys(JIANGHU.graphics.images).length,2);
 for(let i=0;i<8;i++){const fn=frames.shift();assert(fn,'RAF loop continues');fn(performance.now()+i*34);}
 els.get('#pause').click();assert(g.s.paused,'pause button targets the actual simulation');els.get('#pause').click();assert(!g.s.paused,'resume button works');
 els.get('#speed').click();assert.equal(g.s.speed,2);els.get('#speed').click();assert.equal(g.s.speed,4);els.get('#speed').click();assert.equal(g.s.speed,8);els.get('#speed').click();assert.equal(g.s.speed,16);els.get('#speed').click();assert.equal(g.s.speed,1);
 els.get('#zoomIn').click();assert(JIANGHU.camera.z>3.1,'zoom controls update the current camera');els.get('#home').click();assert.equal(JIANGHU.camera.z,3.1);
 els.get('#artSettings').click();assert.equal(els.get('#sheetTitle').textContent,'ภาพและบรรยากาศ');assert(!els.get('#sheet').hidden,'graphics sheet opens');els.get('#closeSheet').click();assert(els.get('#sheet').hidden,'graphics sheet closes');
 for(const panel of ['build','heroes','bounties','sect','inventory','ecology','life','world','growth','editHub','log','objectives']){JIANGHU.open(panel);assert(lastMarkup.length>20,'panel rendered '+panel);}
 JIANGHU.select(g.heroes[0].id);
 for(const section of ['life','recipes','arts','academy','heritage'])assert(GrowthView.render(g,g.heroes[0],section).length>100,'growth section '+section);
 const legacyBandit=g.world.npcs[g.s.enemyIds[0]];delete legacyBandit.stageLocal.needs;JIANGHU.select(legacyBandit.id);JIANGHU.open('hero');assert(lastMarkup.includes('สถานะ'),'NPC profile renders when legacy needs are missing');assert.equal(JIANGHU.runtimeFault,null,'missing needs does not trigger UI runtime fault');
 const saved=g.serialize(),reload=Frontier.load(saved);assert.equal(reload.s.version,11);assert.equal(reload.heroes.length,2);assert.equal(g.s.version,11,'startup never rewrites the engine envelope to 7');
 g.damage(g.heroes[1],10000,null,true);JIANGHU.open('heroes');const roster=lastMarkup.split('<details class="deceased-roster">');assert.equal(roster.length,2,'deceased NPC archive is collapsed separately');assert(!roster[0].includes('hero dead'),'deceased NPC remains in the live roster');assert(roster[1].includes(g.heroes[1].name),'death history was removed instead of archived');
 const report={pass:true,release:'1.17',backend:'offscreen Canvas + minimal DOM; not a live browser',checks:['actual UI bootstrap','image decode','first frames','pause/resume','1x/2x/4x/8x/16x','zoom/home','graphics panel open/close','current save envelope v11','all main panels','all growth tabs including provenance','NPC profile tolerates missing needs without a UI runtime fault']};
 fs.writeFileSync(path.join(root,'evidence/qa-ui-boot-v1.17.json'),JSON.stringify(report,null,2));console.log('UI_BOOT_V117_PASS',report);
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
