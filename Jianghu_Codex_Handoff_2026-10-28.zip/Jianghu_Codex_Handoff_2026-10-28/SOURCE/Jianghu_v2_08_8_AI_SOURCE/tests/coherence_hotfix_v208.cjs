'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),C=JianghuSectContributions,E=World2026Engine,I=JianghuInfrastructure;
const results=[];
function test(name,fn){const t=Date.now();try{fn();results.push({name,pass:true,ms:Date.now()-t});}catch(e){results.push({name,pass:false,ms:Date.now()-t,error:e.stack});}}
const initial=new Frontier(20899);initial.establish();const raw=initial.serialize();
function game(){
 const g=Frontier.load(raw);g.storyEvents.activate();g.s.storyEvents.autoEvents=false;
 g.money(5000,'TEST');g.s.wood=300;g.add(g.bank,FrontierData.ORE,100,'TEST');
 g.s.life.offices.master={npcId:g.heroes[0].id};
 return g;
}
function build(g,type,x=600,y=960){const b=g.place(type,x,y);assert(b.ok,b.reason);b.building.remaining=0;return b.building;}

test('sect-sponsored crafting cannot take goods reserved for the store',()=>{
 const g=game(),n=g.heroes[0];build(g,'alchemy');
 const lots=g.bank.jianghu.ledgerV140.materialStacks.filter(x=>x.matId===FrontierData.HERB);
 assert(lots.length);for(const lot of lots){lot.storeCount=lot.count;lot.sectStore=true;}
 const before=JSON.stringify(g.bank.jianghu.ledgerV140.materialStacks);
 assert(!C.canCraftForSect(g,n,'L14_remedy').ok);
 assert(!C.craftForSect(g,n,'L14_remedy',{forceSuccess:true}).ok);
 assert.equal(JSON.stringify(g.bank.jianghu.ledgerV140.materialStacks),before);
 assert.equal(C.inspect(g).sectWorkshopRecipes.find(x=>x.id==='L14_remedy').hasInputs,false);
});
test('crafting spends only the available unshelved units, with normal post-craft shelf curation',()=>{
 const g=game(),n=g.heroes[0];build(g,'alchemy');
 const lot=g.bank.jianghu.ledgerV140.materialStacks.find(x=>x.matId===FrontierData.HERB);
 lot.storeCount=lot.count-2;lot.sectStore=true;
 const shelved=lot.storeCount,total=lot.count;
 assert(C.canCraftForSect(g,n,'L14_remedy').ok);
 assert(C.craftForSect(g,n,'L14_remedy',{forceSuccess:true}).ok);
 assert.equal(lot.count,total-2);assert(lot.storeCount<=shelved,'curation may reallocate shelves, but must not create items');
});
test('curator retains the only rare ingredient when a member knows its workshop recipe',()=>{
 const g=game(),n=g.heroes[0];build(g,'alchemy');
 const rare='MAT_HERB_BLOOD_GINSENG_3';
 g.bank.jianghu.ledgerV140.materialStacks=g.bank.jianghu.ledgerV140.materialStacks.filter(x=>x.matId!==rare);
 assert(g.add(g.bank,rare,1,'RARE_INGREDIENT').ok);
 n.stageLocal.growth.knownRecipes.push('L14_ginseng');
 C.curateStore(g);
 const lot=g.bank.jianghu.ledgerV140.materialStacks.find(x=>x.matId===rare);
 assert.equal(lot.count,1);assert.equal(lot.storeCount,0,'one required rare ingredient stays in the treasury');
});
test('purchase order refuses a buyer with no actual stones, without creating currency or transferring goods',()=>{
 const g=game(),order=C.externalMarket(g).orders.find(x=>x.kind==='MATERIAL');assert(order);
 const reserve=C.orderReserve(g,order).reserve;assert(g.add(g.bank,order.targetId,reserve+6,'TEST').ok);
 const buyer=g.world.npcs[order.buyerNpcId];E.setSpiritStonesV140(buyer,0);
 const beforeGold=g.gold,beforeBank=g.count(g.bank,order.targetId),beforeFilled=order.filled;
 assert(!C.quotePurchaseOrder(g,order.id,1).ok);
 assert(!C.sellToPurchaseOrder(g,order.id,1).ok);
 assert.equal(g.gold,beforeGold);assert.equal(g.count(g.bank,order.targetId),beforeBank);assert.equal(order.filled,beforeFilled);
});
test('successful outside sale debits buyer wallet exactly once and credits sect once',()=>{
 const g=game(),order=C.externalMarket(g).orders.find(x=>x.kind==='MATERIAL');assert(order);
 assert(g.add(g.bank,order.targetId,C.orderReserve(g,order).reserve+5,'TEST').ok);
 const buyer=g.world.npcs[order.buyerNpcId],oldBuyer=E.getSpiritStonesV140(buyer),oldGold=g.gold;
 const sale=C.sellToPurchaseOrder(g,order.id,2);assert(sale.ok,sale.reason);
 assert.equal(E.getSpiritStonesV140(buyer),oldBuyer-sale.stones);
 assert.equal(g.gold,oldGold+sale.stones);
});
test('purchase orders reject fractional quantities rather than silently rounding',()=>{
 const g=game(),order=C.externalMarket(g).orders.find(x=>x.kind==='MATERIAL');assert(order);
 assert(g.add(g.bank,order.targetId,C.orderReserve(g,order).reserve+6,'TEST').ok);
 for(const qty of [0,-1,1.5,2.9,NaN,Infinity])assert(!C.sellToPurchaseOrder(g,order.id,qty).ok,qty);
});
test('automatic upgrade budget compares stone costs only, never adds unrelated wood and ore units',()=>{
 const g=game(),b=build(g,'treasury');
 for(let i=0;i<600;i++)g.bank.jianghu.ledgerV140.materialStacks.push({matId:'audit-slot-'+i,count:1});
 g.money(800-g.gold,'TEST_STONE_BUDGET');
 const candidate=I.inspect(g).candidates.find(x=>x.buildingId===b.id);
 assert(candidate,'full storage should create an upgrade candidate');
 assert(candidate.quoteOk,'all three resources are available');
 assert.equal(candidate.cost.stones,198);
 assert(candidate.cost.stones<=g.gold*.25);
 assert(candidate.cost.stones+candidate.cost.wood+candidate.cost.ore>g.gold*.25,'fixture must reproduce mixed-unit budget bug');
 assert(candidate.reserveOk,'wood and ore are checked separately');
 assert(candidate.eligible,'reasonable investment should not be blocked by summing unrelated currencies');
});
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+' ('+r.ms+'ms)'+(r.pass?'':'\n'+r.error));
fs.writeFileSync('evidence/coherence-hotfix-v208.json',JSON.stringify({pass:results.every(r=>r.pass),results},null,2));
if(results.some(r=>!r.pass))process.exitCode=1;
