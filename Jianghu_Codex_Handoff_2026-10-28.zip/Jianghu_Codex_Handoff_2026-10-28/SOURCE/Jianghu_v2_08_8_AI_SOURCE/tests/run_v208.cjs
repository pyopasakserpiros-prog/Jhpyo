/* Complete release checks, including the inherited simulation/content suites. */
'use strict';
const {execFile}=require('child_process'),path=require('path'),fs=require('fs'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const checks=[
 ['stats','tests/combat_stats_v201.cjs'],['combat_stats_batch','tests/combat_stats_batch_v2088.cjs'],['resolver','tests/combat_overhaul_v201.cjs'],['visuals','tests/combat_visuals_v201.cjs'],['retreat','tests/retreat_v201.cjs'],['world_links','tests/world_links_v201.cjs'],['status_links','tests/combat_status_v201.cjs'],['final_regressions','tests/final_regressions_v201.cjs'],['merge_ecology','tests/merge_ecology_v201.cjs'],['merge_npc','tests/merge_npc_v201.cjs'],
 ...['audit','flows','expedition','combat','combat_integration','simulation','world','balance','ui','render'].map(s=>[s,'tests/'+s+'_v117.cjs']),
 ['cultivation_quests','tests/cultivation_quests_v202.cjs'],['quest_combat','tests/quest_combat_v202.cjs'],['treasury','tests/treasury_v202.cjs'],['story_events','tests/story_events_v205.cjs'],['story_content','tests/story_content_v205.cjs'],['sidequests','tests/sidequests_v202.cjs'],['contributions','tests/contributions_v205.cjs'],['episode_runtime','tests/ep4_runtime_v205.cjs'],['gear_integrity','tests/gear_integrity_v205.cjs'],['runtime_ui','tests/runtime_ui_v205.cjs'],['review_regressions','tests/review_regressions_v205.cjs'],['treasury_routes','tests/treasury_routes_v205.cjs'],['treasury_ui','tests/treasury_ui_v205.cjs'],['sect_economy','tests/economy_v207.cjs'],['member_external_trade','tests/member_external_trade_v2084.cjs'],['caravan_ecology','tests/caravan_ecology_v2085.cjs'],['caravan_route_economy','tests/caravan_route_economy_v2088.cjs'],['sect_trade','tests/sect_trade_v2086.cjs'],['sect_network_trade','tests/sect_network_trade_v2087.cjs'],['library_economy','tests/library_economy_v207.cjs'],['infrastructure','tests/infrastructure_v207.cjs'],['economy_integration','tests/economy_integration_v207.cjs'],['coherence','tests/coherence_v208.cjs'],['coherence_hotfix','tests/coherence_hotfix_v208.cjs'],['ep5_speed_hotfix','tests/ep5_speed_v2082.cjs'],['academy_formula_schema','tests/academy_formula_schema_v2083.cjs'],['runtime_report_recovery_smoke','tests/runtime_report_recovery_smoke_v2083.cjs'],['economy_ui','tests/economy_ui_v207.cjs'],['economy_simulation','tests/economy_simulation_v207.cjs'],['living_quests','tests/living_quests_v205.cjs'],
 ['myriad_worlds','tests/myriad_worlds_v200.cjs'],['build','tools/build.py'],['verify_build','tests/verify_build_v205.cjs']
];
// audit creates the fixture used by the other processes. Build and its verifier
// consume final outputs, so only isolated runtime checks share the worker pool.
const results=[],startedAt=new Date().toISOString();let failed=false;
const sourceFiles=['source/index.html','source/style.css',...fs.readdirSync(path.join(root,'source/scripts')).filter(n=>n.endsWith('.js')).sort().map(n=>'source/scripts/'+n)];
const digest=()=>{const h=crypto.createHash('sha256');for(const f of sourceFiles){h.update(f);h.update(fs.readFileSync(path.join(root,f)));}return h.digest('hex');};
const sourceSha256=digest();
function checkpoint(){fs.writeFileSync(path.join(root,'evidence/suite-v2088.json'),JSON.stringify({release:'2.08.8-full-economy-performance-and-longrun',startedAt,completedAt:new Date().toISOString(),sourceSha256,pass:results.length===checks.length&&!failed&&results.every(x=>x.pass),status:results.length===checks.length?(!failed&&results.every(x=>x.pass)?'passed':'failed'):'incomplete',completed:results.length,expected:checks.length,results:[...results].sort((a,b)=>checks.findIndex(c=>c[0]===a.name)-checks.findIndex(c=>c[0]===b.name))},null,2));}
async function run([name,file]){
 const start=Date.now();
 const r=await new Promise(resolve=>execFile(file.endsWith('.py')?'python3':process.execPath,[file],{cwd:root,encoding:'utf8',maxBuffer:12*1024*1024},(error,stdout,stderr)=>resolve({status:error?(Number.isInteger(error.code)?error.code:1):0,stdout:stdout||'',stderr:stderr||'',error})));
 const log='evidence/v2088-'+name+'.log';fs.writeFileSync(path.join(root,log),r.stdout+r.stderr+(r.error&& !r.stderr?'\n'+r.error.message:''));
 const row={name,pass:r.status===0,exitCode:r.status,seconds:+((Date.now()-start)/1000).toFixed(2),log};results.push(row);failed ||= !row.pass;checkpoint();
 console.log(name+': '+(row.pass?'PASS':'FAIL')+' ('+row.seconds+'s)');
 if(!row.pass)console.error((r.stdout+r.stderr).slice(-5000));
}
(async()=>{
 checkpoint();await run(checks.find(c=>c[0]==='audit'));if(failed){process.exitCode=1;return;}
 const slow=['simulation','living_quests','world','economy_simulation','economy_integration','balance'];
 // Schedule fast, independently useful regressions first. Starting three long simulations
 // simultaneously hid all progress when one legacy scenario took several minutes.
 const eligible=checks.filter(c=>!['audit','build','verify_build'].includes(c[0]));
 const queue=[...eligible.filter(c=>!slow.includes(c[0])),...eligible.filter(c=>slow.includes(c[0]))];
 let next=0;
 await Promise.all(Array.from({length:3},async()=>{while(!failed&&next<queue.length){const check=queue[next++];await run(check);}}));
 if(!failed&&digest()!==sourceSha256){failed=true;console.error('Source files changed during checks; run again after freezing sources.');checkpoint();}
 if(!failed)await run(checks.find(c=>c[0]==='build'));
 if(!failed)await run(checks.find(c=>c[0]==='verify_build'));
 if(failed){process.exitCode=1;return;}
 console.log('ALL_V208_CHECKS_PASS');
})().catch(e=>{failed=true;checkpoint();console.error(e.stack);process.exitCode=1;});
