'use strict';
require('./inspect-engine.cjs');
const fs=require('fs'),path=require('path'),assert=require('assert');
const E=World2026Engine,H=HumanCore,results=[];
const initial=new Frontier(20107);initial.establish();const save=initial.serialize(),HERB='MAT_HERB_DEW_GRASS_1';
function fresh(){const g=Frontier.load(save);g.s.t=100;const st=g.storyEvents.activate();st.autoEvents=false;st.treasury.autoDistribute=false;for(const k of ['materialStacks','equipmentItems','pillStacks','scrolls'])g.bank.jianghu.ledgerV140[k]=[];g.s.growth.scriptureLibrary=[];for(const n of g.heroes){n.health=100;n.stageLocal.mode='idle';n.stageLocal.action=null;n.stageLocal.offmap=null;n.jianghu.internalInjury=0;}g.s.life.offices.master={npcId:g.heroes[0].id};for(const n of g.heroes){const a=JianghuSectContributions.account(g,n);a.balance=100000;a.earned=100000;}return g;}
function test(id,fn){try{const value=fn(fresh());results.push({id,pass:true,evidence:value});}catch(e){results.push({id,pass:false,error:e.message,actual:e.actual,expected:e.expected});}}
function eq(id,extra={}){return {id,nameTh:id,slot:'WEAPON',tier:2,minStageReq:1,durability:100,compatiblePath:'ANY',...extra};}
function request(g,n,kind,id){return g.storyEvents.createManualRequisition(n.id,kind,id,'REDEEM');}
function grant(g,n,kind,id){const r=request(g,n,kind,id);assert(r.ok,r.reason);return g.storyEvents.judgeRequisition(r.req.id,true);}
function unknownArt(g,n){const a=g.progression.arts.find(a=>!a.innateRoute&&g.progression.compatible(n,a)&&g.progression.canStudyArtTier(n,a)&&!n.jianghu.knowledgeV190[a.id]);assert(a);return a;}
function book(id,a,extra={}){return {id,artId:a.id,nameTh:a.nameTh,tier:a.tier,count:1,rights:'OWNER',...extra};}
function holdings(g,n){return JSON.stringify({source:g.bank.jianghu.ledgerV140,destination:n.jianghu.ledgerV140});}

test('full_material_bag_preserves_bank_and_pending_request',g=>{
 const n=g.heroes[0];n.jianghu.ledgerV140.materialStacks=Array.from({length:24},(_,i)=>({matId:'slot-'+i,count:1,quality:'STANDARD',isTranscendent:false}));assert(g.add(g.bank,HERB,5,'TEST').ok);
 const req=request(g,n,'MATERIAL',HERB);assert(req.ok);const before=holdings(g,n),r=g.storyEvents.judgeRequisition(req.req.id,true);
 assert(!r.ok,'Full material inventory must reject the handoff');assert.strictEqual(holdings(g,n),before);assert(g.s.storyEvents.treasury.requisitions.some(x=>x.id===req.req.id));return {bank:g.count(g.bank,HERB)};
});
test('material_transfer_preserves_quality_origin_and_quantity',g=>{
 const n=g.heroes[0];n.jianghu.ledgerV140.materialStacks=[];assert(g.add(g.bank,HERB,5,'TEST',{quality:'PERFECT',originType:'WORLD_NODE',originId:'original-node',originLabelTh:'Original provenance'}).ok);
 const r=grant(g,n,'MATERIAL',HERB);assert(r.ok,r.reason);const dst=n.jianghu.ledgerV140.materialStacks.find(s=>s.matId===HERB);assert(dst);assert.strictEqual(dst.count,2);assert.strictEqual(dst.quality,'PERFECT');assert.strictEqual(dst.originId,'original-node');assert.strictEqual(g.count(g.bank,HERB),3);
});
test('material_transfer_respects_human_carry_limit',g=>{
 const n=g.heroes[0];n.jianghu.ledgerV140.materialStacks=[];const cap=H.carryLimit(n);assert(g.add(n,HERB,cap,'TEST').ok);assert(g.add(g.bank,HERB,5,'TEST').ok);
 const r=grant(g,n,'MATERIAL',HERB);assert(!r.ok);assert.strictEqual(H.load(n),cap);assert.strictEqual(g.count(g.bank,HERB),5);
});
test('partial_material_failure_rolls_back_real_stacks_and_knowledge',g=>{
 const n=g.heroes[0];n.core.human.body.strength=100;n.core.physiology.endurance=100;n.jianghu.ledgerV140.materialStacks=Array.from({length:23},(_,i)=>({matId:'held-material-'+i,count:1,quality:'STANDARD',isTranscendent:false}));assert(g.add(g.bank,HERB,1,'TEST',{quality:'PERFECT'}).ok);assert(g.add(g.bank,HERB,1,'TEST',{quality:'GOOD'}).ok);
 const req=request(g,n,'MATERIAL',HERB);assert(req.ok);const before=holdings(g,n),known=JSON.stringify(n.jianghu.knownMaterialIds),r=g.storyEvents.judgeRequisition(req.req.id,true);assert(!r.ok,'A two-quality transfer into one free slot must roll back');assert.strictEqual(holdings(g,n),before);assert.strictEqual(JSON.stringify(n.jianghu.knownMaterialIds),known);assert(g.s.storyEvents.treasury.requisitions.some(x=>x.id===req.req.id));
});
for(const [kind,key,cap] of [['EQUIPMENT','equipmentItems',12],['PILL','pillStacks',16],['SCROLL','scrolls',24]])test('full_'+key+'_rejects_without_any_debit',g=>{
 const n=g.heroes[0],a=unknownArt(g,n),l=n.jianghu.ledgerV140;
 l[key]=Array.from({length:cap},(_,i)=>kind==='EQUIPMENT'?eq('held-'+i):kind==='PILL'?{id:'held-'+i,recipeId:'held-'+i,nameTh:'Held '+i,count:1,effect:{}}:book('held-'+i,{id:'held-art-'+i,nameTh:'Held',tier:1}));
 const item=kind==='EQUIPMENT'?eq('full-test'):kind==='PILL'?{id:'full-test',recipeId:'unique',nameTh:'Unique',count:1,effect:{}}:book('full-test',a,{ownerNpcId:g.bank.id});g.bank.jianghu.ledgerV140[key]=[item];
 const req=request(g,n,kind,item.id);assert(req.ok);const before=holdings(g,n),r=g.storyEvents.judgeRequisition(req.req.id,true);assert(!r.ok,'Full '+key+' must reject');assert.strictEqual(holdings(g,n),before);assert(!n.jianghu.knowledgeV190[a.id]);
});
test('equipment_moves_same_instance_updates_owner_and_equips_legally',g=>{
 const n=g.heroes[0],item=eq('same-instance',{ownerId:g.bank.id,ownerNpcId:g.bank.id});n.jianghu.ledgerV140.equipmentItems=[];g.bank.jianghu.ledgerV140.equipmentItems=[item];
 const r=grant(g,n,'EQUIPMENT',item.id);assert(r.ok,r.reason);assert.strictEqual(n.jianghu.ledgerV140.equipmentItems[0],item);assert.strictEqual(item.ownerId,n.id);assert.strictEqual(item.ownerNpcId,n.id);assert.strictEqual(n.jianghu.equipmentV140.WEAPON,item.id);assert.strictEqual(g.bank.jianghu.ledgerV140.equipmentItems.length,0);
});
test('ineligible_equipment_cannot_be_debited_or_equipped',g=>{
 const n=g.heroes[0],item=eq('too-high',{minStageReq:99});g.bank.jianghu.ledgerV140.equipmentItems=[item];const r=grant(g,n,'EQUIPMENT',item.id);assert(!r.ok);assert.strictEqual(g.bank.jianghu.ledgerV140.equipmentItems[0],item);assert.notStrictEqual(n.jianghu.equipmentV140.WEAPON,item.id);
});
test('pill_handoff_transfers_one_unconsumed_dose',g=>{
 g.s.storyEvents.treasury.elderNpcId=g.heroes[1].id;const n=g.heroes[0];n.health=10;n.jianghu.pillToxicity=0;n.jianghu.ledgerV140.pillStacks=[];const item={id:'one-dose',recipeId:'test-remedy',nameTh:'Remedy',count:1,effect:{healHealth:20,toxicity:4}};g.bank.jianghu.ledgerV140.pillStacks=[item];
 const r=grant(g,n,'PILL',item.id);assert(r.ok);assert.strictEqual(n.health,10);assert.strictEqual(n.jianghu.pillToxicity,0);assert.strictEqual(n.jianghu.ledgerV140.pillStacks[0],item);assert.strictEqual(item.count,1);assert(E.consumePillFromLedgerV150(g.world,n.id,item.id).ok);assert.strictEqual(n.health,30);assert.strictEqual(n.jianghu.pillToxicity,4);
});
test('pill_split_preserves_origin_and_leaves_source_quantity',g=>{
 const n=g.heroes[0];n.jianghu.ledgerV140.pillStacks=[];const item={id:'two-dose',recipeId:'split-remedy',nameTh:'Split remedy',count:2,quality:'PERFECT',effect:{healHealth:7},originLabelTh:'Maker source'};g.bank.jianghu.ledgerV140.pillStacks=[item];assert(grant(g,n,'PILL',item.id).ok);assert.strictEqual(item.count,1);const dst=n.jianghu.ledgerV140.pillStacks[0];assert.strictEqual(dst.count,1);assert.notStrictEqual(dst.id,item.id);assert.strictEqual(dst.originLabelTh,'Maker source');assert.strictEqual(dst.quality,'PERFECT');
});
test('scroll_moves_real_instance_without_granting_knowledge',g=>{
 const n=g.heroes[0],a=unknownArt(g,n),item=book('unique-book',a,{ownerNpcId:g.bank.id,canRedistribute:true,access:'SECT'});n.jianghu.ledgerV140.scrolls=[];g.bank.jianghu.ledgerV140.scrolls=[item];const beforeKnowledge=JSON.stringify(n.jianghu.knowledgeV190);const r=grant(g,n,'SCROLL',item.id);assert(r.ok,r.reason);assert.strictEqual(n.jianghu.ledgerV140.scrolls[0],item);assert.strictEqual(item.ownerNpcId,n.id);assert.strictEqual(g.bank.jianghu.ledgerV140.scrolls.length,0);assert.strictEqual(JSON.stringify(n.jianghu.knowledgeV190),beforeKnowledge);assert(!item.adminGrant);
});
test('transferred_scroll_reaches_real_knowledge_only_through_normal_reading',g=>{
 const n=g.heroes[0],a=g.progression.arts.find(a=>!a.innateRoute&&g.progression.canStudyArtTier(n,a)&&g.discovery.canStudy(n,a)&&!n.jianghu.knowledgeV190[a.id]);assert(a);const item=book('readable-treasury-scroll',a,{ownerNpcId:g.bank.id,canRedistribute:true});n.jianghu.ledgerV140.scrolls=[];g.bank.jianghu.ledgerV140.scrolls=[item];assert(grant(g,n,'SCROLL',item.id).ok);assert(!n.jianghu.knowledgeV190[a.id]);
 const endpoint=g.endpoint(g.built('shrine')||g.built('training')||g.built('hall'));let sessions=0;
 while((n.jianghu.knowledgeV190[a.id]?.stage||0)<4&&sessions<30){Object.assign(n.stageLocal,{x:endpoint.x,y:endpoint.y,target:endpoint,mode:'working',job:0,growthTarget:a.id});g.progression.start(n,'readScripture');assert(g.progression.finish(n,'readScripture').success);sessions++;}
 assert(sessions>1);assert.strictEqual(n.jianghu.knowledgeV190[a.id].reading,100);assert.strictEqual(n.jianghu.knowledgeV190[a.id].stage,4);assert(n.jianghu.knownArtIdsV150.includes(a.id));assert.strictEqual(n.jianghu.ledgerV140.scrolls[0],item);return {sessions,artId:a.id};
});
test('missing_scroll_and_unknown_art_requests_cannot_mint_items',g=>{
 const n=g.heroes[0],a=unknownArt(g,n),before=holdings(g,n);assert(!request(g,n,'SCROLL',a.id).ok);assert(!request(g,n,'SCROLL','UNKNOWN_ART_TEST').ok);assert.strictEqual(holdings(g,n),before);assert(!n.jianghu.knowledgeV190.UNKNOWN_ART_TEST);
});
test('shared_library_is_not_removed_or_copied_by_treasury',g=>{
 const n=g.heroes[0],a=unknownArt(g,n),item=book('communal-book',a,{rights:'SECT_LIBRARY',ownerNpcId:null,access:'SECT'});g.s.growth.scriptureLibrary=[item];const r=request(g,n,'SCROLL',a.id);assert(!r.ok);assert.strictEqual(g.s.growth.scriptureLibrary[0],item);assert(!n.jianghu.ledgerV140.scrolls.some(s=>s.artId===a.id));
});
for(const restriction of ['private_owner','loan','loanedTo','no_redistribute'])test('treasury_honors_'+restriction,g=>{
 const n=g.heroes[0],owner=g.heroes[1],a=unknownArt(g,n),extra=restriction==='private_owner'?{ownerNpcId:owner.id,access:'PRIVATE'}:restriction==='loan'?{rights:'LOAN',loan:{ownerNpcId:owner.id,borrowerNpcId:g.bank.id,sessionId:'active'}}:restriction==='loanedTo'?{loanedTo:owner.id}:{canRedistribute:false};const item=book('restricted',a,extra);g.bank.jianghu.ledgerV140.scrolls=[item];const r=request(g,n,'SCROLL',item.id);assert(!r.ok,'Restricted item must not be requisitionable');assert.strictEqual(g.bank.jianghu.ledgerV140.scrolls[0],item);
});
test('enemy_and_dead_members_cannot_receive_or_administer_treasury',g=>{
 const enemy=g.enemies[0];enemy.alive=true;enemy.health=100;const item=eq('guarded');g.bank.jianghu.ledgerV140.equipmentItems=[item];assert(!request(g,enemy,'EQUIPMENT',item.id).ok);assert(!g.storyEvents.setTreasuryAuthority('APPOINTED_ELDER',enemy.id).ok);
 const n=g.heroes[1];n.alive=false;n.health=0;assert(!request(g,n,'EQUIPMENT',item.id).ok);assert(!g.storyEvents.setTreasuryAuthority('APPOINTED_ELDER',n.id).ok);
});
test('offmap_and_disgraced_members_cannot_teleport_physical_items',g=>{
 const n=g.heroes[1],item=eq('present-only');g.bank.jianghu.ledgerV140.equipmentItems=[item];n.stageLocal.offmap={journeyId:'away'};assert(!request(g,n,'EQUIPMENT',item.id).ok);g.storyEvents.refreshDiscipleRequisitions();assert(!g.s.storyEvents.treasury.requisitions.some(r=>r.requesterId===n.id));n.stageLocal.offmap=null;g.life.member(n).disgracedUntil=200;assert(!g.storyEvents.setTreasuryAuthority('APPOINTED_ELDER',n.id).ok);
});
test('dead_or_disgraced_elder_falls_back_to_available_member',g=>{
 const elder=g.heroes[1];assert(g.storyEvents.setTreasuryAuthority('APPOINTED_ELDER',elder.id).ok);g.life.member(elder).disgracedUntil=200;
 const item=eq('fallback-grant');g.bank.jianghu.ledgerV140.equipmentItems=[item];const n=g.heroes[0],r=grant(g,n,'EQUIPMENT',item.id);assert(r.ok,r.reason);assert.strictEqual(r.logEntry.distributorName,n.name);
});
test('pending_requests_are_deduplicated_and_bounded_per_member',g=>{
 const n=g.heroes[0];g.bank.jianghu.ledgerV140.equipmentItems=Array.from({length:10},(_,i)=>eq('bounded-'+i));for(let i=0;i<100;i++)request(g,n,'EQUIPMENT','bounded-'+(i%10));const reqs=g.s.storyEvents.treasury.requisitions.filter(r=>r.requesterId===n.id);assert(reqs.length<=2,'At most two pending requests per member');assert.strictEqual(new Set(reqs.map(r=>r.itemKind+':'+r.itemId)).size,reqs.length);
});
test('stale_item_is_revalidated_at_judgment',g=>{
 const n=g.heroes[0],item=eq('stale');g.bank.jianghu.ledgerV140.equipmentItems=[item];const req=request(g,n,'EQUIPMENT',item.id);assert(req.ok);item.ownerNpcId=g.heroes[1].id;const r=g.storyEvents.judgeRequisition(req.req.id,true);assert(!r.ok);assert.strictEqual(g.bank.jianghu.ledgerV140.equipmentItems[0],item);
});
test('forced_rejection_records_the_explicit_override',g=>{
 const n=g.heroes[0],item=eq('override-reject');g.bank.jianghu.ledgerV140.equipmentItems=[item];const req=request(g,n,'EQUIPMENT',item.id);assert(req.ok);const r=g.storyEvents.judgeRequisition(req.req.id,false);assert(r.ok&&!r.approved);assert.strictEqual(r.logEntry.decision,'REJECTED');assert.strictEqual(r.logEntry.verdictType,'MASTER_OVERRIDE');assert.strictEqual(g.bank.jianghu.ledgerV140.equipmentItems[0],item);
});
test('hoarder_proactive_distribution_respects_its_approval_threshold',g=>{
 const master=g.heroes[0];Object.assign(master.personality,{integrity:100,discipline:0,empathy:0,ambition:0,caution:100,courage:0,rationality:0,trustfulness:0});master.core.values.wealthResource=100;for(const n of g.heroes)g.life.member(n).merit=0;assert(g.add(g.bank,HERB,5,'TEST').ok);assert(g.storyEvents.setTreasuryAuthority('MASTER_DIRECT').ok);const r=g.storyEvents.proactiveDistributeFromTreasury();assert(!r.ok,'Hoarder should keep stock when no candidate meets threshold');assert.strictEqual(g.count(g.bank,HERB),5);
});
test('compassion_uses_aggression_relative_to_its_neutral_value',g=>{
 const n=g.heroes[0];for(const d of JianghuNpcCoreData.PERSONALITY_AXES_14)n.personality[d.id]=50;Object.assign(n.personality,{integrity:55,trustfulness:45,empathy:70});for(const d of JianghuNpcCoreData.VALUE_DIMENSIONS_8)n.core.values[d.id]=50;n.core.values.familyClan=45;assert(g.storyEvents.setTreasuryAuthority('MASTER_DIRECT').ok);assert.strictEqual(g.storyEvents.inspect().treasuryView.philosophy.styleId,'COMPASSIONATE_RELIEF');
});
test('treasury_approval_preserves_all_canonical_identity_axes',g=>{
 const before=Object.fromEntries(g.heroes.map(n=>[n.id,H.fingerprint(n)])),n=g.heroes[0],item=eq('identity-stable');g.bank.jianghu.ledgerV140.equipmentItems=[item];assert(grant(g,n,'EQUIPMENT',item.id).ok);for(const h of g.heroes){assert.strictEqual(H.fingerprint(h),before[h.id]);assert(H.validate(h));}return {canonicalAxes:68,personalityAxes:JianghuNpcCoreData.PERSONALITY_AXES_14.length,values:JianghuNpcCoreData.VALUE_DIMENSIONS_8.length};
});

const report={release:'treasury-v202',pass:results.every(r=>r.pass),checks:results};const filename=process.argv.includes('--red')?'treasury-v202-red.json':process.argv.includes('--extra-red')?'treasury-v202-red-extra.json':'treasury-v202.json';fs.writeFileSync(path.join(__dirname,'../evidence',filename),JSON.stringify(report,null,2));for(const r of results)console.log(r.pass?'PASS':'FAIL',r.id,r.error||'');console.log(JSON.stringify({pass:report.pass,total:results.length,failed:results.filter(r=>!r.pass).length}));if(!report.pass)process.exitCode=1;
