/* Focused merged ecology/economy behavioral audit. Does not run npm/build suites. */
require('./inspect-engine.cjs');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const E = global.World2026Engine, H = global.HumanCore, D = global.JianghuMyriadWorldsData;
const base = new Frontier(8821); base.establish();
const save = base.serialize();
const checks = [];
function fresh() { const g = Frontier.load(save); for (const e of g.enemies) e.alive = false; return g; }
function check(id, fn) {
  try { const evidence = fn(); checks.push({id, pass:true, evidence}); }
  catch (e) { checks.push({id, pass:false, error:e.message, actual:e.actual, expected:e.expected}); }
}
function building(g, type, x=600, y=960) {
  g.money(10000,'AUDIT'); g.s.wood=1000; g.add(g.bank,FrontierData.ORE,300,'AUDIT');
  const b=g.built(type)||g.place(type,x,y).building; b.remaining=0; return b;
}
function work(g,n,action,targetId,b) {
  const at=g.endpoint(b); Object.assign(n.stageLocal,{x:at.x,y:at.y,growthTarget:targetId,action,mode:'working',job:0,target:at});
  g.progression.start(n,action); return g.progression.finish(n,action);
}
check('raw_individual_damage_preserves_identity_and_rare_organ',()=>{
  const g=fresh(),n=g.heroes[0];
  const ind=g.myriad.generateBeastIndividual('MW_BEAST_005','ecology-audit',{forceRareOrgan:true,forceRareOrganId:'MW_ORGAN_014'});
  const id=ind.individualId;
  g.myriad.recordDamageTypeOnBeast(ind,n,'FIRE');
  assert.strictEqual(ind.damageHistory.fireDamage,15,'Damage must update the persisted encounter individual, not regenerate nested anatomy');
  assert(!ind.individual,'Existing individual must not acquire a second individual');
  const r=g.myriad.harvestIndividualCorpse(n,ind,{guaranteeOrganRecovery:true});
  assert.strictEqual(r.organResult?.organId,'MW_ORGAN_014'); assert(ind.harvested);
  return {id,organ:r.organResult};
});
check('map_beast_fire_damage_uses_executed_art_metadata',()=>{
  const g=fresh(),n=g.heroes[0],b=g.spawnBeast('wolf-forest','MW_BEAST_005');
  const fire=g.progression.arts.find(a=>/FIRE|FLAME|SOLAR|EMBER/.test([a.id,a.subPath,a.element].join(' ')));
  assert(fire,'Fixture needs a registered fire art'); n.jianghu.path='XIAN';
  g.damage(b,1,n,true,{combat201:true,type:'art',artId:fire.id});
  assert(b.individual.damageHistory.fireDamage>0,'Executed fire art must mark fire-sensitive anatomy; attacker major path XIAN is insufficient');
  return {artId:fire.id,history:b.individual.damageHistory};
});
check('stale_experiment_preflights_all_inputs_before_payment',()=>{
  const g=fresh(),n=g.heroes[0],d=D.experimentDesigns[0];
  n.jianghu.ledgerV140.materialStacks=[];g.bank.jianghu.ledgerV140.materialStacks=[];
  g.add(n,d.trialInputs[0].matId,d.trialInputs[0].count,'AUDIT'); E.addSpiritStonesV140(n,12);
  n.stageLocal.mwTargetId=d.id;
  const before={stones:E.getSpiritStonesV140(n),first:g.count(n,d.trialInputs[0].matId)};
  const r=g.myriad.finish(n,'experimentPropertyRecipe'); assert(!r.success);
  assert.deepStrictEqual({stones:E.getSpiritStonesV140(n),first:g.count(n,d.trialInputs[0].matId)},before,'A cancelled trial with unavailable later input must not burn fee/earlier material');
  return before;
});
check('healing_qi_event_restores_canonical_tactical_qi',()=>{
  const g=fresh(),n=g.heroes[0],cs=g.combatSystem.ensure(n); cs.qi=0; n.jianghu.currentQiV190=0;n.health=40;
  const inst=g.myriad.rollMyriadWorldsInstance(D.entrances[0].id,n,'ecology-qi');
  const r=g.myriad.executeExplorationEventOutcome(n,inst,{nameTh:'Audit spring'},{outcome:'HEAL_AND_QI_RESTORE'},{int:(a)=>a});
  assert(n.health>40); assert(cs.qi>0,'HEAL_AND_QI_RESTORE must restore stageLocal.combatState.qi');
  assert.strictEqual(cs.qi,n.jianghu.currentQiV190); return {health:n.health,qi:cs.qi,summary:r.summaryTh};
});
check('bank_overflow_manuscript_remains_accessible_to_owner',()=>{
  const g=fresh(),n=g.heroes[0]; n.jianghu.ledgerV140.scrolls=Array.from({length:24},(_,i)=>({id:'held'+i,count:1}));
  const ms=g.myriad.grantRecipeManuscript(n,'MW_REC_001','AUDIT','Audit discovery');
  assert(g.bank.jianghu.ledgerV140.scrolls.some(s=>s.id===ms.id));
  n.jianghu.ledgerV140.scrolls.pop();
  const r=g.myriad.studyRecipeManuscript(n,ms.id);
  assert(r.ok,'A discovered personal manuscript sent to sect storage needs an owner retrieval/study path');
  assert(!g.heroes[1].stageLocal.growth.knownRecipes.includes('MW_REC_001'));
  return {manuscriptId:ms.id,study:r};
});
check('both_full_manuscript_settlement_does_not_report_unreachable_reward',()=>{
  const g=fresh(),n=g.heroes[0]; n.jianghu.ledgerV140.scrolls=Array.from({length:24},(_,i)=>({id:'held'+i,count:1}));
  g.bank.jianghu.ledgerV140.scrolls=Array.from({length:120},(_,i)=>({id:'bank'+i,count:1}));
  const ms=g.myriad.grantRecipeManuscript(n,'MW_REC_001','AUDIT','Audit discovery');
  const accessible=ms && [n,g.bank].some(owner=>owner.jianghu.ledgerV140.scrolls.some(s=>s.id===ms.id));
  const deferred=ms && g.myriad.state.deferredClaims.some(c=>c.id===ms.id||c.item?.id===ms.id||c.scroll?.id===ms.id);
  assert(!ms||accessible||deferred,'When both scroll containers are full, retain an accessible deferred reward or reject settlement');
  return {manuscriptId:ms?.id,accessible,deferred};
});
check('crafted_myriad_equipment_retains_catalog_path_requirement',()=>{
  const g=fresh(),r=D.newRecipes.find(r=>r.id==='MW_REC_023');
  const n=g.heroes.slice().sort((a,b)=>H.capacity(b,'forging').total-H.capacity(a,'forging').total)[0];
  E.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:3,progress:0});
  assert(H.capacity(n,'forging').total>=r.minMastery,'Fixture artisan must meet natural forging capacity');
  const b=building(g,'forge'); n.stageLocal.growth.knownRecipes.push(r.id);
  for(const i of r.inputs)g.add(n,i.matId,i.count,'AUDIT'); E.addSpiritStonesV140(n,20);
  g.rng.next=()=>0; const result=work(g,n,'makePersonalItem',r.id,b); assert(result.success,'Fixture equipment craft must succeed');
  const item=n.jianghu.ledgerV140.equipmentItems.find(i=>i.recipeId===r.id); assert(item);
  assert.strictEqual(item.compatiblePath,r.compatiblePath,'Personal manufacturing must preserve authored HEART_SOUL equipment restriction');
  return {recipe:r.id,catalogPath:r.compatiblePath,item};
});
check('equipment_adapter_retains_functional_special_effects',()=>{
  const g=fresh(),catalog=D.newRecipes.find(r=>r.id==='MW_REC_035'),r=g.progression.recipe(catalog.id);
  assert.strictEqual(r.effect.dissectionBonus,catalog.effect.dissectionBonus);
  assert.strictEqual(r.effect.craftBonusScore,catalog.effect.craftBonusScore,'New dissection tool must keep authored craft bonus through personal-recipe adapter');
  assert.strictEqual(r.effect.craftBonusPath,catalog.effect.craftBonusPath);
  return {catalog:catalog.effect,adapted:r.effect};
});
check('sect_funded_real_equipment_commission_delivers_one_item',()=>{
  const g=fresh(),n=g.heroes[0],r=D.newRecipes.find(r=>r.id==='MW_REC_021'),b=building(g,'forge');
  for(const i of r.inputs)g.add(g.bank,i.matId,i.count,'AUDIT');
  assert(g.fundOrder(r.id).ok);const o=g.s.orders.at(-1),ep=g.endpoint(b);
  Object.assign(n.stageLocal,{x:ep.x,y:ep.y,orderId:o.id});g.rng.next=()=>0;
  assert(g.startCommission(n),'Real commission must start');
  const c=g.world.jianghu.causalV1180.commissions.find(c=>c.id===o.commissionId);assert(c?.outputEscrow);
  g.world.tick=c.finishTick;g.settleCommissions();
  const output=[...n.jianghu.ledgerV140.equipmentItems,...g.bank.jianghu.ledgerV140.equipmentItems].filter(i=>i.recipeId===r.id);
  assert.strictEqual(output.length,1,'One funded commission must not clone output into both client and warehouse');
  assert.strictEqual(c.status,'DELIVERED');assert(g.bank.jianghu.ledgerV140.equipmentItems.some(i=>i.recipeId===r.id));
  return {commission:c.id,outputCount:output.length,bankItem:output[0].id};
});
check('full_commission_storage_waits_then_delivers_escrow_once',()=>{
  const g=fresh(),n=g.heroes[0],r=D.newRecipes.find(r=>r.id==='MW_REC_021'),b=building(g,'forge');
  for(const i of r.inputs)g.add(g.bank,i.matId,i.count,'AUDIT');assert(g.fundOrder(r.id).ok);
  const o=g.s.orders.at(-1),ep=g.endpoint(b);Object.assign(n.stageLocal,{x:ep.x,y:ep.y,orderId:o.id});g.rng.next=()=>0;
  assert(g.startCommission(n));const c=g.world.jianghu.causalV1180.commissions.find(c=>c.id===o.commissionId),itemId=c.outputEscrow.item.id;
  n.jianghu.ledgerV140.equipmentItems=Array.from({length:12},(_,i)=>({id:'client-full'+i}));
  g.bank.jianghu.ledgerV140.equipmentItems=Array.from({length:240},(_,i)=>({id:'bank-full'+i}));
  const stones=E.getSpiritStonesV140(n);g.world.tick=c.finishTick;g.settleCommissions();
  assert.strictEqual(c.status,'WAITING_STORAGE');assert.strictEqual(c.outputEscrow.item.id,itemId);
  assert.strictEqual(E.getSpiritStonesV140(n),stones);
  g.bank.jianghu.ledgerV140.equipmentItems.pop();g.settleCommissions();g.settleCommissions();
  assert.strictEqual(c.status,'DELIVERED');assert(!c.outputEscrow);
  assert.strictEqual(g.bank.jianghu.ledgerV140.equipmentItems.filter(i=>i.id===itemId).length,1);
  return {itemId,stoneCostOnRetry:0,deliveredOnce:true};
});
check('failed_experiment_with_valid_inputs_still_pays_real_costs',()=>{
  const g=fresh(),n=g.heroes[0],d=D.experimentDesigns[0];n.stageLocal.mwTargetId=d.id;
  n.jianghu.ledgerV140.materialStacks=[];g.bank.jianghu.ledgerV140.materialStacks=[];
  for(const inp of d.trialInputs)g.add(g.bank,inp.matId,inp.count,'AUDIT');E.addSpiritStonesV140(n,12);
  const stones=E.getSpiritStonesV140(n);g.rng.next=()=>.999;
  const r=g.myriad.finish(n,'experimentPropertyRecipe');assert(!r.success);
  assert.strictEqual(E.getSpiritStonesV140(n),stones-6);for(const inp of d.trialInputs)assert.strictEqual(g.count(g.bank,inp.matId),0);
  assert(n.stageLocal.growth.archivedResearchNotes.some(note=>note.formulaId===d.id));
  return {stonesSpent:6,trialInputsConsumed:d.trialInputs,archivedFailure:true};
});
check('working_link_personal_fragment_to_recipe_to_real_pill_to_health_and_qi',()=>{
  const g=fresh(),n=g.heroes[0],b=building(g,'alchemy'),peer=g.heroes[1];
  const ms=g.myriad.grantRecipeManuscript(n,'MW_REC_001','AUDIT','Audit field fragment',{isFragment:true,fragmentPct:60});
  assert(!n.stageLocal.growth.knownRecipes.includes('MW_REC_001'));
  for(let i=0;i<6&&!n.stageLocal.growth.knownRecipes.includes('MW_REC_001');i++)assert(g.myriad.studyRecipeManuscript(n,ms.id).ok);
  assert(n.stageLocal.growth.knownRecipes.includes('MW_REC_001'));assert(!peer.stageLocal.growth.knownRecipes.includes('MW_REC_001'));
  const r=g.progression.recipe('MW_REC_001'); for(const i of r.inputs)g.add(n,i.matId,i.count,'AUDIT');E.addSpiritStonesV140(n,20);
  const before=r.inputs.map(i=>g.count(n,i.matId)),stones=E.getSpiritStonesV140(n);g.rng.next=()=>0;
  assert(work(g,n,'makePersonalItem',r.id,b).success);
  r.inputs.forEach((i,k)=>assert.strictEqual(g.count(n,i.matId),before[k]-i.count));assert.strictEqual(E.getSpiritStonesV140(n),stones-2);
  const pill=n.jianghu.ledgerV140.pillStacks.find(p=>p.recipeId===r.id);assert.strictEqual(pill.effect.healHealth,26);
  n.health=40;const cs=g.combatSystem.ensure(n);cs.qi=0;n.jianghu.currentQiV190=0;
  assert(work(g,n,'usePersonalPill',pill.id,b).success);assert(n.health>40);assert(cs.qi>0);assert.strictEqual(pill.count,0);
  return {owner:n.id,peerUnaware:true,health:n.health,qi:cs.qi,realInputsConsumed:r.inputs};
});
check('working_link_damage_quality_overflow_deferred_and_no_duplicate_harvest',()=>{
  const g=fresh(),n=g.heroes[0],ind=g.myriad.generateBeastIndividual('MW_BEAST_005','quality-audit',{forceRareOrgan:true,forceRareOrganId:'MW_ORGAN_014'});
  g.myriad.recordDamageTypeOnBeast({individual:ind},n,'FIRE');g.myriad.recordDamageTypeOnBeast({individual:ind},n,'FIRE');
  g.add(n,'MAT_ORE_BLACK_IRON_1',H.carryLimit(n),'AUDIT');
  const r=g.myriad.harvestIndividualCorpse(n,ind,{guaranteeOrganRecovery:true});
  assert(r.items.some(i=>i.quality==='DAMAGED'));assert(r.items.some(i=>i.warehouseAdded>0));assert(r.organResult.recovered);
  assert(!g.myriad.harvestIndividualCorpse(n,ind).ok);
  g.bank.jianghu.ledgerV140.materialStacks=Array.from({length:640},(_,i)=>({matId:'full'+i,count:1,quality:'STANDARD',isTranscendent:false}));
  const settle=g.myriad.settleMaterialReward(n,'MW_MAT_ORE_064',2,{sourceLabel:'AUDIT'});assert.strictEqual(settle.deferred,2);
  g.bank.jianghu.ledgerV140.materialStacks=[];assert.strictEqual(g.myriad.claimDeferredItems(n).moved,2);assert.strictEqual(g.count(g.bank,'MW_MAT_ORE_064'),2);
  return {damagedParts:r.items.filter(i=>i.quality==='DAMAGED'),organ:r.organResult.organId,claimed:2};
});
check('working_link_transcendent_ledger_provenance_guard',()=>{
  const g=fresh(),n=g.heroes[0],id='MW_MAT_HERB_048';
  assert(!E.addMaterialToLedgerV140(g.world,n,id,1,{originType:'WORLD_NODE',originId:'BAD'}).ok);
  assert(g.myriad.settleMaterialReward(n,id,1,{heritageLegacyId:'LEG_MYRIAD_WORLDS',sourceLabel:'Myriad heritage'}).ok);
  const stack=[...n.jianghu.ledgerV140.materialStacks,...g.bank.jianghu.ledgerV140.materialStacks].find(s=>s.matId===id);
  assert.strictEqual(stack.originType,'HERITAGE_SITE');assert.strictEqual(stack.originId,'LEG_MYRIAD_WORLDS');return stack;
});
const report={
  release:'2.01-merge-ecology-audit',
  pass:checks.every(c=>c.pass),
  scope:'Focused real ecology/loot/experimentation/manufacturing flows; no full suite or build, no identity-foundation edits or old-save migration.',
  historicalDocumentedFixes:{
    source:'Original uploaded Jianghu_Ascension_Myriad_Worlds_v2_00_Unified_Combat (2).zip / QA_REPORT_TH.md section 5; historical claims, separate from newly reproduced failures.',
    items:[
      'Nineteen NW_MAT beast parts reconnected to NW_BEAST partDrops and recipes added for 250 older materials.',
      'Deceased equipmentV140 references cleared when belongings move to fallenRemains.',
      'Small sect safety avoids both initial disciples leaving simultaneously before the valley stabilizes.'
    ]
  },
  checks
};
fs.writeFileSync(path.join(__dirname,'../evidence/merge-ecology-v201.json'),JSON.stringify(report,null,2));
for(const c of checks)console.log(c.pass?'PASS':'FAIL',c.id,c.error||'');
console.log(JSON.stringify({pass:report.pass,total:checks.length,failed:checks.filter(c=>!c.pass).length}));
if(!report.pass)process.exitCode=1;
