/* Regression: migrate legacy formula schema and safely finish a partially committed accepted share. */
'use strict';
const assert=require('assert'),fs=require('fs');
require('./inspect-engine.cjs');
const results=[];
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}

test('legacy formula registry records receive missing collection defaults on load',()=>{
 const fresh=new Frontier(208303);fresh.establish();
 const owner=fresh.heroes[0];assert(owner,'fixture owner exists');
 fresh.s.growth.formulaRegistry.push({id:'TEST_LEGACY_FORMULA',ownerNpcId:owner.id,recipe:{id:'TEST_LEGACY_FORMULA',name:'สูตรทดสอบ'}});
 const loaded=Frontier.load(fresh.serialize());
 const f=loaded.s.growth.formulaRegistry.find(x=>x.id==='TEST_LEGACY_FORMULA');assert(f);
 assert.deepEqual(Array.from(f.knownBy),[owner.id]);assert(Array.isArray(f.licenses));assert(Array.isArray(f.history));assert.equal(f.revision,1);
});

test('accepted share recovers after knownRecipes was added but license append previously crashed',()=>{
 const candidate=process.env.JIANGHU_RUNTIME_REPORT;
 if(!candidate||!fs.existsSync(candidate)){results.push({name:'actual v2.08.2 share recovery (external fixture)',pass:true,skipped:true,reason:'set JIANGHU_RUNTIME_REPORT to the exported runtime report'});return;}
 const report=JSON.parse(fs.readFileSync(candidate,'utf8'));
 const g=Frontier.load(JSON.stringify(report.save));
 const owner=g.world.npcs.NPC_3891,partner=g.world.npcs.NPC_3911;
 assert(owner&&partner,'reported owner and recipient exist');
 const ticket=owner.stageLocal.academyTicket;assert.equal(ticket?.action,'shareFormula');assert.equal(ticket.accepted,true);
 const f=g.s.growth.formulaRegistry.find(x=>x.id===ticket.formulaId);assert(f);assert(Array.isArray(f.licenses));
 assert(partner.stageLocal.growth.knownRecipes.includes(f.id),'fixture reproduces partial commit');
 const beforeCount=partner.stageLocal.growth.knownRecipes.filter(id=>id===f.id).length,beforeTick=g.s.t;
 g.s.paused=false;g.s.speed=1;g.acc=0;
 assert.doesNotThrow(()=>g.frame(.1),'the actual frame loop must finish the recovered sharing job');
 assert(g.s.t>beforeTick,'simulation should advance past the reported crash point');
 assert.equal(partner.stageLocal.growth.knownRecipes.filter(id=>id===f.id).length,beforeCount,'must not duplicate known recipe');
 assert(f.knownBy.includes(partner.id));assert(f.licenses.some(x=>x.npcId===partner.id&&x.rights==='USE_ONLY'));
 assert.equal(owner.stageLocal.academyTicket,null);assert.equal(partner.stageLocal.academyReservation,undefined);
});

const out={pass:results.every(r=>r.pass),release:'2.08.6-sect-to-sect-spirit-stone-trade',results};
console.log(results.map(r=>(r.pass?'PASS ':'FAIL ')+r.name+(r.skipped?' (SKIPPED)':'')).join('\n'));
fs.writeFileSync(__dirname+'/../evidence/academy-formula-schema-v2083.json',JSON.stringify(out,null,2));
if(!out.pass)process.exitCode=1;
