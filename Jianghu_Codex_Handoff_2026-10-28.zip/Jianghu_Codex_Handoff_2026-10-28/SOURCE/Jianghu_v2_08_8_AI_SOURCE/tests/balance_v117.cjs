/* Deterministic equal-opportunity stress fixtures, not natural progression. */
require('./inspect-engine.cjs');const fs=require('fs'),assert=require('assert');
const E=World2026Engine,H=HumanCore,raw=fs.readFileSync('evidence/qa-fixture-v201.json','utf8'),g=Frontier.load(raw),C=g.combatSystem;
// These are isolated duels: neither contender is a recipient of the other's allied healing/ward.
C.injuredAllies=()=>[];C.wardAllies=()=>{};
for(const n of g.enemies)n.alive=false;for(const b of g.s.beasts)b.alive=false;
const base=JSON.parse(JSON.stringify(g.heroes[0])),ids=g.s.heroIds.slice(0,2),profiles=Object.values(CombatData117.profiles),out=[];
function build(id,p,f,x){const n=JSON.parse(JSON.stringify(base));n.id=id;n.name=p.subPath;n.jianghu.knowledgeV190={};n.jianghu.attackArtIds=[];n.stageLocal.combatState=null;n.stageLocal.nextLoadoutAt=0;n.stageLocal.mode='idle';n.stageLocal.x=x;n.stageLocal.y=1300;n.health=100;n.alive=true;n.core.condition.fatigue=0;Object.assign(n.jianghu,{path:p.path,subPath:p.subPath});g.world.npcs[id]=n;const o=Math.max(1,Math.round(1+(p.realmCount-1)*f));E.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:o,progress:0});
 for(const a of C.arts.filter(a=>!a.innateRoute&&(a.path===p.path||a.path==='ANY')&&g.progression.canStudyArtTier(n,a))){n.jianghu.knowledgeV190[a.id]={artId:a.id,stage:5,mastery:50,reading:100,source:'BALANCE_FIXTURE'};}
 C.ensure(n);C.reconcileLoadout(n,{force:true});n.stageLocal.mode='combat';return n;}
const start=performance.now();
for(const phase of [.0,.5,1])for(let i=0;i<profiles.length;i++)for(const offset of [1,11,23]){
 const j=(i+offset)%profiles.length,a=build(ids[0],profiles[i],phase,1000),b=build(ids[1],profiles[j],phase,1110);g.s.t=100;let steps=0;
 for(;steps<240&&a.alive&&b.alive;steps++){g.s.t+=.25;H.tick(a,.25);H.tick(b,.25);C.tick(a,.25);C.tick(b,.25);if(steps%2){C.act(a,b);C.act(b,a);}else{C.act(b,a);C.act(a,b);}assert(Number.isFinite(a.health)&&Number.isFinite(b.health),'nonfinite health');assert(a.stageLocal.combatState.qi>=0&&b.stageLocal.combatState.qi>=0,'negative Qi');}
 const sa=C.ensure(a),sb=C.ensure(b);out.push({a:profiles[i].subPath,b:profiles[j].subPath,phase,winner:!a.alive?profiles[j].subPath:!b.alive?profiles[i].subPath:null,seconds:steps*.25,hp:[+a.health.toFixed(1),+b.health.toFixed(1)],moves:[sa.moveCount,sb.moveCount],qiSpent:[sa.qiSpent,sb.qiSpent],combos:[sa.comboCount,sb.comboCount],capacities:[C.attackCapacity(a),C.attackCapacity(b)]});
}
const summary=profiles.map(p=>{const bouts=out.filter(x=>x.a===p.subPath||x.b===p.subPath),wins=bouts.filter(x=>x.winner===p.subPath).length,draws=bouts.filter(x=>!x.winner).length;return {route:p.subPath,style:p.style,bouts:bouts.length,wins,draws,score:+((wins+draws*.5)/bouts.length).toFixed(3)};}).sort((a,b)=>b.score-a.score);
const result={scope:'equal identity and same relative route progress fractions; all same-path ordinary arts known at mastery50; not a natural playthrough or proof of universal balance',bouts:out.length,runtimeSeconds:+((performance.now()-start)/1000).toFixed(2),summary,battles:out};fs.writeFileSync('evidence/balance-v117.json',JSON.stringify(result,null,2));console.log(JSON.stringify({bouts:out.length,seconds:result.runtimeSeconds,top:summary.slice(0,6),bottom:summary.slice(-6),draws:out.filter(x=>!x.winner).length},null,2));
