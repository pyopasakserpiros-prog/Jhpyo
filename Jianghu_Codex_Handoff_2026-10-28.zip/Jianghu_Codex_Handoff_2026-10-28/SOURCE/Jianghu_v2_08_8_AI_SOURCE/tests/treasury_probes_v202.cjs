/* Focused, read-only-of-production probes for the uploaded v2.04 treasury.
   Run: node tests/treasury_probes_v202.cjs
   The report records safety invariants as false on the uncorrected upload;
   setup errors are reported separately so every independent probe still runs. */
'use strict';
require('./inspect-engine.cjs');
const fs=require('fs'),path=require('path'),assert=require('assert');
const E=World2026Engine,H=HumanCore;
const seedGame=new Frontier(20107);seedGame.establish();
const seedSave=seedGame.serialize(),checks=[];
function fresh(){
 const g=Frontier.load(seedSave);g.s.t=100;
 for(const n of g.enemies){n.alive=false;n.health=0;}
 for(const b of g.s.beasts)b.alive=false;
 for(const h of g.heroes){h.stageLocal.mode='idle';h.stageLocal.action=null;h.stageLocal.offmap=null;h.jianghu.busyProductionUntilTick=-1;}
 const st=g.storyEvents.activate();st.autoEvents=false;st.treasury.autoDistribute=false;
 for(const k of ['materialStacks','equipmentItems','pillStacks','scrolls'])g.bank.jianghu.ledgerV140[k]=[];
 g.s.growth.scriptureLibrary=[];return g;
}
function fingerprint(g){return Object.fromEntries(g.heroes.map(n=>[n.id,H.fingerprint(n)]));}
function probe(id,fn){try{const g=fresh(),before=fingerprint(g),v=fn(g);checks.push({id,...v,humanFoundationPreserved:JSON.stringify(before)===JSON.stringify(fingerprint(g))});}catch(e){checks.push({id,setupError:e.stack});}}
function request(g,n,kind,id){const r=g.storyEvents.createManualRequisition(n.id,kind,id);assert(r.ok,r.reason);return r.req;}
function grant(g,n,kind,id){const r=request(g,n,kind,id);return g.storyEvents.judgeRequisition(r.id,true);}
function equipment(id,opts={}){return {id,nameTh:id,slot:'WEAPON',tier:2,durability:100,maxDurability:100,compatiblePath:'ANY',minStageReq:1,...opts};}
function artFor(g,n){const a=g.progression.arts.find(a=>!a.innateRoute&&g.progression.compatible(n,a)&&g.progression.canStudyArtTier(n,a)&&!n.jianghu.knowledgeV190[a.id]);assert(a,'Need a real unknown compatible art');return a;}
const herb='MAT_HERB_DEW_GRASS_1';

probe('material_full_inventory_destroys_bank_stock',g=>{
 const n=g.heroes[0],l=n.jianghu.ledgerV140;
 l.materialStacks=Array.from({length:E.PATCH140_CAPS.materialStacks},(_,i)=>({matId:'FULL_SLOT_'+i,quality:'STANDARD',count:1,isTranscendent:false}));
 assert(g.add(g.bank,herb,5,'PROBE').ok);
 const before={bank:g.count(g.bank,herb),recipient:g.count(n,herb),slots:l.materialStacks.length};
 const r=grant(g,n,'MATERIAL',herb),after={bank:g.count(g.bank,herb),recipient:g.count(n,herb),slots:l.materialStacks.length};
 return {expected:'Reject or defer with both ledgers unchanged when recipient cannot accept the stack',invariant:before.bank+before.recipient===after.bank+after.recipient,before,after,result:r.ok};
});
probe('material_transfer_rewrites_quality_and_origin',g=>{
 const n=g.heroes[0];n.jianghu.ledgerV140.materialStacks=[];
 assert(g.add(g.bank,herb,5,'ORIGINAL_FIND',{quality:'PERFECT',originType:'WORLD_NODE',originId:'unique-node',originLabelTh:'Unique field provenance'}).ok);
 const source=JSON.parse(JSON.stringify(g.bank.jianghu.ledgerV140.materialStacks[0]));
 const r=grant(g,n,'MATERIAL',herb),received=n.jianghu.ledgerV140.materialStacks.find(s=>s.matId===herb);
 return {expected:'Preserve the consumed source stack quality and provenance, as stage.transferMaterialStack does',invariant:received?.quality===source.quality&&received?.originId===source.originId,source,received,result:r.ok};
});
probe('material_transfer_ignores_human_carry_limit',g=>{
 const n=g.heroes[0],cap=H.carryLimit(n);n.jianghu.ledgerV140.materialStacks=[];
 assert(g.add(n,herb,cap,'PROBE').ok);assert(g.add(g.bank,herb,5,'PROBE').ok);
 const r=grant(g,n,'MATERIAL',herb);
 return {expected:'Do not exceed the canonical HumanCore carry limit',invariant:H.load(n)<=cap,carryLimit:cap,load:H.load(n),result:r.ok};
});
probe('equipment_full_inventory_is_lost_by_canonical_cap_enforcement',g=>{
 const n=g.heroes[0],l=n.jianghu.ledgerV140,cap=E.PATCH140_CAPS.equipmentItems,id='treasury-unique-equipment';
 l.equipmentItems=Array.from({length:cap},(_,i)=>equipment('held-'+i));g.bank.jianghu.ledgerV140.equipmentItems=[equipment(id)];
 const r=grant(g,n,'EQUIPMENT',id),immediate={recipientSlots:l.equipmentItems.length,recipientHas:l.equipmentItems.some(i=>i.id===id),bankHas:g.bank.jianghu.ledgerV140.equipmentItems.some(i=>i.id===id)};
 E.enforceCapsV140(g.world,true);
 const afterCaps={recipientSlots:l.equipmentItems.length,recipientHas:l.equipmentItems.some(i=>i.id===id),bankHas:g.bank.jianghu.ledgerV140.equipmentItems.some(i=>i.id===id)};
 return {expected:'Keep the unique equipment in the bank until a recipient slot is available',invariant:afterCaps.recipientHas||afterCaps.bankHas,cap,immediate,afterCaps,result:r.ok};
});
probe('equipment_force_equips_an_ineligible_path_and_realm',g=>{
 const n=g.heroes[0],id='wrong-path-and-realm',otherPath=n.jianghu.path==='XIAN'?'DEMON':'XIAN';
 const item=equipment(id,{compatiblePath:otherPath,tier:7,minStageReq:99});g.bank.jianghu.ledgerV140.equipmentItems=[item];
 const r=grant(g,n,'EQUIPMENT',id),eligibility=g.progression.canEquipItem(n,item);
 return {expected:'Only equip after canEquipItem validates path, minimum realm, and ownership',invariant:!(n.jianghu.equipmentV140.WEAPON===id&&!eligibility.ok),equipped:n.jianghu.equipmentV140.WEAPON,eligibility,result:r.ok};
});
probe('pill_grant_applies_one_dose_twice',g=>{
 const n=g.heroes[0];n.health=10;n.jianghu.pillToxicity=0;n.jianghu.ledgerV140.pillStacks=[];
 g.bank.jianghu.ledgerV140.pillStacks=[{id:'single-dose',recipeId:'PROBE_REMEDY',nameTh:'Single dose',count:1,effect:{healHealth:20,toxicity:4}}];
 const r=grant(g,n,'PILL','single-dose'),p=n.jianghu.ledgerV140.pillStacks[0];
 const afterGrant={health:n.health,storedDoses:p?.count||0,toxicity:n.jianghu.pillToxicity};
 const consumed=E.consumePillFromLedgerV150(g.world,n.id,p.id);
 const afterConsumption={health:n.health,storedDoses:n.jianghu.ledgerV140.pillStacks.reduce((s,x)=>s+x.count,0),toxicity:n.jianghu.pillToxicity};
 return {expected:'Either transfer an unconsumed pill or consume it once through the canonical effect/toxicity pipeline',invariant:n.health<=30,afterGrant,afterConsumption,result:r.ok,consumed:consumed.ok};
});
probe('pill_full_inventory_is_lost_by_canonical_cap_enforcement',g=>{
 const n=g.heroes[0],l=n.jianghu.ledgerV140,cap=E.PATCH140_CAPS.pillStacks;
 l.pillStacks=Array.from({length:cap},(_,i)=>({id:'held-pill-'+i,recipeId:'held-recipe-'+i,nameTh:'Held '+i,count:1,effect:{}}));
 g.bank.jianghu.ledgerV140.pillStacks=[{id:'unique-pill',recipeId:'unique-recipe',nameTh:'Unique pill',count:1,effect:{}}];
 const r=grant(g,n,'PILL','unique-pill'),immediateSlots=l.pillStacks.length;
 E.enforceCapsV140(g.world,true);
 const recipientHas=l.pillStacks.some(p=>p.recipeId==='unique-recipe'),bankHas=g.bank.jianghu.ledgerV140.pillStacks.some(p=>p.recipeId==='unique-recipe');
 return {expected:'Reject or defer when no pill stack can be added or safely merged',invariant:recipientHas||bankHas,cap,immediateSlots,afterSlots:l.pillStacks.length,recipientHas,bankHas,result:r.ok};
});
probe('scroll_grant_duplicates_a_private_loan_and_unlocks_knowledge',g=>{
 const n=g.heroes[0],owner=g.heroes[1],a=artFor(g,n);n.jianghu.ledgerV140.scrolls=[];
 const original={id:'unique-private-loan',artId:a.id,nameTh:a.nameTh,tier:a.tier,count:1,ownerNpcId:owner.id,rights:'LOAN',canRedistribute:false,access:'PRIVATE',loan:{ownerNpcId:owner.id,borrowerNpcId:g.bank.id,sessionId:'probe-loan'}};
 g.bank.jianghu.ledgerV140.scrolls=[original];g.s.growth.bookLoans.push({bookId:original.id,ownerNpcId:owner.id,borrowerNpcId:g.bank.id,sessionId:'probe-loan',status:'ACTIVE',dueAt:1000});
 const r=grant(g,n,'SCROLL',a.id),received=n.jianghu.ledgerV140.scrolls.find(s=>s.artId===a.id);
 return {expected:'Enforce owner/loan/redistribution rights and move a permitted physical item without admin fabrication or automatic mastery',invariant:!received&&g.bank.jianghu.ledgerV140.scrolls[0]===original,original,received,knowledge:n.jianghu.knowledgeV190[a.id],physicalCopies:g.bank.jianghu.ledgerV140.scrolls.filter(s=>s.artId===a.id).length+n.jianghu.ledgerV140.scrolls.filter(s=>s.artId===a.id).length,result:r.ok};
});
probe('scroll_request_needs_no_stock_and_can_invent_unknown_knowledge',g=>{
 const n=g.heroes[0],a=artFor(g,n);n.jianghu.ledgerV140.scrolls=[];
 const valid=grant(g,n,'SCROLL',a.id),invalid=grant(g,n,'SCROLL','ART_DOES_NOT_EXIST_PROBE');
 return {expected:'Reject absent physical sources and art IDs absent from the real catalog',invariant:!valid.ok&&!invalid.ok&&!(n.jianghu.knowledgeV190.ART_DOES_NOT_EXIST_PROBE),bankScrolls:g.bank.jianghu.ledgerV140.scrolls.length,validResult:valid.ok,invalidResult:invalid.ok,validKnowledge:n.jianghu.knowledgeV190[a.id],invalidKnowledge:n.jianghu.knowledgeV190.ART_DOES_NOT_EXIST_PROBE};
});
probe('scroll_full_bag_is_reported_successful_and_still_teaches',g=>{
 const n=g.heroes[0],a=artFor(g,n);n.jianghu.ledgerV140.scrolls=Array.from({length:24},(_,i)=>({id:'held-scroll-'+i,artId:'held-art-'+i,count:1}));
 g.bank.jianghu.ledgerV140.scrolls=[{id:'bank-real-scroll',artId:a.id,nameTh:a.nameTh,count:1,ownerNpcId:g.bank.id,rights:'OWNER'}];
 const r=grant(g,n,'SCROLL',a.id);
 return {expected:'If physical receipt fails, leave the source and knowledge unchanged and report failure',invariant:!r.ok&&!n.jianghu.knowledgeV190[a.id],result:r.ok,recipientScrolls:n.jianghu.ledgerV140.scrolls.length,hasPhysicalSource:n.jianghu.ledgerV140.scrolls.some(s=>s.artId===a.id),knowledge:n.jianghu.knowledgeV190[a.id],bankStillHas:g.bank.jianghu.ledgerV140.scrolls[0].id};
});
probe('enemy_can_become_treasury_elder_and_receive_sect_property',g=>{
 const outsider=g.enemies[0];assert(outsider);outsider.alive=true;outsider.health=100;
 const isMember=!!g.life.member(outsider),isHero=g.s.heroIds.includes(outsider.id),id='sect-property';g.bank.jianghu.ledgerV140.equipmentItems=[equipment(id)];
 const appointed=g.storyEvents.setTreasuryAuthority('APPOINTED_ELDER',outsider.id),r=grant(g,outsider,'EQUIPMENT',id);
 return {expected:'Only current living eligible members can administer or requisition sect property',invariant:!appointed.ok&&!r.ok,isMember,isHero,enemy:!!outsider.stageLocal.enemy,appointed:appointed.ok,recordedSteward:g.s.life.offices.steward?.npcId,recipientHas:outsider.jianghu.ledgerV140.equipmentItems.some(i=>i.id===id),result:r.ok};
});
probe('offmap_hero_submits_and_receives_physical_items',g=>{
 const n=g.heroes[0],id='offmap-eq';n.stageLocal.offmap={journeyId:'physically-away'};n.jianghu.ledgerV140.equipmentItems=[];g.bank.jianghu.ledgerV140.equipmentItems=[equipment(id,{tier:7})];
 g.storyEvents.refreshDiscipleRequisitions();const req=g.s.storyEvents.treasury.requisitions.find(r=>r.requesterId===n.id&&r.itemId===id);assert(req,'Off-map request unexpectedly filtered');
 const r=g.storyEvents.judgeRequisition(req.id,true);
 return {expected:'Defer physical handoff while the recipient is away; retain stock and request',invariant:!r.ok&&!n.jianghu.ledgerV140.equipmentItems.some(i=>i.id===id),offmap:n.stageLocal.offmap,autoGenerated:true,result:r.ok,received:n.jianghu.ledgerV140.equipmentItems.some(i=>i.id===id)};
});
probe('dead_requester_is_correctly_rejected',g=>{
 const n=g.heroes[0],id='dead-eq';g.bank.jianghu.ledgerV140.equipmentItems=[equipment(id)];const req=request(g,n,'EQUIPMENT',id);n.health=0;n.alive=false;
 const r=g.storyEvents.judgeRequisition(req.id,true);
 return {expected:'A dead NPC cannot receive a grant',invariant:!r.ok&&g.bank.jianghu.ledgerV140.equipmentItems.some(i=>i.id===id),result:r.ok};
});
probe('proactive_grant_overrides_its_own_personality_rejection',g=>{
 const master=g.heroes[0];g.s.life.offices.master={npcId:master.id};
 Object.assign(master.personality,{integrity:100,discipline:0,empathy:0,ambition:0,caution:100,courage:0,rationality:0,trustfulness:0});master.core.values.wealthResource=100;
 for(const n of g.heroes){n.health=100;g.life.member(n).merit=0;n.jianghu.internalInjury=0;}
 assert(g.add(g.bank,herb,5,'PROBE').ok);g.storyEvents.setTreasuryAuthority('MASTER_DIRECT');
 const before=fingerprint(g),r=g.storyEvents.proactiveDistributeFromTreasury();
 return {expected:'Honor the selected distributor approval threshold during proactive distribution',invariant:!r.ok||r.logEntry.score>=r.logEntry.threshold,result:r.ok,score:r.logEntry?.score,threshold:r.logEntry?.threshold,verdict:r.logEntry?.verdictType,reason:r.logEntry?.reasonTh,humanFoundationPreservedAfterFixtureSetup:JSON.stringify(before)===JSON.stringify(fingerprint(g))};
});

const report={release:'uploaded-treasury-v2.04-audit',createdAt:new Date().toISOString(),checks,setupErrors:checks.filter(c=>c.setupError).length,violatedSafetyInvariants:checks.filter(c=>c.invariant===false).length,notes:['No production files or existing tests modified.','Human Foundation hashes exclude dynamic condition and experience. The final hoarder fixture intentionally changes existing canonical traits before testing; its second hash confirms the operation preserves them.']};
fs.writeFileSync(path.join(__dirname,'../evidence/treasury-probes-v202.json'),JSON.stringify(report,null,2));
for(const c of checks)console.log(c.setupError?'SETUP_ERROR':c.invariant?'INVARIANT_OK':'REPRODUCED',c.id,c.setupError||'');
console.log(JSON.stringify({probes:checks.length,setupErrors:report.setupErrors,violatedSafetyInvariants:report.violatedSafetyInvariants}));
if(report.setupErrors)process.exitCode=1;
