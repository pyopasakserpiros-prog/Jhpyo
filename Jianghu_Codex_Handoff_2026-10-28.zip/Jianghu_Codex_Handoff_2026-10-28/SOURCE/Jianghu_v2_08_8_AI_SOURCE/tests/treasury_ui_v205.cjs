/* Execute the actual UI startup and controls with offscreen Canvas + a minimal DOM (v1.17). */
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const C=require('./canvas-shim.cjs');
const root=path.resolve(__dirname,'..');require('./inspect-engine.cjs');
let lastMarkup="";
class El{
 set innerHTML(v){this._html=String(v);lastMarkup=this._html;}get innerHTML(){return this._html||"";}
 constructor(id=''){this.id=id;this.hidden=false;this.style={};this.dataset={};this.childNodes=[];this.attributes=[];this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this.listeners={};this.scrollTop=0;this.textContent='';this.value='';this.tagName='DIV';}
 setAttribute(k,v){const old=this.attributes.find(a=>a.name===k);if(old)old.value=String(v);else this.attributes.push({name:k,value:String(v)});}
 getAttribute(k){return this.attributes.find(a=>a.name===k)?.value??null;}
 hasAttribute(k){return this.getAttribute(k)!==null;}
 removeAttribute(k){this.attributes=this.attributes.filter(a=>a.name!==k);}
 addEventListener(k,v){(this.listeners[k]||=[]).push(v);}
 getBoundingClientRect(){return {width:430,height:720,left:0,top:0};}
 querySelectorAll(){return[];}querySelector(){return null;}closest(){return null;}
 appendChild(v){this.childNodes.push(v);}removeChild(v){this.childNodes=this.childNodes.filter(x=>x!==v);}get lastChild(){return this.childNodes.at(-1);}
 setPointerCapture(){}click(){this.onclick?.({target:this});}
}
const html=fs.readFileSync(path.join(root,'source/index.html'),'utf8'),els=new Map();for(const m of html.matchAll(/\bid="([^"]+)"/g))els.set('#'+m[1],new El(m[1]));
for(const key of ['#map','#minimap']){const cv=C.createCanvas(key==='#map'?430:156,key==='#map'?720:117),el=els.get(key);for(const k of ['addEventListener','getBoundingClientRect','setPointerCapture'])cv[k]=el[k].bind(el);cv.style={};els.set(key,cv);}
els.set('.ruler i',new El());els.set('#loading p',new El());
const docEvents={};
global.document={hidden:false,querySelector(s){assert(els.has(s),'Unknown startup DOM selector '+s);return els.get(s);},querySelectorAll(){return[];},addEventListener(k,v){(docEvents[k]||=[]).push(v);},createElement(tag){return tag==='canvas'?C.createCanvas(1,1):new El();}};
const stored=new Map();global.localStorage={getItem(k){return stored.get(k)||null;},setItem(k,v){stored.set(k,v);}};
global.window=global;window.addEventListener=()=>{};global.devicePixelRatio=1;global.location={search:'?fresh=1&qa=1'};global.Image=C.Image;global.matchMedia=()=>({matches:false});
const frames=[];global.requestAnimationFrame=fn=>{frames.push(fn);return frames.length;};
global.LivingArtAssets=JSON.parse(fs.readFileSync(path.join(root,'assets/art-manifest.json'),'utf8'));for(const [k,v] of Object.entries(LivingArtAssets.images))LivingArtAssets.images[k]='data:image/webp;base64,'+fs.readFileSync(path.resolve(root,'source',v)).toString('base64');
require('../source/scripts/living-art.js');
vm.runInThisContext(fs.readFileSync(path.join(root,'source/scripts/ui.js'),'utf8'),{filename:'ui.js'});
(async()=>{
 const start=Date.now();while(!global.JIANGHU&&Date.now()-start<30000)await new Promise(r=>setTimeout(r,100));assert(JIANGHU);const g=JIANGHU.game;g.storyEvents.activate();g.s.life.offices.master={npcId:g.heroes[0].id};g.s.storyEvents.treasury.elderNpcId=g.heroes[1].id;
 g.bank.jianghu.ledgerV140.equipmentItems=[{id:'rare-form-item',nameTh:'Rare sword',slot:'WEAPON',tier:4,quality:'PERFECT',durability:100}];g.bank.jianghu.ledgerV140.pillStacks=[{id:'ordinary-form-pill',nameTh:'Daily remedy',recipeId:'basic',count:3,tier:1,quality:'COMMON',effect:{healHealth:20}}];
 JIANGHU.open('objectives');const b=new El();b.dataset.questTab='treasury';b.closest=()=>b;for(const h of docEvents.click)await h({target:b});let form=lastMarkup.split('➕ ยื่นคำร้องต่อผู้ดูแลคลัง')[1].split('</article>')[0];assert(form.includes('ordinary-form-pill'));assert(!form.includes('rare-form-item'),'Welfare selector must not offer precious equipment');assert(form.includes('ขอรับแจกของใช้พื้นฐาน'));assert(form.includes('ใช้แต้มคุณูปการแลกของ'));assert(form.includes(g.heroes[0].name)&&form.includes(g.heroes[1].name));
 const select=new El('reqMethodSelect');select.value='REDEEM';for(const h of docEvents.change)await h({target:select});form=lastMarkup.split('➕ ยื่นคำร้องต่อผู้ดูแลคลัง')[1].split('</article>')[0];assert(form.includes('rare-form-item'),'Redemption selector exposes reserved valuables');assert(form.includes('แต้ม'));fs.writeFileSync('evidence/treasury-ui-v205.json',JSON.stringify({pass:true,backend:'actual UI handlers with native offscreen Canvas',checks:['two routes displayed','welfare filters reserved goods','redemption lists valuables and prices','master and elder options']}));console.log('TREASURY_UI_PASS');
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
