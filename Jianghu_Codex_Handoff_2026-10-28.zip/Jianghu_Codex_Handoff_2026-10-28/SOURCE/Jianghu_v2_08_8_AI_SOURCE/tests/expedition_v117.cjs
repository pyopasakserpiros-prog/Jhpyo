require('./inspect-engine.cjs');
const F=global.Frontier,Realm=global.LivingJianghuSystem;
function assert(c,m){if(!c)throw new Error(m)}
const g=new F(4418);g.establish();
const hero=g.heroes[0];
const def=Realm.SITES.find(s=>s.scroll);assert(def,'expedition site with scroll exists');
const site=g.s.realm.sites.find(s=>s.id===def.id);assert(site&&site.remaining>0,'site has remaining discovery stock');
const journey={id:'journey-real-test',npcId:hero.id,siteId:def.id,createdAt:g.s.t,phase:'away',resolved:false,outcome:null,loot:[],returnAt:g.s.t};
g.s.realm.journeys.unshift(journey);hero.stageLocal.journey=journey.id;hero.stageLocal.offmap={kind:'realmJourney',journeyId:journey.id};hero.stageLocal.mode='offmap';hero.currentCityId=null;
const next=g.rng.next.bind(g.rng),int=g.rng.int.bind(g.rng);g.rng.next=()=>0.999999;g.rng.int=(a,b)=>a;
const handled=g.realm.handleOffmap(hero);g.rng.next=next;g.rng.int=int;
assert(handled,'off-map journey handled');assert(journey.resolved&&journey.outcome==='success','journey resolves successfully in deterministic test');assert(journey.scroll?.itemId&&journey.scroll.artId,'actual scroll returned from expedition');assert(hero.jianghu.ledgerV140.scrolls.some(s=>s.id===journey.scroll.itemId),'scroll is physically in the returning NPC inventory');assert(journey.phase==='returning'&&hero.stageLocal.action==='returnExpedition','NPC is sent through the return leg');
hero.stageLocal.x=Realm.MARKET.x;hero.stageLocal.y=Realm.MARKET.y;hero.stageLocal.target={x:Realm.MARKET.x,y:Realm.MARKET.y};hero.stageLocal.mode='working';hero.stageLocal.job=0;hero.stageLocal.journey=journey.id;
const returned=g.realm.finish(hero,'returnExpedition');assert(returned?.success&&journey.phase==='complete','return leg completes at market');assert(g.s.realm.receipts.some(r=>r.kind==='journeyOutcome'&&r.scroll?.itemId===journey.scroll.itemId),'journey receipt includes scroll provenance');
console.log('EXPEDITION_RETURN_V117_PASS',{hero:hero.name,site:def.name,scroll:journey.scroll.nameTh,artId:journey.scroll.artId,phase:journey.phase,outcome:journey.outcome,inventoryHasScroll:true});
