'use strict';require('./inspect-engine.cjs');const fs=require('fs'),assert=require('assert'),C=JianghuSectContributions;
const results=[];const totals={};
for(const seed of [2071,2072,2073,2074]){
 const g=new Frontier(seed);g.establish();g.money(4000,'SIMULATION_STARTING_INFRASTRUCTURE');g.s.wood=700;g.add(g.bank,FrontierData.ORE,120,'SIMULATION_STARTING_INFRASTRUCTURE');
 for(const [type,x,y] of [['alchemy',600,960],['forge',950,960],['market',1330,960]]){const r=g.place(type,x,y);assert(r.ok,r.reason);r.building.remaining=0;}
 while(g.heroes.length<4)assert(g.recruit().ok);
 if(seed===2074){const school=g.place('shrine',600,1600);assert(school.ok,school.reason);school.building.remaining=0;}
 const st=g.storyEvents.activate();st.autoEvents=false;st.autoNpcBranchDecision=false;st.epPhase='ALL_COMPLETED';g.s.raidAt=1e9;
 for(const n of [...g.enemies,...g.s.beasts]){n.alive=false;n.health=0;}for(const h of g.s.ecology.habitats)h.nextSpawnAt=1e9;
 const fingerprints=g.heroes.map(n=>HumanCore.fingerprint(n));const seen=new Set(),events={};
 for(let day=0;day<40;day++){
  g.advance(20);
  for(const row of C.inspect(g).history)if(!seen.has(row.id)){seen.add(row.id);events[row.kind]=(events[row.kind]||0)+1;totals[row.kind]=(totals[row.kind]||0)+1;}
  const audit=C.inspect(g).pointEconomy;assert.equal(audit.issued-audit.retired,audit.circulating);
  for(const a of Object.values(g.s.storyEvents.treasury.contributions.accounts))assert(a.balance>=0);
  assert(g.gold>=0);for(const l of [g.bank,...g.heroes].map(n=>n.jianghu.ledgerV140))for(const x of [...l.materialStacks,...l.pillStacks]){assert(x.count>=0);if(x.storeCount!==undefined)assert(x.storeCount<=x.count);}
 }
 for(let i=0;i<fingerprints.length;i++)assert.equal(HumanCore.fingerprint(g.heroes[i]),fingerprints[i]);
 const h=Frontier.load(g.serialize());
 function differences(a,b,path='',out=[]){if(out.length>=12)return out;if(typeof a!==typeof b||a===null||b===null){if(a!==b)out.push({path,a,b});return out;}if(typeof a!=='object'){if(a!==b)out.push({path,a,b});return out;}for(const key of new Set([...Object.keys(a),...Object.keys(b)]))differences(a[key],b[key],path+'.'+key,out);return out;}
 const beforeDiff=differences(JSON.parse(g.serialize()),JSON.parse(h.serialize()));g.advance(20);h.advance(20);const afterDiff=differences(JSON.parse(g.serialize()),JSON.parse(h.serialize()));if(afterDiff.length){console.log(JSON.stringify({seed,events,beforeDiff,afterDiff}));throw Error('save continuation differs');}
 results.push({seed,days:40,events,gold:g.gold,points:C.inspect(g).pointEconomy,storeItems:C.storeInventory(g).all.length});
 if(seed===2074){assert(events.LIBRARY_ENROLL>0,'With a library NPCs must autonomously pay enrollment fees');assert(g.s.growth.receipts.some(r=>r.kind==='readLibraryScripture'),'Paid learners must perform native reading');}
 console.log(JSON.stringify(results.at(-1)));
}
assert(totals.DONATE>0,'NPCs must donate without directing their actions');assert(totals.SHOP_BUY>0,'NPCs must buy desired goods without directing their actions');assert(totals.SECT_CRAFT>0,'NPCs must produce for the sect without directing their actions');
fs.writeFileSync('evidence/economy-simulation-v207.json',JSON.stringify({pass:true,results,totals},null,2));console.log('AUTONOMOUS_ECONOMY_PASS');
