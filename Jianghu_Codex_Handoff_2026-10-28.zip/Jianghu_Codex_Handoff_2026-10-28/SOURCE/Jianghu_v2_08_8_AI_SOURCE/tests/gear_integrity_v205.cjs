'use strict';require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),g=Frontier.load(fs.readFileSync('evidence/qa-fixture-v201.json','utf8')),n=g.heroes[0];
const item={id:'post-injury-armor',slot:'ARMOR',nameTh:'Test armor',tier:3,minStageReq:3,compatiblePath:'ANY',durability:100};
World2026Engine.syncNpcCultivationIdentityV1200(g.world,n,{path:'BODY',subPath:'TIGER_BODY',trackOrdinal:2,progress:95});
// The precise branch name is inherited from the fixture; verify the premise.
if(n.jianghu.realizationBand<3)World2026Engine.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:3,progress:0});
n.jianghu.ledgerV140.equipmentItems.push(item);assert(g.progression.canEquipItem(n,item).ok);n.jianghu.equipmentV140.ARMOR=item.id;
World2026Engine.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:1,progress:0});assert(!g.progression.canEquipItem(n,item).ok);g.advance(.1);
assert.notEqual(n.jianghu.equipmentV140.ARMOR,item.id,'Equipment that lost its required cultivation band must be unequipped in a normal simulation tick');
assert(n.jianghu.ledgerV140.equipmentItems.includes(item),'An unusable item stays in its owner inventory');
fs.writeFileSync('evidence/gear-integrity-v205.json',JSON.stringify({pass:true,checks:['cultivation regression removes ineligible loadout','item custody retained']}));console.log('GEAR_INTEGRITY_PASS');
