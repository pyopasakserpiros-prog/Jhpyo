/* Complete release checks, including the inherited simulation/content suites. */
'use strict';
const {spawnSync}=require('child_process'),path=require('path'),fs=require('fs');
const root=path.resolve(__dirname,'..');
const checks=[
 ['stats','tests/combat_stats_v201.cjs'],['resolver','tests/combat_overhaul_v201.cjs'],['visuals','tests/combat_visuals_v201.cjs'],['retreat','tests/retreat_v201.cjs'],['world_links','tests/world_links_v201.cjs'],['status_links','tests/combat_status_v201.cjs'],['final_regressions','tests/final_regressions_v201.cjs'],['merge_ecology','tests/merge_ecology_v201.cjs'],['merge_npc','tests/merge_npc_v201.cjs'],
 ...['audit','flows','expedition','combat','combat_integration','simulation','world','balance','ui','render'].map(s=>[s,'tests/'+s+'_v117.cjs']),
 ['cultivation_quests','tests/cultivation_quests_v202.cjs'],['quest_combat','tests/quest_combat_v202.cjs'],['treasury','tests/treasury_v202.cjs'],['story_events','tests/story_events_v205.cjs'],['story_content','tests/story_content_v205.cjs'],['sidequests','tests/sidequests_v202.cjs'],['contributions','tests/contributions_v205.cjs'],['episode_runtime','tests/ep4_runtime_v205.cjs'],['gear_integrity','tests/gear_integrity_v205.cjs'],['runtime_ui','tests/runtime_ui_v205.cjs'],['review_regressions','tests/review_regressions_v205.cjs'],['treasury_routes','tests/treasury_routes_v205.cjs'],['treasury_ui','tests/treasury_ui_v205.cjs'],['sect_store_ecosystem','tests/sect_store_ecosystem_v206.cjs'],['living_quests','tests/living_quests_v205.cjs'],
 ['myriad_worlds','tests/myriad_worlds_v200.cjs'],['build','tools/build.py'],['verify_build','tests/verify_build_v205.cjs']
];
const results=[];
for(const [name,file] of checks){
 const start=Date.now(),r=spawnSync(file.endsWith('.py')?'python3':process.execPath,[file],{cwd:root,encoding:'utf8',maxBuffer:12*1024*1024});
 const log='evidence/v205-'+name+'.log';fs.writeFileSync(path.join(root,log),(r.stdout||'')+(r.stderr||''));
 results.push({name,pass:r.status===0,exitCode:r.status,seconds:+((Date.now()-start)/1000).toFixed(2),log});
 fs.writeFileSync(path.join(root,'evidence/suite-v205.json'),JSON.stringify({release:'2.05-quests-treasury',completedAt:new Date().toISOString(),pass:results.every(x=>x.pass),completed:results.length,expected:checks.length,results},null,2));
 console.log(name+': '+(r.status===0?'PASS':'FAIL')+' ('+results.at(-1).seconds+'s)');
 if(r.status!==0){console.error(((r.stdout||'')+(r.stderr||'')).slice(-5000));process.exit(r.status||1);}
}
console.log('ALL_V205_CHECKS_PASS');
