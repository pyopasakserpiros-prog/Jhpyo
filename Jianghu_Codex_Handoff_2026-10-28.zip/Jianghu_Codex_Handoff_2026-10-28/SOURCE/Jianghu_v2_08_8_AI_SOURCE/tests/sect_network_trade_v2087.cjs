'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs');
const E=World2026Engine,C=JianghuSectContributions,results=[];
const ORE='MAT_ORE_BLACK_IRON_1',HERB='MAT_HERB_DEW_GRASS_1',CIN='MAT_ORE_CINNABAR_1',JADE='MAT_HERB_JADE_LOTUS_2',MIST='MAT_HERB_MIST_ORCHID_2',CINDER='MAT_HERB_CINDER_LEAF_1',BLOOD='MAT_HERB_BLOOD_GINSENG_3',NETWORK_MATS=[ORE,HERB,CIN,JADE,MIST,CINDER,BLOOD];
const seed=new Frontier(20871028);seed.establish();const raw=seed.serialize();
function game(){const g=Frontier.load(raw);g.s.t=100;for(const n of [...g.enemies,...g.s.beasts]){n.alive=false;n.health=0;}return g;}
function faction(g,id){return g.s.realm.factions.find(f=>f.id===id);}
function count(g,o,id){return g.count(o,id);}
function stones(o){return E.getSpiritStonesV140(o);}
function setStones(o,n){E.setSpiritStonesV140(o,n);}
function resetMaterial(g,f,id,qty){f.cache.jianghu.ledgerV140.materialStacks=f.cache.jianghu.ledgerV140.materialStacks.filter(x=>x.matId!==id);if(qty>0){const r=g.add(f.cache,id,qty,'NETWORK_TEST_STOCK');assert(r.ok,r.reason);}}
function isolateJadeMarket(g,sellerId='CN',sellerQty=5){for(const f of g.s.realm.factions)for(const id of NETWORK_MATS)resetMaterial(g,f,id,id===JADE&&f.id===sellerId?sellerQty:0);}
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}

test('external sects autonomously exchange real materials for spirit stones without touching the main sect',()=>{
 const g=game(),seller=faction(g,'CN'),beforeBank=stones(g.bank),beforeBankStock=count(g,g.bank,JADE),merit=C.account(g,g.heroes[0]).balance;isolateJadeMarket(g);const beforeTotal=g.s.realm.factions.reduce((n,f)=>n+stones(f.cache),0),beforeSeller=stones(seller.cache),beforeQty=count(g,seller.cache,JADE);
 const trades=g.realm.processSectNetworkTrade(6);assert(Array.isArray(trades));assert(trades.length>0,'market should find a buyer for a surplus specialty material');
 const row=g.s.realm.sectTrade.networkHistory[0],buyer=faction(g,row.buyerId);assert.equal(row.sellerId,seller.id);assert(buyer&&buyer.id!==seller.id);assert.equal(row.matId,JADE);assert.equal(row.quantity,1);assert.equal(row.currency,'SPIRIT_STONES');assert.equal(count(g,seller.cache,JADE),beforeQty-trades.length);assert.equal(count(g,buyer.cache,JADE),1);const sellerRevenue=trades.filter(x=>x.sellerId===seller.id).reduce((n,x)=>n+x.totalStones,0);assert.equal(stones(seller.cache),beforeSeller+sellerRevenue);assert.equal(g.s.realm.factions.reduce((n,f)=>n+stones(f.cache),0),beforeTotal,'network settlement must transfer, not mint, stones');assert.equal(stones(g.bank),beforeBank);assert.equal(count(g,g.bank,JADE),beforeBankStock);assert.equal(C.account(g,g.heroes[0]).balance,merit);
});

test('network prices rise with buyer shortage and ease when seller has more surplus',()=>{
 const g=game(),seller=faction(g,'CN'),buyer=faction(g,'SG');const scarce=g.realm.sectNetworkPrice(seller,buyer,JADE,3,0),surplus=g.realm.sectNetworkPrice(seller,buyer,JADE,6,1);assert(scarce>surplus);assert(scarce>0&&surplus>0);
});

test('a network day is idempotent and the daily trade limit is enforced',()=>{
 const g=game();isolateJadeMarket(g);const first=g.realm.processSectNetworkTrade(9),again=g.realm.processSectNetworkTrade(9);assert(first.length>0);assert.deepEqual(again,[]);assert(g.s.realm.sectTrade.networkHistory.length<=3);assert(g.s.realm.sectTrade.networkStats.totalTrades>=first.length);
});

test('daily production, consumption, and network trade run only once per day',()=>{
 const g=game();isolateJadeMarket(g);const state=g.s.realm.sectTrade;state.lastMarketDay=5;state.networkLastDay=5;const first=g.realm.tickSectMarketDay(6),after=JSON.stringify({stones:g.s.realm.factions.map(f=>stones(f.cache)),stocks:g.s.realm.factions.map(f=>NETWORK_MATS.map(id=>count(g,f.cache,id))),history:state.networkHistory,stats:state.networkStats});assert(first.length>0);const second=g.realm.tickSectMarketDay(6),afterAgain=JSON.stringify({stones:g.s.realm.factions.map(f=>stones(f.cache)),stocks:g.s.realm.factions.map(f=>NETWORK_MATS.map(id=>count(g,f.cache,id))),history:state.networkHistory,stats:state.networkStats});assert.deepEqual(second,[]);assert.equal(afterAgain,after);
});

test('insufficient buyer funds and a capped seller wallet do not cause partial settlement',()=>{
 const g=game();isolateJadeMarket(g);for(const f of g.s.realm.factions)setStones(f.cache,0);setStones(faction(g,'CN').cache,200);const stock=count(g,faction(g,'CN').cache,JADE);assert.deepEqual(g.realm.processSectNetworkTrade(7),[]);assert.equal(count(g,faction(g,'CN').cache,JADE),stock);for(const f of g.s.realm.factions)setStones(f.cache,100);setStones(faction(g,'CN').cache,g.s.realm.sectTrade.walletCap);assert.deepEqual(g.realm.processSectNetworkTrade(8),[]);assert.equal(count(g,faction(g,'CN').cache,JADE),stock);
});

test('network trades respect destination capacity and seller reserve',()=>{
 const g=game(),seller=faction(g,'CN');isolateJadeMarket(g);for(const f of g.s.realm.factions)setStones(f.cache,0);setStones(seller.cache,100);setStones(faction(g,'SG').cache,200);const materials=E.PATCH140_DATA.MATERIALS_REGISTRY_V140.filter(x=>!x.isTranscendent&&x.id!==JADE).slice(0,E.PATCH140_CAPS?.materialStacks||24);const buyer=faction(g,'SG');buyer.cache.jianghu.ledgerV140.materialStacks=[];for(let i=0;i<materials.length;i++){const d=materials[i];buyer.cache.jianghu.ledgerV140.materialStacks.push({id:'network-cap-'+i,matId:d.id,count:1,quality:'STANDARD',ownerNpcId:buyer.cache.id,ownerId:buyer.cache.id,originId:'NETWORK_CAPACITY'});}const before=count(g,seller.cache,JADE);const trades=g.realm.processSectNetworkTrade(11);assert(!trades.some(x=>x.buyerId===buyer.id&&x.matId===JADE),'full cache must reject a network transfer');assert.equal(count(g,seller.cache,JADE),before);resetMaterial(g,seller,JADE,1);assert.deepEqual(g.realm.processSectNetworkTrade(12),[],'seller must keep its minimum specialty reserve');
});

test('network cursor, balances, stock, and bounded history survive same-version save/load',()=>{
 const g=game();isolateJadeMarket(g);isolateJadeMarket(g,'CN',7);const first=g.realm.processSectNetworkTrade(6);assert(first.length>0);const h=Frontier.load(g.serialize());assert.deepEqual(h.s.realm.sectTrade.networkHistory,g.s.realm.sectTrade.networkHistory);assert.deepEqual(h.s.realm.sectTrade.networkStats,g.s.realm.sectTrade.networkStats);assert.equal(h.s.realm.sectTrade.networkCursor,g.s.realm.sectTrade.networkCursor);assert.deepEqual(h.realm.processSectNetworkTrade(6),[]);const a=g.realm.processSectNetworkTrade(7),b=h.realm.processSectNetworkTrade(7);assert.deepEqual(a,b);assert.deepEqual(h.s.realm.sectTrade.networkHistory,g.s.realm.sectTrade.networkHistory);assert.equal(h.s.realm.sectTrade.networkHistory.length<=60,true);
});

test('diplomacy UI shows live autonomous external-sect market history',()=>{
 const g=game();isolateJadeMarket(g);g.realm.processSectNetworkTrade(6);const html=JianghuRealmView.render(g,'diplomacy');assert(html.includes('เครือข่ายการค้าระหว่างสำนักต่างแดน'));assert(html.includes('หินวิญญาณ'));assert(html.includes('data-network-trade-history'));
});

fs.writeFileSync('evidence/sect-network-trade-v2087.json',JSON.stringify({release:'2.08.7-autonomous-sect-network-market',pass:results.every(r=>r.pass),cases:results.length,results},null,2));
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
process.exit(results.some(r=>!r.pass)?1:0);
