/* Read-only combat projection and the real Living Ink floating-feedback boundary. */
'use strict';
const assert=require('assert'),fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');
require('./inspect-engine.cjs');
// The integration loader may not yet include the new derived-stat script.
if(!global.CombatStats201&&fs.existsSync(path.join(root,'source/scripts/combat-stats.js')))
 vm.runInThisContext(fs.readFileSync(path.join(root,'source/scripts/combat-stats.js'),'utf8'),{filename:'combat-stats.js'});
vm.runInThisContext(fs.readFileSync(path.join(root,'source/scripts/combat-view.js'),'utf8'),{filename:'combat-view.js'});
const results=[];
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function statsFixture(){return {maxHP:1200,physicalAttack:160,artAttack:140,armor:80,resistance:70,accuracy:115,evasion:30,critChance:.125,critMultiplier:1.75,attackSpeed:1.5,moveSpeed:3.75,penetration:12,controlResist:.25,maxQi:80,qiRegen:3.5,base:{maxHP:1000,physicalAttack:100,artAttack:100,armor:50,resistance:50,accuracy:100,evasion:20,critChance:.05,critMultiplier:1.5,attackSpeed:1,moveSpeed:3,penetration:0,controlResist:0,maxQi:60,qiRegen:2},sources:[{stat:'physicalAttack',source:'body',label:'กำลังกายพื้นฐาน',value:100},{stat:'physicalAttack',source:'equipment',label:'อาวุธกระบี่หยก',value:60},{stat:'attackSpeed',source:'condition',label:'ความเหนื่อยล้า',value:-.2}],meta:{}};}
function fixture(entity={id:'npc',name:'ผู้ฝึก <ทดสอบ>',health:50,core:{},jianghu:{},stageLocal:{combatState:{qi:0}}}){const sheet=statsFixture();return {entity,sheet,g:{s:{t:1,beasts:[],realm:{pets:[]}},world:{npcs:{}},combatSystem:{stats(){return sheet;},maxHealth(){return 100;}}}};}
test('stats show derived NPC HP, unambiguous base/current columns, rates, percentages, and Thai sources',()=>{
 const {g,entity}=fixture(),html=CombatView117.stats(g,entity);
 assert(html.includes('600 / 1,200'),'NPC condition was displayed as combat HP');
 assert(html.includes('ค่าพื้นฐาน')&&html.includes('ค่าปัจจุบัน'),'base/current values are indistinguishable');
 for(const text of ['1,000','12.5%','1.75','1.5','3.75','ครั้ง/วินาที','ม./วินาที','กำลังกายพื้นฐาน','อาวุธกระบี่หยก','ความเหนื่อยล้า','ที่มาของค่า','สภาพร่างกาย'])assert(html.includes(text),'missing visible stat explanation: '+text);
 assert(!html.includes('<ทดสอบ>'),'entity name is unescaped');
 assert(html.includes('0 / 80'),'zero Qi was replaced by a default');
});
test('beasts and companions display their native health ledger without the NPC condition conversion',()=>{
 for(const entity of [{id:'beast',name:'หมาป่า',health:210,maxHP:300,tier:2,x:30,y:40},{id:'pet',name:'คู่หู',health:0,maxHP:300,ownerId:'npc',stageLocal:{pet:true,x:40,y:50}}]){
  const {g,sheet}=fixture(entity);sheet.maxHP=300;
  const html=CombatView117.stats(g,entity);
  assert(html.includes(entity.health+' / 300'),'native beast/pet HP incorrectly converted');
  assert(!html.includes('NaN')&&!html.includes('Infinity'),'nonfinite panel output');
 }
});
test('repeated actual NPC/beast/pet sheets and retained dossiers preserve every serialized state and RNG byte',()=>{
 const g=Frontier.load(fs.readFileSync(path.join(root,'evidence/qa-fixture-v201.json'),'utf8'));
 const before=g.serialize();
 for(let i=0;i<3;i++){
  for(const n of [g.heroes[0],g.s.beasts[0],g.s.realm.pets[0]])assert(CombatView117.stats(g,n).length>200);
  CombatView117.render(g,g.heroes[0]);CombatView117.guide(g);
 }
 assert.equal(g.serialize(),before,'inspection changed simulation, resources, loadouts, or RNG');
 assert(CombatView117.guide(g).includes('ความจุ'),'41-route guide was lost');
});

// No atlas or terrain is needed to exercise the actual feedback draw method.
global.LivingArtAssets={images:{pending:'pending'}};
global.Image=class {set src(_){} };global.localStorage={getItem(){return null;},setItem(){}};
global.matchMedia=()=>({matches:false});
require('../source/scripts/living-art.js');
function context(){const calls=[],stack=[];return {calls,canvas:{width:390,height:640},font:'10px sans-serif',fillStyle:'#000',strokeStyle:'#000',globalAlpha:1,
 save(){stack.push({font:this.font,fillStyle:this.fillStyle,strokeStyle:this.strokeStyle,globalAlpha:this.globalAlpha});},restore(){Object.assign(this,stack.pop());},
 fillText(text,x,y){calls.push({text:String(text),x,y,font:this.font,color:this.fillStyle});},strokeText(){},measureText(s){return {width:Array.from(String(s)).length*7};},
 beginPath(){},closePath(){},ellipse(){},stroke(){},fill(){},fillRect(){},moveTo(){},lineTo(){},translate(){},rotate(){},roundRect(){}};}
function renderEvents(events,f=.5,geometry={}){const c=context(),ink=LivingInk.create(c,FrontierData),g={s:{t:10,combat:events,beasts:[],realm:{pets:[]}},world:{npcs:{caster:{id:'caster',stageLocal:{x:geometry.casterX??80,y:300}},victim:{id:'victim',stageLocal:{x:280,y:300}}}}};
 ink.settings.motion=false;const before=JSON.stringify(g);ink.combatVfx(c,g,p=>({x:p.x,y:p.y}),f,10.2);assert.equal(JSON.stringify(g),before,'drawing feedback changed simulation');return c.calls;}
const event=(extra={})=>({kind:'damage',value:137,t:10,until:11.5,targetId:'victim',entityId:'victim',attackerId:'caster',x:280,y:300,...extra});
test('critical damage visibly says คริ!, uses larger gold type, and miss/support events never fabricate zero damage',()=>{
 const calls=renderEvents([event({kind:'critical',critical:true}),event({kind:'miss',value:0}),event({kind:'guard',label:'คุ้มกาย',value:0})]);
 const crit=calls.find(c=>c.text.includes('คริ!'));
 assert(crit&&crit.text.includes('137'),'critical number has no explicit Thai critical cue');
 assert(parseFloat(crit.font.match(/[\d.]+px/)[0])>=18,'critical is not larger');
 assert(/^#(?:ffd|ffe|f9d|fbd)/i.test(crit.color),'critical lacks gold color');
 assert(calls.some(c=>/หลบ|MISS/.test(c.text)),'miss is invisible');
 assert(calls.some(c=>c.text==='คุ้มกาย'),'support label is invisible');
 assert(!calls.some(c=>/^[+-]?0$/.test(c.text)),'label-only event fabricated zero damage');
});
test('each named move is fully readable above its caster separately from victim damage, even with odd event order',()=>{
 const label='กระบวนท่าพิฆาตมังกรเมฆาเก้าชั้นฟ้าสะท้านปฐพี';
 const calls=renderEvents([event(),event({kind:'move',label,value:0,entityId:'caster',targetId:'caster',x:280,y:300})]);
 const move=calls.filter(c=>!/^[-+]?\d/.test(c.text));
 assert.equal(move.map(c=>c.text).join(''),label,'named move was dropped, truncated or split inside a Thai mark');
 assert(move.every(c=>Math.abs(c.x-80)<100),'move label follows victim instead of caster');
 assert(calls.some(c=>c.text.includes('137')&&c.x>200),'damage left its victim');
 assert(move.every(c=>parseFloat(c.font.match(/[\d.]+px/)[0])>=12),'move text is too small');
});
test('legacy recovery events retain the full support move name and a distinct positive healing number',()=>{
 const calls=renderEvents([event({kind:'heal',value:-12,label:'น้ำทิพย์รักษาชีพ',attackerId:null,entityId:'caster',targetId:'caster',x:80})]);
 assert(calls.some(c=>c.text==='น้ำทิพย์รักษาชีพ'),'recovery move name disappeared');
 const heal=calls.find(c=>c.text==='+12');assert(heal&&heal.color==='#b6ead0','healing is not distinct from damage');
});
test('a nearby caster move name does not push damage horizontally away from the victim',()=>{
 const calls=renderEvents([event({kind:'move',value:0,entityId:'caster',attackerId:'caster',label:'กระบวนท่าพิฆาตมังกรเมฆาเก้าชั้นฟ้าสะท้านปฐพี'}),event({kind:'critical',critical:true})],.5,{casterX:180});
 const number=calls.find(c=>c.text.includes('คริ!'));assert(number&&Math.abs(number.x-280)<10,'caster label displaced damage away from the victim');
});
const Canvas=require('./canvas-shim.cjs');
test('human attack poses follow attack speed through the visible arm stroke and recovery without changing the actor',()=>{
 function handAt(attackSpeed,age){const ctx=Canvas.createCanvas(200,120).getContext('2d'),drawEllipse=ctx.ellipse.bind(ctx);let handY;
  ctx.ellipse=function(x,y,rx,ry,...rest){if(x===-6&&rx===1.3&&ry===1.4)handY=y;return drawEllipse(x,y,rx,ry,...rest);};
  const ink=LivingInk.create(ctx,FrontierData),n={id:'pose-fixture',alive:true,health:100,core:{},jianghu:{path:'XIAN'},stageLocal:{x:100,y:70,mode:'combat',action:null,route:[],combatState:{lastAttackAt:10}}},g={s:{},combatSystem:{stats(){return {attackSpeed};}}},before=JSON.stringify(n);
  ink.settings.motion=true;ink.settings.uiTheme='classic';ink.drawHuman(ctx,n,g,10+age,.5,false);assert.equal(JSON.stringify(n),before,'pose rendering modified the actor');return handY;
 }
 assert(Math.abs(handAt(.5,.3)-3.4)<.01,'slow attack does not reach its stroke peak at its own cadence');
 assert(Math.abs(handAt(2,.0875)-3.4)<.01,'fast attack uses the slow attack sine denominator');
 assert(Math.abs(handAt(2,.3)+.6)<.01,'fast attack pose persists beyond its recovery window');
});
if(!Canvas.isFallback)test('mixed Thai and numeric feedback uses a font stack with real Latin glyphs',()=>{
 Canvas.GlobalFonts.registerFromPath(path.join(root,'assets/noto-sans-thai-400.woff2'),'Thai');
 const text=renderEvents([event({kind:'critical',critical:true})]).find(c=>c.text.includes('คริ!')),ctx=Canvas.createCanvas(200,80).getContext('2d');ctx.font=text.font;
 assert(ctx.measureText('WWW').width-ctx.measureText('111').width>6,'Latin digits and letters resolve to identical missing-glyph boxes');
});
test('offscreen combat anchors do not create labels or damage clamped to the viewport edges',()=>{
 const calls=renderEvents([event({x:4000}),event({kind:'miss',value:0,x:-4000}),event({kind:'damage',y:3000}),event({kind:'move',value:0,entityId:'caster',label:'กระบวนท่านอกจอ'})],.5,{casterX:4000});
 assert.equal(calls.length,0,'offscreen fight created floating text inside the viewport');
});
test('overlapping combat events stack in bounded screen space and text stays readable across zoom',()=>{
 const calls=renderEvents(Array.from({length:80},(_,i)=>event({value:100+i}))),numbers=calls.filter(c=>/^[-+]\d/.test(c.text));
 assert(numbers.length<=24,'event draw count is unbounded');
 assert(numbers.length>1&&new Set(numbers.map(c=>c.x+','+c.y)).size===numbers.length,'numbers overlap exactly');
 for(const zoom of [.02,4]){const n=renderEvents([event()],zoom).find(c=>c.text.includes('137'));assert(n&&parseFloat(n.font.match(/[\d.]+px/)[0])>=14,'zoom makes damage unreadable');}
});
async function controlsTest(){
 const listeners={},timers=[],elements=new Map();let markup='';
 class El{
  constructor(id=''){this.id=id;this.style={};this.dataset={};this.childNodes=[];this.attributes=[];this.scrollTop=0;this.textContent='';this.tagName='DIV';this.classList={add(){},remove(){},toggle(){}};}
  set innerHTML(s){this._html=String(s);markup=this._html;}get innerHTML(){return this._html||'';}
  getContext(){return context();}getBoundingClientRect(){return {width:390,height:640,left:0,top:0};}
  setAttribute(k,v){const a=this.attributes.find(a=>a.name===k);if(a)a.value=String(v);else this.attributes.push({name:k,value:String(v)});}
  getAttribute(k){return this.attributes.find(a=>a.name===k)?.value??null;}hasAttribute(k){return this.getAttribute(k)!==null;}
  removeAttribute(k){this.attributes=this.attributes.filter(a=>a.name!==k);}addEventListener(){}setPointerCapture(){}
  querySelectorAll(){return [];}appendChild(n){this.childNodes.push(n);}get lastChild(){return this.childNodes.at(-1);}
 }
 const doc={hidden:false,body:new El(),querySelector(s){if(!elements.has(s))elements.set(s,new El(s));return elements.get(s);},querySelectorAll(){return [];},createElement(){return new El();},addEventListener(k,fn){(listeners[k]||=[]).push(fn);}};
 global.document=doc;
 const sandbox={document:doc,console,performance,URL,TextEncoder,TextDecoder,structuredClone,location:{search:'?fresh=1&qa=1'},devicePixelRatio:1,localStorage:{getItem(){return null;},setItem(){}},setTimeout(fn){timers.push(fn);return timers.length;},clearTimeout(){},requestAnimationFrame(){return 0;},addEventListener(){},LivingInk:{create(){return {ready:Promise.resolve(),settings:{uiTheme:'sonnet'},set(){}};}}};
 for(const name of ['FrontierData','World2026Engine','Frontier','RealmSprites','JianghuInventory1222','GrowthView','HumanDossier','SectLifeView','SectLifeSystem','JianghuRealmView','JianghuSafeEditor','HumanCore','CombatView117'])sandbox[name]=global[name];
 sandbox.window=sandbox;vm.createContext(sandbox);vm.runInContext(fs.readFileSync(path.join(root,'source/scripts/ui.js'),'utf8'),sandbox,{filename:'ui.js'});
 await timers[0]();assert(sandbox.JIANGHU,'UI startup did not expose controls: '+doc.querySelector('#loading p').textContent);
 const ui=sandbox.JIANGHU,g=ui.game,before=g.serialize(),n=g.heroes[0],pet=g.s.realm.pets[0],beast=g.s.beasts[0];
 async function click(dataset){const button={dataset,hasAttribute(k){return k==='data-detail'&&dataset.detail!==undefined;}};for(const fn of listeners.click||[])await fn({target:{closest(selector){return selector.includes('data-i1222')?null:button;}}});}
 ui.select(n.id);await click({heroTab:'combat'});assert(markup.includes('ค่าพื้นฐาน')&&markup.includes('ค่าปัจจุบัน'),'NPC stats tab did not open');
 await click({worldSection:'companions'});assert(markup.includes('data-combat-entity="'+pet.id+'"'),'companion dossier has no combat stats access');
 await click({combatEntity:pet.id});assert(markup.includes('คุณสมบัติต่อสู้')&&markup.includes(pet.name),'companion stats link did not open');
 ui.open('ecology');assert(markup.includes('data-combat-entity="'+beast.id+'"'),'ecology has no beast stats access');
 await click({combatEntity:beast.id});assert(markup.includes(beast.name)&&markup.includes('ค่าปัจจุบัน'),'beast stats link did not open');
 assert.equal(g.serialize(),before,'opening stats controls changed simulation or RNG');
}
controlsTest().then(()=>results.push({name:'existing NPC, companion, and ecology controls open read-only stats panels',pass:true}),e=>results.push({name:'existing NPC, companion, and ecology controls open read-only stats panels',pass:false,error:e.stack})).then(()=>{
 for(const result of results)console.log((result.pass?'PASS ':'FAIL ')+result.name+(result.pass?'':'\n'+result.error));
 if(results.some(r=>!r.pass))process.exitCode=1;
});
