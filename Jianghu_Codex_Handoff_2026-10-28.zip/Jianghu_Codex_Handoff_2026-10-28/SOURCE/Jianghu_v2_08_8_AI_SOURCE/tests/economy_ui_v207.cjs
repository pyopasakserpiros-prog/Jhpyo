/* Execute the actual UI startup and controls with offscreen Canvas + a minimal DOM (v1.17). */
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const C=require('./canvas-shim.cjs');
const root=path.resolve(__dirname,'..');require('./inspect-engine.cjs');
C.GlobalFonts.registerFromPath(path.join(root,'assets/noto-sans-thai-400.woff2'),'Thai');
C.GlobalFonts.registerFromPath(path.join(root,'assets/noto-sans-thai-600.woff2'),'Thai');
let lastMarkup="";
class El{
 set innerHTML(v){this._html=String(v);lastMarkup=this._html;}get innerHTML(){return this._html||"";}
 constructor(id=''){this.id=id;this.hidden=false;this.style={};this.dataset={};this.childNodes=[];this.attributes=[];this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this.listeners={};this.scrollTop=0;this.textContent='';this.value='';this.tagName='DIV';}
 setAttribute(k,v){const old=this.attributes.find(a=>a.name===k);if(old)old.value=String(v);else this.attributes.push({name:k,value:String(v)});}
 getAttribute(k){return this.attributes.find(a=>a.name===k)?.value??null;}
 hasAttribute(k){return this.getAttribute(k)!==null;}
 removeAttribute(k){this.attributes=this.attributes.filter(a=>a.name!==k);}
 addEventListener(k,v){(this.listeners[k]||=[]).push(v);}
 getBoundingClientRect(){return {width:430,height:720,left:0,top:0};}
 querySelectorAll(){return[];}querySelector(){return null;}closest(){return null;}
 appendChild(v){this.childNodes.push(v);}removeChild(v){this.childNodes=this.childNodes.filter(x=>x!==v);}get lastChild(){return this.childNodes.at(-1);}
 setPointerCapture(){}click(){this.onclick?.({target:this});}
}
const html=fs.readFileSync(path.join(root,'source/index.html'),'utf8'),els=new Map();for(const m of html.matchAll(/\bid="([^"]+)"/g))els.set('#'+m[1],new El(m[1]));
for(const key of ['#map','#minimap']){const cv=C.createCanvas(key==='#map'?430:156,key==='#map'?720:117),el=els.get(key);for(const k of ['addEventListener','getBoundingClientRect','setPointerCapture'])cv[k]=el[k].bind(el);cv.style={};els.set(key,cv);}
els.set('.ruler i',new El());els.set('#loading p',new El());
const docEvents={};
global.document={hidden:false,querySelector(s){assert(els.has(s),'Unknown startup DOM selector '+s);return els.get(s);},querySelectorAll(){return[];},addEventListener(k,v){(docEvents[k]||=[]).push(v);},createElement(tag){return tag==='canvas'?C.createCanvas(1,1):new El();}};
const stored=new Map();global.localStorage={getItem(k){return stored.get(k)||null;},setItem(k,v){stored.set(k,v);}};
global.window=global;window.addEventListener=()=>{};global.devicePixelRatio=1;global.location={search:'?fresh=1&qa=1'};global.Image=C.Image;global.matchMedia=()=>({matches:false});
const frames=[];global.requestAnimationFrame=fn=>{frames.push(fn);return frames.length;};
global.LivingArtAssets=JSON.parse(fs.readFileSync(path.join(root,'assets/art-manifest.json'),'utf8'));for(const [k,v] of Object.entries(LivingArtAssets.images))LivingArtAssets.images[k]='data:image/webp;base64,'+fs.readFileSync(path.resolve(root,'source',v)).toString('base64');
require('../source/scripts/living-art.js');
vm.runInThisContext(fs.readFileSync(path.join(root,'source/scripts/ui.js'),'utf8'),{filename:'ui.js'});
(async()=>{
 const start=Date.now();while(!global.JIANGHU&&Date.now()-start<30000)await new Promise(r=>setTimeout(r,100));assert(JIANGHU);const g=JIANGHU.game,SC=JianghuSectContributions;
 g.storyEvents.activate();g.s.life.offices.master={npcId:g.heroes[0].id};
 for(const n of [...g.enemies,...g.s.beasts]){n.alive=false;n.health=0;}
 const n=g.heroes[0],a=SC.account(g,n);a.balance=a.earned=1000;World2026Engine.addSpiritStonesV140(n,1000);n.jianghu.ledgerV140.materialStacks=[];
 g.bank.jianghu.ledgerV140.materialStacks=[];g.add(g.bank,FrontierData.HERB,10,'UI_SUPPLIER');SC.curateStore(g);const it=SC.storeInventory(g).materials[0];assert(it);
 els.set('#storeBuyerSelect',Object.assign(new El('storeBuyerSelect'),{value:n.id}));els.set('#externalMemberSelect',Object.assign(new El('externalMemberSelect'),{value:n.id}));
 async function click(dataset,attributes=[]){const b=new El();b.dataset=dataset;for(const key of attributes)b.setAttribute(key,'');b.closest=()=>b;for(const h of docEvents.click)await h({target:b});}
 const ext=SC.externalMarket(g);assert(ext.offers.length);ext.visitState.phase='TRADING';ext.visitorPhase='TRADING';g.world.npcs[ext.visitState.merchantId].stageLocal.externalMerchantPhase='TRADING';g.world.npcs[ext.visitState.merchantId].stageLocal.mode='waiting';JIANGHU.open('objectives');await click({questTab:'store'});let markup=lastMarkup;
 assert(markup.includes('หินวิญญาณ/ชุด'));assert(markup.includes('บัญชีแต้มคุณูปการ'));assert(markup.includes('data-outside-buy'));
 const before=a.balance;await click({storeBuy:'MATERIAL:'+it.id});assert.equal(g.count(n,FrontierData.HERB),1);assert.equal(before-a.balance,it.unitStorePrice);
 const memberOffer=ext.offers.find(x=>x.kind==='MATERIAL'),memberStones=World2026Engine.getSpiritStonesV140(n),memberQty=memberOffer.quantity;await click({memberOutsideBuy:memberOffer.id+':1'});assert.equal(World2026Engine.getSpiritStonesV140(n),memberStones-memberOffer.unitStones);assert.equal(memberOffer.quantity,memberQty-1);
 const personalOrder=ext.orders.find(x=>x.kind==='MATERIAL');assert(personalOrder);assert(g.add(n,personalOrder.targetId,8,'UI_PERSONAL_SELL',{quality:'STANDARD'}).ok);const personalQuote=SC.quotePersonalPurchaseOrder(g,n.id,personalOrder.id,1),stonesBeforeSale=World2026Engine.getSpiritStonesV140(n);assert(personalQuote.ok,personalQuote.reason);await click({memberOutsideSell:personalOrder.id+':1'});assert.equal(World2026Engine.getSpiritStonesV140(n),stonesBeforeSale+personalQuote.stones);assert.equal(personalOrder.filled,1);
 const o=ext.offers[0],gold=g.gold;await click({outsideBuy:o.id});assert.equal(g.gold,gold-o.totalStones);assert.equal(o.status,'ACCEPTED');
 const next=ext.offers[1],gold2=g.gold;await click({outsideReject:next.id});assert.equal(next.status,'REJECTED');assert.equal(g.gold,gold2);
 await click({},['data-outside-auto']);assert.equal(ext.autoProcure,false);await click({},['data-member-trade-auto']);assert.equal(ext.autoMemberTrade,false);
 const css=fs.readFileSync('source/style.css','utf8');JIANGHU.refresh();
 fs.writeFileSync('evidence/store-ui-v207.html','<!doctype html><html lang="th"><meta charset="utf-8"><style>'+css+'</style><body><main style="padding:12px;max-width:430px">'+lastMarkup+'</main></body></html>');
 JIANGHU.open('build');assert(lastMarkup.includes('หอคลังสำนัก'));assert(lastMarkup.includes('โรงช่างโยธา'));assert(lastMarkup.includes('data-upgrade-building'));
 g.money(2000,'UI_UPGRADE_SETUP');g.s.wood=100;g.add(g.bank,FrontierData.ORE,40,'UI_UPGRADE_SETUP');const hall=g.built('hall'),q=JianghuInfrastructure.quoteUpgrade(g,hall.id),funds=g.gold;assert(q.ok,q.reason);await click({upgradeBuilding:hall.id});assert(hall.upgrade);assert.equal(g.gold,funds-q.cost.stones);await click({},['data-infrastructure-auto']);assert.equal(g.s.infrastructure.autoEnabled,false);
 const sectPartner=g.s.realm.factions.find(f=>f.id==='CN'),sectQuote=g.realm.quoteSectTrade('CN','BUY_FROM_SECT',FrontierData.ORE,1),sectGold=g.gold,partnerGold=World2026Engine.getSpiritStonesV140(sectPartner.cache),partnerStock=g.count(sectPartner.cache,FrontierData.ORE);assert(sectQuote.ok,sectQuote.reason);await click({sectTrade:'CN:BUY_FROM_SECT:'+FrontierData.ORE+':1'});assert.equal(g.gold,sectGold-sectQuote.totalStones);assert.equal(World2026Engine.getSpiritStonesV140(sectPartner.cache),partnerGold+sectQuote.totalStones);assert.equal(g.count(sectPartner.cache,FrontierData.ORE),partnerStock-1);
 fs.writeFileSync('evidence/infrastructure-ui-v207.html','<!doctype html><html lang="th"><meta charset="utf-8"><style>'+css+'</style><body><main style="padding:12px;max-width:430px">'+lastMarkup+'</main></body></html>');
 for(const [type,x,y] of [['treasury',600,960],['missionHall',950,960],['works',1330,960]]){const placed=g.place(type,x,y);assert(placed.ok,type+': '+placed.reason);placed.building.remaining=0;}
 frames.shift()(performance.now()+40);assert(!JIANGHU.runtimeFault);fs.writeFileSync('evidence/economy-map-v207.png',els.get('#map').toBuffer('image/png'));
 fs.writeFileSync('evidence/economy-ui-v207.json',JSON.stringify({pass:true,release:'2.08.7-autonomous-sect-network-market',backend:'actual UI handlers and native Canvas; Chromium unavailable',checks:['display spirit-stone outsider offers','exact one-unit shop button','accept debits treasury spirit stones','reject preserves stones','autoprocure and personal auto-trade toggles','member buy/sell controls use personal spirit stones','Canvas frame after transactions','new buildings and upgrade costs','native upgrade button spends once','NPC construction toggle','sect-to-sect UI handler transfers goods and spirit stones']}));console.log('ECONOMY_UI_PASS');
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
