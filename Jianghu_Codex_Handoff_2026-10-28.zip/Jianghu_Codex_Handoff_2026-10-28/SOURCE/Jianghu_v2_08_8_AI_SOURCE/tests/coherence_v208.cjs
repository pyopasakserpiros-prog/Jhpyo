'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),C=JianghuSectContributions,I=JianghuInfrastructure,results=[];
const initial=new Frontier(20801);initial.establish();const raw=initial.serialize();
function game(){
 const g=Frontier.load(raw);g.s.t=100;g.storyEvents.activate();g.s.storyEvents.autoEvents=false;
 g.money(10000,'AUDIT_SETUP');g.s.wood=500;g.add(g.bank,FrontierData.ORE,300,'AUDIT_SETUP');
 g.s.life.offices.master={npcId:g.heroes[0].id};
 for(const n of g.heroes){n.health=100;n.core.condition.fatigue=0;Object.assign(n.stageLocal,{offmap:null,mode:'idle',action:null});n.stageLocal.needs.hunger=0;}
 I.tick(g);g.s.infrastructure.autoEnabled=false;return g;
}
function build(g,type,x=600,y=1600){const r=g.place(type,x,y);assert(r.ok,r.reason);r.building.remaining=0;return r.building;}
function auto(g){g.s.infrastructure.autoEnabled=true;g.s.t+=41;I.tick(g);}
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
test('automatic storage upgrades do not spend on a lower duplicate with no extra capacity',()=>{
 const g=game(),high=build(g,'treasury'),low=build(g,'treasury',1750,1660);high.level=3;
 for(let i=0;i<750;i++)g.bank.jianghu.ledgerV140.materialStacks.push({matId:'full-'+i,count:1});
 const before=[g.gold,g.s.wood,g.ore];auto(g);
 assert(!low.upgrade,'a second level-2 treasury adds no capacity beside a level-3 treasury');
 assert.deepEqual([g.gold,g.s.wood,g.ore],before);
});
test('point shortages alone cannot justify buying more work slots while workers are idle',()=>{
 for(const stale of [false,true]){
  const g=game(),hall=build(g,'missionHall');for(const n of g.heroes){n.stageLocal.storeWish={deficit:20};if(stale)n.stageLocal.action='sectGather:'+g.s.nodes[0].id;}
  if(stale)Object.assign(g.heroes[1].stageLocal,{mode:'working',offmap:{until:1e9}});
  assert.equal(C.economicWorkload(g).gathering,0,'idle and off-map old actions do not occupy work slots');
  const before=g.gold;auto(g);assert(!hall.upgrade,'extra slots cannot help idle workers earn points');assert.equal(g.gold,before);
 }
});
test('saturated economic work with real point shortages can justify more work slots',()=>{
 const g=game(),hall=build(g,'missionHall');
 for(const n of g.heroes){n.stageLocal.storeWish={deficit:20};n.stageLocal.action='sectGather:'+g.s.nodes[0].id;n.stageLocal.mode='working';}
 auto(g);assert(hall.upgrade,'both existing gathering slots are occupied so extra capacity is useful');
});
test('common detox is eligible for the same basic welfare as ordinary healing',()=>{
 const g=game();assert(C.grantEligibility(g,'PILL',{id:'detox',tier:1,quality:'COMMON',effect:{clearPoison:20}},1).ok);
});
test('a recovery label cannot give permanent progression bonuses away as basic welfare',()=>{
 const g=game();
 for(const effect of [{healHealth:20,foundationBonus:1},{healHealth:20,daoComprehensionBonus:1},{healHealth:20,tribulationResist:1},{healHealth:20,openMeridianBonus:1}])
  assert(!C.grantEligibility(g,'PILL',{id:'advanced',tier:1,quality:'COMMON',effect},1).ok,JSON.stringify(effect));
});
test('sect-made tools retain authored craft and escort effects rather than becoming generic equipment',()=>{
 const g=new Frontier(20727);g.establish();g.storyEvents.activate();g.money(5000,'AUDIT_SETUP');g.s.wood=200;g.add(g.bank,FrontierData.ORE,60,'AUDIT_SETUP');build(g,'forge');
 const n=g.heroes[0];
 for(const [id,want] of [['MW_REC_044',{craftBonusPath:'TALISMAN',craftBonusScore:6}],['MW_REC_055',{escortSafetyBonus:.048}]]){
  const r=g.progression.recipe(id);n.stageLocal.growth.knownRecipes.push(id);
  for(const x of r.inputs)assert(g.add(g.bank,x.matId,x.count,'AUDIT_RECIPE_INPUT').ok);
  const made=C.craftForSect(g,n,id,{forceSuccess:true});assert(made.ok,made.reason);
  for(const [key,value] of Object.entries(want))assert.equal(made.item[key],value,key+' must survive actual production');
 }
});
test('a learned recipe from the wider world can become a sect production job and appear in the workshop',()=>{
 const g=game(),n=g.heroes[0];build(g,'forge');g.bank.jianghu.ledgerV140.materialStacks=[];g.bank.jianghu.ledgerV140.pillStacks=[];g.bank.jianghu.ledgerV140.equipmentItems=[];
 const r=g.progression.recipe('MW_REC_044');n.stageLocal.growth.knownRecipes.push(r.id);
 for(const x of r.inputs)assert(g.add(g.bank,x.matId,x.count,'LEARNED_RECIPE_INPUT').ok);
 assert(C.canCraftForSect(g,n,r.id).ok,'the learned recipe has a valid maker, workshop, skill and materials');
 const choices=[];C.options(g,n,(id)=>choices.push(id));assert(choices.includes('sectCraft:MW_REC_044'),'known recipes must not disappear behind the old fixed recipe list');
 assert(C.inspect(g).sectWorkshopRecipes.some(x=>x.id===r.id),'the same learned recipe must be offered in the workshop UI');
});
test('personal crafting buys only the one missing ingredient and can afford exactly its price',()=>{
 for(const balance of [100,7]){
  const g=game(),n=g.heroes[0],mat=FrontierData.HERB;g.bank.jianghu.ledgerV140.materialStacks=[];n.jianghu.ledgerV140.materialStacks=[];
  assert(g.add(n,mat,1,'OWNED_INPUT').ok);assert(g.add(g.bank,mat,10,'BANK_INPUT').ok);
  const a=C.account(g,n);a.balance=a.earned=balance;n.stageLocal.growth.knownRecipes.push('L14_remedy');
  n.stageLocal.growth.plan={kind:'craft',targetId:'L14_remedy'};
  const at=g.endpoint(g.built('hall'));Object.assign(n.stageLocal,{x:at.x,y:at.y,target:at,mode:'working',job:0,growthTarget:mat});
  g.progression.start(n,'takeIngredient');const r=g.progression.finish(n,'takeIngredient');assert(r.success,'one missing ingredient must cost only 7 points');
  assert.equal(g.count(n,mat),2);assert.equal(g.count(g.bank,mat),9);assert.equal(a.balance,balance-7);
 }
});
test('outsider purchase orders enforce tiered quota bonus only on initial quota units and never beyond',()=>{
 const g=game();const m=C.externalMarket(g);assert(m.orders.length>=2,'caravan visit must generate purchase orders');
 const order=m.orders.find(o=>o.kind==='MATERIAL');assert(order);
 g.bank.jianghu.ledgerV140.materialStacks=[];
 const res=C.orderReserve(g,order).reserve;
 assert(g.add(g.bank,order.targetId,res+6,'SURPLUS_TEST').ok);
 const gold0=g.gold;
 const sale1=C.sellToPurchaseOrder(g,order.id,4);
 assert(sale1.ok,sale1.reason);
 assert.equal(sale1.bonusUnits,order.bonusQuota,'only the first bonusQuota units receive the quota bonus');
 assert.equal(sale1.regularUnits,4-order.bonusQuota);
 assert.equal(sale1.stones,4*order.unitStones+order.bonusQuota*order.bonusPerUnit);
 assert.equal(g.gold,gold0+sale1.stones);
 const sale2=C.sellToPurchaseOrder(g,order.id,2);
 assert(sale2.ok,sale2.reason);
 assert.equal(sale2.bonusUnits,0,'subsequent units beyond bonusQuota must receive zero bonus');
 assert.equal(sale2.bonusStones,0);
 assert.equal(sale2.stones,2*order.unitStones);
 assert.equal(g.count(g.bank,order.targetId),res,'warehouse reserve must remain intact after selling all surplus');
});
test('outsider surplus sales preserve sect reserves and reject rare or non-surplus items',()=>{
 const g=game();const m=C.externalMarket(g);const order=m.orders.find(o=>o.kind==='MATERIAL');assert(order);
 g.bank.jianghu.ledgerV140.materialStacks=[];
 const res=C.orderReserve(g,order).reserve;
 assert(g.add(g.bank,order.targetId,res,'EXACT_RESERVE').ok);
 assert(g.add(g.bank,order.targetId,5,'RARE_LOT',{quality:'PERFECT'}).ok);
 const gold0=g.gold;
 const rejected=C.sellToPurchaseOrder(g,order.id,1);
 assert(!rejected.ok,'cannot sell reserved stock or high-quality/rare lots as ordinary surplus');
 assert.equal(g.gold,gold0);
 assert.equal(g.count(g.bank,order.targetId),res+5);
});
test('outsider trade prevents buy-low sell-high spirit stone arbitrage across all caravan guilds',()=>{
 const g=game();
 for(let v=0;v<C.CARAVAN_GUILDS.length;v++){
  g.s.t+=200;const m=C.externalMarket(g);
  for(const o of m.orders){
   const maxUnitPayout=o.unitStones+(o.bonusPerUnit||0);
   assert(maxUnitPayout<o.minOfferBuyStones,`order ${o.id} max unit payout (${maxUnitPayout}) must stay strictly below merchant offer buy price (${o.minOfferBuyStones})`);
  }
 }
});
test('autonomous officer surplus sale and save-load serialization preserve exact order state',()=>{
 const g=game();const m=C.externalMarket(g);const order=m.orders.find(o=>o.kind==='MATERIAL');assert(order);
 g.bank.jianghu.ledgerV140.materialStacks=[];
 assert(g.add(g.bank,order.targetId,40,'ABUNDANT_SURPLUS').ok);
 const gold0=g.gold;
 g.s.t+=25;C.tick(g);
 assert(g.gold>gold0,'autonomous officer must sell abundant surplus for spirit stones');
 assert(C.inspect(g).history.some(h=>h.kind==='EXTERNAL_SELL'),'transaction history must record EXTERNAL_SELL');
 const h=Frontier.load(g.serialize());
 assert.equal(JSON.stringify(C.externalMarket(h)),JSON.stringify(C.externalMarket(g)));
});
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
fs.writeFileSync('evidence/coherence-v208.json',JSON.stringify({pass:results.every(r=>r.pass),results},null,2));
if(results.some(r=>!r.pass))process.exitCode=1;
