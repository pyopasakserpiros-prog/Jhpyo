'use strict';
require('./inspect-engine.cjs');
const fs=require('fs');
const out=[];
function game(){const g=new Frontier(20107);g.establish();for(const n of g.enemies)n.alive=false;for(const b of g.s.beasts)b.alive=false;g.s.t=100;return g;}
function route(g,n,path,sub,ord){Object.assign(n.jianghu,{path,subPath:sub});World2026Engine.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:ord,progress:0});n.stageLocal.mode='idle';g.combatSystem.ensure(n);}
function probe(name,fn){try{out.push({name,...fn()});}catch(e){out.push({name,error:e.stack});}}
probe('cross-path technique damage channel',()=>{
 const g=game(),c=g.combatSystem,n=g.heroes[0];route(g,n,'XIAN','SWORD_IMMORTAL',4);
 const body=c.arts.find(a=>a.path==='BODY'&&g.progression.compatible(n,a)&&g.progression.canStudyArtTier(n,a)&&['attack','control'].includes(c.classify(a)));
 const bodyActor=g.heroes[1];route(g,bodyActor,'BODY','STAR_BODY',4);
 const art=c.arts.find(a=>a.path==='XIAN'&&g.progression.compatible(bodyActor,a)&&g.progression.canStudyArtTier(bodyActor,a)&&c.classify(a)==='attack');
 return {bodyTechnique:body&&{id:body.id,path:body.path,actorPath:n.jianghu.path,actual:c.attackType(n,body),expected:'physical'},nonBodyTechnique:art&&{id:art.id,path:art.path,actorPath:bodyActor.jianghu.path,actual:c.attackType(bodyActor,art),expected:'art'}};
});
probe('off-map encounter reuses an unavailable technique',()=>{
 const g=game(),c=g.combatSystem,n=g.heroes[0];route(g,n,'XIAN','SWORD_IMMORTAL',4);
 const a=c.arts.find(a=>!a.innateRoute&&a.path==='XIAN'&&g.progression.compatible(n,a)&&g.progression.canStudyArtTier(n,a)&&g.progression.slot(a)==='technique'&&c.classify(a)==='attack'&&c.cooldownSeconds(a)>0);
 n.jianghu.knowledgeV190[a.id]={artId:a.id,stage:4,mastery:80,reading:100};n.jianghu.attackArtIds=[a.id];
 const e={art:a,role:'attack',knowledge:n.jianghu.knowledgeV190[a.id],mastery:80,slot:'technique'};c.activeArts=()=>[e];
 const s=c.ensure(n);s.qi=s.maxQi;s.cooldowns[a.id]=600;s.globalReadyAt=600;
 const before={ready:c.ready(n,e,s),qi:s.qi,qiSpent:s.qiSpent,cooldown:s.cooldowns[a.id],time:g.s.t};
 const inst=g.myriad.rollMyriadWorldsInstance('MW_ENT_NORTH_MIST',n,'review-cooldown');
 inst.encounters=[1,2].map(step=>{const ind=g.myriad.generateBeastIndividual('MW_BEAST_001','review-cooldown-'+step);ind.affordances=['COMBAT'];ind.power=1;return {stepIndex:step,type:'BEAST_ENCOUNTER',individual:ind,resolved:false};});
 n.stageLocal.offmap={journeyId:'review'};
 g.myriad.resolveExpeditionInstance(n,inst);
 return {artId:a.id,cost:c.qiCost(n,a),before,after:{qi:s.qi,qiSpent:s.qiSpent,cooldown:s.cooldowns[a.id],time:g.s.t,history:s.history.filter(h=>h.offmap).map(h=>({t:h.t,artId:h.artId}))},encounters:inst.encounters.map(e=>({artId:e.combat201?.artId,winChance:e.combat201?.winChance}))};
});
probe('blood buff completion after a reflected lethal hit',()=>{
 const g=game(),c=g.combatSystem,n=g.heroes[0],t=g.heroes[1];route(g,n,'DEMON','ABYSSAL_MIRROR_ECLIPSE',6);
 const a=c.artMap.get('ART_V210_ECLIPSE_NIGHTFALL');n.jianghu.knowledgeV190[a.id]={artId:a.id,stage:4,mastery:80,reading:100};n.jianghu.attackArtIds=[a.id];
 const e={art:a,role:'attack',knowledge:n.jianghu.knowledgeV190[a.id],mastery:80,slot:'technique'};c.choose=()=>e;
 Object.assign(t.stageLocal,{x:n.stageLocal.x+30,y:n.stageLocal.y});
 const s=c.ensure(n),ts=c.ensure(t);s.qi=s.maxQi;s.lastAttackAt=-100;s.globalReadyAt=0;n.health=3.01;t.health=100;
 Object.assign(ts,{parryUntil:110,parryCharges:2,reflectRatio:.58});
 const rolls=[0,.99];let i=0;g.rng.next=()=>rolls[(i++)%2];
 const before={health:n.health,alive:n.alive};c.act(n,t);
 return {before,after:{health:n.health,alive:n.alive,mode:n.stageLocal.mode,buffs:s.buffs},targetHealth:t.health,events:g.s.combat.filter(x=>x.damageType==='reflect')};
});
probe('guardian share and reflection use no extra hit rolls',()=>{
 const g=game(),c=g.combatSystem,n=g.heroes[0],t=g.heroes[1],guardian=g.heroes[2]||g.heroes[0];
 Object.assign(guardian.stageLocal,{x:t.stageLocal.x+30,y:t.stageLocal.y});
 const ts=c.ensure(t);ts.allyWard={guardianId:guardian.id,expiresAt:105,charges:2};Object.assign(ts,{parryUntil:105,parryCharges:1,reflectRatio:.3});
 const before={n:n.health,t:t.health,guardian:guardian.health};let rolls=0;g.rng.next=()=>{rolls++;return rolls===1?0:.99;};c.hit(n,t,30,{type:'physical'});
 return {rolls,before,after:{n:n.health,t:t.health,guardian:guardian.health},finite:[n,t,guardian].every(n=>Number.isFinite(n.health))};
});
probe('same-patch reload after damage preserves current derived Qi capacity',()=>{
 const g=new Frontier(20107);g.establish();const c=g.combatSystem,n=g.heroes[0],s=c.ensure(n);
 s.qi=s.maxQi;g.damage(n,10,null,true,{combat201:true,type:'physical'});
 const raw=g.serialize(),loaded=Frontier.load(raw),ln=loaded.world.npcs[n.id],ls=ln.stageLocal.combatState;
 const before={health:n.health,qi:s.qi,maxQi:s.maxQi,sheetQi:c.stats(n).maxQi};
 const after={health:ln.health,qi:ls.qi,maxQi:ls.maxQi,sheetQi:loaded.combatSystem.stats(ln).maxQi};
 const changed=raw!==loaded.serialize();g.advance(.2);loaded.advance(.2);
 return {before,after,serializationChanged:changed,continuationEqual:g.serialize()===loaded.serialize()};
});
probe('healing feedback uses the same derived HP units as damage and the sheet',()=>{
 const g=game(),c=g.combatSystem,n=g.heroes[0];route(g,n,'GOD','MERCY_DEITY',4);
 const a=c.artMap.get('ART_C117_INNATE_MERCY_DEITY'),e={art:a,role:'recovery',knowledge:{mastery:50},mastery:50,slot:'innate',innate:true};
 c.choose=()=>e;const s=c.ensure(n);s.lastAttackAt=-100;s.globalReadyAt=0;s.qi=s.maxQi;n.health=50;
 const before=n.health,scale=c.healthScale(n);c.act(n,{id:'dummy',health:1000,maxHP:1000,alive:true,x:n.stageLocal.x+40,y:n.stageLocal.y});
 return {artId:a.id,conditionHeal:n.health-before,derivedHPHeal:(n.health-before)*scale,event:g.s.combat.find(e=>e.entityId===n.id&&e.kind==='heal')};
});
probe('offscreen combat feedback stays offscreen',()=>{
 global.LivingArtAssets={images:{pending:'pending'}};global.Image=class{set src(_){} };global.localStorage={getItem(){return null;}};global.matchMedia=()=>({matches:false});
 const Ink=require('../source/scripts/living-art.js'),calls=[],c={canvas:{width:390,height:640},font:'',save(){},restore(){},measureText(t){return {width:t.length*7};},fillText(t,x,y){calls.push({text:t,x,y});},strokeText(){},fillRect(){},beginPath(){},ellipse(){},stroke(){},fill(){},roundRect(){},translate(){},rotate(){},moveTo(){},lineTo(){}};
 const ink=Ink.create(c,{});ink.settings.motion=false;
 const g={s:{combat:[{x:4000,y:300,value:42,t:1,until:2,kind:'damage',targetId:'far'}],beasts:[],realm:{pets:[]}},world:{npcs:{far:{id:'far',stageLocal:{x:4000,y:300}}}}};
 ink.combatVfx(c,g,p=>({x:p.x,y:p.y}),.5,1.2);return {anchor:{x:4000,y:300},canvas:{width:390,height:640},calls};
});
fs.writeFileSync('evidence/review-v201.json',JSON.stringify(out,null,2));
console.log(JSON.stringify(out,null,2));
