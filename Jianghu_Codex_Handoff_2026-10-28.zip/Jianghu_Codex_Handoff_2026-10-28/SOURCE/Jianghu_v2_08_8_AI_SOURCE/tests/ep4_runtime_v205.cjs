'use strict';
require('./inspect-engine.cjs');
const fs=require('fs'),assert=require('assert'),A=JianghuStoryEvents,results=[];
const raw=fs.readFileSync('evidence/qa-fixture-v201.json','utf8');
for(const node of A.STORY_TREE_NODES_V203){
 try{
  const g=Frontier.load(raw),st=g.storyEvents.activate();
  st.autoEvents=false;st.treasury.autoDistribute=false;st.currentNodeId=node.id;st.currentEp=node.ep;
  st.completedNodeIds=[...(node.parentIds||[])];st.completedEpisodes=Array.from({length:node.ep-1},(_,i)=>i+1);
  // Isolate completion of the authored encounter; enemies die via the real resolver.
  st.epPhase='ACTIVE_TRIAL';st.trialTagId='runtime-'+node.id;st.trialStartedAt=g.s.t;
  const b=g.spawnBeast('wolf-forest');b.storyEventId=st.trialTagId;st.trialEntityIds=[b.id];
  g.damage(b,1e8,g.heroes[0],true,{combat201:true});
  const h=Frontier.load(g.serialize());h.storyEvents.tick(.1);
  assert(h.s.storyEvents.completedNodeIds.includes(node.id),'completion did not commit');
  assert.equal(h.s.storyEvents.history.filter(r=>r.kind==='STORY_COMPLETE'&&r.titleTh.includes(node.titleTh)).length,1);
  const total=h.gold;h.storyEvents.tick(.1);assert.equal(h.gold,total,'reward repeated');
  h.advance(.2);h.storyEvents.inspect();
  assert.doesNotThrow(()=>Frontier.load(h.serialize()).storyEvents.inspect());
  results.push({id:node.id,ep:node.ep,pass:true});
 }catch(e){results.push({id:node.id,ep:node.ep,pass:false,error:e.stack});}
}
fs.writeFileSync('evidence/episode-runtime-v205.json',JSON.stringify(results,null,2));
console.log(JSON.stringify({passed:results.filter(r=>r.pass).length,total:results.length,ep4:results.filter(r=>r.ep===4),failures:results.filter(r=>!r.pass)},null,2));
if(results.some(r=>!r.pass))process.exitCode=1;
