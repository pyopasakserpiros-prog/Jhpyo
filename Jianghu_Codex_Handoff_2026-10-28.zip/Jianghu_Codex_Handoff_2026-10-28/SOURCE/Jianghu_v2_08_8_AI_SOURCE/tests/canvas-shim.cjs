/* Pure-JS offscreen Canvas2D fallback for Node QA environments when @napi-rs/canvas is not installed. */
'use strict';
const zlib=require('zlib');

function makePng1x1(){
 // Valid 64x64 solid sage-green PNG buffer for QA snapshot outputs
 const pngHex='89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c63647068f80f00030401005a3f1a710000000049454e44ae426082';
 return Buffer.from(pngHex,'hex');
}

class MockContext2D{
 constructor(canvas){
  this.canvas=canvas;
  this.fillStyle='#000';
  this.strokeStyle='#000';
  this.lineWidth=1;
  this.lineCap='butt';
  this.lineDashOffset=0;
  this.globalAlpha=1;
  this.globalCompositeOperation='source-over';
  this.font='10px sans-serif';
  this.textAlign='start';
  this.textBaseline='alphabetic';
  this._stack=[];
 }
 save(){this._stack.push({globalAlpha:this.globalAlpha,fillStyle:this.fillStyle,strokeStyle:this.strokeStyle});}
 restore(){const s=this._stack.pop();if(s)Object.assign(this,s);}
 scale(){}
 translate(){}
 rotate(){}
 transform(){}
 setTransform(){}
 beginPath(){}
 closePath(){}
 moveTo(){}
 lineTo(){}
 quadraticCurveTo(){}
 bezierCurveTo(){}
 arc(){}
 ellipse(){}
 roundRect(){}
 rect(){}
 fill(){}
 stroke(){}
 fillRect(){}
 strokeRect(){}
 clearRect(){}
 setLineDash(){}
 fillText(){}
 strokeText(){}
 measureText(text){return {width:String(text||'').length*6.5};}
 createLinearGradient(){return {addColorStop(){}};}
 createRadialGradient(){return {addColorStop(){}};}
 drawImage(){}
}

class MockCanvas{
 constructor(w=300,h=150){
  this.width=w;
  this.height=h;
  this.style={};
  this._ctx=new MockContext2D(this);
 }
 getContext(type){return type==='2d'?this._ctx:null;}
 toBuffer(){return makePng1x1();}
}

class MockImage{
 constructor(){
  this.width=2048;
  this.height=2048;
  this.onload=null;
  this.onerror=null;
  this._src='';
 }
 set src(v){
  this._src=String(v||'');
  Promise.resolve().then(()=>{if(typeof this.onload==='function')this.onload();});
 }
 get src(){return this._src;}
}

function loadCanvasModule(){
 try{return require('@napi-rs/canvas');}catch{}
 try{return require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas');}catch{}
 return {
  createCanvas:(w,h)=>new MockCanvas(w,h),
  Image:MockImage,
  GlobalFonts:{registerFromPath(){return true;}},
  isFallback:true
 };
}

module.exports=loadCanvasModule();
