/* Real Frontier integration checks for comparable story cultivation milestones. */
'use strict';
require('./inspect-engine.cjs');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const E = World2026Engine;
const Q = JianghuExpansionV112.storyEvents;
const g = new Frontier(202041);
g.establish();
const results = [];
const evidence = { profileCount: Object.keys(CombatData117.profiles).length, results, examples: [], trackMilestones: [] };
let serial = 0;
function actor(major, sub, ordinal, progress = 0) {
  const n = JSON.parse(JSON.stringify(g.heroes[0]));
  // Native synchronizers resolve registered IDs through the world; use an isolated real NPC.
  n.id = 'cultivation-quest-test-' + (++serial);
  Object.assign(n.jianghu, { path: major, subPath: sub });
  E.syncNpcCultivationIdentityV1200(g.world, n, { trackOrdinal: ordinal, progress });
  return n;
}
function check(name, fn) {
  try { fn(); results.push({ name, pass: true }); }
  catch (error) { results.push({ name, pass: false, error: error.message }); }
}

// Catches local ordinal comparisons denying a BODY/ELIXIR/Leviathan disciple
// who has reached the same actual normalized attainment as Sword realm 3.
check('EP4 accepts the same attainment within heterogeneous realms', () => {
  const cases = [
    ['XIAN', 'SWORD_IMMORTAL', 3, 0, true],
    ['BODY', 'TIGER_SOVEREIGN', 2, 77, false],
    ['BODY', 'TIGER_SOVEREIGN', 2, 78, true],
    ['XIAN', 'ELIXIR_DAO', 3, 52, false],
    ['XIAN', 'ELIXIR_DAO', 3, 53, true],
    ['BODY', 'ABYSSAL_LEVIATHAN_BODY', 2, 25, false],
    ['BODY', 'ABYSSAL_LEVIATHAN_BODY', 2, 26, true]
  ];
  for (const [major, sub, ordinal, progress, want] of cases) {
    const n = actor(major, sub, ordinal, progress);
    const actual = Q.evaluateDiscipleForEp(g, n, 4);
    evidence.examples.push({ major, sub, ordinal, progress, band: E.resolveNpcCultivationIdentityReadOnlyV1200(g.world, n).realizationBand, qualified: actual.qualified, want });
    assert.strictEqual(actual.qualified, want, sub + ' realm ' + ordinal + ' progress ' + progress);
  }
});

// Catches the special-case 55%-of-first-realm shortcut, whose actual attainment
// differs by track width, replacing it with the common early training milestone.
check('EP2 uses comparable fractional attainment across short and long tracks', () => {
  const cases = [
    ['XIAN', 'SWORD_IMMORTAL', 1, 52, false],
    ['XIAN', 'SWORD_IMMORTAL', 1, 53, true],
    ['BODY', 'TIGER_SOVEREIGN', 1, 45, false],
    ['BODY', 'TIGER_SOVEREIGN', 1, 46, true],
    ['XIAN', 'ELIXIR_DAO', 1, 65, false],
    ['XIAN', 'ELIXIR_DAO', 1, 66, true],
    ['BODY', 'ABYSSAL_LEVIATHAN_BODY', 1, 32, false],
    ['BODY', 'ABYSSAL_LEVIATHAN_BODY', 1, 33, true]
  ];
  for (const [major, sub, ordinal, progress, want] of cases) {
    assert.strictEqual(Q.evaluateDiscipleForEp(g, actor(major, sub, ordinal, progress), 2).qualified, want, sub + ' progress ' + progress);
  }
});

// Catches trusting stale compatibility projections, and the unwrapped legacy
// getRealizationBand resolver that treats Mist Lotus's 11 realms as Sword's 9.
check('quest evaluation resolves live canonical identity for expanded profiles', () => {
  const n = actor('XIAN', 'MIST_LOTUS_ALCHEMY', 3, 0);
  n.jianghu.realizationBand = 99;
  const low = Q.evaluateDiscipleForEp(g, n, 4);
  assert.strictEqual(low.qualified, false);
  assert.strictEqual(low.currentBand, 2.6);
  n.jianghu.cultivationProgress = 53;
  const high = Q.evaluateDiscipleForEp(g, n, 4);
  assert.strictEqual(high.qualified, true);
  assert.strictEqual(high.currentBand, 3.0028);
  const native = actor('XIAN', 'SWORD_IMMORTAL', 1, 0);
  native.jianghu.stage = 3;
  assert.strictEqual(Q.evaluateDiscipleForEp(g, native, 4).qualified, true);
});

// Catches a summary table advertising a realm inconsistent with the exact
// required progress and gate used for the individual disciple.
check('milestone display describes real realm progress for each path', () => {
  const table = Q.getPathStageTableForEp(4);
  const body = table.find(row => row.path === 'BODY');
  assert.strictEqual(body.requiredBand, 3);
  assert.strictEqual(body.requiredOrdinal, 2);
  assert(body.requiredProgress > 77 && body.requiredProgress < 78);
  const n = actor('BODY', 'TIGER_SOVEREIGN', 2, body.requiredProgress);
  const row = Q.evaluateDiscipleForEp(g, n, 4);
  assert.strictEqual(row.requiredStage, 2);
  assert.strictEqual(row.requiredBand, 3);
  assert.strictEqual(row.requiredProgress, body.requiredProgress);
  assert.strictEqual(row.qualified, true);
  assert.strictEqual(Q.requiredOrdinalForPath('XIAN', 'ELIXIR_DAO', 4), 3);
  assert.strictEqual(Q.requiredOrdinalForPath('BODY', 'ABYSSAL_LEVIATHAN_BODY', 4), 2);
});

// Catches missing hidden profiles, count-only threshold interpolation, clamping
// to a major path's sample, and any inaccessible late-episode requirement.
check('all 47 profiles qualify exactly by real normalized attainment at every episode', () => {
  assert.strictEqual(evidence.profileCount, 47);
  const targets = [1, 1.5, 2, 3, 4, 5, 6, 7];
  let observations = 0;
  for (const key of Object.keys(CombatData117.profiles)) {
    const [major, sub] = key.split(':');
    const track = E.getCultivationTrackV1200(major, sub);
    assert.strictEqual(track.subpathId, sub, key);
    const milestones = [];
    for (let ep = 1; ep <= 8; ep++) {
      const terminal = actor(major, sub, track.realmCount, 100);
      const requirement = Q.evaluateDiscipleForEp(g, terminal, ep);
      assert.strictEqual(requirement.qualified, true, key + ' EP' + ep + ' must be reachable');
      assert.strictEqual(requirement.requiredBand, targets[ep - 1]);
      assert(requirement.requiredStage >= 1 && requirement.requiredStage <= track.realmCount);
      assert(requirement.requiredProgress >= 0 && requirement.requiredProgress <= 100);
      const atRequirement = actor(major, sub, requirement.requiredStage, requirement.requiredProgress);
      assert.strictEqual(Q.evaluateDiscipleForEp(g, atRequirement, ep).qualified, true, key + ' display must meet EP' + ep);
      milestones.push({ ep, requiredBand: requirement.requiredBand, ordinal: requirement.requiredStage, progress: requirement.requiredProgress, realmNameTh: requirement.requiredStageNameTh });
      for (const realm of track.realms) for (const progress of [0, 25, 55, 85, 100]) {
        const n = actor(major, sub, realm.ordinal, progress);
        const identity = E.resolveNpcCultivationIdentityReadOnlyV1200(g.world, n);
        const actual = Q.evaluateDiscipleForEp(g, n, ep);
        assert.strictEqual(actual.currentBand, identity.realizationBand, key);
        assert.strictEqual(actual.qualified, identity.realizationBand >= targets[ep - 1], key + ' EP' + ep + ' realm' + realm.ordinal + ' at ' + progress);
        observations++;
      }
    }
    evidence.trackMilestones.push({ key, realmCount: track.realmCount, milestones });
  }
  evidence.observations = observations;
});

// Catches inspection changing actors, world state, resources, or game RNG.
check('milestone inspection is read-only and deterministic', () => {
  const n = actor('BODY', 'TIGER_SOVEREIGN', 2, 78);
  const before = JSON.stringify(n);
  const save = g.serialize();
  const rng = g.rng.seed;
  for (let ep = 1; ep <= 8; ep++) {
    Q.evaluateDiscipleForEp(g, n, ep);
    Q.getPathStageTableForEp(ep);
  }
  assert.strictEqual(JSON.stringify(n), before);
  assert.strictEqual(g.serialize(), save);
  assert.strictEqual(g.rng.seed, rng);
});

evidence.pass = results.every(row => row.pass);
const reportName = process.env.CULTIVATION_QUEST_REPORT || 'cultivation-quests-v202.json';
fs.writeFileSync(path.join(__dirname, '../evidence', reportName), JSON.stringify(evidence, null, 2));
console.log(JSON.stringify({ pass: evidence.pass, profileCount: evidence.profileCount, observations: evidence.observations, results }, null, 2));
if (!evidence.pass) process.exitCode = 1;
