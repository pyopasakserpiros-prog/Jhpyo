/* Execute the actual UI startup and controls with offscreen Canvas + a minimal DOM (v1.17). */
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const C=require('./canvas-shim.cjs');
const root=path.resolve(__dirname,'..');require('./inspect-engine.cjs');
let lastMarkup="";
class El{
 set innerHTML(v){this._html=String(v);lastMarkup=this._html;}get innerHTML(){return this._html||"";}
 constructor(id=''){this.id=id;this.hidden=false;this.style={};this.dataset={};this.childNodes=[];this.attributes=[];this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this.listeners={};this.scrollTop=0;this.textContent='';this.value='';this.tagName='DIV';}
 setAttribute(k,v){const old=this.attributes.find(a=>a.name===k);if(old)old.value=String(v);else this.attributes.push({name:k,value:String(v)});}
 getAttribute(k){return this.attributes.find(a=>a.name===k)?.value??null;}
 hasAttribute(k){return this.getAttribute(k)!==null;}
 removeAttribute(k){this.attributes=this.attributes.filter(a=>a.name!==k);}
 addEventListener(k,v){(this.listeners[k]||=[]).push(v);}
 getBoundingClientRect(){return {width:430,height:720,left:0,top:0};}
 querySelectorAll(){return[];}querySelector(){return null;}closest(){return null;}
 appendChild(v){this.childNodes.push(v);}removeChild(v){this.childNodes=this.childNodes.filter(x=>x!==v);}get lastChild(){return this.childNodes.at(-1);}
 setPointerCapture(){}click(){this.onclick?.({target:this});}
}
const html=fs.readFileSync(path.join(root,'source/index.html'),'utf8'),els=new Map();for(const m of html.matchAll(/\bid="([^"]+)"/g))els.set('#'+m[1],new El(m[1]));
for(const key of ['#map','#minimap']){const cv=C.createCanvas(key==='#map'?430:156,key==='#map'?720:117),el=els.get(key);for(const k of ['addEventListener','getBoundingClientRect','setPointerCapture'])cv[k]=el[k].bind(el);cv.style={};els.set(key,cv);}
els.set('.ruler i',new El());els.set('#loading p',new El());
const docEvents={};
global.document={hidden:false,querySelector(s){assert(els.has(s),'Unknown startup DOM selector '+s);return els.get(s);},querySelectorAll(){return[];},addEventListener(k,v){(docEvents[k]||=[]).push(v);},createElement(tag){return tag==='canvas'?C.createCanvas(1,1):new El();}};
const stored=new Map();global.localStorage={getItem(k){return stored.get(k)||null;},setItem(k,v){stored.set(k,v);}};
global.window=global;window.addEventListener=()=>{};global.devicePixelRatio=1;global.location={search:'?fresh=1&qa=1'};global.Image=C.Image;global.matchMedia=()=>({matches:false});
const frames=[];global.requestAnimationFrame=fn=>{frames.push(fn);return frames.length;};
global.LivingArtAssets=JSON.parse(fs.readFileSync(path.join(root,'assets/art-manifest.json'),'utf8'));for(const [k,v] of Object.entries(LivingArtAssets.images))LivingArtAssets.images[k]='data:image/webp;base64,'+fs.readFileSync(path.resolve(root,'source',v)).toString('base64');
require('../source/scripts/living-art.js');
vm.runInThisContext(fs.readFileSync(path.join(root,'source/scripts/ui.js'),'utf8'),{filename:'ui.js'});
(async()=>{
 const start=Date.now();while(!global.JIANGHU&&Date.now()-start<30000)await new Promise(r=>setTimeout(r,100));assert(global.JIANGHU,'boot failed');
 const g=JIANGHU.game,original=g.frame;const st=g.storyEvents.activate();st.currentNodeId='EP4_BEAST_SOVEREIGN';st.currentEp=4;st.epPhase='ACTIVE_TRIAL';st.trialTagId='ui-ep4';st.trialEntityIds=JianghuStoryEvents.STORY_TREE_NODES_V203.find(n=>n.id===st.currentNodeId).spawnTrial(g,st.trialTagId);frames.shift()(performance.now()+34);fs.writeFileSync('evidence/ep4-native-canvas-v205.png',els.get('#map').toBuffer('image/png'));const oldSave=g.serialize();stored.set('jianghu-frontier-qa-combat201',oldSave);
 g.frame=()=>{throw Error('EP4 injected completion error');};
 const next=frames.shift();assert.doesNotThrow(()=>next(performance.now()+1000),'A simulation exception must not kill the UI loop');
 assert(g.s.paused,'simulation must pause on fault');assert(JIANGHU.runtimeFault,'retain the error for export');assert(frames.length,'RAF must stay scheduled');
 assert.equal(els.get('#runtimeFault').hidden,false,'show a recoverable error');
 document.hidden=true;for(const f of docEvents.visibilitychange||[])await f();document.hidden=false;await new Promise(r=>setTimeout(r,30));assert.equal(stored.get('jianghu-frontier-qa-combat201'),oldSave,'fault state must never overwrite a healthy autosave');
 els.get('#pause').click();assert(g.s.paused,'resume cannot replay a failed tick');
 els.get('#menu').click();assert(!els.get('#sheet').hidden,'menu still works');
 const button=new El();button.dataset.action='load';button.closest=()=>button;for(const handler of docEvents.click||[])await handler({target:button});
 assert(!JIANGHU.runtimeFault,'loading clears the fault');assert.equal(els.get('#runtimeFault').hidden,true);assert.notEqual(JIANGHU.game,g);const before=JIANGHU.game.s.t;frames.shift()(performance.now()+1200);assert(JIANGHU.game.s.t>before,'loaded game resumes');
 fs.writeFileSync('evidence/runtime-ui-v205.json',JSON.stringify({pass:true,backend:'actual UI handlers and offscreen Canvas; no Chromium installed',checks:['simulation exception pauses safely','RAF survives','error banner','autosave preserved','menu and load work','loaded game resumes']},null,2));console.log('RUNTIME_UI_PASS');
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
