/* Story/combat integration regressions: run from the project root with Node. */
'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),path=require('path');
const fixture=fs.readFileSync(path.join(__dirname,'../evidence/qa-fixture-v201.json'),'utf8'),results=[];
function fresh(){
 const g=Frontier.load(fixture),n=g.heroes[0];g.s.t=100;
 g.s.storyEvents={active:true,doctrines:[],aftermaths:[]};
 n.health=100;n.alive=true;n.core.condition.fatigue=0;n.core.human.state.pain=0;n.stageLocal.needs.hunger=0;
 for(const part of Object.keys(n.core.human.state.parts))n.core.human.state.parts[part]=0;
 Object.assign(n.jianghu,{knowledgeV190:{},attackArtIds:[],techniqueId:null,mantraId:null,lightnessId:null,auxiliaryId:null,forbiddenId:null,equipmentV140:{},meridiansV150:{},internalInjury:0,poisonAccumulated:0,pillToxicity:0,heartDemon:0});
 n.jianghu.ledgerV140.equipmentItems=[];n.stageLocal.combatState={};
 return {g,n,c:g.combatSystem};
}
function test(name,fn){const detail={};try{fn(detail);results.push({name,pass:true,detail});}catch(e){results.push({name,pass:false,detail,error:e.stack});}}
function close(actual,expected,message){assert(Math.abs(actual-expected)<.00001,message||`${actual} != ${expected}`);}
function equip(n,extra={}){const it={id:'quest-tool',nameTh:'เครื่องรางทดสอบ',slot:'TALISMAN_VESSEL',tier:1,minStageReq:1,compatiblePath:'ANY',durability:100,...extra};n.jianghu.ledgerV140.equipmentItems.push(it);n.jianghu.equipmentV140[it.slot]=it.id;return it;}
function beast(n,extra={}){return {id:'quest-poison-target',name:'หมาป่าทดสอบ',speciesId:'BEAST_MIST_WOLF',alive:true,health:100,maxHP:100,power:100,tier:1,x:n.stageLocal.x+40,y:n.stageLocal.y,...extra};}

test('adding and editing a doctrine immediately changes operational cached combat stats',detail=>{
 const {g,n,c}=fresh(),base=c.stats(n).physicalAttack;
 g.s.storyEvents.doctrines.push({id:'quest-doctrine',mods:{scale:{physicalAttack:1.25}}});
 detail.base=base;detail.cached=c.stats(n).physicalAttack;detail.explained=c.stats(n,{explain:true}).physicalAttack;
 close(detail.cached,base*1.25,'new doctrine did not change its advertised physical attack');
 close(detail.cached,detail.explained,'cached combat ignored a newly awarded doctrine');
 g.s.storyEvents.doctrines[0].mods.scale.physicalAttack=1.10;
 close(c.stats(n).physicalAttack,c.stats(n,{explain:true}).physicalAttack,'cached combat ignored edited doctrine effects');
});
test('story activation and sect membership invalidate only the applicable story bonuses',()=>{
 const {g,n,c}=fresh();g.s.storyEvents.doctrines=[{id:'member',mods:{add:{accuracy:10}}}];
 const member=c.stats(n).accuracy;g.s.storyEvents.active=false;
 close(c.stats(n).accuracy,member-10,'deactivating story left a doctrine active');
 g.s.storyEvents.active=true;close(c.stats(n).accuracy,member);
 g.s.heroIds=g.s.heroIds.filter(id=>id!==n.id);close(c.stats(n).accuracy,member-10,'former member retained sect doctrine');
});
test('aftermath expiry invalidates the cache even when no actor input changes',detail=>{
 const {g,n,c}=fresh();g.s.storyEvents.aftermaths=[{id:'brief',expiresAt:101,mods:{scale:{artAttack:1.30}}}];
 detail.active=c.stats(n).artAttack;g.s.t=102;detail.expired=c.stats(n).artAttack;
 detail.explained=c.stats(n,{explain:true}).artAttack;
 close(detail.expired,detail.explained,'expired aftermath remained in operational stats');assert(detail.expired<detail.active);
});
test('story critical aliases change canonical critical stats without duplicate or unknown stats',detail=>{
 const {g,n,c}=fresh(),base=c.stats(n);
 g.s.storyEvents.doctrines=[{id:'critical',mods:{add:{critRate:.05,critDamage:.25,irrelevant:999,undefined:999}}}];
 const next=c.stats(n,{explain:true});detail.before={chance:base.critChance,multiplier:base.critMultiplier};detail.after={chance:next.critChance,multiplier:next.critMultiplier};
 close(next.critChance,base.critChance+.05,'doctrine critRate was ignored');close(next.critMultiplier,base.critMultiplier+.25,'doctrine critDamage was ignored');
 close(next.physicalAttack,base.physicalAttack,'an unknown modifier leaked into canonical combat stats');
 assert(!('critRate'in next)&&!('critDamage'in next)&&!('irrelevant'in next));
 g.s.storyEvents.doctrines[0].mods.add={critChance:.02,critRate:.10,critMultiplier:.10,critDamage:.50};
 const both=c.stats(n);close(both.critChance,base.critChance+.02);close(both.critMultiplier,base.critMultiplier+.10);
 g.s.storyEvents.aftermaths=[{id:'critical-scale',expiresAt:105,mods:{scale:{critRate:2,critDamage:1.1}}}];
 close(c.stats(n).critChance,(base.critChance+.02)*2);close(c.stats(n).critMultiplier,(base.critMultiplier+.10)*1.1);
});
test('quest equipment critical aliases affect real critical rolls and multipliers',detail=>{
 const {g,n,c}=fresh(),base=c.stats(n);equip(n,{combatStats:{critRate:.06,critDamage:.30}});
 const next=c.stats(n);detail.before={chance:base.critChance,multiplier:base.critMultiplier};detail.after={chance:next.critChance,multiplier:next.critMultiplier};
 close(next.critChance,base.critChance+.06,'reward critRate was ignored');close(next.critMultiplier,base.critMultiplier+.30,'reward critDamage was ignored');
 const t=beast(n),rolls=[0,base.critChance+.03];let count=0;g.rng.next=()=>rolls[count++%2];
 const hit=c.hit(n,t,10,{type:'physical'});assert(hit.critical,'reward did not enable the critical roll between old and new chance');assert.equal(count,2);
});
test('meridian stats count canonical opened nodes rather than nonzero channels',detail=>{
 const {n,c}=fresh();n.jianghu.meridiansV150={MERIDIAN_REN:1};const one=c.stats(n);
 n.jianghu.meridiansV150.MERIDIAN_REN=9;const nine=c.stats(n);
 detail.oneQi=one.maxQi;detail.nineQi=nine.maxQi;detail.canonicalNodes=World2026Engine.computeMeridianBonusesV150(n).totalOpenedNodes;
 close(nine.maxQi-one.maxQi,8*3.5,'nodes 2..9 did not add Qi capacity');close(nine.artAttack-one.artAttack,8*1.5);
 n.jianghu.meridiansV150={MERIDIAN_REN:9,MERIDIAN_1:true,note:{openedNodes:100},MERIDIAN_DU:true};
 close(c.stats(n).maxQi,nine.maxQi,'boolean or unrelated ledger fields granted meridian stats');
 n.jianghu.meridiansV150={MERIDIAN_REN:999};close(c.stats(n).maxQi,nine.maxQi,'more than nine nodes were accepted in one channel');
});
test('craft and escort equipment bonuses count only usable matching slots once',detail=>{
 const {g,n}=fresh(),it=equip(n,{craftBonusPath:'ALCHEMY',craftBonusScore:8,escortSafetyBonus:.08});
 close(g.progression.equippedCraftBonus(n),8);close(g.progression.equippedEscortBonus(n),.08);
 n.jianghu.equipmentV140.WEAPON=it.id;n.jianghu.equipmentV140.ARMOR=it.id;
 detail.duplicateCraft=g.progression.equippedCraftBonus(n);detail.duplicateEscort=g.progression.equippedEscortBonus(n);
 close(detail.duplicateCraft,8,'one tool was counted through duplicate/wrong slots');close(detail.duplicateEscort,.08);
 delete n.jianghu.equipmentV140.TALISMAN_VESSEL;close(g.progression.equippedCraftBonus(n),0);close(g.progression.equippedEscortBonus(n),0);
});
test('ineligible escort equipment cannot reduce an off-map encounter threat',detail=>{
 const {g,n,c}=fresh(),t=beast(n),base=c.encounterPreview(n,t);equip(n,{minStageReq:99,escortSafetyBonus:.20});
 detail.before=base.threat;detail.after=c.encounterPreview(n,t).threat;
 close(g.progression.equippedEscortBonus(n),0);close(detail.after,base.threat,'preview applied a bonus rejected by canonical equipment eligibility');
});
test('craft tools match their exact discipline or an explicit ANY bonus',()=>{
 const {g,n}=fresh(),it=equip(n,{craftBonusScore:8}),disciplines=['ALCHEMY','FORGING','TALISMAN','ARRAY','BEAST_TAMING'];
 for(const tool of [...disciplines,'ANY'])for(const target of disciplines){
  it.craftBonusPath=tool;close(g.progression.equippedCraftBonus(n,target),tool===target||tool==='ANY'?8:0,`${tool} tool incorrectly affected ${target}`);
 }
 it.craftBonusPath='FORGING';close(g.progression.equippedCraftBonus(n,'forge'),8);
});
test('personal production uses recipe discipline rather than its shared workshop',detail=>{
 const rows=[['L14_ironblade','TALISMAN',false],['MW_REC_044','TALISMAN',true],['MW_REC_044','FORGING',false],['MW_REC_051','BEAST_TAMING',true],['MW_REC_051','ALCHEMY',false]];
 detail.cases=[];
 for(const [recipeId,toolPath,matching]of rows){
  const {g,n}=fresh(),r=g.progression.recipe(recipeId),activity=r.workshop==='alchemy'?'alchemy':'forging';
  n.jianghu.realizationBand=r.tier;g.money(5000,'QA');const placed=g.place(r.workshop,600,960);assert(placed.ok);placed.building.remaining=0;
  const spot=g.endpoint(placed.building);Object.assign(n.stageLocal,{...spot,mode:'working',job:0,target:{...spot}});
  const q=n.stageLocal.growth;q.knownRecipes.push(r.id);q.ticket={id:'discipline-production',action:'makePersonalItem',target:r.id,done:false};
  for(const input of r.inputs)assert(g.add(n,input.matId,input.count,'QA').ok);World2026Engine.setSpiritStonesV140(n,100);
  equip(n,{craftBonusPath:toolPath,craftBonusScore:8});const capacity=HumanCore.capacity(n,activity).total;
  const expected=Math.max(.35,Math.min(.92,.48+(capacity+(matching?8:0))*.006-r.tier*.06));
  g.rng.next=()=>.99;g.progression.finish(n,'makePersonalItem');
  const receipt=g.s.growth.receipts.find(x=>x.kind==='production'&&x.recipeId===recipeId);assert(receipt,'production was rejected before the craft roll');
  detail.cases.push({recipeId,discipline:r.discipline||r.workshop,toolPath,expected,actual:receipt.chance});
  close(receipt.chance,expected,`${toolPath} used the wrong bonus for ${recipeId}`);
 }
});
test('research trials use the design discipline rather than every tool for its workshop',detail=>{
 detail.cases=[];
 for(const [toolPath,matching]of [['TALISMAN',true],['FORGING',false]]){
  const {g,n}=fresh(),d=g.academy.designs.find(x=>x.id==='MW_EXP_015');assert(d&&d.discipline==='TALISMAN');
  g.money(5000,'QA');const placed=g.place('forge',600,960);assert(placed.ok);placed.building.remaining=0;
  Object.assign(n.stageLocal,g.endpoint(placed.building));n.stageLocal.academyTicket={targetId:d.id};
  g.s.growth.researchProjects.push({id:'discipline-research',formulaId:d.id,npcId:n.id,status:'ACTIVE',progress:0,trials:0,successes:0,failures:0,insight:0,paid:[],history:[]});
  for(const input of d.trialInputs)assert(g.add(g.bank,input.matId,input.count,'QA').ok);World2026Engine.setSpiritStonesV140(n,100);
  equip(n,{craftBonusPath:toolPath,craftBonusScore:8});const cap=HumanCore.capacity(n,'forging'),mind=HumanCore.capacity(n,'researchFormula');
  const expected=Math.max(.18,Math.min(.82,.18+(cap.total+(matching?8:0))*.004+mind.cognition*.0025+cap.aptitude*.0025+HumanCore.liking(n,'researchFormula')*.001-d.tier*.035));
  g.rng.next=()=>.99;g.academy.finish(n,'continueResearch');
  const receipt=g.s.growth.receipts.find(x=>x.kind==='researchTrial'&&x.formulaId===d.id);assert(receipt,'research trial did not reach its craft roll');
  detail.cases.push({toolPath,expected,actual:receipt.chance});close(receipt.chance,expected,`${toolPath} used the wrong research discipline`);
 }
});
test('poison never heals a target below one HP and can kill through canonical damage settlement',detail=>{
 const {g,n,c}=fresh(),t=beast(n,{health:.001});g.s.beasts.push(t);const s=c.targetState(t);
 Object.assign(s,{poisonUntil:105,poisonOwnerId:n.id,poisonArtId:'quest-poison-art',statusTickAt:99.9});
 const kills=g.s.stats.kills;g.rng.next=()=>{throw Error('poison consumed a hit/critical roll');};
 c.tickStatuses(t,.1);detail.health=t.health;detail.alive=t.alive;detail.kills=g.s.stats.kills-kills;
 assert.equal(t.health,0,'poison left or raised the near-dead target above zero');assert.equal(t.alive,false);assert.equal(detail.kills,1);
 assert(g.s.combat.some(e=>e.targetId===t.id&&e.damageType==='dot'&&e.attackerId===n.id),'poison bypassed the canonical damage event');
});
test('poison ticks use raw HP mitigation and only the active part of an elapsed interval',detail=>{
 const {g,n,c}=fresh(),s=c.ensure(n);Object.assign(s,{poisonUntil:100.5,poisonOwnerId:g.heroes[1].id,statusTickAt:100});
 const rawPerSecond=.35,scale=c.healthScale(n),resistance=c.stats(n).resistance,protection=g.realm.formationBonus(n,'protection')||1;
 const expected=rawPerSecond*.5*100/(100+resistance*.5)/scale/protection,before=n.health;
 g.s.t=101;g.rng.next=()=>{throw Error('poison consumed RNG');};c.tickStatuses(n,1);
 detail.expected=expected;detail.actual=before-n.health;close(detail.actual,expected,'poison used condition units, missed expiry interval, or skipped damage mitigation');
 assert.equal(s.poisonUntil,0);
});
test('a creature with no poison takes no phantom damage at time zero',()=>{
 const {g,n,c}=fresh(),t=beast(n);g.s.t=0;c.tickStatuses(t,.1);assert.equal(t.health,100);
});
test('story and equipment inspection preserves saves RNG and actor fields',()=>{
 const {g,n,c}=fresh();equip(n,{combatStats:{critRate:.06},craftBonusPath:'ALCHEMY',craftBonusScore:8,escortSafetyBonus:.08});
 g.s.storyEvents.doctrines=[{id:'pure',mods:{add:{critDamage:.20}}}];const before=g.serialize(),seed=g.rng.seed;
 g.rng.next=()=>{throw Error('inspection consumed RNG');};
 for(let i=0;i<3;i++){c.stats(n);c.stats(n,{explain:true});g.progression.equippedCraftBonus(n);g.progression.equippedEscortBonus(n);c.encounterPreview(n,beast(n));}
 assert.equal(g.serialize(),before);assert.equal(g.rng.seed,seed);
});
const report={suite:'quest_combat_v202',pass:results.every(r=>r.pass),passed:results.filter(r=>r.pass).length,total:results.length,results};
const output=process.env.QUEST_COMBAT_EVIDENCE||path.join(__dirname,'../evidence/quest-combat-v202.json');
fs.writeFileSync(output,JSON.stringify(report,null,2));
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
console.log(`quest_combat_v202: ${report.passed}/${report.total} passed`);if(!report.pass)process.exitCode=1;
