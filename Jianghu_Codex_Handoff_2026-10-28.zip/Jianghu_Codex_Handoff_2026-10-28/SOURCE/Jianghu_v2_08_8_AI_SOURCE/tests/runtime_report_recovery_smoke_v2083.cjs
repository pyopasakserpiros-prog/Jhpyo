/* Continue the actual exported v2.08.2 save for 1,000 frames after schema migration. */
'use strict';
const fs=require('fs'),assert=require('assert');
require('./inspect-engine.cjs');
const reportPath=process.env.JIANGHU_RUNTIME_REPORT;
if(!reportPath||!fs.existsSync(reportPath)){console.log('SKIP actual runtime report smoke test: set JIANGHU_RUNTIME_REPORT');process.exit(0);}
const report=JSON.parse(fs.readFileSync(reportPath,'utf8'));
const g=Frontier.load(JSON.stringify(report.save));
const startT=g.s.t,startTick=g.world.tick;
g.s.paused=false;g.s.speed=1;g.acc=0;
let frames=0;
try{for(;frames<1000;frames++)g.frame(.1);}catch(e){
 const result={pass:false,release:'2.08.6-sect-to-sect-spirit-stone-trade',frames,startT,endT:g.s.t,startTick,endTick:g.world.tick,error:e.stack};
 fs.writeFileSync(__dirname+'/../evidence/runtime-report-recovery-smoke-v2083.json',JSON.stringify(result,null,2));console.error(e.stack);process.exit(1);
}
const f=g.s.growth.formulaRegistry.find(x=>x.id==='MW_EXP_002');
assert(g.s.t>startT,'simulation time should advance');
assert.equal(g.s.paused,false,'simulation should remain running');
assert(f?.licenses?.some(x=>x.npcId==='NPC_3911'&&x.rights==='USE_ONLY'),'recovered formula license should exist');
const result={pass:true,release:'2.08.6-sect-to-sect-spirit-stone-trade',frames,startT,endT:g.s.t,startTick,endTick:g.world.tick,episode:g.s.storyEvents?.currentEp,paused:g.s.paused,formulaId:f.id,licenseCount:f.licenses.length,recipientLicense:f.licenses.find(x=>x.npcId==='NPC_3911')};
fs.writeFileSync(__dirname+'/../evidence/runtime-report-recovery-smoke-v2083.json',JSON.stringify(result,null,2));
console.log('PASS actual runtime report recovery smoke',JSON.stringify(result));
