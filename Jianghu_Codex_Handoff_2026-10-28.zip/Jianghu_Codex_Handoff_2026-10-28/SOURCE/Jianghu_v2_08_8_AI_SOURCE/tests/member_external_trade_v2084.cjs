'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),path=require('path');
const C=JianghuSectContributions,E=World2026Engine,results=[];
const seed=new Frontier(22084);seed.establish();const raw=seed.serialize();
function game(){
 const g=Frontier.load(raw);g.s.t=100;g.storyEvents.activate();g.s.storyEvents.autoEvents=false;g.s.storyEvents.treasury.autoDistribute=false;g.s.life.offices.master={npcId:g.heroes[0].id};
 for(const n of [...g.enemies,...g.s.beasts]){n.alive=false;n.health=0;}
 for(const n of g.heroes){Object.assign(n.stageLocal,{offmap:null,journey:null,mode:'idle',action:null});n.stageLocal.needs.hunger=0;n.core.condition.fatigue=0;n.health=100;for(const k of ['materialStacks','pillStacks','equipmentItems','scrolls'])n.jianghu.ledgerV140[k]=[];n.jianghu.equipmentV140={};}
 for(const k of ['materialStacks','pillStacks','equipmentItems','scrolls'])g.bank.jianghu.ledgerV140[k]=[];
 return g;
}
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function findItem(owner,kind,id){const key={MATERIAL:'materialStacks',PILL:'pillStacks',EQUIPMENT:'equipmentItems',SCROLL:'scrolls'}[kind];return owner.jianghu.ledgerV140[key].find(x=>(x.id||x.matId)===id);}

test('member buys a partial outside offer with personal stones only',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),offer=ext.offers.find(x=>x.kind==='MATERIAL');assert(offer);E.addSpiritStonesV140(n,1000);const q=C.quoteMemberExternalOffer(g,n.id,offer.id,1);assert(q.ok,q.reason);
 const seller=g.world.npcs[offer.sellerNpcId],item=findItem(seller,offer.kind,offer.itemId),beforeMember=E.getSpiritStonesV140(n),beforeSeller=E.getSpiritStonesV140(seller),beforeSect=g.gold,points=C.account(g,n).balance,memberStock=g.count(n,item.matId),sellerStock=g.count(seller,item.matId);
 const r=C.buyExternalOffer(g,n.id,offer.id,1);assert(r.ok,r.reason);assert.equal(E.getSpiritStonesV140(n),beforeMember-q.stones);assert.equal(E.getSpiritStonesV140(seller),beforeSeller+q.stones);assert.equal(g.gold,beforeSect);assert.equal(C.account(g,n).balance,points);assert.equal(g.count(n,item.matId),memberStock+1);assert.equal(g.count(seller,item.matId),sellerStock-1);assert.equal(offer.quantity,q.available-1);assert.equal(offer.status,'PENDING');assert(C.inspect(g).history.some(x=>x.kind==='MEMBER_EXTERNAL_BUY'&&x.npcId===n.id));
});

test('compatible outside scripture can be bought into a disciple-owned private ledger',()=>{
 const g=game(),ext=C.externalMarket(g),offer=ext.offers.find(x=>x.kind==='SCROLL');assert(offer&&offer.artId);let buyer=null,quote=null;for(const n of g.heroes){E.addSpiritStonesV140(n,1000);const q=C.quoteMemberExternalOffer(g,n.id,offer.id,1);if(q.ok){buyer=n;quote=q;break;}}assert(buyer,'at least one disciple should be compatible with the offered scripture');const seller=g.world.npcs[offer.sellerNpcId],before=E.getSpiritStonesV140(buyer);const r=C.buyExternalOffer(g,buyer.id,offer.id,1);assert(r.ok,r.reason);assert.equal(E.getSpiritStonesV140(buyer),before-quote.stones);const book=buyer.jianghu.ledgerV140.scrolls.find(x=>x.artId===offer.artId);assert(book);assert.equal(book.ownerNpcId,buyer.id);assert.equal(book.access,'PRIVATE');assert(!seller.jianghu.ledgerV140.scrolls.some(x=>x.id===offer.itemId));
});

test('member cannot buy when personal stones are insufficient and no ledger changes',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),offer=ext.offers.find(x=>x.kind==='MATERIAL');assert(offer);E.setSpiritStonesV140(n,0);const seller=g.world.npcs[offer.sellerNpcId],before=JSON.stringify(seller.jianghu.ledgerV140),member=JSON.stringify(n.jianghu.ledgerV140),gold=g.gold,qty=offer.quantity;const r=C.buyExternalOffer(g,n.id,offer.id,1);assert(!r.ok);assert.equal(JSON.stringify(seller.jianghu.ledgerV140),before);assert.equal(JSON.stringify(n.jianghu.ledgerV140),member);assert.equal(g.gold,gold);assert.equal(offer.quantity,qty);assert.equal(offer.status,'PENDING');
});

test('member sells genuine surplus to a finite outside purchase order for personal stones',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),order=ext.orders.find(x=>x.kind==='MATERIAL');assert(order);const add=g.add(n,order.targetId,8,'PERSONAL_TRADE_TEST',{quality:'STANDARD'});assert(add.ok,add.reason);const q=C.quotePersonalPurchaseOrder(g,n.id,order.id,1);assert(q.ok,q.reason);const buyer=g.world.npcs[order.buyerNpcId],beforeMember=E.getSpiritStonesV140(n),beforeBuyer=E.getSpiritStonesV140(buyer),beforeSect=g.gold,points=C.account(g,n).balance,stock=g.count(n,order.targetId),buyerStock=g.count(buyer,order.targetId),filled=order.filled||0;
 const r=C.sellPersonalToPurchaseOrder(g,n.id,order.id,1);assert(r.ok,r.reason);assert.equal(E.getSpiritStonesV140(n),beforeMember+q.stones);assert.equal(E.getSpiritStonesV140(buyer),beforeBuyer-q.stones);assert.equal(g.gold,beforeSect);assert.equal(C.account(g,n).balance,points);assert.equal(g.count(n,order.targetId),stock-1);assert.equal(g.count(buyer,order.targetId),buyerStock+1);assert.equal(order.filled,filled+1);assert.equal(ext.sales[0].sellerType,'DISCIPLE');assert(C.inspect(g).history.some(x=>x.kind==='MEMBER_EXTERNAL_SELL'&&x.npcId===n.id));
});

test('personal sale preserves a material reserve and refuses rare or loaned lots',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),order=ext.orders.find(x=>x.kind==='MATERIAL');assert(order);const mat=FrontierData.HERB;order.targetId=mat;order.nameTh='สมุนไพรพื้นฐาน';
 g.add(n,mat,5,'COMMON_SURPLUS',{quality:'STANDARD'});const q=C.quotePersonalPurchaseOrder(g,n.id,order.id);assert(q.ok&&q.surplusQty>0);assert(q.reserve>=1,'basic personal herbs must keep a reserve');const before=g.count(n,mat),reserve=q.reserve;const sold=C.sellPersonalToPurchaseOrder(g,n.id,order.id,1);assert(sold.ok,sold.reason);assert.equal(g.count(n,mat),before-1);assert(g.count(n,mat)>=reserve);
 n.jianghu.ledgerV140.materialStacks=n.jianghu.ledgerV140.materialStacks.filter(x=>x.matId!==mat);
 const rare={id:'rare_personal_lot',matId:mat,nameTh:'ของหายาก',quality:'PERFECT',rarity:'PERFECT',count:5,ownerNpcId:n.id,ownerId:n.id};
 const protectedLot={id:'loaned_personal_lot',matId:mat,nameTh:'ของยืม',quality:'STANDARD',count:5,ownerNpcId:n.id,ownerId:n.id,rights:'LOAN'};
 n.jianghu.ledgerV140.materialStacks.push(rare,protectedLot);const q2=C.quotePersonalPurchaseOrder(g,n.id,order.id);assert(!q2.ok,'rare and loaned lots must not be sellable');assert.equal(q2.totalStock,0);assert.equal(rare.count,5);assert.equal(protectedLot.count,5);
});

test('autonomous member trade uses a real personal wallet and ledger',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),offer=ext.offers.find(x=>x.kind==='MATERIAL');assert(offer);const seller=g.world.npcs[offer.sellerNpcId],item=findItem(seller,offer.kind,offer.itemId);E.addSpiritStonesV140(n,1000);n.stageLocal.growth.knownRecipes=[];n.stageLocal.storeWish={kind:'MATERIAL',id:item.matId,nameTh:item.nameTh,price:10,urgency:90};ext.autoMemberTrade=true;ext.autoProcure=false;ext.autoSell=false;ext.nextDecisionAt=0;ext.nextMemberDecisionAt=0;const before=E.getSpiritStonesV140(n),qty=offer.quantity;C.tick(g);assert(E.getSpiritStonesV140(n)<before,'autonomous shopper should spend personal stones');assert(offer.quantity<qty,'autonomous shopper should reduce finite merchant cargo');assert(C.inspect(g).history.some(x=>x.kind==='MEMBER_EXTERNAL_BUY'&&x.npcId===n.id));
});

test('autonomous member sells surplus only when it can retain reserves and earns personal stones',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),order=ext.orders.find(x=>x.kind==='MATERIAL');assert(order);for(const o of ext.offers)o.status='REJECTED';assert(g.add(n,order.targetId,8,'AUTONOMOUS_PERSONAL_SURPLUS',{quality:'STANDARD'}).ok);E.setSpiritStonesV140(n,0);ext.autoMemberTrade=true;ext.autoProcure=false;ext.autoSell=false;ext.nextDecisionAt=0;ext.nextMemberDecisionAt=0;const stock=g.count(n,order.targetId);C.tick(g);assert(E.getSpiritStonesV140(n)>0,'autonomous sale should pay the disciple');assert.equal(g.count(n,order.targetId),stock-1);assert(C.inspect(g).history.some(x=>x.kind==='MEMBER_EXTERNAL_SELL'&&x.npcId===n.id));
});

test('caravan asking prices respond to real scarcity, surplus, and guild trust',()=>{
 const g=game();C.externalMarket(g);const scarce=C.externalAskPrice(g,'MATERIAL',{matId:FrontierData.HERB},100,'HERB_GUILD');assert(g.add(g.bank,FrontierData.HERB,100,'MARKET_SURPLUS',{quality:'STANDARD'}).ok);const surplus=C.externalAskPrice(g,'MATERIAL',{matId:FrontierData.HERB},100,'HERB_GUILD');assert(surplus<scarce,`surplus price ${surplus} should be below scarce price ${scarce}`);const state=C.externalMarket(g);state.guildRelations.HERB_GUILD=50;const trusted=C.externalAskPrice(g,'MATERIAL',{matId:FrontierData.HERB},100,'HERB_GUILD');assert(trusted<surplus,`trusted-guild price ${trusted} should be below ${surplus}`);const pulse=C.computeMarketPulse(g);assert(pulse.signals.some(x=>x.kind==='MATERIAL'&&x.targetId===FrontierData.HERB));
});

test('outside trade accounts and guild relationship persist across same-version save/load',()=>{
 const g=game(),n=g.heroes[0],ext=C.externalMarket(g),offer=ext.offers.find(x=>x.kind==='MATERIAL');E.addSpiritStonesV140(n,1000);const r=C.buyExternalOffer(g,n.id,offer.id,1);assert(r.ok,r.reason);const h=Frontier.load(g.serialize()),trade=C.inspect(h).externalTrade;assert.equal(trade.guildRelations[offer.guildId],1);assert(trade.history.some(x=>x.buyerType==='DISCIPLE'));assert.equal(trade.autoMemberTrade,true);assert.equal(trade.offers.find(x=>x.id===offer.id).quantity,offer.quantity);
});

fs.writeFileSync(path.join(__dirname,'../evidence/member-external-trade-v2084.json'),JSON.stringify({pass:results.every(r=>r.pass),release:'2.08.6-sect-to-sect-spirit-stone-trade',results},null,2));
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
if(results.some(r=>!r.pass))process.exitCode=1;
