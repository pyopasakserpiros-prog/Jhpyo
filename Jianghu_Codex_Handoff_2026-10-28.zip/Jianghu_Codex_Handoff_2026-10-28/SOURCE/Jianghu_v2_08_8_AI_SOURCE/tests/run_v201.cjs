/* Complete release checks, including the inherited simulation/content suites. */
'use strict';
const {spawnSync}=require('child_process'),path=require('path'),fs=require('fs');
const root=path.resolve(__dirname,'..');
const checks=[
 ['stats','tests/combat_stats_v201.cjs'],['resolver','tests/combat_overhaul_v201.cjs'],['visuals','tests/combat_visuals_v201.cjs'],['retreat','tests/retreat_v201.cjs'],['world_links','tests/world_links_v201.cjs'],['status_links','tests/combat_status_v201.cjs'],['final_regressions','tests/final_regressions_v201.cjs'],['merge_ecology','tests/merge_ecology_v201.cjs'],['merge_npc','tests/merge_npc_v201.cjs'],
 ...['audit','flows','expedition','combat','combat_integration','simulation','world','balance','ui','render'].map(s=>[s,'tests/'+s+'_v117.cjs']),
 ['myriad_worlds','tests/myriad_worlds_v200.cjs'],['build','tools/build.py'],['verify_build','tests/verify_build_v117.cjs']
];
const results=[];
for(const [name,file] of checks){
 const start=Date.now(),r=spawnSync(file.endsWith('.py')?'python3':process.execPath,[file],{cwd:root,encoding:'utf8',maxBuffer:12*1024*1024});
 const log='evidence/v201-'+name+'.log';fs.writeFileSync(path.join(root,log),(r.stdout||'')+(r.stderr||''));
 results.push({name,pass:r.status===0,exitCode:r.status,seconds:+((Date.now()-start)/1000).toFixed(2),log});
 fs.writeFileSync(path.join(root,'evidence/suite-v201.json'),JSON.stringify({release:'2.01-combat-attributes',completedAt:new Date().toISOString(),pass:results.every(x=>x.pass),completed:results.length,expected:checks.length,results},null,2));
 console.log(name+': '+(r.status===0?'PASS':'FAIL')+' ('+results.at(-1).seconds+'s)');
 if(r.status!==0){console.error(((r.stdout||'')+(r.stderr||'')).slice(-5000));process.exit(r.status||1);}
}
console.log('ALL_V201_CHECKS_PASS');
