/* Offscreen Canvas2D QA (v1.17). Uses the very same renderer as the shipped game. */
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const Canvas=require('./canvas-shim.cjs');
const root=path.resolve(__dirname,'..'),out=path.resolve(root,'evidence/art-qa');fs.mkdirSync(out,{recursive:true});
require('./inspect-engine.cjs');
const raw=JSON.parse(fs.readFileSync(path.join(root,'assets/art-manifest.json'),'utf8'));
const images={};for(const [k,v] of Object.entries(raw.images))images[k]='data:image/webp;base64,'+fs.readFileSync(path.resolve(root,'source',v)).toString('base64');
global.LivingArtAssets={...raw,images};global.Image=Canvas.Image;global.document={createElement(tag){assert.equal(tag,'canvas');return Canvas.createCanvas(1,1);}};
global.localStorage={getItem(){return null;},setItem(){}};global.matchMedia=()=>({matches:false});
Canvas.GlobalFonts.registerFromPath(path.join(root,'assets/noto-sans-thai-400.woff2'),'Thai');
require('../source/scripts/living-art.js');
let checks=0;function check(v,message){assert(v,message);checks++;}
function viewFor(w,h,z=3.1,x=1230,y=1390){const f=Math.min(w/FrontierData.W,h/FrontierData.H)*z;return {view:{w,h,dpr:1},camera:{x,y,z},f,labels:true,selected:null,screenPoint(p){return{x:(p.x-x)*f+w/2,y:(p.y-y)*f+h/2};}};}
(async()=>{
 const g=new Frontier(8821);g.establish();
 const cv=Canvas.createCanvas(430,720),art=LivingInk.create(cv.getContext('2d'),FrontierData);await art.ready;
 check(Object.keys(art.images).length===2,'both local atlas images decoded');check(Object.keys(raw.sprites).length===18,'18 declared image sprites');
 for(const [id,s] of Object.entries(raw.sprites)){const im=art.images[s.atlas],[x,y,w,h]=s.rect;check(x>=0&&y>=0&&w>20&&h>20&&x+w<=im.width&&y+h<=im.height,'valid atlas rectangle '+id);}
 const before=g.serialize();const a=viewFor(430,720);for(let i=0;i<3;i++)art.render(g,a);art.minimap(Canvas.createCanvas(156,117).getContext('2d'),g);check(g.serialize()===before,'rendering and minimap leave all game/NPC/ledger/RNG bytes unchanged');
 fs.writeFileSync(path.join(out,'initial-mobile.png'),cv.toBuffer('image/png'));
 for(const n of g.heroes){const p=art.pick.get(n.id),s=a.screenPoint(n.stageLocal);check(p&&p.x===s.x&&p.y===s.y,'tap hit projection equals actual displayed feet for '+n.id);}
 const profile=LivingInk.visualProfile(g.heroes[0]);check(JSON.stringify(profile)===JSON.stringify(LivingInk.visualProfile(g.heroes[0])),'identity appearance deterministic');check(JSON.stringify(profile)!==JSON.stringify(LivingInk.visualProfile(g.heroes[1])),'two original NPCs remain visually distinct');
 art.set('quality','light');art.set('motion',false);art.set('ambience',false);art.render(g,a);check(g.serialize()===before,'light/reduced motion/daylight do not affect simulation');fs.writeFileSync(path.join(out,'light-mobile.png'),cv.toBuffer('image/png'));
 art.set('quality','rich');art.set('motion',true);art.set('ambience',true);
 g.money(10000,'QA_ONLY');g.s.wood=200;g.add(g.bank,FrontierData.ORE,200,'QA_ONLY');
 for(const [type,x,y] of [['alchemy',600,960],['forge',950,960],['market',1330,960],['garden',1650,960],['shrine',600,1600],['sanctuary',950,1600],['tower',1670,1550]]){const r=g.place(type,x,y);check(r.ok,'real building placement '+type);r.building.remaining=0;}
 while(g.heroes.length<12){const r=g.recruit();if(!r.ok)break;}
 const actions=['train','readScripture','gardenWater:qa','mine:mine','herb:grove','wood','makePersonalItem','medicine','rest','social','train','train'];
 g.heroes.forEach((n,i)=>{const p=n.stageLocal;p.x=680+(i%6)*180;p.y=1360+Math.floor(i/6)*120;p.mode=i===0?'travel':'working';p.action=actions[i];p.route=i===0?[{x:p.x+100,y:p.y+30}]:[];});
 const locked=g.serialize();art.render(g,viewFor(430,720,3.2,1120,1320));check(g.serialize()===locked,'busy sect render leaves simulation unchanged');fs.writeFileSync(path.join(out,'busy-sect-mobile.png'),cv.toBuffer('image/png'));
 cv.width=1440;cv.height=900;art.render(g,viewFor(1440,900,2.65,1540,1500));fs.writeFileSync(path.join(out,'valley-desktop.png'),cv.toBuffer('image/png'));
 const gallery=Canvas.createCanvas(1200,940),gc=gallery.getContext('2d');gc.fillStyle='#b4bd98';gc.fillRect(0,0,1200,940);let i=0;for(const type of Object.keys(FrontierData.B)){art.atlas(gc,type,190+(i%3)*410,250+Math.floor(i/3)*305,310);art.badge(gc,FrontierData.B[type].name,190+(i%3)*410,275+Math.floor(i/3)*305,16);i++;}fs.writeFileSync(path.join(out,'building-gallery.png'),gallery.toBuffer('image/png'));
 const n=g.heroes[0],b=g.s.beasts.find(b=>b.alive&&g.isHostileCreature(b));n.stageLocal.x=b.x-110;n.stageLocal.y=b.y;n.stageLocal.mode='combat';g.attack(n,b);const health=b.health;check(g.s.combat.some(e=>e.targetId===b.id),'actual combat emits a damage event');
 cv.width=600;cv.height=600;const combatState=g.serialize();art.render(g,viewFor(600,600,7,b.x,b.y));check(g.serialize()===combatState&&b.health===health,'combat effects do not apply a second hit');fs.writeFileSync(path.join(out,'combat-close.png'),cv.toBuffer('image/png'));
 const save=g.serialize(),loaded=Frontier.load(save);check(loaded.s.version===11&&loaded.heroes.length===g.heroes.length,'current v1.17 save round-trips in renderer test');
 const profileTimes={};for(const method of ['atlas','badge','drawHuman','drawNode','drawPlot','combatVfx']){const original=art[method];art[method]=function(...args){const st=performance.now(),result=original.apply(this,args);profileTimes[method]=(profileTimes[method]||0)+performance.now()-st;return result;};}
 const drawImage=art.ctx.drawImage;art.ctx.drawImage=function(...args){const st=performance.now(),result=drawImage.apply(this,args);profileTimes.drawImage=(profileTimes.drawImage||0)+performance.now()-st;return result;};
 const start=performance.now();for(let i=0;i<30;i++)art.render(g,viewFor(430,720));const ms=(performance.now()-start)/30;
 check(art.stats.terrainPixels<=5000000,'bounded ground cache');check(art.stats.visibleSprites<500,'culled scene has bounded draw count');
 const report={checks,rendererMeanMs:Number(ms.toFixed(2)),profileMsPerFrame:Object.fromEntries(Object.entries(profileTimes).map(([k,v])=>[k,Number((v/30).toFixed(2))])),backend:'@napi-rs/canvas offscreen, not a phone/browser FPS benchmark',sprites:18,simulationReadOnly:true,simulationEnvelope:11,scope:'renderer regression for 1.17',imagesGenerated:true,limitations:['Cloud browser does not allow local file URL inspection. Live browser/mobile-device FPS not verified here.']};
 fs.writeFileSync(path.join(root,'evidence/qa-art-v1.17.json'),JSON.stringify(report,null,2));console.log('LIVING_INK_V117_PASS',report);
})().catch(e=>{console.error(e.stack);process.exit(1);});
