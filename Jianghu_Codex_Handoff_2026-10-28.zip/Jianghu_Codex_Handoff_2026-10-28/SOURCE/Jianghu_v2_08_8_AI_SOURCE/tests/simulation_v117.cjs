require('./inspect-engine.cjs');const fs=require('fs'),assert=require('assert');
const F=Frontier,E=World2026Engine,H=HumanCore;
const fresh=fs.readFileSync('evidence/qa-fixture-v201.json','utf8');
function invariants(g){
 assert(Number.isFinite(g.gold)&&g.gold>=0);assert(Number.isFinite(g.s.villageHP));assert(Number.isFinite(g.s.food)&&g.s.food>=0);
 const ids=new Set();
 const owners=[...Object.values(g.world.npcs),...(g.s.growth.scriptureLibrary.length?[{id:'LIBRARY',jianghu:{ledgerV140:{scrolls:g.s.growth.scriptureLibrary}}}]:[])];
 for(const n of owners){
  if(n.core?.human)H.validate(n);
  const l=n.jianghu?.ledgerV140;if(!l)continue;
  for(const key of ['materialStacks','pillStacks','beastItems'])for(const s of l[key]||[])assert(Number.isFinite(s.count)&&s.count>=0,key+' '+s.id);
  for(const key of ['equipmentItems','scrolls'])for(const item of l[key]||[]){assert(!ids.has(item.id),'duplicate physical item '+item.id);ids.add(item.id);}
 }
 for(const n of g.heroes){
  assert(g.world.npcs[n.id]===n);
  assert(Number.isFinite(n.health));
  if(n.stageLocal.combatState)assert(Number.isFinite(n.stageLocal.combatState.qi)&&n.stageLocal.combatState.qi>=0);
  // Verify equipped items satisfy canEquipItem
  for(const eqId of Object.values(n.jianghu.equipmentV140||{})){
   if(!eqId)continue;
   const it=n.jianghu.ledgerV140.equipmentItems.find(x=>x.id===eqId);
   assert(it&&g.progression.canEquipItem(n,it).ok,'equipped item must satisfy stage/path requirements: '+eqId);
  }
 }
 // Verify TH political/military positions are never held by non-disciples
 for(const holderId of Object.values(g.world.states?.TH?.positions||{})){
  if(!holderId)continue;
  assert(g.s.heroIds.includes(holderId),'TH position holder must be a sect disciple: '+holderId);
 }
}
function support(g){g.money(18000,'QA_STARTING_INFRASTRUCTURE');g.s.wood=1500;g.add(g.bank,FrontierData.ORE,900,'QA_STARTING_INFRASTRUCTURE');
 for(const [type,x,y] of [['alchemy',600,960],['forge',950,960],['market',1330,960],['garden',1650,960],['shrine',600,1600],['sanctuary',1350,1600],['tower',1700,1250]]){const r=g.place(type,x,y);assert(r.ok,type+':'+r.reason);r.building.remaining=0;}
 while(g.heroes.length<8)assert(g.recruit().ok);g.realm.support('travel');g.progression.support();g.s.policy='balanced';
}
const results=[];
for(const scenario of ['unassisted','supported']){
 const g=F.load(fresh);if(scenario==='supported')support(g);let starts={},finishes={},events={};const send=g.send.bind(g);g.send=(n,a,t,d)=>{const ok=send(n,a,t,d);if(ok)starts[a]=(starts[a]||0)+1;return ok;};const finish=g.finish.bind(g);g.finish=n=>{const a=n.stageLocal.action;finish(n);finishes[a]=(finishes[a]||0)+1;};const receipt=g.progression.receipt.bind(g.progression);g.progression.receipt=(k,n,d)=>{events[k]=(events[k]||0)+1;receipt(k,n,d);};
 const start=performance.now();for(let day=0;day<365;day++){g.advance(20);invariants(g);if(g.s.status==='lost')break;}
 invariants(g);const after=F.load(g.serialize());invariants(after);
 const result={scenario,requestedDays:365,elapsedDays:g.s.t/20,status:g.s.status,living:g.heroes.filter(n=>n.alive).length,npcCount:g.heroes.length,villageHP:Math.round(g.s.villageHP),food:g.s.food,bankMaterialStacks:g.bank.jianghu.ledgerV140.materialStacks.length,starts,finishes,events,journeys:g.s.realm.journeys.length,library:g.s.growth.scriptureLibrary.length,discoveredArts:Object.keys(g.s.discovery.arts).length,discoveredRoutes:Object.keys(g.s.discovery.routes).length,rumorStates:g.s.discovery.rumors.reduce((m,r)=>(m[r.status]=(m[r.status]||0)+1,m),{}),invariantsPassed:true,saveLoadPassed:true,runtimeSeconds:+((performance.now()-start)/1000).toFixed(2)};
 results.push(result);console.log(JSON.stringify(result));
 fs.writeFileSync('evidence/qa-simulation-v1.17.json',JSON.stringify({pass:true,results},null,2));
}
// Resume must produce the same future actions and RNG results as uninterrupted play.
const a=F.load(fresh),b=F.load(a.serialize());a.advance(90);b.advance(90);assert.equal(a.serialize(),b.serialize(),'save/load continuation deterministic');
const data=JSON.parse(fs.readFileSync('evidence/qa-simulation-v1.17.json'));data.deterministicContinuation=true;fs.writeFileSync('evidence/qa-simulation-v1.17.json',JSON.stringify(data,null,2));console.log('SIMULATION_V117_PASS');
