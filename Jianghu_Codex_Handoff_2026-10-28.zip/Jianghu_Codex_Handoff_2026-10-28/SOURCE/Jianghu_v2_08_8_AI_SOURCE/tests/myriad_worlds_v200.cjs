/* Comprehensive Acceptance, Structural Validation, Monte Carlo Probability Sampling & Causal Flow Verification for v2.00 — Myriad Worlds (แดนหมื่นภพ) */
require('./inspect-engine.cjs');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const E = global.World2026Engine;
const H = global.HumanCore;
const F = global.Frontier;
const MWD = global.JianghuMyriadWorldsData;
const MW = global.JianghuMyriadWorlds;

const checks = [];
function check(cond, msg) {
  assert(cond, msg);
  checks.push(msg);
}

console.log('=== 1. STRUCTURAL VALIDATION & LOCKED HUMAN FOUNDATION ===');
const humanSha = crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname, '../source/scripts/human.js'))).digest('hex');
check(humanSha === 'b230108298cae486c3dc6bf6698f0384ca67128b064ff3947f19fa6e5522328a', 'Locked Human Foundation SHA256 matches b230108298cae486c3dc6bf6698f0384ca67128b064ff3947f19fa6e5522328a');

const baseGame = new F(8821);
baseGame.establish();
const freshSave = baseGame.serialize();
function freshGame() {
  const g = F.load(freshSave);
  for (const e of g.enemies) e.alive = false;
  for (const b of g.s.beasts) b.alive = false;
  g.s.campSupplies = 0;
  g.s.activation = null;
  return g;
}

const allBeasts = E.PATCH140_DATA.BEAST_SPECIES_V140;
const allMats = E.PATCH140_DATA.MATERIALS_REGISTRY_V140;
const allRecipes = Object.values(baseGame.world.jianghu.systemsV140.recipes.registry);
const matMap = new Map(allMats.map(m => [m.id, m]));
const beastMap = new Map(allBeasts.map(b => [b.id, b]));
const organMap = MWD.organMap;

check(MWD.newBeasts.length === 125, `125 new base beast species registered (actual: ${MWD.newBeasts.length})`);
check(MWD.rareOrgans.length === 40, `40 rare organs/mutations registered (actual: ${MWD.rareOrgans.length})`);
check(MWD.newMaterials.length === 235, `235 new materials registered (actual: ${MWD.newMaterials.length})`);
check(MWD.newRecipes.length === 165, `165 new recipes registered (actual: ${MWD.newRecipes.length})`);
check(MWD.experimentDesigns.length === 25, `25 property experimentation designs registered (actual: ${MWD.experimentDesigns.length})`);
check(MWD.entrances.length === 5, `5 physical entrances to แดนหมื่นภพ registered (actual: ${MWD.entrances.length})`);
check(MWD.environments.length === 15, `15 distinct environments registered (actual: ${MWD.environments.length})`);
check(MWD.pools.length === 90, `90 coherent encounter pools registered (actual: ${MWD.pools.length})`);
check(MWD.explorationEvents.length === 24, `24 exploration event chains registered (actual: ${MWD.explorationEvents.length})`);

// Validate unique IDs and foreign keys across all registries
const seenMatIds = new Set();
for (const m of allMats) {
  check(!seenMatIds.has(m.id), `Unique material ID: ${m.id}`);
  seenMatIds.add(m.id);
  check(m.tier >= 1 && m.tier <= 7, `Valid material tier for ${m.id}`);
  check(typeof m.nameTh === 'string' && m.nameTh.length > 1, `Valid Thai name for material ${m.id}`);
}

const seenBeastIds = new Set();
for (const b of allBeasts) {
  check(!seenBeastIds.has(b.id), `Unique beast species ID: ${b.id}`);
  seenBeastIds.add(b.id);
  check(b.tier >= 1 && b.tier <= 7, `Valid beast tier for ${b.id}`);
  for (const d of (b.partDrops || [])) {
    check(matMap.has(d.matId), `Beast ${b.id} drop ${d.matId} exists in material registry`);
  }
  for (const oid of (b.eligibleRareOrgans || [])) {
    check(organMap.has(oid), `Beast ${b.id} rare organ ${oid} exists in organ registry`);
  }
}

for (const r of MWD.newRecipes) {
  check(!!baseGame.world.jianghu.systemsV140.recipes.registry[r.id], `Recipe ${r.id} registered in world registry`);
  check(Array.isArray(r.inputs) && r.inputs.length > 0, `Recipe ${r.id} has non-empty inputs`);
  for (const inp of r.inputs) {
    check(matMap.has(inp.matId) && inp.count > 0, `Recipe ${r.id} input ${inp.matId} exists and count > 0`);
  }
}

for (const p of MWD.pools) {
  check(MWD.environmentMap.has(p.environmentId), `Pool ${p.id} references valid environment ${p.environmentId}`);
  check(p.weight > 0 && Number.isFinite(p.weight), `Pool ${p.id} has finite positive weight`);
  check(p.residentBeasts.length > 0, `Pool ${p.id} has resident beasts`);
  check(p.resourceEntries.length > 0, `Pool ${p.id} has resource entries`);
  for (const bid of p.residentBeasts) check(beastMap.has(bid), `Pool ${p.id} resident beast ${bid} exists`);
  for (const mid of p.resourceEntries) check(matMap.has(mid), `Pool ${p.id} resource ${mid} exists`);
}

// Verify 100% consumer coverage for all 609 materials (374 baseline + 235 new)
const consumedMats = new Set();
for (const r of [...allRecipes, ...baseGame.progression.allRecipes()]) {
  for (const inp of (r.inputs || [])) consumedMats.add(inp.matId);
  if (r.optionalCatalystMatId) consumedMats.add(r.optionalCatalystMatId);
}
for (const m of allMats) {
  check(consumedMats.has(m.id), `Every material has at least one recipe consumer: ${m.id}`);
}

console.log('=== 2. TARGETED TESTS: ANATOMY, RARE ORGANS, NON-REROLL, OVERFLOW & PROVENANCE ===');
{
  const g = freshGame();
  const n = g.heroes[0];
  // 2a. Stable individual anatomy across save/load & non-rerollable corpse harvest
  const ind1 = g.myriad.generateBeastIndividual('MW_BEAST_005', 'fixed-seed-test-1', { forceRareOrgan: true, forceRareOrganId: 'MW_ORGAN_014' });
  const ind1Repeat = g.myriad.generateBeastIndividual('MW_BEAST_005', 'fixed-seed-test-1', { forceRareOrgan: true, forceRareOrganId: 'MW_ORGAN_014' });
  check(JSON.stringify(ind1.anatomyParts) === JSON.stringify(ind1Repeat.anatomyParts), 'Individual anatomy is 100% deterministic under the same seed');
  check(ind1.rareOrgan?.organId === 'MW_ORGAN_014', 'Individual rare organ is assigned and persisted');

  // Damage by fire degrades hide/feather parts
  g.myriad.recordDamageTypeOnBeast({ individual: ind1 }, n, 'FIRE');
  g.myriad.recordDamageTypeOnBeast({ individual: ind1 }, n, 'FIRE');
  const h1 = g.myriad.harvestIndividualCorpse(n, ind1, { guaranteeOrganRecovery: true });
  check(h1.ok && h1.items.length > 0, 'First harvest of individual corpse succeeds');
  check(h1.items.some(x => x.quality === 'DAMAGED' && x.damagedReasonTh), 'Fire damage on beast degrades fragile hide/feather part quality');
  check(h1.organResult?.recovered && h1.organResult.organId === 'MW_ORGAN_014', 'Rare organ is recovered and settled into inventory');

  // Re-harvesting the same corpse must fail and grant 0 additional items
  const countBeforeReharvest = g.count(n, 'MAT_MW_ORGAN_014') + g.count(g.bank, 'MAT_MW_ORGAN_014');
  const h2 = g.myriad.harvestIndividualCorpse(n, ind1, { guaranteeOrganRecovery: true });
  const countAfterReharvest = g.count(n, 'MAT_MW_ORGAN_014') + g.count(g.bank, 'MAT_MW_ORGAN_014');
  check(!h2.ok && h2.items.length === 0 && countAfterReharvest === countBeforeReharvest, 'Re-opening or re-harvesting a corpse never rerolls anatomy or duplicates drops');

  // 2b. Inventory overflow -> Warehouse -> Deferred Claim (zero silent deletion)
  const g2 = freshGame();
  const n2 = g2.heroes[0];
  // Fill personal carry capacity
  g2.add(n2, 'MAT_ORE_BLACK_IRON_1', H.carryLimit(n2), 'FILL_PERSONAL');
  const bankBefore = g2.count(g2.bank, 'MW_MAT_HERB_001');
  const over1 = g2.myriad.settleMaterialReward(n2, 'MW_MAT_HERB_001', 3, { sourceLabel: 'QA_OVERFLOW_TO_BANK' });
  check(over1.status === 'WAREHOUSE_OVERFLOW' && over1.warehouse === 3 && g2.count(g2.bank, 'MW_MAT_HERB_001') === bankBefore + 3, 'When personal bag is full, reward overflows cleanly to sect warehouse');

  // Now fill sect warehouse to 640 stacks and verify deferred claim fallback
  g2.bank.jianghu.ledgerV140.materialStacks = Array.from({ length: 640 }, (_, i) => ({
    matId: 'DUMMY_BANK_' + i,
    nameTh: 'Dummy',
    count: 1,
    quality: 'STANDARD',
    isTranscendent: false
  }));
  const over2 = g2.myriad.settleMaterialReward(n2, 'MW_MAT_ORE_064', 2, { sourceLabel: 'QA_DEFERRED' });
  check(over2.status === 'DEFERRED_CLAIM' && over2.deferred === 2 && g2.s.myriadWorlds.deferredClaims.length === 1, 'When both personal bag and sect warehouse are full, reward is preserved in deferredClaims without silent loss');

  // Free warehouse space and claim deferred items
  g2.bank.jianghu.ledgerV140.materialStacks = [];
  const claimRes = g2.myriad.claimDeferredItems(n2);
  check(claimRes.ok && claimRes.moved === 2 && g2.count(g2.bank, 'MW_MAT_ORE_064') === 2 && g2.s.myriadWorlds.deferredClaims.length === 0, 'Deferred claims settle into storage once capacity is freed');

  // 2c. Transcendent material provenance enforcement
  const transMat = 'MW_MAT_HERB_048'; // Tier 7 transcendent fruit
  const directInvalid = E.addMaterialToLedgerV140(g2.world, n2, transMat, 1, { originType: 'WORLD_NODE', originId: 'BAD' });
  check(!directInvalid.ok, 'Global transcendent material provenance restriction remains enforced against non-heritage sources');
  const validMyriadTrans = g2.myriad.settleMaterialReward(n2, transMat, 1, { sourceLabel: 'มรดกแดนหมื่นภพ', heritageLegacyId: 'LEG_MYRIAD_WORLDS' });
  check(validMyriadTrans.ok && validMyriadTrans.isTranscendent && validMyriadTrans.originId === 'LEG_MYRIAD_WORLDS', 'Myriad Worlds transcendent drop carries valid HERITAGE_SITE provenance');
}

console.log('=== 3. CAUSAL FLOWS: MANUSCRIPTS, EXPERIMENTATION, CRAFTING & DEATH INHERITANCE ===');
{
  const g = freshGame();
  const n = g.heroes[0];
  // Build alchemy & shrine
  g.money(10000, 'QA'); g.s.wood = 1000; g.add(g.bank, FrontierData.ORE, 300, 'QA');
  const alc = g.place('alchemy', 600, 960); alc.building.remaining = 0;
  const shr = g.place('shrine', 600, 1600); shr.building.remaining = 0;

  // Flow A: Field manuscript found -> personal possession (not omnisciently known) -> studied -> crafted -> pill consumed
  const ms = g.myriad.grantRecipeManuscript(n, 'MW_REC_001', 'FIELD_MANUSCRIPT', 'ค่ายร้างในพงไพรบรรพกาล', { isFragment: true, fragmentPct: 60 });
  check(!!ms && ms.isFragment && !n.stageLocal.growth.knownRecipes.includes('MW_REC_001'), 'Found recipe fragment is a personal manuscript and not immediately unlocked');
  check(!g.heroes[1].stageLocal.growth.knownRecipes.includes('MW_REC_001'), 'Other disciples do not omnisciently learn a personal manuscript');

  // Study fragment -> complete manuscript -> learn recipe
  let studySteps = 0;
  while (!n.stageLocal.growth.knownRecipes.includes('MW_REC_001') && studySteps++ < 6) {
    g.myriad.studyRecipeManuscript(n, ms.id);
  }
  check(n.stageLocal.growth.knownRecipes.includes('MW_REC_001'), 'Studying manuscript completes fragment and unlocks recipe for the owner');

  // Provide ingredients and craft MW_REC_001 personally
  g.add(n, 'MW_MAT_HERB_001', 2, 'QA');
  g.add(n, 'MW_MAT_HERB_050', 1, 'QA');
  g.add(n, 'MW_MAT_BP_141', 1, 'QA');
  E.addSpiritStonesV140(n, 20);
  const epAlc = g.endpoint(alc.building);
  Object.assign(n.stageLocal, { x: epAlc.x, y: epAlc.y, growthTarget: 'MW_REC_001', action: 'makePersonalItem', mode: 'working', job: 0, target: epAlc });
  g.progression.start(n, 'makePersonalItem');
  const savedRng = g.rng.next; g.rng.next = () => 0.05;
  const craftRes = g.progression.finish(n, 'makePersonalItem');
  g.rng.next = savedRng;
  check(craftRes?.success, 'NPC crafts new Myriad Worlds recipe into a real item');
  const createdPill = n.jianghu.ledgerV140.pillStacks.find(p => p.recipeId === 'MW_REC_001');
  check(!!createdPill && createdPill.effect.healHealth === 26, 'Created Myriad Worlds pill has normalized executable effects');

  // Flow B: Property-based experimentation failure -> archived note -> retry with rare organ catalyst -> discovery!
  const expDesign = MWD.experimentDesigns[0];
  for (const inp of expDesign.trialInputs) g.add(g.bank, inp.matId, 5, 'QA');
  const epShr = g.endpoint(shr.building);
  Object.assign(n.stageLocal, { x: epShr.x, y: epShr.y, mwTargetId: expDesign.id, action: 'experimentPropertyRecipe', mode: 'working', job: 0, target: epShr });
  g.rng.next = () => 0.99; // Force first trial failure
  const failExp = g.myriad.finish(n, 'experimentPropertyRecipe');
  check(failExp.handled && !failExp.success, 'Failed property experiment is handled cleanly');
  check(n.stageLocal.growth.archivedResearchNotes.some(x => x.formulaId === expDesign.id), 'Failed experiment records property evidence in archivedResearchNotes without clogging scroll slots');

  // Now add optional rare organ catalyst and succeed
  if (expDesign.optionalCatalystMatId) g.add(n, expDesign.optionalCatalystMatId, 1, 'QA_CATALYST');
  g.rng.next = () => 0.05;
  const winExp = g.myriad.finish(n, 'experimentPropertyRecipe');
  g.rng.next = savedRng;
  check(winExp.handled && winExp.success && n.stageLocal.growth.knownRecipes.includes(expDesign.id), 'Subsequent experiment with catalyst and prior insight succeeds and unlocks formula');

  // Flow C: Death during expedition / combat -> fallenRemains created -> peer recovers belongings without duplication
  const peer = g.heroes[1];
  const uniqueScrollCountBefore = n.jianghu.ledgerV140.scrolls.length;
  check(uniqueScrollCountBefore > 0, 'Disciple holds manuscripts before death');
  g.damage(n, 500, null);
  check(!n.alive && n.jianghu.ledgerV140.scrolls.length === 0, 'Deceased disciple scrolls are moved to fallenRemains');
  check(g.s.myriadWorlds.fallenRemains.length === 1, 'Fallen remains record is created upon death');
  const rem = g.s.myriadWorlds.fallenRemains[0];
  const peerScrollsBefore = peer.jianghu.ledgerV140.scrolls.length;
  const recRes = g.myriad.recoverFallenRemains(peer, rem.id);
  check(recRes.ok && peer.jianghu.ledgerV140.scrolls.length === peerScrollsBefore + uniqueScrollCountBefore, 'Peer recovers exact manuscripts from fallen disciple with updated provenance');

  // Flow D: Future combat art/inheritance ID compatibility in pool
  const futureArtId = 'ART_FUTURE_COMBAT_PATH_T5';
  MWD.pools[0].futureInheritanceIds = [futureArtId];
  check(MWD.pools[0].futureInheritanceIds.includes(futureArtId), 'Pools accept future combat art/inheritance IDs without modifying the randomization engine');
}

console.log('=== 4. MONTE CARLO PROBABILITY SAMPLING ACROSS ALL 5 ENTRANCES, 15 ENVIRONMENTS & 90 POOLS ===');
{
  const g = freshGame();
  const n = g.heroes[0];
  const samplesPerEntrance = 1200; // 5 * 1,200 = 6,000 total Monte Carlo expedition rolls
  const entranceEnvCounts = {};
  const globalEnvCounts = {};
  const globalPoolCounts = {};
  const tierBeastCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  const tierMatCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  let totalRareOrgansSpawned = 0;
  let totalBeastsSpawned = 0;

  for (const ent of MWD.entrances) {
    entranceEnvCounts[ent.id] = {};
    for (let s = 0; s < samplesPerEntrance; s++) {
      const inst = g.myriad.rollMyriadWorldsInstance(ent.id, n, `${ent.id}-mc-${s}`);
      entranceEnvCounts[ent.id][inst.environmentId] = (entranceEnvCounts[ent.id][inst.environmentId] || 0) + 1;
      globalEnvCounts[inst.environmentId] = (globalEnvCounts[inst.environmentId] || 0) + 1;
      globalPoolCounts[inst.poolId] = (globalPoolCounts[inst.poolId] || 0) + 1;

      for (const enc of inst.encounters) {
        if (enc.type === 'BEAST_ENCOUNTER' && enc.individual) {
          totalBeastsSpawned++;
          const t = enc.individual.tier || 1;
          tierBeastCounts[t] = (tierBeastCounts[t] || 0) + 1;
          if (enc.individual.rareOrgan) totalRareOrgansSpawned++;
        } else if (enc.type === 'RESOURCE_NODE') {
          const t = enc.tier || 1;
          tierMatCounts[t] = (tierMatCounts[t] || 0) + 1;
        }
      }
    }
  }

  // Verify every single one of the 15 environments and all 90 pools were reached naturally in Monte Carlo sampling!
  check(Object.keys(globalEnvCounts).length === 15, `All 15 environments reached in Monte Carlo sampling (${Object.keys(globalEnvCounts).length}/15)`);
  check(Object.keys(globalPoolCounts).length === 90, `All 90 coherent pools reached in Monte Carlo sampling (${Object.keys(globalPoolCounts).length}/90)`);

  // Verify entrance equivalence: every entrance reaches all 15 environments with comparable proportions
  for (const ent of MWD.entrances) {
    const reachedEnvs = Object.keys(entranceEnvCounts[ent.id]).length;
    check(reachedEnvs === 15, `Entrance ${ent.id} reaches all 15 environments under shared probability law`);
  }

  // Verify higher-tier rarity scaling (Tier 1-3 more common than Tier 6-7)
  check(tierBeastCounts[1] + tierBeastCounts[2] + tierBeastCounts[3] > tierBeastCounts[6] + tierBeastCounts[7], 'Lower-tier beasts are statistically more common than Tier 6-7 beasts');
  check(tierMatCounts[1] + tierMatCounts[2] + tierMatCounts[3] > tierMatCounts[6] + tierMatCounts[7], 'Lower-tier materials are statistically more common than Tier 6-7 materials');
  check(totalRareOrgansSpawned > 20 && totalRareOrgansSpawned < totalBeastsSpawned * 0.25, `Rare organs spawn at a bounded uncommon rate (${totalRareOrgansSpawned}/${totalBeastsSpawned})`);

  // Persist Monte Carlo report to evidence/qa-monte-carlo-v2.00.json
  const mcReport = {
    totalSamples: samplesPerEntrance * MWD.entrances.length,
    samplesPerEntrance,
    environmentsReached: Object.keys(globalEnvCounts).length,
    poolsReached: Object.keys(globalPoolCounts).length,
    globalEnvCounts,
    samplePoolCounts: Object.fromEntries(Object.entries(globalPoolCounts).slice(0, 20)),
    entranceEquivalenceVerified: true,
    tierBeastCounts,
    tierMatCounts,
    totalBeastsSpawned,
    totalRareOrgansSpawned,
    empiricalOrganRate: +(totalRareOrgansSpawned / Math.max(1, totalBeastsSpawned)).toFixed(4)
  };
  fs.writeFileSync(path.join(__dirname, '../evidence/qa-monte-carlo-v2.00.json'), JSON.stringify(mcReport, null, 2));
  console.log('MONTE_CARLO_V200_PASS', {
    totalSamples: mcReport.totalSamples,
    environmentsReached: mcReport.environmentsReached,
    poolsReached: mcReport.poolsReached,
    empiricalOrganRate: mcReport.empiricalOrganRate
  });
}

fs.writeFileSync(path.join(__dirname, '../evidence/qa-myriad-worlds-v2.00.json'), JSON.stringify({
  release: '2.00-myriad-worlds',
  pass: true,
  checksCount: checks.length,
  sampleChecks: checks.slice(0, 40)
}, null, 2));

console.log('=== 5. CROSS-PATCH UNIFIED TESTS: NPC SLOT/COMBO/WORLD AWARENESS & COMBAT v1.17 <-> MYRIAD WORLDS v2.00 ===');
{
  const g = freshGame();
  const n = g.heroes[0];
  const peer = g.heroes[1];

  // 5a. Slot & Combo State Awareness across routes
  Object.assign(n.jianghu, { path: 'XIAN', subPath: 'SWORD_IMMORTAL' });
  E.syncNpcCultivationIdentityV1200(g.world, n, { trackOrdinal: 4, progress: 0 });
  g.combatSystem.ensure(n);
  g.combatSystem.reconcileLoadout(n, { force: true });

  const st1 = g.progression.inspectSlotAndComboState(n);
  check(st1.attackCapacity === 3, `SWORD_IMMORTAL ordinal 4 has attackCapacity 3 (actual: ${st1.attackCapacity})`);
  check(st1.openAttackSlots >= 1, `NPC recognizes open attack slots (${st1.openAttackSlots}/${st1.attackCapacity})`);
  check(Array.isArray(st1.missingSupportSlots), 'NPC recognizes missing support slots');

  // 5b. Art Suitability & Combo Synergy Scoring (Subpath + Combo Finisher vs Generic Art)
  const allTechs = g.progression.arts.filter(a => !a.innateRoute && g.progression.slot(a) === 'technique' && g.progression.compatible(n, a) && g.progression.canStudyArtTier(n, a));
  const swordTech = allTechs.find(a => a.subPath === 'SWORD_IMMORTAL') || allTechs[0];
  const offSubTech = allTechs.find(a => a.subPath && a.subPath !== 'SWORD_IMMORTAL') || allTechs[allTechs.length - 1];
  const scoreSword = g.progression.scoreArtSuitability(n, swordTech);
  const scoreOff = g.progression.scoreArtSuitability(n, offSubTech);
  check(scoreSword.eligible && scoreSword.fillsOpenSlot, 'Suitability evaluator detects open attack slot need');
  check(scoreSword.score > scoreOff.score, `Subpath-matching technique scores higher (${scoreSword.score} > ${scoreOff.score})`);

  // 5c. Smart Scroll Prioritization in refresh(n) & Epistemic World Art Knowledge
  n.jianghu.ledgerV140.scrolls = [
    { id: 'scr-off', artId: offSubTech.id, nameTh: offSubTech.nameTh, tier: offSubTech.tier || 1, count: 1, ownerNpcId: n.id, rights: 'OWNER' },
    { id: 'scr-sword', artId: swordTech.id, nameTh: swordTech.nameTh, tier: swordTech.tier || 1, count: 1, ownerNpcId: n.id, rights: 'OWNER' }
  ];
  delete n.jianghu.knowledgeV190[offSubTech.id];
  delete n.jianghu.knowledgeV190[swordTech.id];
  g.progression.refresh(n, true);
  check(n.stageLocal.growth.plan.kind === 'read' && n.stageLocal.growth.plan.targetId === swordTech.id, `NPC chooses to read the subpath/combo-fitting scroll (${swordTech.id}) over the first array item (${offSubTech.id})`);
  check(n.stageLocal.growth.seekingArtGoal && n.stageLocal.growth.seekingArtGoal.artId === swordTech.id, 'NPC sets seekingArtGoal to top suitable known art');

  // 5d. Mentor Art Candidate Scoring & Multi-Slot Reconcile After Mentor Lesson
  const mentorArt = allTechs.find(a => a.subPath === 'SWORD_IMMORTAL' && a.id !== swordTech.id) || allTechs[1];
  peer.jianghu.knowledgeV190[mentorArt.id] = { artId: mentorArt.id, stage: 5, mastery: 55, reading: 100, redistribute: true, source: 'SECT_LIBRARY' };
  const worldAw = g.progression.inspectKnownWorldArts(n);
  check(worldAw.knownArts.some(x => x.artId === mentorArt.id && x.sourceKind === 'SECT_MENTOR'), 'NPC epistemic world knowledge includes compatible arts mastered by sect peers/mentors');

  // 5e. Deliberate Harvester Discipline in Myriad Worlds with Combat v1.17 Loadout
  const fireArt = allTechs.find(a => /FIRE|FLAME|SOLAR/i.test((a.id || '') + ' ' + (a.subPath || '') + ' ' + (a.element || ''))) || { ...swordTech, id: 'TEST_FIRE_SWORD', element: 'FIRE', combat117: { role: 'attack', qi: 6, cooldown: 5, range: 150, damage: 1.1, tags: ['FIRE'] } };
  if (!g.progression.artMap.has(fireArt.id)) g.progression.artMap.set(fireArt.id, fireArt);
  if (!g.combatSystem.artMap.has(fireArt.id)) g.combatSystem.artMap.set(fireArt.id, fireArt);
  n.jianghu.knowledgeV190[fireArt.id] = { artId: fireArt.id, stage: 5, mastery: 40, reading: 100 };
  n.jianghu.knowledgeV190[swordTech.id] = { artId: swordTech.id, stage: 5, mastery: 45, reading: 100 };
  n.jianghu.attackArtIds = [fireArt.id, swordTech.id];
  n.personality.caution = 75;
  const beforeMastery = n.jianghu.knowledgeV190[swordTech.id].mastery;
  const testInst = g.myriad.rollMyriadWorldsInstance('MW_ENT_NORTH_MIST', n, 'unified-combat-harvest-test');
  const beastInd = g.myriad.generateBeastIndividual('MW_BEAST_001', 'unified-beast-1', { forceRareOrgan: true });
  beastInd.power = Math.round(g.power(n) * 0.85); beastInd.affordances = ['COMBAT'];
  testInst.encounters = [{ stepIndex: 1, type: 'BEAST_ENCOUNTER', isAnomaly: false, individual: beastInd, resolved: false }];
  g.myriad.resolveExpeditionInstance(n, testInst);
  check(beastInd.damageHistory.fireDamage === 0, 'Careful harvester with multiple attack slots avoids using FIRE technique on fire-sensitive pelt beast');
  check(n.jianghu.knowledgeV190[swordTech.id].mastery > beforeMastery, 'Fighting beasts in Myriad Worlds trains mastery on equipped attackArtIds');

  // 5f. Read-Only CombatView117 & GrowthView Verification
  const snapBefore = g.serialize();
  const cvHtml = global.CombatView117.render(g, n);
  const gvHtml = global.GrowthView.render(g, n, 'life');
  check(cvHtml.includes('ความเข้าใจชุดวิชา ช่องติดตั้ง และการต่อเคล็ด'), 'CombatView117 renders NPC Martial Awareness card');
  check(g.serialize() === snapBefore, 'CombatView117 and GrowthView remain 100% read-only');
}


console.log('=== 6. V2.10 TESTS: HIDDEN SUBPATHS, 36 WORLD ARTS, 0s CHAIN SKILLS, BUFFS/DEBUFFS & EXTERNAL MASTER TRANSMISSION ===');
{
  const g = freshGame();
  const n = g.heroes[0];
  const CD = global.CombatData117;

  // 6a. Verify 6 hidden subpaths and 36 world-discovered arts exist and are NOT in starter sectArtIds
  check(Array.isArray(CD.hiddenSubpathsV210) && CD.hiddenSubpathsV210.length === 6, '6 hidden world subpaths registered');
  check(Array.isArray(CD.worldArtsV210) && CD.worldArtsV210.length === 36, '36 world-discovered martial arts registered');
  for (const wa of CD.worldArtsV210) {
    check(!g.s.growth.sectArtIds.includes(wa.id), `Hidden world art ${wa.id} does not spawn in starter sectArtIds`);
  }

  // 6b. Verify 0-cooldown chain skill + buff/debuff application in combat
  const chainArt = CD.worldArtsV210.find(a => a.id === 'ART_V210_CHAIN_STAR_SWORD');
  const sealArt = CD.worldArtsV210.find(a => a.id === 'ART_V210_STAR_ASTRO_SEAL');
  check(chainArt && CD.mechanics(chainArt).cooldown === 0, 'ART_V210_CHAIN_STAR_SWORD has 0s cooldown');
  Object.assign(n.jianghu, { path: 'XIAN', subPath: 'STAR_SWORD_ASTROLOGY' });
  E.syncNpcCultivationIdentityV1200(g.world, n, { trackOrdinal: 4, progress: 0 });
  if (!g.progression.artMap.has(chainArt.id)) g.progression.artMap.set(chainArt.id, chainArt);
  if (!g.combatSystem.artMap.has(chainArt.id)) g.combatSystem.artMap.set(chainArt.id, chainArt);
  if (!g.progression.artMap.has(sealArt.id)) g.progression.artMap.set(sealArt.id, sealArt);
  if (!g.combatSystem.artMap.has(sealArt.id)) g.combatSystem.artMap.set(sealArt.id, sealArt);
  n.jianghu.knowledgeV190 = {
    [chainArt.id]: { artId: chainArt.id, stage: 5, mastery: 50, reading: 100 },
    [sealArt.id]: { artId: sealArt.id, stage: 5, mastery: 50, reading: 100 }
  };
  g.combatSystem.ensure(n);
  g.combatSystem.reconcileLoadout(n, { force: true });
  const dummy = { id: 'dummy-v210', alive: true, health: 5000, maxHP: 5000, power: 200, x: n.stageLocal.x + 60, y: n.stageLocal.y, stageLocal: { x: n.stageLocal.x + 60, y: n.stageLocal.y } };
  const cs = g.combatSystem.ensure(n);
  cs.qi = cs.maxQi;
  g.s.t = 200;
  g.combatSystem.schedule(n, { art: chainArt, role: 'attack', mastery: 50 }, cs);
  check(cs.cooldowns[chainArt.id] === 200, '0s cooldown skill does not lock individual skill cooldown beyond current timestamp');
  check(g.combatSystem.hasBuff(n, 'SWORD_INTENT'), 'Casting chain star sword grants SWORD_INTENT buff');

  // 6c. Verify External Envoy carries secretArtIds and can transmit to high-affinity disciple
  const fac = g.s.realm.factions[0];
  fac.relation = 45;
  const envoy = g.realm.createEnvoy(fac);
  check(Array.isArray(envoy.stageLocal.envoy.secretArtIds) && envoy.stageLocal.envoy.secretArtIds.length === 2, 'External envoy carries 2 secret hidden arts');
}

console.log('MYRIAD_WORLDS_V200_ACCEPTANCE_PASS', checks.length);
