'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs');
const E=World2026Engine,C=JianghuSectContributions,results=[];
const seed=new Frontier(20861027);seed.establish();const raw=seed.serialize();
const ORE='MAT_ORE_BLACK_IRON_1',HERB='MAT_HERB_DEW_GRASS_1',CIN='MAT_ORE_CINNABAR_1';
function game(){const g=Frontier.load(raw);g.s.t=100;for(const n of [...g.enemies,...g.s.beasts]){n.alive=false;n.health=0;}return g;}
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function faction(g,id='CN'){return g.s.realm.factions.find(f=>f.id===id);}
function setStones(owner,value){E.setSpiritStonesV140(owner,value);}
function count(g,owner,id){return g.count(owner,id);}

test('main sect buys real material from a faction and pays only spirit stones',()=>{
 const g=game(),f=faction(g),beforeSect=E.getSpiritStonesV140(g.bank),beforeFaction=E.getSpiritStonesV140(f.cache),beforeStock=count(g,f.cache,ORE),beforeSectStock=count(g,g.bank,ORE),rel=g.realm.factionRelation(f),member=g.heroes[0],meritBefore=C.account(g,member).balance;
 const q=g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,1);assert(q.ok,q.reason);assert.equal(q.currency,'SPIRIT_STONES');
 const r=g.realm.buyFromFaction(f.id,ORE,1);assert(r.ok,r.reason);assert.equal(count(g,f.cache,ORE),beforeStock-1);assert.equal(count(g,g.bank,ORE),beforeSectStock+1);assert.equal(E.getSpiritStonesV140(g.bank),beforeSect-q.totalStones);assert.equal(E.getSpiritStonesV140(f.cache),beforeFaction+q.totalStones);assert(g.realm.factionRelation(f)>rel);assert.equal(C.account(g,member).balance,meritBefore,'sect-to-sect trade must not use contribution points');assert.equal(g.s.realm.sectTrade.history[0].direction,'BUY_FROM_SECT');
});

test('main sect sells only tradeable surplus to a faction and receives spirit stones',()=>{
 const g=game(),f=faction(g),add=g.add(g.bank,ORE,30,'SECT_TRADE_SURPLUS');assert(add.ok,add.reason);const beforeSect=E.getSpiritStonesV140(g.bank),beforeFaction=E.getSpiritStonesV140(f.cache),beforeFactionStock=count(g,f.cache,ORE),beforeBank=count(g,g.bank,ORE),meritBefore=C.account(g,g.heroes[0]).balance;
 const q=g.realm.quoteSectTrade(f.id,'SELL_TO_SECT',ORE,1);assert(q.ok,q.reason);const r=g.realm.sellToFaction(f.id,ORE,1);assert(r.ok,r.reason);assert.equal(count(g,g.bank,ORE),beforeBank-1);assert.equal(count(g,f.cache,ORE),beforeFactionStock+1);assert.equal(E.getSpiritStonesV140(g.bank),beforeSect+q.totalStones);assert.equal(E.getSpiritStonesV140(f.cache),beforeFaction-q.totalStones);assert.equal(C.account(g,g.heroes[0]).balance,meritBefore,'sect-to-sect trade must not use contribution points');assert.equal(g.s.realm.sectTrade.history[0].direction,'SELL_TO_SECT');
});

test('relation improves buy price and sell price without making either price invalid',()=>{
 const g=game(),f=faction(g);f.relation=-50;const badBuy=g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,1);const badSell=g.realm.quoteSectTrade(f.id,'SELL_TO_SECT',ORE,1);f.relation=50;const goodBuy=g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,1);const goodSell=g.realm.quoteSectTrade(f.id,'SELL_TO_SECT',ORE,1);assert(badBuy.ok&&goodBuy.ok&&badSell.ok&&goodSell.ok);assert(goodBuy.unitStones<badBuy.unitStones);assert(goodSell.unitStones>badSell.unitStones);assert(goodBuy.unitStones>0&&goodSell.unitStones>0);
});


test('stock scarcity and surplus move both buy and sell quotes in the expected direction',()=>{
 const g=game(),f=faction(g),add=g.add(g.bank,ORE,30,'PRICE_TEST_SURPLUS');assert(add.ok,add.reason);const source=f.cache.jianghu.ledgerV140.materialStacks.find(x=>x.matId===ORE);assert(source);source.count=1;const scarceBuy=g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,1),scarceSell=g.realm.quoteSectTrade(f.id,'SELL_TO_SECT',ORE,1);source.count=20;const surplusBuy=g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,1),surplusSell=g.realm.quoteSectTrade(f.id,'SELL_TO_SECT',ORE,1);assert(scarceBuy.ok&&surplusBuy.ok&&scarceSell.ok&&surplusSell.ok);assert(scarceBuy.unitStones>surplusBuy.unitStones);assert(scarceSell.unitStones>surplusSell.unitStones);
});

test('all six external sects have live trade listings and distinct specialty stock',()=>{
 const g=game(),market=g.realm.sectTradeSnapshot(),specialty={CN:'MAT_HERB_JADE_LOTUS_2',SG:'MAT_HERB_MIST_ORCHID_2',IN:'MAT_HERB_CINDER_LEAF_1',JP:'MAT_HERB_CINDER_LEAF_1',VN:'MAT_HERB_BLOOD_GINSENG_3',RU:'MAT_HERB_MIST_ORCHID_2'};assert.equal(market.factions.length,6);assert.equal(new Set(market.factions.map(f=>f.id)).size,6);for(const f of market.factions){const actual=faction(g,f.id);assert(f.goods.length>0,`${f.id} must expose actual goods`);assert(f.goods.some(x=>x.factionStock>0),`${f.id} must have stock backed by its cache`);assert(E.getSpiritStonesV140(actual.cache)>0,`${f.id} must have a real wallet`);assert(count(g,actual.cache,specialty[f.id])>0,`${f.id} must expose its specialty stock`);}
});

test('invalid direction, material, or quantity never mutates inventory or wallets',()=>{
 const g=game(),f=faction(g),before=JSON.stringify({gold:E.getSpiritStonesV140(g.bank),stones:E.getSpiritStonesV140(f.cache),bank:count(g,g.bank,ORE),foreign:count(g,f.cache,ORE)});
 assert.equal(g.realm.quoteSectTrade(f.id,'TELEPORT',ORE,1).ok,false);assert.equal(g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT','NOT_A_MATERIAL',1).ok,false);assert.equal(g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,0).ok,false);assert.equal(g.realm.quoteSectTrade(f.id,'BUY_FROM_SECT',ORE,11).ok,false);assert.equal(g.realm.buyFromFaction(f.id,ORE,0).ok,false);
 assert.equal(JSON.stringify({gold:E.getSpiritStonesV140(g.bank),stones:E.getSpiritStonesV140(f.cache),bank:count(g,g.bank,ORE),foreign:count(g,f.cache,ORE)}),before);
});

test('insufficient funds, stock, and destination capacity reject trades without partial settlement',()=>{
 const g=game(),f=faction(g),beforeStock=count(g,f.cache,ORE),beforeGold=E.getSpiritStonesV140(g.bank),beforeForeign=E.getSpiritStonesV140(f.cache);setStones(g.bank,0);assert.equal(g.realm.buyFromFaction(f.id,ORE,1).ok,false);assert.equal(count(g,f.cache,ORE),beforeStock);assert.equal(E.getSpiritStonesV140(f.cache),beforeForeign);setStones(g.bank,beforeGold);
 f.cache.jianghu.ledgerV140.materialStacks=f.cache.jianghu.ledgerV140.materialStacks.filter(s=>s.matId!==ORE);assert.equal(g.realm.buyFromFaction(f.id,ORE,1).ok,false);assert.equal(E.getSpiritStonesV140(g.bank),beforeGold);
 const insolvent=game(),seller=faction(insolvent);assert(insolvent.add(insolvent.bank,ORE,30,'INSOLVENT_SECT_TEST').ok);setStones(seller.cache,0);const insolventStock=count(insolvent,insolvent.bank,ORE),insolventGold=E.getSpiritStonesV140(insolvent.bank);assert.equal(insolvent.realm.sellToFaction(seller.id,ORE,1).ok,false);assert.equal(count(insolvent,insolvent.bank,ORE),insolventStock);assert.equal(E.getSpiritStonesV140(insolvent.bank),insolventGold);const capped=game(),richFaction=faction(capped);setStones(richFaction.cache,999);assert.equal(capped.realm.quoteSectTrade(richFaction.id,'BUY_FROM_SECT',ORE,1).ok,false);
 const h=game(),target=faction(h),materials=E.PATCH140_DATA.MATERIALS_REGISTRY_V140.filter(x=>!x.isTranscendent).slice(0,E.PATCH140_CAPS?.materialStacks||24);target.cache.jianghu.ledgerV140.materialStacks=[];for(let i=0;i<materials.length;i++){const d=materials[i];target.cache.jianghu.ledgerV140.materialStacks.push({id:'cap_'+i,matId:d.id,count:1,quality:'STANDARD',ownerNpcId:target.cache.id,ownerId:target.cache.id,originId:'CAP_FIXTURE'});}const saleMat=E.PATCH140_DATA.MATERIALS_REGISTRY_V140.find(x=>!x.isTranscendent&&!target.cache.jianghu.ledgerV140.materialStacks.some(s=>s.matId===x.id))?.id;assert(saleMat,'fixture must leave at least one material id outside the filled cache');h.add(h.bank,saleMat,20,'CAPACITY_TEST');const stonesBefore=E.getSpiritStonesV140(h.bank),srcBefore=count(h,h.bank,saleMat);const q=h.realm.quoteSectTrade(target.id,'SELL_TO_SECT',saleMat,1);assert.equal(q.ok,false);assert.equal(count(h,h.bank,saleMat),srcBefore);assert.equal(E.getSpiritStonesV140(h.bank),stonesBefore);
});


test('internal store stock and operational reserve cannot be sold to another sect',()=>{
 const g=game(),f=faction(g);g.bank.jianghu.ledgerV140.materialStacks=g.bank.jianghu.ledgerV140.materialStacks.filter(s=>s.matId!==ORE);assert(g.add(g.bank,ORE,10,'STORE_RESERVED_FIXTURE').ok);const stack=g.bank.jianghu.ledgerV140.materialStacks.find(s=>s.matId===ORE);stack.storeCount=10;stack.sectStore=true;const q=g.realm.quoteSectTrade(f.id,'SELL_TO_SECT',ORE,1);assert.equal(q.ok,false);assert.equal(count(g,g.bank,ORE),10);
});

test('faction supply and wallet production stay within hard caps',()=>{
 const g=game(),f=faction(g,'VN'),state=g.s.realm;assert(g.realm.sectTradeSnapshot);const snapshot=g.realm.sectTradeSnapshot();assert(snapshot.walletCap>0&&snapshot.stockCap>0);setStones(f.cache,snapshot.walletCap-1);state.lastDay=0;g.s.t=2000;g.realm.tick(0);assert(E.getSpiritStonesV140(f.cache)<=snapshot.walletCap);for(const item of E.PATCH140_DATA.MATERIALS_REGISTRY_V140.filter(x=>!x.isTranscendent)){const qty=count(g,f.cache,item.id);if(qty>0)assert(qty<=snapshot.stockCap,`${item.id} stock exceeded cap: ${qty}`);}assert(Array.isArray(state.sectTrade.history));
});

test('sect trade history, stock, balances, and relations survive same-version save/load',()=>{
 const g=game(),f=faction(g);const r=g.realm.buyFromFaction(f.id,ORE,1);assert(r.ok,r.reason);const h=Frontier.load(g.serialize()),hf=faction(h);assert(h.s.realm.sectTrade.history.length);assert.equal(h.s.realm.sectTrade.history[0].totalStones,r.totalStones);assert.equal(E.getSpiritStonesV140(hf.cache),E.getSpiritStonesV140(f.cache));assert.equal(count(h,hf.cache,ORE),count(g,f.cache,ORE));assert.equal(h.realm.factionRelation(hf),g.realm.factionRelation(f));
});


test('v2.08.5 save without sect-trade state migrates lazily and keeps save envelope v11',()=>{
 const old=JSON.parse(raw);delete old.s.realm.sectTrade;for(const f of old.s.realm.factions){f.cache.jianghu.ledgerV140.materialStacks=f.cache.jianghu.ledgerV140.materialStacks.filter(s=>s.matId!==Object.keys({MAT_HERB_JADE_LOTUS_2:1,MAT_HERB_MIST_ORCHID_2:1,MAT_HERB_CINDER_LEAF_1:1,MAT_HERB_BLOOD_GINSENG_3:1})[0]);}const migrated=Frontier.load(JSON.stringify(old));assert(migrated.s.realm.sectTrade);assert.equal(migrated.serialize().includes('"version":11'),true);assert.equal(migrated.s.realm.sectTrade.history.length,0);assert(migrated.s.realm.factions.some(f=>count(migrated,f.cache,'MAT_HERB_JADE_LOTUS_2')>0));
});

test('diplomacy UI shows the real sect market and spirit-stone buy/sell controls',()=>{
 const g=game(),html=JianghuRealmView.render(g,'diplomacy');assert(html.includes('ตลาดการค้าระหว่างสำนัก'));assert(html.includes('หินวิญญาณ'));assert(html.includes('data-sect-trade='));assert(html.includes('สำนักมังกรหลงหยวน'));assert(html.includes('BUY_FROM_SECT'));assert(html.includes('SELL_TO_SECT'));
});

fs.writeFileSync('evidence/sect-trade-v2086.json',JSON.stringify({pass:results.every(r=>r.pass),release:'2.08.6-sect-to-sect-spirit-stone-trade',cases:results.length,results},null,2));
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
if(results.some(r=>!r.pass))process.exitCode=1;
