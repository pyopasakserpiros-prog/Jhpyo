/* Desired-behavior regressions for NPC/knowledge/save integration after the merge. */
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),path=require('path');
const E=World2026Engine,D=CombatData117;
const base=new Frontier(8821);base.establish();const save=base.serialize();
const checks=[];
function fresh(){return Frontier.load(save);}
function check(id,fn){try{const evidence=fn();checks.push({id,pass:true,evidence});}catch(e){checks.push({id,pass:false,error:e.message,actual:e.actual,expected:e.expected});}}
for(const [major,sub] of D.hiddenSubpathsV210)check('hidden_route_has_native_track_'+sub,()=>{
 const g=fresh(),n=g.heroes[0];Object.assign(n.jianghu,{path:major,subPath:sub});
 const tr=E.getCultivationTrackV1200(major,sub);
 assert.strictEqual(tr.subpathId,sub,'Hidden route must resolve to its own cultivation track');
 E.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:2,progress:97});
 const ro=E.resolveNpcCultivationIdentityReadOnlyV1200(g.world,n);
 assert.strictEqual(ro.subpathId,sub);assert.strictEqual(n.jianghu.cultivationIdentityV1200.subpathId,sub);
 assert.strictEqual(E.getRealmDefinitionV1200(ro.realmId).subpathId,sub);
 const evaluation=E.evaluateCausalBreakthroughV1200(g.world,n);
 assert.strictEqual(evaluation.transition?.subpathId,sub,'Readiness must evaluate this route transition');
 n.jianghu.evidenceLedgerV1200.totalEvidenceScore=1000;
 const start=E.startOrAdvanceBreakthroughProjectV1200(g.world,n);assert(start.ok);assert(start.project,'Hidden route must start a timed project');
 g.world.tick=start.project.phaseFinishTick;
 assert(E.stepBreakthroughProjectV1200(g.world,n,{rng:{next:()=>0}}).success);
 assert.strictEqual(n.jianghu.trackOrdinal,3);assert.strictEqual(n.jianghu.cultivationIdentityV1200.subpathId,sub);
 const loaded=Frontier.load(g.serialize()).world.npcs[n.id];
 assert.strictEqual(loaded.jianghu.subPath,sub);assert.strictEqual(loaded.jianghu.cultivationIdentityV1200.subpathId,sub);
 return {track:tr.id,realm:ro.realmId,transition:evaluation.transition?.id};
});
check('source_specific_discoveries_reach_every_non_external_world_art',()=>{
 const g=fresh(),n=g.heroes[0],seen=new Set();let seed=55377;
 g.rng.next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(const source of ['MYRIAD_WORLDS','SECRET_REALM','RUMOR_HERITAGE']){
  for(let i=0;i<1536;i++){
   n.jianghu.ledgerV140.scrolls=[];
   const book=g.progression.grantScroll(n,'World discovery',n,{danger:100,allowAnyTier:true,discoveryChannel:source});
   const art=g.progression.artMap.get(book?.artId);
   if(art?.hiddenWorldArt){assert.strictEqual(art.discoveryChannel,source);seen.add(art.id);}
  }
 }
 const expected=D.worldArtsV210.filter(a=>a.discoveryChannel!=='EXTERNAL_MASTER');
 for(const art of expected)assert(seen.has(art.id),'No natural acquisition of '+art.id);
 return {reachable:seen.size,expected:expected.length};
});
check('myriad_discoveries_can_reach_hidden_routes_before_exhausting_old_manuals',()=>{
 const g=fresh(),n=g.heroes[0],found=new Set();
 let draw=77123;g.rng.next=()=>{draw=(Math.imul(draw,1664525)+1013904223)>>>0;return draw/4294967296;};
 for(let i=0;i<1536;i++){
  const [major]=D.hiddenSubpathsV210[i%D.hiddenSubpathsV210.length];n.jianghu.path=major;
  n.jianghu.ledgerV140.scrolls=[];
  const b=g.progression.grantScroll(n,'มรดกแดนหมื่นภพ',n,{danger:100,allowAnyTier:true,discoveryChannel:'MYRIAD_WORLDS'});
  if(b){assert(!g.progression.artMap.get(b.artId)?.innateRoute);if(b.artId.startsWith('ART_V210_'))found.add(g.progression.artMap.get(b.artId).subPath);}
 }
 for(const [,sub] of D.hiddenSubpathsV210)assert(found.has(sub),'A natural Myriad reward must reach hidden route '+sub+' while ordinary old manuals remain unknown');
 return {hiddenRoutes:[...found]};
});
for(const kind of ['scrolls','equipmentItems'])check('full_remains_'+kind+'_are_recoverable_after_space_frees',()=>{
 const g=fresh(),dead=g.heroes[0],actor=g.heroes[1],cap=kind==='scrolls'?24:12;
 dead.jianghu.ledgerV140.scrolls=[];dead.jianghu.ledgerV140.equipmentItems=[];dead.jianghu.ledgerV140.materialStacks=[];
 const item={id:'unique-inherited-'+kind,nameTh:'Unique inheritance',count:1,ownerNpcId:dead.id,rights:'OWNER'};
 dead.jianghu.ledgerV140[kind]=[item];
 actor.jianghu.ledgerV140[kind]=Array.from({length:cap},(_,i)=>({id:'held-'+i,count:1}));
 g.bank.jianghu.ledgerV140[kind]=Array.from({length:120},(_,i)=>({id:'bank-'+i,count:1}));
 g.myriad.onNpcDeath(dead);const rem=g.myriad.state.fallenRemains.at(-1);
 g.myriad.recoverFallenRemains(actor,rem.id);
 assert(!rem.claimed,'Full bags must retain an unclaimed retrievable remains record');
 assert(rem[kind].some(x=>x.id===item.id));actor.jianghu.ledgerV140[kind].pop();
 const result=g.myriad.recoverFallenRemains(actor,rem.id);assert(result.ok);assert(rem.claimed);
 assert.strictEqual(actor.jianghu.ledgerV140[kind].filter(x=>x.id===item.id).length,1);
 assert(!g.myriad.recoverFallenRemains(actor,rem.id).ok);
 return {itemId:item.id,claimed:rem.claimed};
});
check('recovering_a_borrowed_scroll_returns_its_existing_owner_rights',()=>{
 const g=fresh(),borrower=g.heroes[0],owner=g.heroes[1],sessionId='inheritance-loan';
 const sc={id:'loaned-relic',artId:'ART_V210_CHAIN_STAR_SWORD',count:1,ownerNpcId:owner.id,rights:'LOAN',loan:{ownerNpcId:owner.id,borrowerNpcId:borrower.id,sessionId}};
 borrower.jianghu.ledgerV140.scrolls=[sc];
 owner.jianghu.ledgerV140.scrolls=Array.from({length:23},(_,i)=>({id:'held-'+i,count:1}));
 const loan={bookId:sc.id,ownerNpcId:owner.id,borrowerNpcId:borrower.id,sessionId,status:'ACTIVE',dueAt:g.s.t};g.s.growth.bookLoans.push(loan);
 g.myriad.onNpcDeath(borrower);const rem=g.myriad.state.fallenRemains.at(-1);
 assert(g.myriad.recoverFallenRemains(owner,rem.id).ok);
 const recovered=owner.jianghu.ledgerV140.scrolls.find(s=>s.id===sc.id);
 assert.strictEqual(recovered.ownerNpcId,owner.id);assert.strictEqual(recovered.rights,'OWNER');assert(!recovered.loan);assert.strictEqual(loan.status,'RETURNED');
 return {item:sc.id,owner:owner.id,status:loan.status};
});
check('private_bank_or_deferred_manuscript_can_be_retrieved_and_studied_only_by_owner',()=>{
 const g=fresh(),n=g.heroes[0],peer=g.heroes[1];
 n.jianghu.ledgerV140.scrolls=Array.from({length:24},(_,i)=>({id:'held'+i,count:1}));
 g.bank.jianghu.ledgerV140.scrolls=Array.from({length:120},(_,i)=>({id:'bank'+i,count:1}));
 const ms=g.myriad.grantRecipeManuscript(n,'MW_REC_001','AUDIT','Field discovery');assert(ms);
 assert(g.myriad.state.deferredClaims.some(c=>c.item?.id===ms.id||c.scroll?.id===ms.id||c.id===ms.id),'Full bags must defer the physical scroll');
 assert(!g.myriad.studyRecipeManuscript(peer,ms.id).ok);n.jianghu.ledgerV140.scrolls.pop();
 assert(g.myriad.claimDeferredItems(n).ok);assert(n.jianghu.ledgerV140.scrolls.some(s=>s.id===ms.id));
 assert(g.myriad.studyRecipeManuscript(n,ms.id).ok);assert(!peer.stageLocal.growth.knownRecipes.includes(ms.recipeId));
 return {item:ms.id,owner:n.id};
});
check('current_release_populated_save_preserves_identity_costs_and_prepared_arts',()=>{
 const g=fresh(),n=g.heroes[0];g.s.t=2400;E.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:4,progress:71});
 const cs=g.combatSystem.ensure(n);cs.qi=7;cs.cooldowns['persisted-cooldown']=2408;
 const entry={art:{id:'debt-probe',costs:{lifespanCostYears:2},combat117:{role:'forbidden',qi:1,vitality:0}},role:'forbidden'};
 assert(g.combatSystem.applyResourceCost(n,entry,cs));const lifetime=n.jianghu.lifespanMax;
 const snapshot=JSON.parse(g.serialize()),loaded=Frontier.load(JSON.stringify(snapshot)),q=loaded.world.npcs[n.id];
 assert.strictEqual(q.jianghu.lifespanMax,lifetime);assert.strictEqual(q.jianghu.combatLifespanDebt117,2);
 assert.strictEqual(q.stageLocal.combatState.qi,cs.qi);assert.strictEqual(q.stageLocal.combatState.cooldowns['persisted-cooldown'],2408);
 assert.deepStrictEqual(JSON.parse(JSON.stringify(q.jianghu.attackArtIds)),JSON.parse(JSON.stringify(n.jianghu.attackArtIds)));
 assert.strictEqual(q.jianghu.techniqueId,q.jianghu.attackArtIds[0]||null);
 assert.strictEqual(loaded.heroes[0],loaded.world.npcs[n.id]);assert.strictEqual(loaded.rng.seed,g.rng.seed);
 return {npc:n.id,qi:cs.qi,lifetime,debt:2};
});
const report={release:'2.01-merge-npc-audit',pass:checks.every(c=>c.pass),checks};
fs.writeFileSync(path.join(__dirname,'../evidence/merge-npc-v201.json'),JSON.stringify(report,null,2));
for(const c of checks)console.log(c.pass?'PASS':'FAIL',c.id,c.error||'');
console.log(JSON.stringify({pass:report.pass,total:checks.length,failed:checks.filter(c=>!c.pass).length}));
if(!report.pass)process.exitCode=1;
