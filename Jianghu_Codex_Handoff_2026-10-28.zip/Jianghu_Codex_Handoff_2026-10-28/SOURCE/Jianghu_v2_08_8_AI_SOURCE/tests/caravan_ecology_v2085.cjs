'use strict';
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs');
const C=JianghuSectContributions,E=World2026Engine,results=[];
const seed=new Frontier(22085);seed.establish();const raw=seed.serialize();
function game(){
 const g=Frontier.load(raw);g.s.t=100;g.storyEvents.activate();g.s.storyEvents.autoEvents=false;g.s.storyEvents.treasury.autoDistribute=false;g.s.life.offices.master={npcId:g.heroes[0].id};
 for(const n of [...g.enemies,...g.s.beasts]){n.alive=false;n.health=0;}
 for(const n of g.heroes){Object.assign(n.stageLocal,{offmap:null,journey:null,mode:'idle',action:null});n.stageLocal.needs.hunger=0;n.core.condition.fatigue=0;n.health=100;}
 return g;
}
function test(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function setupMarket(g){const s=C.externalMarket(g);s.autoProcure=false;s.autoSell=false;s.autoMemberTrade=false;return s;}
function forceDepartAtExit(g,s){const v=s.visitState,m=g.world.npcs[v.merchantId],exit=g.s.nodes.find(x=>x.id==='exit')||{x:3380,y:2500};v.phase='DEPARTING';s.visitorPhase='DEPARTING';m.stageLocal.externalMerchantPhase='DEPARTING';m.stageLocal.offmap=null;m.stageLocal.x=exit.x;m.stageLocal.y=exit.y;m.stageLocal.route=[];m.stageLocal.target=exit;s.lastMovementAt=g.s.t;return m;}

test('caravan appears as a visible visitor and physically approaches the market',()=>{
 const g=game(),s=setupMarket(g),v=s.visitState,m=g.world.npcs[v.merchantId];assert(v&&v.phase==='APPROACHING');assert.equal(m.stageLocal.offmap,null);assert(g.visitors.some(n=>n.id===m.id),'active merchant must be included in rendered visitor list');const start={x:m.stageLocal.x,y:m.stageLocal.y};
 for(let i=0;i<350;i++){g.s.t=+(g.s.t+.2).toFixed(6);C.tick(g);}
 assert.equal(v.phase,'TRADING','caravan should arrive and open the market');assert(g.visitors.some(n=>n.id===m.id));assert(Math.hypot(m.stageLocal.x-start.x,m.stageLocal.y-start.y)>500,'merchant must actually move through the map');assert.equal(m.stageLocal.externalMerchantPhase,'TRADING');
});

test('caravan cargo and buy-order funds are backed by finite regional stock and liquidity',()=>{
 const g=game(),pre=C.externalMarket(g),m=g.world.npcs[pre.visitState.merchantId];pre.autoProcure=false;pre.autoSell=false;pre.autoMemberTrade=false;
 const byId={};for(const o of pre.offers.filter(o=>o.kind==='MATERIAL')){const item=m.jianghu.ledgerV140.materialStacks.find(x=>x.id===o.itemId);assert(item);byId[item.matId]=(byId[item.matId]||0)+o.quantity;}const wallet=E.getSpiritStonesV140(m);
 assert(Object.keys(byId).length>0);Object.entries(pre.regionalStock.MATERIAL).forEach(([id,stock],i)=>assert.equal(stock+(byId[id]||0),i<3?12:8,'offered materials must be deducted from finite regional stock'));assert.equal(1600-pre.regionalLiquidity,wallet,'merchant cash must be funded by the regional fund, not minted');assert(pre.regionalLiquidity>=0);assert(pre.orders.every(o=>o.purseStones>0));
});

test('unsold regional cargo returns to the outside market when the caravan leaves',()=>{
 const g=game(),s=setupMarket(g),materialOffer=s.offers.find(o=>o.kind==='MATERIAL');assert(materialOffer);const id=materialOffer.itemId,m=g.world.npcs[s.visitState.merchantId],item=m.jianghu.ledgerV140.materialStacks.find(x=>x.id===id);assert(item&&item.regionalOrigin);const key=item.regionalStockKey,before=s.regionalStock.MATERIAL[key],qty=item.count;forceDepartAtExit(g,s);C.tick(g);assert.equal(s.visitState.phase,'OFFMAP');assert(m.stageLocal.offmap);assert(!g.visitors.some(n=>n.id===m.id));assert.equal(s.regionalStock.MATERIAL[key],Math.min(24,before+qty));assert(s.nextVisitAt>g.s.t);assert(s.regionalLedger.some(x=>x.kind==='RETURN_UNSOLD_CARGO'));
});

test('regional-origin goods are retained with the caravan when the regional stock cap is full',()=>{
 const g=game(),s=setupMarket(g),offer=s.offers.find(o=>o.kind==='MATERIAL');assert(offer);const m=g.world.npcs[s.visitState.merchantId],item=m.jianghu.ledgerV140.materialStacks.find(x=>x.id===offer.itemId);assert(item);const key=item.regionalStockKey,qty=item.count;s.regionalStock.MATERIAL[key]=24;forceDepartAtExit(g,s);C.tick(g);const kept=m.jianghu.ledgerV140.materialStacks.find(x=>x.id===offer.itemId);assert(kept,'cargo must not be destroyed if the outside warehouse is full');assert.equal(kept.count,qty);assert.equal(s.regionalStock.MATERIAL[key],24);assert(s.regionalLedger.some(x=>x.kind==='RETURN_UNSOLD_CARGO'&&x.retained===qty));
});

test('goods bought from disciples are exported and paid by the finite outside market',()=>{
 const g=game(),s=setupMarket(g),order=s.orders.find(o=>o.kind==='MATERIAL');assert(order,'regional market should publish at least one material purchase order');const member=g.heroes[0],merchant=g.world.npcs[order.buyerNpcId];member.jianghu.ledgerV140.materialStacks=[];assert(g.add(member,order.targetId,8,'LOCAL_SURPLUS_FOR_EXPORT',{quality:'STANDARD'}).ok);const sale=C.sellPersonalToPurchaseOrder(g,member.id,order.id,1);assert(sale.ok,sale.reason);const regionalBefore=s.regionalLiquidity,merchantBefore=E.getSpiritStonesV140(merchant);s.regionalStock.MATERIAL[order.targetId]=0;const stockBefore=s.regionalStock.MATERIAL[order.targetId];forceDepartAtExit(g,s);C.tick(g);const row=s.exports.find(x=>x.kind==='MATERIAL'&&x.itemId===order.targetId);assert(row,'purchased material should be resold to regional market');assert.equal(row.quantity,1);assert(row.stones>0);assert.equal(s.regionalStock.MATERIAL[order.targetId],stockBefore+1);assert.equal(s.regionalLiquidity,regionalBefore-row.stones);assert.equal(E.getSpiritStonesV140(merchant),merchantBefore+row.stones);assert.equal(s.totalExports,1);
});

test('regional production replenishes inventory and liquidity only up to hard caps',()=>{
 const g=game(),s=setupMarket(g);s.regionalDay=0;g.s.t=60;s.regionalLiquidity=s.regionalLiquidityCap-5;for(const id of Object.keys(s.regionalStock.MATERIAL))s.regionalStock.MATERIAL[id]=24;for(const id of Object.keys(s.regionalStock.PILL))s.regionalStock.PILL[id]=10;s.regionalStock.SCROLL=12;s.regionalStock.EQUIPMENT.L14_ironblade=4;C.tickRegionalMarket(g,s,60);assert.equal(s.regionalLiquidity,s.regionalLiquidityCap);assert(Object.values(s.regionalStock.MATERIAL).every(x=>x<=24));assert(Object.values(s.regionalStock.PILL).every(x=>x<=10));assert.equal(s.regionalStock.SCROLL,12);assert.equal(s.regionalStock.EQUIPMENT.L14_ironblade,4);assert(s.regionalLedger.some(x=>x.kind==='REGIONAL_PRODUCTION'));
});

test('regional market and merchant route persist through same-version save/load',()=>{
 const g=game(),s=setupMarket(g),h=Frontier.load(g.serialize()),ext=C.inspect(h).externalTrade;assert(ext.regionalMarket);assert.equal(ext.regionalMarket.visitorPhase,s.visitorPhase);assert.equal(ext.regionalMarket.liquidity,s.regionalLiquidity);assert.equal(ext.visitState.merchantId,s.visitState.merchantId);assert(h.visitors.some(n=>n.id===s.visitState.merchantId));
});

fs.writeFileSync('evidence/caravan-ecology-v2085.json',JSON.stringify({release:'2.08.6-sect-to-sect-spirit-stone-trade',pass:results.every(r=>r.pass),results},null,2));
for(const r of results)console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':'\n'+r.error));
if(results.some(r=>!r.pass))process.exitCode=1;
