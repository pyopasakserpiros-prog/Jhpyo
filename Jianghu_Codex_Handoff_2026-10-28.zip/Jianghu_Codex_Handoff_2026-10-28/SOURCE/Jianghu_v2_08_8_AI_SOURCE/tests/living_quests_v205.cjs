'use strict';require('./inspect-engine.cjs');
const fs=require('fs'),assert=require('assert'),raw=fs.readFileSync('evidence/qa-fixture-v201.json','utf8'),results=[];
function invariant(g){
 for(const a of Object.values(g.s.storyEvents.treasury.contributions?.accounts||{})){
  assert(Number.isFinite(a.balance)&&a.balance>=0);assert.equal(a.balance,a.earned-a.spent);
 }
 const seen=new Set();for(const n of [...Object.values(g.world.npcs),{jianghu:{ledgerV140:{scrolls:g.s.growth.scriptureLibrary}}}]){
  const l=n.jianghu?.ledgerV140;if(!l)continue;
  for(const k of ['equipmentItems','scrolls'])for(const x of l[k]||[]){assert(!seen.has(x.id),'duplicate item '+x.id);seen.add(x.id);}
  for(const k of ['materialStacks','pillStacks'])for(const x of l[k]||[])assert(Number.isFinite(x.count)&&x.count>=0);
 }
 assert(Number.isFinite(g.gold)&&g.gold>=0);assert(Number.isFinite(g.s.food)&&g.s.food>=0);
}
for(const nodeId of ['EP4_BEAST_SOVEREIGN','EP4_GRAND_ALCHEMIST']){
 const g=Frontier.load(raw);g.money(20000,'CONTROLLED_INTEGRATION_INFRASTRUCTURE');g.s.wood=2000;g.add(g.bank,FrontierData.ORE,1000,'CONTROLLED_INTEGRATION_INFRASTRUCTURE');
 for(const [type,x,y] of [['alchemy',600,960],['forge',950,960],['market',1330,960],['garden',1650,960],['shrine',600,1600],['sanctuary',1350,1600],['tower',1700,1250]]){const r=g.place(type,x,y);assert(r.ok,type+':'+r.reason);r.building.remaining=0;}
 while(g.heroes.length<8)assert(g.recruit().ok);
 for(const n of g.heroes)World2026Engine.syncNpcCultivationIdentityV1200(g.world,n,{trackOrdinal:3,progress:30});
 const fingerprints=Object.fromEntries(g.heroes.map(n=>[n.id,HumanCore.fingerprint(n)]));
 const st=g.storyEvents.activate();st.currentNodeId=nodeId;st.currentEp=4;st.completedNodeIds=['EP1_ROOT','EP2_MARTIAL',nodeId==='EP4_BEAST_SOVEREIGN'?'EP3_M2_BEAST_DOMINION':'EP3_A1_FORBIDDEN_ELIXIR'];st.completedEpisodes=[1,2,3];
 assert(JianghuSideQuests.accept(g,'SQ_SAFE_PATHS').ok);
 let started=0;const before=st.history.length;
 for(let day=0;day<140;day++){g.advance(20);invariant(g);if(day===60){const a=Frontier.load(g.serialize()),b=Frontier.load(g.serialize());a.advance(.2);b.advance(.2);assert.equal(a.serialize(),b.serialize(),'same-release saved continuation must be deterministic');}if(g.s.status==='lost')break;}
 for(const n of g.heroes)if(fingerprints[n.id]!==undefined)assert.equal(HumanCore.fingerprint(n),fingerprints[n.id]);
 const loaded=Frontier.load(g.serialize());invariant(loaded);assert.doesNotThrow(()=>loaded.storyEvents.inspect());
 results.push({nodeId,requestedDays:140,elapsedDays:g.s.t/20,status:g.s.status,living:g.heroes.filter(n=>n.alive&&n.health>0).length,finalEpisode:st.currentEp,phase:st.epPhase,storyCompletions:st.completedNodeIds.length,history:st.history.slice(0,8).map(x=>x.kind),contributionAccounts:Object.keys(st.treasury.contributions?.accounts||{}).length,contributionTransactions:st.treasury.contributions?.history.length||0,pass:true});
 fs.writeFileSync('evidence/living-quests-v205.json',JSON.stringify({controlledStartingInfrastructure:true,notes:'Starts in EP4 with canonical stage3/30% disciples and funded buildings. Tests error-free integrated execution, custody, accounts, identity and same-release save continuation; not an unassisted balance claim.',results},null,2));console.log('LIVING_QUESTS_SCENARIO',JSON.stringify(results.at(-1)));
}
console.log('LIVING_QUESTS_V205_PASS');
