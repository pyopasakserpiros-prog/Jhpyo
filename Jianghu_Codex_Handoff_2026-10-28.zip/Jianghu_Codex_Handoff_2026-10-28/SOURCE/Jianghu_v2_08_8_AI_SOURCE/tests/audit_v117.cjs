/* Behavioral integration and regression tests for v1.17 (B1–B5, AI1–AI6, L1–L5, X1–X4 + all v1.15 checks).
   Setup grants are isolated fixtures; decisions, work completion, receipts and saves use the shipped engine. */
require('./inspect-engine.cjs');
const assert=require('assert'),fs=require('fs'),crypto=require('crypto');
const E=World2026Engine,H=HumanCore,X=JianghuExpansionV112,F=Frontier;
let checks=[];function check(v,m){assert(v,m);checks.push(m);}
const base=new F(8821);base.establish();const fresh=base.serialize();
function game(){return F.load(fresh);}
function safe(g){for(const e of g.enemies)e.alive=false;for(const b of g.s.beasts)b.alive=false;g.s.campSupplies=0;g.s.activation=null;}
function building(g,type,x=600,y=1600){let b=g.built(type);if(b)return b;g.money(10000,'QA_SETUP');g.s.wood=1000;g.add(g.bank,FrontierData.ORE,300,'QA_SETUP');const r=g.place(type,x,y);assert(r.ok,r.reason);r.building.remaining=0;return r.building;}
function work(g,n,action,target,at,extra={}){Object.assign(n.stageLocal,{...extra,growthTarget:target,x:at.x,y:at.y,mode:'working',job:0,action,target:{...at},route:[]});g.progression.start(n,action);g.academy.start(n,action);g.discovery.start(n,action);return g.discovery.finish(n,action)||g.academy.finish(n,action)||g.progression.finish(n,action)||g.realm.finish(n,action);}

const lock='b230108298cae486c3dc6bf6698f0384ca67128b064ff3947f19fa6e5522328a';
check(crypto.createHash('sha256').update(fs.readFileSync('source/scripts/human.js')).digest('hex')===lock,'68-axis Human Foundation file remains 100% unchanged');

for(const n of base.heroes){
 check(LivingDiscovery.TRADITIONS[n.jianghu.path]?.includes(n.jianghu.subPath),'recruits start with sect traditions');
 check(n.jianghu.knownArtIdsV150.every(id=>base.s.growth.sectArtIds.includes(id)&&!id.startsWith('ART_V112_')),'starter knowledge comes from the sect curriculum');
}

// All expansion data must have paths into the actual local gameplay.
const mats=new Map(E.PATCH140_DATA.MATERIALS_REGISTRY_V140.map(m=>[m.id,m])),species=new Map(E.PATCH140_DATA.BEAST_SPECIES_V140.map(s=>[s.id,s]));
const reg=base.world.jianghu.systemsV140.recipes.registry;
for(const r of [...X.recipes,...X.recipesV114]){check(!!reg[r.id]&&base.recipes.some(x=>x.id===r.id),'recipe registered and usable by workshop: '+r.id);for(const i of r.inputs)check(mats.has(i.matId),'recipe input exists: '+i.matId);}
for(const [habitat,ids]of Object.entries(X.habitatPoolsV114))for(const id of ids)check(species.has(id),'habitat uses registered species: '+habitat+'/'+id);
for(const s of [...X.beasts,...X.beastsV114])for(const d of s.partDrops||[])check(mats.has(d.matId),'beast drop material exists: '+d.matId);

// [B1 & X2] Sect storage capacity (>24 material stacks) and deposit conservation / false-success prevention
{
 const g=game();safe(g);const n=g.heroes[0],ep=g.endpoint(g.built('hall'));
 const allMatIds=E.PATCH140_DATA.MATERIALS_REGISTRY_V140.filter(m=>!m.isTranscendent).map(m=>m.id);
 for(let i=0;i<32;i++)check(g.add(g.bank,allMatIds[i%allMatIds.length],2,'QA_STACK_'+i,{quality:i>=allMatIds.length?'GOOD':'STANDARD'}).ok,'sect bank accepts >24 material stacks (stack '+i+')');
 check(g.bank.jianghu.ledgerV140.materialStacks.length>24,'sect warehouse holds more than 24 distinct material stacks');
 check(n.jianghu.ledgerV140.materialStacks.length<=24,'personal inventory still enforces 24-stack cap');

 // Now test deposit conservation when bank is artificially capped at current stacks
 const rareMat='MAT_ORE_CLOUD_JADE_3';
 g.add(n,rareMat,4,'QA_RARE');
 const beforeNpcCount=g.count(n,rareMat),beforeBankCount=g.count(g.bank,rareMat);
 Object.assign(n.stageLocal,{x:ep.x,y:ep.y,action:'deposit',mode:'working',job:0,target:ep});
 g.finish(n);
 check(g.count(g.bank,rareMat)===beforeBankCount+4&&g.count(n,rareMat)===0,'deposit moves exact material count into warehouse without loss');

 // Test blocked deposit when bank cannot accept new stack
 g.bank.jianghu.ledgerV140.materialStacks=Array.from({length:640},(_,i)=>({matId:'DUMMY_'+i,nameTh:'Dummy',count:1,quality:'STANDARD',isTranscendent:false}));
 g.add(n,'MAT_ORE_THUNDER_IRON_4',3,'QA_BLOCKED');
 const beforeBlocked=g.count(n,'MAT_ORE_THUNDER_IRON_4');
 const memBefore=n.stageLocal.memories.length;
 check(g.transferableDepositCount(n)===0,'transferableDepositCount is 0 when warehouse is completely full');
 check(!g.options(n).some(o=>o.id==='deposit'),'deposit option is not offered when warehouse cannot accept any carried items');
 Object.assign(n.stageLocal,{x:ep.x,y:ep.y,action:'deposit',mode:'working',job:0,target:ep});
 g.finish(n);
 check(g.count(n,'MAT_ORE_THUNDER_IRON_4')===beforeBlocked,'blocked deposit never deletes items from NPC inventory');
 check(n.stageLocal.memories[0]?.valence<0,'blocked deposit records failure rather than false-positive success memory');
}

// [B2 & L4] Transcendent materials from expeditions & Edit Hub, plus expedition equipmentRecipeId settlement
{
 const g=game();safe(g);const n=g.heroes[0];
 const peachGrant=JianghuSafeEditor.grantMaterial(g,'MAT_HERB_IMMORTAL_PEACH_6',2);
 const jadeGrant=JianghuSafeEditor.grantMaterial(g,'MAT_ORE_CHAOS_VOID_JADE_6',2);
 check(peachGrant.ok&&jadeGrant.ok,'Edit Hub grants transcendent materials with valid heritage provenance');
 check(g.count(g.bank,'MAT_HERB_IMMORTAL_PEACH_6')===2&&g.count(g.bank,'MAT_ORE_CHAOS_VOID_JADE_6')===2,'transcendent materials are stored in sect bank');

 // Expedition settlement with transcendent material and equipmentRecipeId
 const kunlun=LivingJianghuSystem.SITES.find(s=>s.id==='SITE_KUNLUN_GROTTO');
 const j={id:'qa-kunlun',npcId:n.id,siteId:kunlun.id,createdAt:g.s.t,phase:'away',resolved:false,outcome:null,loot:[],returnAt:g.s.t};
 g.s.realm.journeys.unshift(j);n.stageLocal.journey=j.id;n.stageLocal.offmap={kind:'realmJourney',journeyId:j.id};
 const origRoll=X.rollExpeditionTreasure;
 X.rollExpeditionTreasure=()=>({matId:'MAT_HERB_IMMORTAL_PEACH_6',count:1,equipmentRecipeId:'REC1140_ARM_DREAM_MOTH_ROBE',pool:{siteId:kunlun.id}});
 const origNext=g.rng.next;g.rng.next=()=>0.99;
 g.realm.resolveJourney(n,j);
 g.rng.next=origNext;X.rollExpeditionTreasure=origRoll;
 check(j.outcome==='success'&&g.count(n,'MAT_HERB_IMMORTAL_PEACH_6')>=1,'expedition delivers transcendent material with valid HERITAGE_SITE origin');
 check(j.recipeReward&&n.jianghu.knownRecipeIdsV140.includes('REC1140_ARM_DREAM_MOTH_ROBE'),'expedition settles equipmentRecipeId into real recipe knowledge and relic reward');
 // Also verify transferring transcendent material to bank preserves provenance
 const tr=g.transferMaterialStack(n,g.bank,'MAT_HERB_IMMORTAL_PEACH_6',1,'QA_DEPOSIT_TRANSCENDENT');
 check(tr.ok&&tr.moved===1,'transcendent material stack transfers cleanly between disciple and sect bank');
}

// [B3] Unified pill consumption semantics, jade-inventory effect labels, and sect commission delivery to bank
{
 const g=game();safe(g);const n=g.heroes[0];
 // Test L14_clarity (grief + toxicity) via both consumePillFromLedgerV150 and usePersonalPill
 n.core.human.state.grief=40;n.jianghu.pillToxicity=10;
 const clarityPill={id:'QA_CLARITY',recipeId:'L14_clarity',nameTh:'โอสถประคองใจ',tier:1,count:2,livingEffect:{grief:12,toxicity:1}};
 n.jianghu.ledgerV140.pillStacks.push(clarityPill);
 check(g.hasUsefulPill(n)&&g.chooseUsefulPill(n)?.id==='QA_CLARITY','hasUsefulPill recognizes L14 livingEffect grief pill');
 const res1=E.consumePillFromLedgerV150(g.world,n.id,'QA_CLARITY');
 check(res1.ok&&n.core.human.state.grief===28&&n.jianghu.pillToxicity===11,'consumePillFromLedgerV150 applies L14 grief and exact toxicity once');

 // Test REC1110_ALC_LONGEVITY_ELIXIR_3 (lifespanBonusYears + healHealth + foundationBonus)
 const beforeLife=n.jianghu.lifespanMax,beforeFound=n.jianghu.foundationStability;
 n.health=60;
 const longPill={id:'QA_LONGEVITY',recipeId:'REC1110_ALC_LONGEVITY_ELIXIR_3',nameTh:'โอสถอายุวัฒนะโสมโลหิต',tier:3,count:1,effect:{lifespanBonusYears:12,healHealth:30,foundationBonus:8,toxicity:6}};
 n.jianghu.ledgerV140.pillStacks.push(longPill);
 const res2=E.consumePillFromLedgerV150(g.world,n.id,'QA_LONGEVITY');
 check(res2.ok&&n.jianghu.lifespanMax===beforeLife+12&&n.health===90&&n.jianghu.foundationStability===beforeFound+8,'consumePillFromLedgerV150 applies lifespanBonusYears, healHealth, and foundationBonus');

 // Test REC1140_ALC_FROST_DETOX_PILL_3 (purifyPillToxicity + clearPoison + healInternalInjury)
 n.jianghu.pillToxicity=35;n.jianghu.poisonAccumulated=25;n.jianghu.internalInjury=20;
 const detoxPill={id:'QA_DETOX',recipeId:'REC1140_ALC_FROST_DETOX_PILL_3',nameTh:'โอสถจันทราเหมันต์สลายพิษ',tier:3,count:1,effect:{purifyPillToxicity:28,clearPoison:20,healInternalInjury:15,toxicity:2}};
 n.jianghu.ledgerV140.pillStacks.push(detoxPill);
 const res3=E.consumePillFromLedgerV150(g.world,n.id,'QA_DETOX');
 check(res3.ok&&n.jianghu.pillToxicity===9&&n.jianghu.poisonAccumulated===5&&n.jianghu.internalInjury===5,'detox pill purifies pillToxicity, clearPoison, and internalInjury accurately');

 // Verify Jade Inventory renders effect summary for personally crafted L14 pills
 const craftedPill={id:'QA_CRAFTED_L14',recipeId:'L14_remedy',catalogId:'L14_remedy',nameTh:'โอสถสมานแผล',tier:1,count:1,livingEffect:{heal:22,pain:6}};
 n.jianghu.ledgerV140.pillStacks.push(craftedPill);
 const collected=JianghuInventory1222.collect(E,g.world,n);
 const cItem=collected.find(x=>x.catalogId==='QA_CRAFTED_L14');
 const invHtml=JianghuInventory1222.render(E,g.world,n,{category:'PILL',selected:cItem.key,detailTab:'effects'});
 check(invHtml.includes('ฟื้นฟูสุขภาพ')&&invHtml.includes('ประคองบาดแผลและความเจ็บปวด'),'Jade Inventory displays full effect description for personally crafted L14 pills');
}

// [B4 & B5] Actor role separation, political office sync, bandit naming, and visitor martial initialization
{
 const g=game();
 const positions=Object.values(g.world.states.TH.positions).filter(Boolean);
 for(const id of positions){
  check(g.s.heroIds.includes(id),'every TH state position holder is an actual sect disciple (not bank/bandit/service/visitor)');
 }
 const bandits=g.enemies.filter(e=>!e.stageLocal.boss);
 check(bandits.length>=2&&bandits.every(b=>b.name==='โจรผาทมิฬ'),'non-boss bandits retain their exact bandit name without random disciple name mutation');
 check(!JianghuSafeEditor.listNpcs(g).some(n=>n.id===g.bank.id||n.stageLocal?.enemy),'default Edit Hub listNpcs returns only sect disciples');
 check(!JianghuSafeEditor.editNpc(g,g.bank.id,{name:'Hacked'}).ok,'Edit Hub blocks editing the sect storage pseudo-NPC');

 // Spawn courier visitor and verify they do NOT pollute sectArtIds or public recipes before joining
 const sectArtsBefore=[...g.s.growth.sectArtIds];
 check(g.life.announceCourier()===true, "announceCourier spawns courier story");const courier=g.world.npcs[g.s.life.story.actorId];
 check(courier.stageLocal.visitor===true&&courier.stageLocal.role==='courier','courier is initialized as a visitor with role courier');
 check(!courier.stageLocal.growth,'visitor does not run disciple progression.initialize before joining');
 check(JSON.stringify(g.s.growth.sectArtIds)===JSON.stringify(sectArtsBefore),'visitor creation does not pollute sectArtIds');
 check(!Object.values(g.world.states.TH.positions).includes(courier.id),'visitor is never appointed to TH state offices');
}

// [AI1 & Combat] Bandit combat power coherence, validEquippedArt check, and smart retreat/defend
{
 const g=game();
 const hero=g.heroes[0],minion=g.enemies.find(e=>!e.stageLocal.boss),boss=g.enemies.find(e=>e.stageLocal.boss);
 check(g.power(minion)<g.power(hero)*1.35,'starting minion is a bounded team challenge under the same body-derived rules');
 check(g.power(boss)>g.power(minion)&&g.power(boss)<g.power(hero)*1.6,'bandit boss is a fair tactical challenge without 1,390+ unlearned art inflation');

 // Verify unlearned template art IDs do not inflate maxQi or incoming defense
 minion.jianghu.mantraId='MANTRA_MOONLIGHT_ILLUSION_QI'; // unlearned!
 const qiWithUnlearned=g.combatSystem.maxQi(minion);
 minion.jianghu.mantraId=null;
 const qiWithout=g.combatSystem.maxQi(minion);
 check(qiWithUnlearned===qiWithout,'unlearned mantraId does not grant free maxQi');

 // Verify smart retreat destination avoids enemies attacking the hall
 const raidBandit=g.bandit(false,950,1360);raidBandit.stageLocal.raid=true;
 hero.stageLocal.x=950;hero.stageLocal.y=1365;hero.health=30;
 const dest=g.chooseRetreatDestination(hero,raidBandit);
 check(Math.hypot(dest.x-raidBandit.stageLocal.x,dest.y-raidBandit.stageLocal.y)>200,'chooseRetreatDestination avoids retreating onto a hall under bandit attack');
}

// [AI2] All 9 companion beasts spawned & context-sensitive threatAt
{
 const g=game();
 check(g.s.realm.pets.length===9,'all 9 spirit beast species from SPIRIT_BEAST_CATALOG_V300 spawn on the map');
 check(g.s.realm.pets.some(p=>p.speciesId==='KING_GOLDEN_BODHI_DEER')&&g.s.realm.pets.some(p=>p.speciesId==='KING_THUNDER_QILIN'),'Golden Bodhi Deer and Thunder Qilin are present and reachable');
 const hero=g.heroes[0];
 const weakWolf=g.s.beasts.find(b=>b.alive&&b.tier===1);
 if(weakWolf){
  hero.health=100;hero.core.condition.fatigue=0;
  // This assertion concerns one wolf; a pack is a different tactical threat.
  for(const b of g.s.beasts)if(b!==weakWolf)b.alive=false;
  // Boost hero power to Stage 3 so a single tier-1 wolf is trivial
  E.syncNpcCultivationIdentityV1200(g.world,hero,{trackOrdinal:3,progress:50});
  check(g.realm.threatAt(weakWolf,400)===true,'raw threatAt without actor still detects presence of hostile beast');
  check(g.realm.threatAt(weakWolf,400,hero)===false,'context-sensitive threatAt(p, r, actor) allows strong disciple to work near weak tier-1 beast');
 }
}

// [AI3] Sanctuary spirit beasts are non-hostile sect residents
{
 const g=game();safe(g);
 building(g,'sanctuary',1350,1600);
 building(g,'tower',1670,1550);
 const qilin=g.spawnBeast('sect-sanctuary','BEAST_CLOUD_QILIN_CALF');
 check(qilin&&qilin.sanctuaryResident===true&&qilin.hostile===false&&!g.isHostileCreature(qilin),'sanctuary beast is marked non-hostile SECT_SANCTUARY resident');
 const hero=g.heroes[0];
 hero.stageLocal.x=qilin.x+20;hero.stageLocal.y=qilin.y+20;
 const hpBefore=qilin.health,heroHpBefore=hero.health;
 g.step(0.1);
 check(qilin.health===hpBefore&&hero.health===heroHpBefore,'towers, disciples, and sanctuary beasts never attack each other');
 check(!g.options(hero).some(o=>o.id==='hunt'&&o.target?.id===qilin.id),'disciples never generate hunt options against sanctuary beasts');
}

// [AI4] Breakthrough readiness & seclusion phase locking
{
 const g=game();safe(g);const n=g.heroes[0];
 n.jianghu.cultivationProgress=99.2;
 E.syncNpcCultivationIdentityV1200(g.world,n,{progress:99.2});
 // When gates are not met (e.g. comprehension/foundation/stones missing), breakthrough is not spammed
 E.setSpiritStonesV140(n,0);
 check(!g.canAdvanceBreakthroughNow(n),'canAdvanceBreakthroughNow is false when spirit stones / gates are unmet');
 check(!g.options(n).some(o=>o.id==='breakthrough'),'breakthrough option is not offered when NPC cannot start or advance a breakthrough');

 // When a project is in PROCURE or PAUSED, updateHero does NOT lock the NPC in seclusion
 n.jianghu.breakthroughProjectV1200={id:'QA_BT_PROCURE',phase:'PROCURE',statusCode:'PROCURING_MEDIA_AND_INSIGHT',phaseFinishTick:g.world.tick+5};
 g.updateHero(n,0.1);
 check(n.stageLocal.action!=='seclusion','PROCURE phase does not lock disciple in training hall seclusion');
 n.jianghu.breakthroughProjectV1200.phase='SECLUDE';
 n.jianghu.breakthroughProjectV1200.statusCode='IN_SECLUSION';
 g.updateHero(n,0.1);
 check(n.stageLocal.action==='seclusion','SECLUDE phase properly locks disciple in closed-door seclusion');
 n.jianghu.breakthroughProjectV1200=null;
}

// [AI5 & X1] Research prioritization, failed notebook archiving, and transactional book loan return
{
 const g=game();safe(g);const [teacher,student]=g.heroes;
 building(g,'alchemy',600,960);
 const design=g.academy.designs[0],ep=g.endpoint(g.built('alchemy'));
 student.stageLocal.growth.hasResearchExperience=true;
 E.addSpiritStonesV140(student,100);
 for(const inp of design.trialInputs)g.add(g.bank,inp.matId,30,'QA_RESEARCH');
 // Verify startResearch is offered even when routine practiceScripture exists
 const opts=g.options(student);
 check(opts.some(o=>o.id==='startResearch'),'startResearch is offered alongside routine scripture practice');
 check(work(g,student,'startResearch',null,ep,{academyTargetId:design.id}).success,'startResearch creates an active research project and notebook');
 const proj=g.academy.activeProjectForNpc(student);
 check(!!proj&&student.jianghu.ledgerV140.scrolls.some(s=>s.id===proj.notebookId),'research notebook is in scrolls during active project');
 // Force 5 failed trials and verify the failed notebook is archived out of physical scrolls
 const origRng=g.rng.next;g.rng.next=()=>0.999;
 for(let t=0;t<5;t++){
  const res=work(g,student,'continueResearch',null,ep,{academyTargetId:design.id});
  if(t<4)check(res.success,'intermediate research trial completes');
  else check(res.success===false,'5th failed trial returns success:false so no false-positive memory is recorded');
 }
 g.rng.next=origRng;
 check(proj.status==='FAILED','project status is FAILED after 5 unsuccessful trials');
 check(!student.jianghu.ledgerV140.scrolls.some(s=>s.id===proj.notebookId),'failed research notebook is archived out of physical scroll bag');
 check(student.stageLocal.growth.archivedResearchNotes.some(a=>a.projectId===proj.id),'failed research note is preserved in archivedResearchNotes');
 check(g.academy.priorFailedInsightBonus(student,design.id)===10,'archived research note grants +10% starting insight bonus on retry');

 // [X1] Transactional returnLoan when owner's scroll bag is full (24/24)
 const loanedBook={id:'QA_LOAN_BOOK',artId:teacher.jianghu.techniqueId,nameTh:'คัมภีร์ทดสอบยืม',tier:1,count:1,rights:'LOAN',ownerNpcId:teacher.id,loan:{ownerNpcId:teacher.id,borrowerNpcId:student.id,sessionId:'qa-sess-1',dueAt:g.s.t+10}};
 student.jianghu.ledgerV140.scrolls.push(loanedBook);
 const loanRec={bookId:loanedBook.id,ownerNpcId:teacher.id,borrowerNpcId:student.id,sessionId:'qa-sess-1',status:'ACTIVE',startedAt:g.s.t,dueAt:g.s.t+10};
 g.s.growth.bookLoans.push(loanRec);
 // Fill teacher's scroll bag to 24
 teacher.jianghu.ledgerV140.scrolls=Array.from({length:24},(_,i)=>({id:'FILL_'+i,artId:'DUMMY',nameTh:'Dummy '+i,count:1,rights:'OWNER',ownerNpcId:teacher.id}));
 check(g.academy.returnLoan(loanRec)===false,'returnLoan returns false when owner bag is full (24/24)');
 check(loanRec.status==='PENDING_RETURN'&&loanedBook.rights==='LOAN'&&loanedBook.ownerNpcId===teacher.id&&!!loanedBook.loan,'book remains LOAN owned by teacher while pending return (never hijacked by borrower)');
 // Free 1 slot in teacher's bag and retry
 teacher.jianghu.ledgerV140.scrolls.pop();
 check(g.academy.returnLoan(loanRec)===true,'returnLoan succeeds once owner has space');
 check(loanRec.status==='RETURNED'&&teacher.jianghu.ledgerV140.scrolls.includes(loanedBook)&&loanedBook.rights==='OWNER'&&!loanedBook.loan,'book returns cleanly to teacher with OWNER rights');
}

// [L1] Inheritance adoption unlocks a usable foundation for DEMON / HEART_SOUL
{
 const g=game();safe(g);const n=g.heroes[0],ep=g.endpoint(g.built('training'));
 // Test adopting a DEMON subpath (whose lowest technique in MANUALS_V112 is Tier 2)
 const demonArt=X.manualsV112.find(a=>a.path==='DEMON'&&a.subPath==='VENOM_GU_SOVEREIGN');
 const dBook={id:'QA_DEMON_BOOK',artId:demonArt.id,nameTh:demonArt.nameTh,tier:demonArt.tier,count:1,rights:'OWNER',ownerNpcId:n.id,sourceType:'DISCOVERY',originLabelTh:'แท่นบูชาพิษกู่'};
 n.jianghu.ledgerV140.scrolls.push(dBook);g.discovery.recordFind(n,dBook);
 let tries=0;while(!g.discovery.state(n).routes[g.discovery.routeKey(demonArt)]&&tries++<20)work(g,n,'decipherInheritance',dBook.id,ep);
 check(work(g,n,'adoptInheritance',dBook.id,ep).success,'NPC adopts DEMON inheritance');
 check(n.jianghu.path==='DEMON'&&n.jianghu.subPath==='VENOM_GU_SOVEREIGN'&&n.jianghu.trackOrdinal===1,'NPC is now Stage 1 DEMON / VENOM_GU_SOVEREIGN');
 check(g.combatSystem.activeArts(n).length>=1,'adopted DEMON cultivator immediately has a usable foundational art at Stage 1');
 check(g.progression.canStudyArtTier(n,demonArt),'adopted DEMON cultivator can study their Tier 2 foundational inheritance art at Stage 1');

 // Also test HEART_SOUL adoption and firstPractitioner recording (original v1.15 regression)
 g.s.t+=1300;
 const soulArt=X.manualsV112.find(a=>a.path==='HEART_SOUL'&&a.tier===1);
 const sBook={id:'QA_PRIVATE',artId:soulArt.id,nameTh:soulArt.nameTh,tier:1,count:1,rights:'OWNER',ownerNpcId:n.id,sourceType:'DISCOVERY',originLabelTh:'ห้องหินใต้ศาลร้าง'};
 n.jianghu.ledgerV140.scrolls.push(sBook);g.discovery.recordFind(n,sBook);
 tries=0;while(!g.discovery.state(n).routes[g.discovery.routeKey(soulArt)]&&tries++<20)check(work(g,n,'decipherInheritance',sBook.id,ep).success,'decipher inheritance uses real work');
 check(g.discovery.routeKnown(n,soulArt),'deciphering unlocks personal route knowledge');
 check(work(g,n,'adoptInheritance',sBook.id,ep).success,'NPC can adopt a decoded HEART_SOUL inheritance');
 tries=0;while((n.jianghu.knowledgeV190[soulArt.id]?.stage||0)<4&&tries++<20)check(work(g,n,'readScripture',soulArt.id,ep).success,'reading grows real knowledge');
 check(g.discovery.data.arts[soulArt.id].firstPractitionerId===n.id,'first practitioner recorded after learning');
 check(g.combatSystem.learned(n,soulArt),'newly learned manual is an eligible loadout candidate; NPC may prefer another known art');
}

// [L2] Non-destructive comparative scripture deduction (synthesizeScriptures)
{
 const g=game();safe(g);const n=g.heroes[0],ep=g.endpoint(g.built('training'));
 E.addSpiritStonesV140(n,50);
 const samePathArts=X.manualsV112.filter(a=>a.path===n.jianghu.path&&(a.tier||1)===1);
 if(samePathArts.length>=2){
  const [a1,a2]=samePathArts;
  const s1={id:'QA_SYN_1',artId:a1.id,nameTh:a1.nameTh,tier:1,count:1,rights:'OWNER',ownerNpcId:n.id,sourceType:'DISCOVERY'};
  const s2={id:'QA_SYN_2',artId:a2.id,nameTh:a2.nameTh,tier:1,count:1,rights:'OWNER',ownerNpcId:n.id,sourceType:'DISCOVERY'};
  n.jianghu.ledgerV140.scrolls.push(s1,s2);
  n.jianghu.knowledgeV190[a1.id]={artId:a1.id,stage:4,mastery:25,reading:100};
  n.jianghu.knowledgeV190[a2.id]={artId:a2.id,stage:4,mastery:25,reading:100};
  const origRng=g.rng.next;
  // First test failed deduction: both source scrolls MUST remain intact!
  g.rng.next=()=>0.999;
  const failRes=work(g,n,'synthesizeScriptures',s1.id+'|'+s2.id,ep);
  check(failRes.handled&&failRes.success===false,'failed scripture deduction returns success:false');
  check(n.jianghu.ledgerV140.scrolls.includes(s1)&&n.jianghu.ledgerV140.scrolls.includes(s2),'failed scripture deduction NEVER destroys the 2 source manuscripts');
  // Now test successful deduction: both source scrolls remain intact AND a new higher-tier manual is created!
  n.stageLocal.growth.deducedPairs={};
  g.rng.next=()=>0.01;
  const okRes=work(g,n,'synthesizeScriptures',s1.id+'|'+s2.id,ep);
  g.rng.next=origRng;
  check(okRes.handled&&okRes.success===true&&!!okRes.item,'successful scripture deduction creates a new synthesized scroll');
  check(n.jianghu.ledgerV140.scrolls.includes(s1)&&n.jianghu.ledgerV140.scrolls.includes(s2)&&n.jianghu.ledgerV140.scrolls.includes(okRes.item),'both original scrolls and the newly deduced scroll are in inventory');
 }
}

// [L3] Persistent career plan when injured & targeted beast hunting for missing MAT_BP_*
{
 const g=game();safe(g);const n=g.heroes[0];
 n.jianghu.equipmentV140={};n.jianghu.ledgerV140.equipmentItems=[];
 building(g,'forge',950,960);
 n.stageLocal.growth.career='forge';
 n.stageLocal.growth.nextPlan=0;
 g.progression.refresh(n,true);
 const careerTarget=n.stageLocal.growth.careerPlan?.targetId;
 check(careerTarget==='L14_ironblade','forge disciple selects L14_ironblade as careerPlan');
 // Give the disciple 2 ORE for their ironblade, then injure them to health 50
 g.add(n,FrontierData.ORE,2,'QA_FORGE_RESERVE');
 n.health=50;
 g.progression.refresh(n,true);
 check(n.stageLocal.growth.careerPlan?.targetId==='L14_ironblade','careerPlan is preserved even when disciple is injured');
 check(g.progression.reserve(n,FrontierData.ORE)>=2,'injured forge disciple still reserves their forging ORE and does not dump it into bank');
 // Spawn a wolf when FANG is missing from bank and verify targeted hunt option is offered
 g.consume(g.bank,FrontierData.FANG,g.count(g.bank,FrontierData.FANG));
 n.health=90;n.stageLocal.growth.nextPlan=0;
 const wolf=g.spawnBeast('wolf-forest','BEAST_MIST_WOLF');
 const opts=g.options(n);
 check(opts.some(o=>o.id==='hunt'&&o.huntForMatId===FrontierData.FANG),'disciple offers targeted hunt option when crafting recipe requires a missing beast part');
}

// [L5] Real food scarcity & village resupply action
{
 const g=game();safe(g);const n=g.heroes[0],ep=g.endpoint(g.built('hall')),vLoc=FrontierData.LOCS.find(l=>l.id==='village');
 g.s.food=0;n.stageLocal.needs.hunger=60;
 check(!g.options(n).some(o=>o.id==='eat'),'eat is not offered when sect food is 0');
 check(g.options(n).some(o=>o.id==='resupplyFood'),'resupplyFood at village is offered when sect food is 0');
 Object.assign(n.stageLocal,{x:ep.x,y:ep.y,action:'eat',mode:'working',job:0,target:ep});
 g.finish(n);
 check(g.s.food===0,'eating at 0 food fails honestly and NEVER conjures +3 free food out of thin air');
 const goldBefore=g.gold;
 Object.assign(n.stageLocal,{x:vLoc.x,y:vLoc.y,action:'resupplyFood',mode:'working',job:0,target:vLoc});
 g.finish(n);
 check(g.s.food>0&&g.gold===goldBefore-6,'resupplyFood at village purchases real rations using sect spirit stones');
}

// [X3] Equipment stage & path eligibility enforcement
{
 const g=game();safe(g);const n=g.heroes[0];
 const highTierSword={id:'QA_HIGH_SWORD',nameTh:'กระบี่เซียนขั้นสูง',slot:'WEAPON',tier:5,minStageReq:4,compatiblePath:'ANY',durability:100,maxDurability:100,combatMult:.25,defenseMult:.05,studyBonus:.15};
 n.jianghu.ledgerV140.equipmentItems.push(highTierSword);
 check(!g.progression.canEquipItem(n,highTierSword).ok,'Stage 1 disciple cannot equip a Tier 5 (minStageReq 4) weapon');
 check(!g.progression.bestEquipment(n).some(x=>x.id==='QA_HIGH_SWORD'),'bestEquipment excludes items above the disciple stage');
 // Force-equip it and verify sanitizeEquippedItems + computeEquipmentResonance strip it
 n.jianghu.equipmentV140.WEAPON='QA_HIGH_SWORD';
 check(X.computeEquipmentResonance(n).combatMult===1,'computeEquipmentResonance ignores ineligible force-equipped item');
 g.progression.sanitizeEquippedItems(n);
 check(!n.jianghu.equipmentV140.WEAPON,'sanitizeEquippedItems unequips ineligible equipment');
}

// [X4] Frontier.send() route pre-validation before ticket/order reservation
{
 const g=game();safe(g);const n=g.heroes[0];
 building(g,'alchemy',600,960);
 check(g.fundOrder('REC1100_SUPPORT_QI').ok,'fund order for route preflight test');
 const order=g.s.orders.at(-1);
 order.heroId=n.id;n.stageLocal.orderId=order.id;
 // Attempt to send to an unreachable coordinate inside obstacle
 const unreachable={id:'unreachable',x:1950,y:1000};
 const sent=g.send(n,'craft',unreachable,10);
 check(sent===false,'send returns false when target is unreachable');
 check(order.heroId===null&&!n.stageLocal.orderId&&!n.stageLocal.growth.ticket,'failed send cleans up orderId and progression ticket without starting action');
}

// Current v1.17 save schema & old save rejection
{
 const g=game();
 const parsed=JSON.parse(g.serialize());
 check(parsed.version===11&&parsed.patch==='1.17-living-combat','v1.17 uses explicit save version 11 and patch 1.17-living-combat');
 const old=JSON.parse(g.serialize());old.version=9;old.patch='1.15-living-provenance';
 assert.throws(()=>F.load(JSON.stringify(old)),/1\.17/);
 checks.push('unsupported v1.15 saves fail clearly with v1.17 message');
}

fs.writeFileSync('evidence/qa-integration-v1.17.json',JSON.stringify({release:'1.17',pass:true,checks:checks.length,details:checks},null,2));
fs.writeFileSync('evidence/qa-fixture-v201.json',fresh);
console.log('INTEGRATION_V117_PASS',checks.length);
