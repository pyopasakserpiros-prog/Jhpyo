# Current 2.08.8 limitations

- The batched combat-stat projection passed focused regression tests, but its measured ~19% improvement was one seeded 34-disciple, 5-day spot-check, not a universal performance guarantee.
- Full-world integrated economy scenarios passed for two seeds and 20/34 disciples over 10 in-game days per scenario. The inter-sect market-only simulation separately covers 120 days.
- Longer full-world runs with 34 disciples have occasionally exceeded the available test time after roughly day 10–12. Do not claim multi-hundred-day full-world stability until the AI/movement performance hotspot is isolated and retested.
- No real Android device or Chromium browser automation was available for this run. UI handlers and actual offscreen Canvas are tested; touch/browser-layout behavior and FPS still need device playtesting.
- Outside merchants walk from the valley entrance to the market and depart again; a controlled end-to-end test confirms one surplus unit can be exported for 6 spirit stones from the regional fund while liquidity replenishment is accounted for. Regional cargo, liquidity and export payments have hard caps.
- Regional production is a bounded aggregate model rather than individually simulated factories and buyers for every outside town.
- Inter-sect network trade currently covers common non-transcendent materials only; pills, unique equipment, scriptures, and direct private disciple-to-other-sect trade are not yet included in the autonomous inter-sect network.
- The new buildings reuse existing atlas art with distinct labels. Unique building art remains future work.
- The mission hall expands simultaneous economic gathering/production work, while the story sidecontract system still accepts one contract at a time.
- Seeded, controlled simulations test invariants and specified scenarios, not universal balance or absence of all bugs.

Historical limitations follow; consult the current README/guide for completed 2.07+ scope.
