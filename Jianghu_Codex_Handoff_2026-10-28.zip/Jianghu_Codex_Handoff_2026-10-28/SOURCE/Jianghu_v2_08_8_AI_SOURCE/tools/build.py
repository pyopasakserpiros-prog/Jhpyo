"""Build the self-contained offline player, verify inputs, and package source.
Run from any directory: python3 tools/build.py
"""
from pathlib import Path
import base64,hashlib,json,re,zipfile,subprocess
ROOT=Path(__file__).resolve().parents[1]
subprocess.run(['node',str(ROOT/'tools/content_manifest.cjs')],cwd=ROOT,check=True)
NAME='Jianghu_Ascension_Myriad_Worlds_v2_08_8'
OUT=ROOT/'dist';OUT.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
html=(ROOT/'source/index.html').read_text()
# Source CSS references shared asset files once; the standalone player embeds
# those same bytes to remain fully offline and independent of directory layout.
css=(ROOT/'source/style.css').read_text()
def inline_css_asset(match):
 filename=match.group(2)
 assert re.fullmatch(r'[A-Za-z0-9_.-]+',filename),filename
 asset=ROOT/'assets'/filename
 assert asset.is_file(),filename
 mime='font/woff2' if filename.endswith('.woff2') else 'image/webp' if filename.endswith('.webp') else None
 assert mime,filename
 return 'url('+match.group(1)+'data:'+mime+';base64,'+base64.b64encode(asset.read_bytes()).decode()+match.group(1)+')'
css=re.sub(r'url\(([\"\']?)\.\./assets/([A-Za-z0-9_.-]+)\1\)',inline_css_asset,css)
assert '../assets/' not in css,'Standalone CSS contains external asset paths'
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
manifest={'release':'2.08.8-full-economy-performance-and-longrun','simulationEnvelope':11,'scripts':[],'assets':{}}
def embed(match):
 rel=match.group(1);p=ROOT/'source'/rel;source=p.read_text();text=source
 if p.name=='art-assets.js':
  art=json.loads((ROOT/'assets/art-manifest.json').read_text())
  for key,value in art['images'].items():art['images'][key]='data:image/webp;base64,'+base64.b64encode((ROOT/'source'/value).resolve().read_bytes()).decode()
  text='globalThis.LivingArtAssets='+json.dumps(art,ensure_ascii=False,separators=(',',':'))+';\n'
 manifest['scripts'].append({'path':'source/'+rel,'sourceSha256':sha(p.read_bytes()),'embeddedSha256':sha(text.encode())})
 return '<script>\n'+re.sub(r'</script',r'<\\/script',text,flags=re.I)+'\n</script>'
html=re.sub(r'<script src="([^"]+)"></script>',embed,html)
assert '<script src=' not in html and '<link rel="stylesheet"' not in html
for p in sorted((ROOT/'assets').iterdir()):
 if p.is_file():manifest['assets'][p.name]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
player=OUT/(NAME+'.html');player.write_text(html)
(ROOT/player.name).write_bytes(player.read_bytes())
for old_name in ['Jianghu_Ascension_Living_Sect_v1_15.html','Jianghu_Ascension_Living_Sect_v1_16.html','Jianghu_Ascension_Living_Sect_v1_17_Combat.html','Jianghu_Ascension_Myriad_Worlds_v2_05_Checkpoint.html','Jianghu_Ascension_Myriad_Worlds_v2_08.html','Jianghu_Ascension_Myriad_Worlds_v2_08_2.html','Jianghu_Ascension_Myriad_Worlds_v2_08_4.html','Jianghu_Ascension_Myriad_Worlds_v2_08_5.html','Jianghu_Ascension_Myriad_Worlds_v2_08_6.html','Jianghu_Ascension_Myriad_Worlds_v2_08_7.html']:
 old_p=ROOT/old_name
 if old_p.exists():old_p.unlink()
manifest['standalone']={'filename':player.name,'bytes':player.stat().st_size,'sha256':sha(player.read_bytes())}
(ROOT/'BUILD_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
baseline=json.loads((ROOT/'references/BASELINE_V116_SHA256.json').read_text())
uploaded=json.loads((ROOT/'references/BASELINE_V200_SHA256.json').read_text())
audit={'release':manifest['release'],'baseline':'attached v1.16 source bytes','uploadedBase':'attached unified v2.00 source bytes','humanFoundationLocked':True,'modules':[]}
for p in sorted((ROOT/'source/scripts').glob('*.js')):
 current=sha(p.read_bytes());old=baseline.get(p.name);uploadHash=uploaded.get('source/scripts/'+p.name);audit['modules'].append({'name':p.name,'baselineSha256':old,'uploadedBaseSha256':uploadHash,'currentSha256':current,'status':'new' if old is None else 'unchanged' if old==current else 'modified','deltaFromUploadedBase':'new' if uploadHash is None else 'unchanged' if uploadHash==current else 'modified'})
assert sha((ROOT/'source/scripts/human.js').read_bytes())=='b230108298cae486c3dc6bf6698f0384ca67128b064ff3947f19fa6e5522328a'
assert sha((ROOT/'source/scripts/legacy.bundle.js').read_bytes())==uploaded['source/scripts/legacy.bundle.js']
(ROOT/'SOURCE_AUDIT.json').write_text(json.dumps(audit,indent=2))
(ROOT/'evidence/sha256.txt').write_text(manifest['standalone']['sha256']+'  '+manifest['standalone']['filename']+'\n'+''.join(r['sourceSha256']+'  '+r['path']+'\n' for r in manifest['scripts']))
# Player-only archive: do not nest source, evidence, and another standalone
# inside a second 27 MB ZIP. The editable source is packaged separately.
archive=OUT/(NAME+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 z.write(player,player.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
for stale in [OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_4.html',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_4.zip',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_5.html',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_5.zip',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_6.html',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_6.zip',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_7.html',OUT/'Jianghu_Ascension_Myriad_Worlds_v2_08_7.zip']:
 if stale.exists():stale.unlink()
print(json.dumps({'html':str(player),'playerZip':str(archive),'scripts':len(manifest['scripts']),'bytes':player.stat().st_size,'zipBytes':archive.stat().st_size}))
