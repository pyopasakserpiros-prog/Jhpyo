"""Produce an AI-friendly, editable, runnable source archive without generated duplicates.
Usage: python3 tools/package_slim.py [output.zip]
"""
from pathlib import Path
import sys, zipfile, json
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'dist/Jianghu_v2_08_8_AI_SOURCE.zip'
ROOT_DOCS={
 'README_TH.md','ARCHITECTURE.md','KNOWN_LIMITATIONS.md','PATCH_NOTES_v208_TH.md','PATCH_NOTES_v2085_TH.md','PATCH_NOTES_v2086_TH.md','PATCH_NOTES_v2087_TH.md','PATCH_NOTES_v2088_TH.md',
 'ROADMAP_TH.md','ECONOMY_BUILDINGS_GUIDE_TH.md','V208_HANDOFF_TH.md','V2085_HANDOFF_TH.md','V2086_HANDOFF_TH.md','V2087_HANDOFF_TH.md','V2088_HANDOFF_TH.md','QA_REPORT_v2086_TH.md','QA_REPORT_v2087_TH.md','QA_REPORT_v2088_TH.md',
 'DEVELOPMENT_RULES.md','NPC_CORE_LOCK.md','NPC_IDENTITY_SPEC.md',
 'COMBAT_STAT_GUIDE_TH.md','HUMAN_FIELD_REFERENCE.md','VERSION.txt',
 'QA_REPORT_TH.md','AI_READ_FIRST_TH.md','GEMINI.md','FIX_REPORT_TH.md',
 'package.json'
}
ASSET_SUFFIXES={'.webp','.woff2'}
REFERENCE_FILES={'BASELINE_V116_SHA256.json','BASELINE_V200_SHA256.json'}
TOOL_FILES={'build.py','content_manifest.cjs','package_slim.py','package_review.py'}
files=[]
for p in ROOT.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(ROOT)
 if len(rel.parts)==1:
  if p.name in ROOT_DOCS:files.append(p)
 elif rel.parts[0]=='source':
  files.append(p)
 elif rel.parts[0]=='assets':
  if p.suffix in ASSET_SUFFIXES or p.name in {'art-manifest.json','NOTO_SANS_THAI_LICENSE.txt'}:files.append(p)
 elif rel.parts[0]=='tests':
  if p.suffix=='.cjs':files.append(p)
 elif rel.parts[0]=='tools':
  if p.name in TOOL_FILES:files.append(p)
 elif rel.parts[0]=='docs' and rel.parts[-1].endswith('.md'):
  files.append(p)
 elif rel.parts[0]=='references':
  if len(rel.parts)==2 and p.name in REFERENCE_FILES:files.append(p)
 elif rel.parts[0]=='evidence' and p.name=='README.txt':
  files.append(p)
assert (ROOT/'source/scripts/legacy.bundle.js') in files
assert (ROOT/'source/style.css') in files
assert (ROOT/'tests/coherence_hotfix_v208.cjs') in files
OUT.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(files):z.write(p,'Jianghu_v2_08_8_AI_SOURCE/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
print(json.dumps({'output':str(OUT),'bytes':OUT.stat().st_size,'files':len(files),'containsLegacyRuntime':True,'includesStandalone':False}))
