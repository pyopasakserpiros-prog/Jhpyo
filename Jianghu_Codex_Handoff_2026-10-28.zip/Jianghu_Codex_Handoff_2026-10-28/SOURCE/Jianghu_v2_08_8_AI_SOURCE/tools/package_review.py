"""Create a tiny code-review-only ZIP; not runnable and not suitable as a patch base.
Usage: python3 tools/package_review.py [output.zip]
"""
from pathlib import Path
import sys,zipfile,json
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'dist/Jianghu_v2_08_8_REVIEW_ONLY.zip'
EXCLUDE={'legacy.bundle.js','myriad-worlds-data.js','living-content-v111.js'}
ROOT_DOCS={'README_TH.md','ROADMAP_TH.md','KNOWN_LIMITATIONS.md','PATCH_NOTES_v2088_TH.md','V2088_HANDOFF_TH.md','QA_REPORT_v2088_TH.md','AI_READ_FIRST_TH.md','FIX_REPORT_TH.md','GEMINI.md','ARCHITECTURE.md','DEVELOPMENT_RULES.md','NPC_CORE_LOCK.md','VERSION.txt','package.json'}
files=[]
for p in ROOT.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(ROOT)
 if len(rel.parts)==1 and p.name in ROOT_DOCS:files.append(p)
 elif rel.parts[0]=='source' and (len(rel.parts)==2 or p.name not in EXCLUDE):files.append(p)
 elif rel.parts[0]=='tests' and p.suffix=='.cjs':files.append(p)
assert not any(p.name in EXCLUDE for p in files)
OUT.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(files):z.write(p,'Jianghu_v2_08_8_REVIEW_ONLY/'+p.relative_to(ROOT).as_posix())
 z.writestr('Jianghu_v2_08_8_REVIEW_ONLY/REVIEW_ONLY_README_TH.md',
  '# แพ็กตรวจโค้ดแบบประหยัดโทเคน (ไม่ใช่เกมที่เปิดเล่นหรือบิลด์ได้)\n\n'
  'ตัด `legacy.bundle.js` (แกนรันไทม์ล็อก), `myriad-worlds-data.js` และ `living-content-v111.js` (ฐานข้อมูลขนาดใหญ่), assets และหลักฐานเก่าออก เพื่อให้ AI ตรวจโค้ดส่วนที่แก้บ่อยได้อย่างรวดเร็ว\n\n'
  '**ห้ามนำแพ็กนี้ไปแทนตัวเกมเต็ม**: เมื่อต้องแก้จริงหรือรันเทสต์ ให้ใช้ `Jianghu_v2_08_8_AI_SOURCE.zip` และอ่านไฟล์เฉพาะส่วนที่เกี่ยวข้อง ไม่ต้องส่งทุกไฟล์เข้า context\n')
with zipfile.ZipFile(OUT) as z:assert z.testzip() is None
print(json.dumps({'output':str(OUT),'bytes':OUT.stat().st_size,'files':len(files)+1,'runnable':False}))
