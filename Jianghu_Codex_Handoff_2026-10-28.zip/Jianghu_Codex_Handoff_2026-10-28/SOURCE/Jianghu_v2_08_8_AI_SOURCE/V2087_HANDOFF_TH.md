# Handoff v2.08.7 — Autonomous Sect Network Market

## Implemented
- Autonomous bilateral trades between six external sects, backed by real faction material ledgers and spirit-stone wallets.
- Daily demand/consumption and bounded specialty production create recurring trade without unbounded stock accumulation.
- Price responds to buyer shortage and seller surplus; max three network trades per day.
- Seller reserves, buyer funds, seller wallet caps, material ownership, and destination capacity are checked before settlement.
- Network history is capped at 60 rows; total trade/item/stone counters, cursor, and day guards persist through same-version save/load.
- Diplomacy UI shows aggregate network turnover and recent seller → buyer transactions.
- Existing main-sect ↔ external-sect trade and disciple ↔ caravan trade remain separate and continue to use spirit stones.

## Verification commands
- `node tests/sect_network_trade_v2087.cjs`
- `node tests/sect_network_simulation_v2087.cjs`
- `node tests/sect_trade_v2086.cjs`
- `node tests/caravan_ecology_v2085.cjs`
- `node tests/member_external_trade_v2084.cjs`
- `node tests/economy_ui_v207.cjs`
- `python3 tools/build.py`
- `node tests/verify_build_v205.cjs`

## Limits
- The new network simulation covers 120 market days across four controlled initial conditions and verifies bounded wallets/stocks plus deterministic save continuation. It does not replace the broader NPC/economy simulation with 20–34 disciples.
- No physical Android device test was available.
- Network trade currently covers common non-transcendent materials only; pills, unique equipment, scriptures, and direct private disciple-to-other-sect trade remain out of scope.
