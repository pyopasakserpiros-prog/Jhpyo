# Handoff v2.08.8 — Full Economy Readiness

## สิ่งที่เปลี่ยน

- ปรับ `source/scripts/combat-stats.js` ให้คำนวณ effective dimensions แบบ batch และแก้ fallback ที่ไม่ครบให้ไม่วนซ้ำ
- เปลี่ยน release metadata เป็น `2.08.8-full-economy-performance-and-longrun` โดยไม่เปลี่ยน save envelope/schema
- เพิ่มชุดทดสอบ projection และ full-economy scenarios
- รักษา `source/scripts/human.js` และ `source/scripts/legacy.bundle.js` ตาม hash ที่ล็อกไว้

## คำสั่งตรวจ

```bash
npm run test:combat-stats:batch
npm run test:market
npm run test:market:longrun
npm run test:economy
npm run test:market:regression
node tests/full_economy_scenario_v2088.cjs 20882001 20 10 1
node tests/full_economy_scenario_v2088.cjs 20882001 34 10 0
node tests/full_economy_scenario_v2088.cjs 20882002 20 10 0
node tests/full_economy_scenario_v2088.cjs 20882002 34 10 0
node tests/full_economy_simulation_v2088.cjs
npm run build
node tests/verify_build_v205.cjs
```

## ข้อจำกัดที่ต้องรักษาความซื่อตรง

- ผล full-world scenarios ครอบคลุม 10 วันในเกมต่อ scenario เท่านั้น
- ตลาดระหว่างสำนักแบบแยกส่วนมีหลักฐาน 120 วัน
- การจำลองเต็มโลกที่ยาวกว่า 10–12 วันกับ 34 ศิษย์บางครั้งเกินกรอบทดสอบ; อย่ารายงานว่าการจำลองหลายร้อยวันผ่านจนกว่าจะตรวจคอขวดได้
- ยังไม่ได้ทดสอบบน Android จริง
