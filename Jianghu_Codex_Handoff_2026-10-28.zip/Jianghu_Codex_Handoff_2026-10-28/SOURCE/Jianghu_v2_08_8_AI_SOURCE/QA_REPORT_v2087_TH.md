# QA Report — Jianghu v2.08.7

## Results verified for this release

| Check | Result | Coverage |
|---|---|---|
| Autonomous sect network trade | PASS | 8 focused cases: real material/stone settlement, price response, idempotence, 3/day cap, insufficient funds, seller wallet cap, destination capacity, seller reserve, save/load and UI history |
| Long-run regional market simulation | PASS | 4 varied starting conditions × 120 in-game market days; 345 network trades per run; wallet and stock caps enforced; 60-row history bound; save continuation matches |
| Existing main-sect ↔ faction trade | PASS | 12 cases |
| Disciple ↔ outsider trade | PASS | 9 cases |
| Caravan / regional market | PASS | 7 cases |
| Economy UI | PASS | 11 UI checks, including network activity rendering |
| Offline build | PASS | 32 inline modules, source/embedded hashes match, no external scripts/styles, locked Human Foundation files unchanged |

The network simulation recorded 345 trades over the 115 days processed per seed, with transferred stone totals varying by initial wallet/material conditions (5,991–7,591 stones). The 345 count is exactly the configured ceiling of three trades/day, so this demonstrates bounded activity, not proof that the market would always have that volume in every live save.

## Known incomplete verification

- The broad legacy `tests/economy_simulation_v207.cjs` (40 days × four seeds plus full world continuation) previously exceeded the 300-second execution limit. The new market-only simulation is faster and passed, but does not establish complete 20–34 disciple economy balance. The broader chained market regression command printed PASS outputs for its constituent tests but did not return before the tool timeout in this environment; those component test files were also executed separately and passed. `npm run test:market` is intentionally kept focused on the new network regression, while the 120-day simulation is separate.
- No physical Android/touch layout test was available.

## Accounting guarantees tested

- Network transaction price is debited from the buyer faction and credited to the seller faction by the same amount.
- Main sect bank, disciple wallets, and contribution points are unchanged by faction-to-faction network transactions.
- Failed trade preconditions do not move goods or stones.
- Network history and continuation state survive same-version save/load.
