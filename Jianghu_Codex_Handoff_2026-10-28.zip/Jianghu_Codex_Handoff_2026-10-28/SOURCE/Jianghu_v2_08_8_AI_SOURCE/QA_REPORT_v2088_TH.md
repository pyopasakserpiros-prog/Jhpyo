# QA Report — Jianghu v2.08.8

## หลักฐานที่ยืนยันแล้ว

- Batch combat-stat regression: ผ่าน; normal actor projection เรียก `HumanCore.effective` 0 ครั้ง และผลค่าสถานะยังลดลงตาม fatigue/pain/hunger
- Incomplete-human fallback: ผ่าน; ได้ค่าสถานะตัวเลขโดยไม่วนซ้ำ
- Full-world economy: 4 scenarios ผ่าน (seed 20882001/20882002 × 20/34 ศิษย์, 10 วันในเกมต่อ scenario)
- บัญชีแต้มคุณูปการ: `issued - retired = circulating` ในทุก scenario; ยอดคงเหลือขั้นต่ำไม่ติดลบ
- เครือข่ายตลาดระหว่างสำนัก: 30 ธุรกรรม/10 วันต่อ scenario รวม 120 ธุรกรรม และหินวิญญาณที่โอนรวม 4,620 ในรายงาน 4 scenarios
- คาราวานครบวงจร: ผ่าน 803 ticks; คาราวานเดินทางเข้า ตั้งร้าน รับซื้อสินค้าส่วนเกิน 1 หน่วย เดินทางออกและส่งออกต่อ รับ 6 หินวิญญาณจากกองทุนภูมิภาค โดยบัญชีกองทุนเท่ากับเงินเริ่มต้น + เงินเติมตลาด - เงินส่งออก
- สร้าง HTML ออฟไลน์และตรวจ hash ของ embedded modules: ผ่าน; 32 โมดูลใน HTML ตรงกับซอร์สทุกตัว

## Performance spot-check

ใช้ seed `2088134`, 34 ศิษย์, ตลาดหนึ่งอาคาร, 5 วันในเกม:

- v2.08.7 baseline: 14.955 วินาทีสำหรับการ advance 5 วัน (หลัง setup)
- batch projection build: 12.071 วินาทีสำหรับการ advance 5 วัน (หลัง setup)
- ความเร็วดีขึ้นประมาณ 19.3% ใน spot-check นี้; ไม่ใช่ benchmark ทุก seed/อุปกรณ์

## ยังไม่ยืนยัน

- Full-world simulation หลายร้อยวัน: ยังไม่ผ่านการรับรอง; การทดสอบ 34 ศิษย์ที่เกิน 10–12 วันบางครั้งใช้เวลานานเกินกรอบ
- ชุด `npm test` แบบรวมทั้งหมด: ยังไม่ได้รันครบในรอบนี้; `npm run test:market:regression` แบบต่อกันหมดเวลาที่ 150 วินาที แต่สมาชิกของชุด (`member_external_trade`, `caravan_ecology`, `sect_trade`) ผ่านเมื่อรันแยกกัน; ให้ใช้ focused commands ก่อน และอย่าอ้างว่าชุดรวมผ่านจนกว่าจะจบและคืน exit code 0
- Android จริง / touch / FPS / layout: ยังไม่ได้ทดสอบ
