# Jianghu v2.08.6 source

Pure derived stats live in `combat-stats.js`; common hit/secondary resolution lives in `combat-overhaul.js`. Preserve `human.js` and `legacy.bundle.js` byte-for-byte. v2.08.6 keeps save envelope v11 and adds visible caravan arrival/departure, bounded regional inventories/liquidity, export settlement, and treasury-to-treasury trade with six external sects using spirit stones. Inter-sect trades use real faction cache ledgers, relation/supply-sensitive quotes, bounded wallets and stocks, and persisted receipts/history.
