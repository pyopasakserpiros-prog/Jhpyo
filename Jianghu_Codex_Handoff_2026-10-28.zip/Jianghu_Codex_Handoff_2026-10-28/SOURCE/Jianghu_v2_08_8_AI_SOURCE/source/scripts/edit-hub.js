/* Jianghu safe editor v1.10 + v1.12/v1.16 Major Expansion — allowlisted data edits only;
   supports editing path/subPath, administrative heritage grants, and role-separated NPC lists; never edits source code or formulas. */
(function(root){'use strict';
const E=root.World2026Engine,H=root.HumanCore,D=E?.NPC_CORE_DATA;
const clone=x=>JSON.parse(JSON.stringify(x));
const readPath=(o,p)=>p.split('.').reduce((v,k)=>v?.[k],o);
const writePath=(o,p,v)=>{const a=p.split('.');let t=o;for(const k of a.slice(0,-1)){if(!t[k]||typeof t[k]!=='object')throw Error('ไม่พบช่องข้อมูล '+p);t=t[k];}const last=a[a.length-1];if(typeof t[last]!=='number')throw Error('ช่องข้อมูลไม่ใช่ตัวเลข '+p);t[last]=v;};
const finite=(v,label,min,max,{integer=true}={})=>{if(v===''||v===null||v===undefined||!Number.isFinite(Number(v))||(integer&&!Number.isInteger(Number(v)))||Number(v)<min||Number(v)>max)throw Error(label+': ต้องเป็น'+(integer?'จำนวนเต็ม':'ตัวเลข')+' '+min+'–'+max);return Number(v);};
const axisDefs={
 personality:()=>D?.PERSONALITY_AXES_14||[],
 value:()=>D?.VALUE_DIMENSIONS_8||[],
 aptitude:()=>D?.APTITUDE_DOMAINS_6||[],
 body:()=>H?.bodyDefs||[],
 cognition:()=>H?.cognitiveDefs||[],
 interest:()=>H?.interestDefs||[]
};
function axisRead(n,kind,id){if(kind==='personality')return n.personality?.[id];if(kind==='value')return n.core?.values?.[id];if(kind==='aptitude')return n.core?.aptitudes?.[id];return H.raw(n,kind,id);}
function axisLabel(d){return d.nameTh||d.label||d.labelTh||d.id;}
function history(game,kind,targetId,summary,details=[]){game.s.editHubHistory=game.s.editHubHistory||[];game.s.editHubHistory.unshift({t:game.s.t,tick:game.world.tick,kind,targetId,summary,details:clone(details).slice(0,80)});if(game.s.editHubHistory.length>50)game.s.editHubHistory.length=50;}
function note(game,text,n=null){game.note?.(text,n);}
function actorRole(game,n){
 if(!n||!n.stageLocal)return 'unknown';
 if(n.stageLocal.role)return n.stageLocal.role;
 if(game?.s?.heroIds?.includes(n.id))return 'disciple';
 if(n.stageLocal.service==='BANK')return 'storage';
 if(n.stageLocal.service)return 'service';
 if(n.stageLocal.enemy)return 'bandit';
 if(n.stageLocal.envoy)return 'envoy';
 if(n.stageLocal.visitor&&game?.s?.life?.story?.actorId===n.id)return 'courier';
 if(n.stageLocal.visitor)return 'visitor';
 return 'disciple';
}
function editNpc(game,id,fields){try{
 const n=game?.world?.npcs?.[id];if(!n||!n.stageLocal||!n.jianghu||!n.core)throw Error('ไม่พบ NPC ของสำนักที่แก้ไขได้');
 if(actorRole(game,n)==='storage')throw Error('คลังสำนักเป็นหน่วยเก็บทรัพยากรส่วนกลาง ไม่ใช่ตัวละครผู้ฝึกตน');
 if(!n.core.human)throw Error('NPC นี้ไม่มีข้อมูลตัวตนพื้นฐาน จึงไม่เปิดให้แก้ไขเพื่อป้องกันข้อมูลเสีย');
 if(!fields||typeof fields!=='object')throw Error('ข้อมูลแก้ไขไม่ถูกต้อง');
 const draft=clone(n),details=[],scalarChanges=[];let touched=false;
 const name=String(fields.name??n.name).trim();if(!name||name.length>80||/[<>]/.test(name))throw Error('ชื่อต้องไม่ว่าง ยาวไม่เกิน 80 ตัวอักษร และห้ามใช้เครื่องหมาย < >');
 if(name!==n.name){scalarChanges.push({path:'name',value:name});details.push({field:'ชื่อ',before:n.name,after:name});touched=true;}
 const age=finite(fields.age??n.age,'อายุ',1,Math.max(1,(n.jianghu.lifespanMax||10000)-1));if(age!==n.age){draft.age=age;if(Number.isFinite(game.world.year))draft.birthYear=game.world.year-age;details.push({field:'อายุ',before:n.age,after:age});touched=true;}
 let health=null;if(n.alive){health=finite(fields.health??n.health,'พลังชีวิต',1,n.stageLocal.boss?240:100);if(health!==n.health){draft.health=health;details.push({field:'พลังชีวิต',before:n.health,after:health});touched=true;}}
 const stones=finite(fields.stones??E.getSpiritStonesV140(n),'ศิลาวิญญาณส่วนตัว',0,1000000000);if(stones!==E.getSpiritStonesV140(n)){details.push({field:'ศิลาวิญญาณส่วนตัว',before:E.getSpiritStonesV140(n),after:stones});touched=true;}
 const reqPath=fields.path??fields.cultivationPath;
 const reqSubPath=fields.subPath??fields.cultivationSubpath;
 let targetPath=n.jianghu.path,targetSubPath=n.jianghu.subPath,pathChanged=false;
 if(reqPath!==undefined&&reqPath!==n.jianghu.path){
  if(!E.CULTIVATION_PATHS?.[reqPath])throw Error('ไม่พบวิถีบ่มเพาะ '+reqPath);
  targetPath=reqPath;pathChanged=true;
 }
 if(reqSubPath!==undefined&&reqSubPath!==n.jianghu.subPath){
  const validSub=E.CULTIVATION_PATHS?.[targetPath]?.subPaths?.[reqSubPath];
  if(!validSub)throw Error('สายการบ่มเพาะไม่ตรงกับวิถีที่เลือก');
  targetSubPath=reqSubPath;pathChanged=true;
 }else if(pathChanged&&!E.CULTIVATION_PATHS?.[targetPath]?.subPaths?.[targetSubPath]){
  targetSubPath=Object.keys(E.CULTIVATION_PATHS[targetPath].subPaths)[0];
 }
 if(pathChanged){
  draft.jianghu.path=targetPath;draft.jianghu.subPath=targetSubPath;
  details.push({field:'วิถีและสายบ่มเพาะ',before:n.jianghu.path+':'+n.jianghu.subPath,after:targetPath+':'+targetSubPath});
  touched=true;
 }
 const track=E.getCultivationTrackV1200?.(targetPath,targetSubPath);const stageMax=track?.realmCount||n.jianghu.maxStage||9;const currentStage=Number(n.jianghu.trackOrdinal||n.jianghu.stage||1);const cultivationStage=finite(fields.cultivationStage??currentStage,'ขั้นขอบเขตพลัง',1,stageMax);if(cultivationStage!==currentStage){draft.jianghu.trackOrdinal=cultivationStage;draft.jianghu.stage=cultivationStage;details.push({field:'ขั้นขอบเขตพลัง',before:currentStage,after:cultivationStage});touched=true;}const progress=finite(fields.progress??n.jianghu.cultivationProgress??0,'ความก้าวหน้าบ่มเพาะ',0,100,{integer:false});if(Math.abs(progress-(n.jianghu.cultivationProgress||0))>.000001){draft.jianghu.cultivationProgress=progress;details.push({field:'ความก้าวหน้าบ่มเพาะ',before:n.jianghu.cultivationProgress||0,after:progress});touched=true;}
 for(const d of axisDefs.personality())if(Object.prototype.hasOwnProperty.call(fields,'personality:'+d.id)){
  const v=finite(fields['personality:'+d.id],axisLabel(d),0,100);draft.personality[d.id]=v;if(v!==n.personality[d.id]){scalarChanges.push({path:'personality.'+d.id,value:v});details.push({field:axisLabel(d),before:n.personality[d.id],after:v});touched=true;}
 }
 for(const kind of ['value','aptitude'])for(const d of axisDefs[kind]())if(Object.prototype.hasOwnProperty.call(fields,kind+':'+d.id)){
  const target=kind==='value'?draft.core.values:draft.core.aptitudes;const v=finite(fields[kind+':'+d.id],axisLabel(d),0,100);if(typeof target?.[d.id]!=='number')throw Error('ไม่พบแกน '+d.id);if(target[d.id]!==v){details.push({field:axisLabel(d),before:target[d.id],after:v});target[d.id]=v;touched=true;}
 }
 for(const kind of ['body','cognition','interest'])for(const d of axisDefs[kind]())if(Object.prototype.hasOwnProperty.call(fields,kind+':'+d.id)){
  const v=finite(fields[kind+':'+d.id],axisLabel(d),0,100),old=axisRead(n,kind,d.id);if(!Number.isFinite(old))throw Error('ข้อมูลแกน '+d.id+' ไม่สมบูรณ์');writePath(draft,d.path,v);if(old!==v){details.push({field:axisLabel(d),before:old,after:v});touched=true;}
 }
 H.validate(draft);
 if(!touched)return {ok:false,reason:'ไม่มีข้อมูลเปลี่ยนแปลง'};
 const legacy=E.Editor1140?.legacy||root.JianghuEditV171;
 if(scalarChanges.length){if(!legacy?.apply)throw Error('ระบบตรวจสอบช่องชื่อ/นิสัยไม่พร้อม');const r=legacy.apply(game.world,'npcs',id,scalarChanges,game.world.tick);if(!r.ok)throw Error(r.reason||'บันทึกชื่อ/นิสัยไม่สำเร็จ');}
 if(age!==n.age){n.age=age;if(Number.isFinite(game.world.year))n.birthYear=game.world.year-age;}
 if(health!==null&&health!==n.health)n.health=health;
 for(const d of axisDefs.value())if(draft.core.values[d.id]!==n.core.values[d.id])n.core.values[d.id]=draft.core.values[d.id];
 for(const d of axisDefs.aptitude())if(draft.core.aptitudes[d.id]!==n.core.aptitudes[d.id])n.core.aptitudes[d.id]=draft.core.aptitudes[d.id];
 for(const kind of ['body','cognition','interest'])for(const d of axisDefs[kind]()){const v=readPath(draft,d.path);if(axisRead(n,kind,d.id)!==v)writePath(n,d.path,v);}
 if(pathChanged){n.jianghu.path=targetPath;n.jianghu.subPath=targetSubPath;}
 if(pathChanged||cultivationStage!==currentStage||Math.abs(progress-(n.jianghu.cultivationProgress||0))>.000001){
  E.cancelBreakthroughProjectV1200?.(game.world,n,'EDITOR_CULTIVATION_CHANGE','ผู้เล่นปรับขอบเขต/ความก้าวหน้าผ่าน Edit Hub');
  if(track&&E.syncNpcCultivationIdentityV1200)E.syncNpcCultivationIdentityV1200(game.world,n,{trackOrdinal:cultivationStage,progress,subRealmId:n.jianghu.subRealmId});
  else{n.jianghu.stage=cultivationStage;n.jianghu.trackOrdinal=cultivationStage;n.jianghu.cultivationProgress=progress;}
  game.progression?.sanitizeEquippedItems?.(n);
 }
 if(stones!==E.getSpiritStonesV140(n))E.setSpiritStonesV140(n,stones);
 E.invalidateNpcCoreCache?.(n);H.validate(n);
 history(game,'NPC',id,'แก้ไขข้อมูล '+n.name,details);note(game,'Edit Hub: แก้ไขข้อมูล NPC '+n.name,n);
 return {ok:true,reason:'บันทึกข้อมูล '+n.name+' แล้ว',details};
 }catch(e){return {ok:false,reason:e.message||'แก้ไข NPC ไม่สำเร็จ'};}}
function setResources(game,fields){try{
 const s=game?.s;if(!s||!game.bank)throw Error('โลกเกมยังไม่พร้อม');
 const desired={stones:finite(fields.stones,'ศิลาวิญญาณสำนัก',0,1000000000),wood:finite(fields.wood,'ไม้',0,1000000000),food:finite(fields.food,'อาหาร',0,1000000000),ore:finite(fields.ore,'แร่เหล็กดำ',0,1000000000)};
 const before={stones:game.gold,wood:s.wood,food:s.food,ore:game.ore};
 if(Object.keys(desired).every(k=>desired[k]===before[k]))return {ok:false,reason:'ทรัพยากรทุกชนิดมีค่าเท่าเดิม'};
 const oreDelta=desired.ore-before.ore;if(oreDelta>0){const r=game.add(game.bank,FrontierDataORE(),oreDelta,'EDIT_HUB_GRANT');if(!r?.ok)throw Error(r?.reason||'เพิ่มแร่เข้าคลังไม่สำเร็จ');}else if(oreDelta<0){if(!game.consume(game.bank,FrontierDataORE(),-oreDelta))throw Error('ลดแร่ในคลังไม่สำเร็จ');}
 const moneyDelta=desired.stones-before.stones;if(moneyDelta&&!game.money(moneyDelta,'Edit Hub · ปรับศิลาวิญญาณสำนัก')){
  if(oreDelta>0)game.consume(game.bank,FrontierDataORE(),oreDelta);else if(oreDelta<0)game.add(game.bank,FrontierDataORE(),-oreDelta,'EDIT_HUB_ROLLBACK');throw Error('ปรับศิลาวิญญาณไม่สำเร็จ');
 }
 s.wood=desired.wood;s.food=desired.food;
 const details=Object.keys(desired).filter(k=>desired[k]!==before[k]).map(k=>({field:({stones:'ศิลาวิญญาณสำนัก',wood:'ไม้',food:'อาหาร',ore:'แร่เหล็กดำ'})[k],before:before[k],after:desired[k]}));
 history(game,'RESOURCES','SECT','ปรับทรัพยากรสำนัก',details);note(game,'Edit Hub: ปรับทรัพยากรสำนัก');return {ok:true,reason:'บันทึกทรัพยากรสำนักแล้ว',details};
 }catch(e){return {ok:false,reason:e.message||'ปรับทรัพยากรไม่สำเร็จ'};}}
function FrontierDataORE(){return root.FrontierData?.ORE||'MAT_ORE_BLACK_IRON_1';}
const TRANSCENDENT_HERITAGE_ORIGINS={
 MAT_HERB_IMMORTAL_PEACH_6:{originId:'LEG_23',siteId:'SITE_KUNLUN_GROTTO',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub · อ้างอิงมรดกเบื้องบน: วังร้างสวนโอสถอมฤตเก้าสวรรค์)'},
 MAT_ORE_CHAOS_VOID_JADE_6:{originId:'LEG_02',siteId:'SITE_STAR_PAGODA',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub · อ้างอิงมรดกเบื้องบน: วังร้างจักรกลหมื่นดารา)'}
};
function grantMaterial(game,matId,qty){try{
 const def=E.PATCH140_DATA?.MATERIALS_REGISTRY_V140?.find(m=>m.id===matId);if(!def)throw Error('วัตถุดิบนี้ไม่มีในทะเบียนเกม');qty=finite(qty,'จำนวนวัตถุดิบ',1,100000);
 const before=game.count(game.bank,matId);
 let r;
 if(def.isTranscendent){
  const hMeta=TRANSCENDENT_HERITAGE_ORIGINS[matId]||{originId:game.world?.jianghu?.higherRealmLegacies?.[0]?.id||'LEG_01',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub · มรดกเบื้องบน)'};
  r=game.add(game.bank,matId,qty,'EDIT_HUB_ADMIN_GRANT',{originType:'HERITAGE_SITE',originId:hMeta.originId,originLabelTh:hMeta.originLabelTh,adminGrant:true});
 }else{
  r=game.add(game.bank,matId,qty,'EDIT_HUB_GRANT',{originType:'STAGE',originId:'EDIT_HUB_GRANT',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub)',adminGrant:true});
 }
 if(!r?.ok)throw Error(r?.reason||'เสกวัตถุดิบไม่สำเร็จ');
 const after=game.count(game.bank,matId);
 history(game,'MATERIAL',game.bank.id,'เสก '+def.nameTh+' ×'+qty+(def.isTranscendent?' [สิทธิ์ผู้ดูแล · มรดกเบื้องบน]':''),[{field:def.nameTh,before,after,adminGrant:true,originType:def.isTranscendent?'HERITAGE_SITE':'STAGE'}]);
 note(game,'Edit Hub: เสก '+def.nameTh+' ×'+qty+' เข้าคลังสำนัก'+(def.isTranscendent?' (สิทธิ์ผู้ดูแล · มรดกเบื้องบน)':''));
 return {ok:true,reason:'เพิ่ม '+def.nameTh+' ×'+qty+' เข้าคลังสำนักแล้ว'+(def.isTranscendent?' (บันทึกสิทธิ์ผู้ดูแลระบบ)':''),stack:r.stack,adminGrant:true};
 }catch(e){return {ok:false,reason:e.message||'เสกวัตถุดิบไม่สำเร็จ'};}}
function grantPill(game,recipeId,qty){try{
 const r=recipeById(game,recipeId);if(!r||r.outputType!=='PILL'||!r.outputNameTh||!r.effect||r.status&&r.status!=='ACTIVE')throw Error('ตำรับนี้ไม่ใช่โอสถที่สามารถเสกได้');qty=finite(qty,'จำนวนโอสถ',1,10000);
 const led=game.bank?.jianghu?.ledgerV140;if(!led||!Array.isArray(led.pillStacks))throw Error('ไม่พบคลังโอสถสำนัก');
 const maxStacks=game.maxPillStacks?game.maxPillStacks(game.bank):64;
 let stack=led.pillStacks.find(x=>x.recipeId===r.id&&x.quality==='STANDARD'&&!x.originatorSeal);
 if(!stack){if(led.pillStacks.length>=maxStacks)throw Error('ช่องเก็บโอสถสำนักเต็ม ('+maxStacks+' กอง)');stack={id:'PILL_EDIT_'+(game.s.nextId++),recipeId:r.id,nameTh:r.outputNameTh,tier:r.tier||1,quality:'STANDARD',count:0,effect:clone(r.effect),makerId:null,makerNameTh:'ผู้ดูแลสำนัก (Edit Hub)',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub)',originatorId:r.originatorId||null,originatorSeal:false,isTranscendent:!!r.isTranscendent,adminGrant:true};led.pillStacks.push(stack);}
 const before=stack.count;stack.count+=qty;E.syncLegacyArraysFromLedgerV140?.(game.bank);history(game,'PILL',game.bank.id,'เสก '+r.outputNameTh+' ×'+qty,[{field:r.outputNameTh,before,after:stack.count}]);note(game,'Edit Hub: เสก '+r.outputNameTh+' ×'+qty+' เข้าคลังสำนัก');return {ok:true,reason:'เพิ่ม '+r.outputNameTh+' ×'+qty+' เข้าคลังสำนักแล้ว'};
 }catch(e){return {ok:false,reason:e.message||'เสกโอสถไม่สำเร็จ'};}}
function recipeRegistry(game){return game?.world?.jianghu?.systemsV140?.recipes?.registry||{};}
function recipeById(game,id){return recipeRegistry(game)[id]||game?.recipes?.find(x=>x.id===id)||null;}
function itemRecipeCatalog(game){const rank={PILL:0,EQUIPMENT:1,BEAST_ITEM:2};return Object.values(recipeRegistry(game)).filter(r=>r&&r.status==='ACTIVE'&&!r.isPartial&&!r.heritageOnly&&r.outputNameTh&&['PILL','EQUIPMENT','BEAST_ITEM'].includes(r.outputType)&&(r.outputType!=='PILL'||!!r.effect)).sort((a,b)=>(rank[a.outputType]-rank[b.outputType])||(a.tier||1)-(b.tier||1)||String(a.outputNameTh).localeCompare(String(b.outputNameTh),'th'));}
function grantItem(game,recipeId,qty){try{
 const rec=recipeById(game,recipeId);if(!rec||rec.status&&rec.status!=='ACTIVE'||rec.isPartial||rec.heritageOnly||!['PILL','EQUIPMENT','BEAST_ITEM'].includes(rec.outputType))throw Error('ไอเท็มนี้ไม่มีในทะเบียนที่พร้อมใช้งาน');
 if(rec.outputType==='PILL')return grantPill(game,recipeId,qty);
 const led=game.bank?.jianghu?.ledgerV140;if(!led)throw Error('ไม่พบคลังสำนัก');qty=finite(qty,'จำนวนไอเท็ม',1,rec.outputType==='EQUIPMENT'?20:10000);
 const beforeCount=rec.outputType==='EQUIPMENT'?led.equipmentItems.length:(led.beastItems||[]).filter(x=>x.recipeId===rec.id).reduce((v,x)=>v+x.count,0);
 if(rec.outputType==='EQUIPMENT'){
  if(led.equipmentItems.length+qty>100)throw Error('คลังอุปกรณ์เต็ม (จำกัด 100 ชิ้น)');
  const slots=['WEAPON','ARMOR','TALISMAN_VESSEL'];const mappedSlot=rec.outputSubSlot==='ACCESSORY'?'TALISMAN_VESSEL':rec.outputSubSlot;const slot=slots.includes(mappedSlot)?mappedSlot:'WEAPON';
  for(let i=0;i<qty;i++){const eqItem={id:'EQ_EDIT_'+(game.s.nextId++),nameTh:rec.outputNameTh,slot,tier:rec.tier||1,quality:(rec.tier||1)>=4?'MASTERWORK':'REFINED',isTranscendent:!!rec.isTranscendent,compatiblePath:rec.compatiblePath||'ANY',element:rec.element||'NEUTRAL',makerId:null,makerNameTh:'ผู้ดูแลสำนัก (Edit Hub)',recipeId:rec.id,originatorId:rec.originatorId||null,originatorSeal:false,ownerId:game.bank.id,durability:100,maxDurability:100,combatMult:+Number(rec.effect?.combatMult??((rec.tier||1)*.04)).toFixed(3),defenseMult:+Number(rec.effect?.defenseMult??.02).toFixed(3),craftBonusPath:rec.effect?.craftBonusPath||null,craftBonusScore:Math.round(Number(rec.effect?.craftBonusScore||0)),escortSafetyBonus:+Number(rec.effect?.escortSafetyBonus||0).toFixed(3),minStageReq:Math.max(1,Number(rec.effect?.minStageReq||Math.floor(((rec.tier||1)+1)/2))),originType:'CRAFTED',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub)',adminGrant:true};root.JianghuExpansionV112?.imbueEquipmentDepth?.(eqItem,game.rng);led.equipmentItems.push(eqItem);}
 }else{
  led.beastItems=Array.isArray(led.beastItems)?led.beastItems:[];let stack=led.beastItems.find(x=>x.recipeId===rec.id&&x.quality==='STANDARD');
  const maxBeastStacks=game.maxBeastItemStacks?game.maxBeastItemStacks(game.bank):32;
  if(!stack){if(led.beastItems.length>=maxBeastStacks)throw Error('ช่องเก็บไอเท็มอสูรเต็ม ('+maxBeastStacks+' กอง)');stack={id:'BITEM_EDIT_'+(game.s.nextId++),recipeId:rec.id,nameTh:rec.outputNameTh,tier:rec.tier||1,quality:'STANDARD',count:0,makerId:game.bank.id,makerNameTh:'ผู้ดูแลสำนัก (Edit Hub)',originLabelTh:'ประทานโดยผู้ดูแลโลก (Edit Hub)',originatorId:rec.originatorId||null,originatorSeal:false,effect:clone(rec.effect||{}),adminGrant:true};led.beastItems.push(stack);}stack.count+=qty;
 }
 E.syncLegacyArraysFromLedgerV140?.(game.bank);const details=[{field:rec.outputNameTh,before:beforeCount,after:rec.outputType==='EQUIPMENT'?led.equipmentItems.length:beforeCount+qty}];history(game,rec.outputType,game.bank.id,'เสก '+rec.outputNameTh+' ×'+qty,details);note(game,'Edit Hub: เสก '+rec.outputNameTh+' ×'+qty+' เข้าคลังสำนัก');return {ok:true,reason:'เพิ่ม '+rec.outputNameTh+' ×'+qty+' เข้าคลังสำนักแล้ว',type:rec.outputType};
 }catch(e){return {ok:false,reason:e.message||'เสกไอเท็มไม่สำเร็จ'};}}
function manualCatalog(){
 const list=root.JianghuExpansionV112?.manualsV112||[];
 return list.slice().sort((a,b)=>(a.tier||1)-(b.tier||1)||String(a.nameTh).localeCompare(String(b.nameTh),'th'));
}
function grantScrollManual(game,arg1,arg2){try{
 const lookupArt=id=>game.progression?.artMap.get(id)||root.JianghuExpansionV112?.manualMapV112?.get(id);
 let targetId=arg1,artId=arg2;
 if(lookupArt(arg1)&&!lookupArt(arg2)){artId=arg1;targetId=arg2;}
 const art=lookupArt(artId);
 if(!art)throw Error('ไม่พบคัมภีร์วิชานี้ในทะเบียน');
 const grade=root.JianghuExpansionV112?.rarityGradesV112?.[art.tier||1]||{badgeTh:'สามัญ',color:'#adb5bd',code:'MORTAL'};
 if(targetId==='SECT_LIBRARY'){
  const library=game?.s?.growth?.scriptureLibrary||(game.s.growth.scriptureLibrary=[]);
  if(library.length>=(root.JianghuSectLibrary?.capacity(game)||120))throw Error('หอคัมภีร์ส่วนรวมเต็มแล้ว');
  const shared={
   id:'SCROLL_LIB_EDIT_'+(game.s.nextId++),
   libraryId:'LIB_EDIT_'+(game.s.nextId++),
   artId:art.id,
   nameTh:art.nameTh,
   tier:art.tier||1,
   rarityGrade:art.rarityGrade||grade.code,
   rarityBadgeTh:art.rarityBadgeTh||grade.badgeTh,
   rarityColor:art.rarityColor||grade.color,
   count:1,
   ownerNpcId:null,
   originalOwnerNpcId:null,
   donatedByNpcId:null,
   donatedAt:game.s.t,
   rights:'SECT_LIBRARY',
   sourceType:'SECT_LIBRARY',
   originLabelTh:art.originTag||'คัมภีร์ประทานเข้าหอสืบทอดโดยผู้ดูแลสำนัก (Edit Hub)',
   adminGrant:true
  };
  library.push(shared);
  history(game,'SCROLL_LIBRARY','SECT_LIBRARY','ประดิษฐานคัมภีร์ '+art.nameTh+' เข้าหอสืบทอด',[{field:art.nameTh,before:library.length-1,after:library.length}]);
  note(game,'Edit Hub: ประดิษฐานคัมภีร์'+shared.rarityBadgeTh+' «'+art.nameTh+'» เข้าหอสืบทอดสำนัก');
  return {ok:true,reason:'ประดิษฐานคัมภีร์ «'+art.nameTh+'» เข้าหอสืบทอดแล้ว',item:shared};
 }
 const n=game?.world?.npcs?.[targetId];if(!n||!n.jianghu?.ledgerV140)throw Error('ไม่พบผู้ฝึกตนที่จะมอบคัมภีร์');
 if(actorRole(game,n)==='storage')throw Error('ไม่สามารถมอบคัมภีร์ส่วนตัวให้คลังสำนักโดยตรง กรุณาเลือกหอคัมภีร์ส่วนรวมหรือศิษย์');
 if(n.jianghu.ledgerV140.scrolls.length>=24)throw Error('สัมภาระคัมภีร์ของ '+n.name+' เต็มแล้ว (24 ม้วน)');
 const item={
  id:'SCROLL_EDIT_'+(game.s.nextId++),
  artId:art.id,
  nameTh:art.nameTh,
  tier:art.tier||1,
  rarityGrade:art.rarityGrade||grade.code,
  rarityBadgeTh:art.rarityBadgeTh||grade.badgeTh,
  rarityColor:art.rarityColor||grade.color,
  count:1,
  ownerNpcId:n.id,
  rights:'OWNER',
  sourceType:'DISCOVERY',
  originLabelTh:'ผู้ดูแลสำนักมอบให้ (Edit Hub)',
  adminGrant:true
 };
 item.access='PRIVATE';item.canRedistribute=true;item.provenance=[{kind:'ADMIN_GRANT',npcId:n.id,at:game.s.t}];n.jianghu.ledgerV140.scrolls.push(item);
 history(game,'SCROLL',n.id,'มอบคัมภีร์ '+art.nameTh+' ให้ '+n.name,[{field:art.nameTh,before:0,after:1}]);
 note(game,'Edit Hub: มอบคัมภีร์'+item.rarityBadgeTh+' «'+art.nameTh+'» ให้ '+n.name,n);
 return {ok:true,reason:'มอบคัมภีร์ «'+art.nameTh+'» ให้ '+n.name+' แล้ว',item};
 }catch(e){return {ok:false,reason:e.message||'มอบคัมภีร์ไม่สำเร็จ'};}}
function listNpcs(game,opts={}){
 const filterRole=opts.role||opts.category||'disciple';
 const all=Object.values(game?.world?.npcs||{}).filter(n=>n?.stageLocal&&n?.core&&n?.jianghu);
 const filtered=filterRole==='ALL'?all.filter(n=>actorRole(game,n)!=='storage'):all.filter(n=>actorRole(game,n)===filterRole);
 return filtered.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'th'));
}
function listNpcsByCategory(game){
 return {
  disciples:listNpcs(game,{role:'disciple'}),
  visitors:[...listNpcs(game,{role:'courier'}),...listNpcs(game,{role:'envoy'}),...listNpcs(game,{role:'visitor'})],
  services:listNpcs(game,{role:'service'}),
  enemies:listNpcs(game,{role:'bandit'})
 };
}
function materialCatalog(){return (E.PATCH140_DATA?.MATERIALS_REGISTRY_V140||[]).slice().sort((a,b)=>(a.tier||1)-(b.tier||1)||String(a.nameTh).localeCompare(String(b.nameTh),'th'));}
function pillCatalog(game){return itemRecipeCatalog(game).filter(r=>r.outputType==='PILL');}
root.JianghuSafeEditor={editNpc,setResources,grantMaterial,grantPill,grantItem,grantScrollManual,manualCatalog,listNpcs,listNpcsByCategory,actorRole,materialCatalog,pillCatalog,itemRecipeCatalog,axisDefs,axisLabel,axisRead};
})(typeof globalThis!=='undefined'?globalThis:this);
