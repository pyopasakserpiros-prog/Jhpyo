/* Jianghu v1.16 Living Sect Coherence & Expansion.
   Expedition discoveries, shared archive, storage capacity, unified pill semantics,
   sanctuary affiliation, and causal NPC autonomy; Human Foundation (human.js) is unchanged. */
(function(root){'use strict';
const E=root.World2026Engine || (typeof require==='function'?require('./legacy/src/engine'):null);
const Human=root.HumanCore || (typeof require==='function'?require('./human'):null);
const Life=root.SectLifeSystem || (typeof require==='function'?require('./sect-life'):null);
const Realm=root.LivingJianghuSystem || (typeof require==='function'?require('./jianghu'):null);
const Growth=root.LivingProgression||(typeof require==='function'?require('./progression'):null);
const Combat=root.LivingCombat||(typeof require==='function'?require('./combat').LivingCombat:null);
const Academy=root.LivingAcademy||(typeof require==='function'?require('./academy').LivingAcademy:null);
const Myriad=root.JianghuMyriadWorlds||(typeof require==='function'?require('./myriad-worlds'):null);
const W=4000,H=3000,DAY=20,STEP=.1;
const B={
 hall:{name:'หอเจ้าสำนัก',icon:'🏯',gold:120,wood:6,ore:0,time:10,size:180,hp:700,cap:30,desc:'เปิดรับศิษย์ 6 คน เป็นศูนย์กลางสำนักสำหรับพักฟื้นและจัดเก็บเสบียง'},
 training:{name:'หอฝึกปราณ',icon:'☯',gold:180,wood:8,ore:4,time:18,size:170,hp:420,cap:5,desc:'ลานเดินลมปราณและสั่งสมหลักฐานเต๋า ก้าวหน้าเร็วกว่าฝึกฝนกลางแจ้ง'},
 alchemy:{name:'หอโอสถ',icon:'⚗',gold:170,wood:8,ore:2,time:22,size:150,hp:350,cap:2,desc:'เตาหลอมโอสถทิพย์ประจำสำนัก ว่าจ้างหมอโอสถปรุงยาตามตำรับและตัวยาจริง'},
 forge:{name:'โรงหลอม',icon:'⚒',gold:190,wood:6,ore:6,time:24,size:160,hp:400,cap:2,desc:'เตาหลอมศาสตราและเครื่องราง หล่อหลอมแร่ปราณและชิ้นส่วนอสูรเป็นยุทธภัณฑ์'},
 market:{name:'คลังและตลาดสำนัก',icon:'▤',gold:100,wood:6,ore:0,time:14,size:155,hp:400,cap:4,desc:'ศูนย์กลางคลังสินค้าและตลาดแลกเปลี่ยน เพิ่มพูนส่วยบำรุงและส่งคาราวานข้ามด่าน'},
 sanctuary:{name:'อุทยานอสูร',icon:'🐾',gold:150,wood:8,ore:3,time:20,size:150,hp:400,cap:4,desc:'อุทยานเลี้ยงดูและฟื้นฟูอสูรวิญญาณคู่พันธสัญญา ต้องใช้เสบียงอาหารดูแลจริง'},
 garden:{name:'สวนสมุนไพรวิญญาณ',icon:'🌿',gold:140,wood:8,ore:2,time:16,size:135,hp:320,cap:4,desc:'แปลงเพาะปลูกสมุนไพรวิญญาณ หว่านเมล็ด รดน้ำปราณ และเก็บเกี่ยวเป็นตัวยาจริง'},
 shrine:{name:'หอสืบทอด',icon:'✧',gold:170,wood:6,ore:4,time:22,size:150,hp:430,cap:4,desc:'หอบรรพชนและคลังคัมภีร์สืบทอด จุดธูปรำลึกผู้ล่วงลับ ถ่ายทอดวิชา และจารึกค่ายกล'},
 tower:{name:'หอพิทักษ์',icon:'♜',gold:150,wood:4,ore:4,time:18,size:120,hp:550,cap:0,desc:'หอคอยศรปราณพิทักษ์สำนัก โจมตีศัตรูที่บุกรุกในรัศมี 420 เมตรโดยอัตโนมัติ'}
};
const LOCS=[
 {id:'village',name:'หมู่บ้านชิงหยุน',x:1100,y:2180,icon:'⌂'},
 {id:'market',name:'ตลาดชายแดน',x:600,y:2040,icon:'⚖'},
 {id:'grove',name:'ดงสมุนไพรหยก',x:2430,y:2200,icon:'✿'},
 {id:'mine',name:'เหมืองเหล็กดำ',x:2720,y:1450,icon:'⛏'},
 {id:'woods',name:'ป่าเขี้ยวหมาป่า',x:3180,y:2400,icon:'♟'},
 {id:'camp',name:'ค่ายโจรผาทมิฬ',x:3340,y:590,icon:'⚑'},
 {id:'exit',name:'เส้นทางการค้า',x:180,y:1850,icon:'➜'},
 {id:'orchid',name:'ดงกล้วยไม้หมอก',x:2480,y:1850,icon:'✿'},
 {id:'cinder',name:'ทุ่งใบชาเพลิง',x:1940,y:2300,icon:'✿'},
 {id:'pond',name:'สระบัวหยก',x:2110,y:2550,icon:'❀'},
 {id:'ginseng',name:'ผาโสมโลหิต',x:1500,y:2500,icon:'✿'},
 {id:'cinnabar',name:'แอ่งชาดปราณ',x:2610,y:1590,icon:'◈'},
 {id:'scout',name:'สันเขาหมอก',x:3070,y:900,icon:'◈'},
 {id:'bamboo',name:'ป่าไผ่เมฆาคราม',x:2840,y:2290,icon:'🎋'},
 {id:'river',name:'ธาราหยกตะวันออก',x:2240,y:2580,icon:'💧'},
 {id:'crystal',name:'ถ้ำผลึกศิลา',x:2910,y:1320,icon:'💎'},
 {id:'ember',name:'ลานเถ้าดารา',x:1810,y:2340,icon:'🔥'},
 {id:'ridge',name:'สันเขาจันทราเหมันต์',x:3110,y:830,icon:'❄'},
 {id:'sanctuary',name:'อุทยานอสูรในสำนัก',x:1510,y:1510,icon:'🐾'}
];
const OBST=[{x:1770,y:680,w:440,h:820},{x:2200,y:2690,w:1000,h:220}];
const HERB='MAT_HERB_DEW_GRASS_1',ORE='MAT_ORE_BLACK_IRON_1',CIN='MAT_ORE_CINNABAR_1',FANG='MAT_BP_WOLF_FANG_1';
const DIST=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),clone=o=>JSON.parse(JSON.stringify(o));
const alive=n=>n&&n.alive&&n.health>0;const loc=id=>LOCS.find(x=>x.id===id);
const LOW_GRADE_PILL_IDS=['REC1100_SUPPORT_RECOVERY','REC1100_SUPPORT_QI','REC1100_SUPPORT_CLARITY','REC140_ALC_QI_DEW_1'];
const RECIPE_IDS=['REC1100_BREAK_XIAN_2',...LOW_GRADE_PILL_IDS,'REC140_FRG_IRON_BLADE_1',...(root.JianghuExpansionV111?.recipeIds||[]),...(root.JianghuExpansionV111?.recipeIdsV114||[])];
const SECLUSION_LOCK_PHASES=new Set(['ATTUNE','SECLUDE','TRANSFORM_OR_TRIAL','STABILIZE','CHANNELING']);
const STAGE_NEED_DEFAULTS=Object.freeze({hunger:20,social:25,safety:10});
// Save migration + runtime guard: old/externally-created NPCs (especially bandits
// and service NPCs) may have stageLocal but no needs object. Preserve every valid
// saved value and fill only absent/non-finite fields.
function ensureStageNeeds(n){
 const p=n?.stageLocal;
 if(!p||typeof p!=='object')return false;
 let changed=false;
 let needs=p.needs;
 if(!needs||typeof needs!=='object'||Array.isArray(needs)){needs={};p.needs=needs;changed=true;}
 for(const [key,fallback] of Object.entries(STAGE_NEED_DEFAULTS)){
  if(!Number.isFinite(needs[key])){needs[key]=fallback;changed=true;}
 }
 return changed;
}

if(Human?.registerActivity&&!Human.activities?.resupplyFood){
 Human.registerActivity({
  ...Human.descriptor('eat'),
  id:'resupplyFood',
  label:'จัดหาเสบียงจากหมู่บ้าน',
  skillDomain:'logistics',
  valueWeights:{sectDuty:.35,familyClan:.25,wealthResource:.2},
  personalityWeights:{discipline:.25,empathy:.2,caution:.15}
 });
}

const CROPS={
 dew:{id:'dew',name:'หญ้าน้ำค้างปราณ',seedName:'เมล็ดหญ้าน้ำค้าง',matId:'MAT_HERB_DEW_GRASS_1',tier:1,growSeconds:72,baseYield:3,seedCost:6,season:'SPRING'},
 cinder:{id:'cinder',name:'ใบชาเพลิงอรุณ',seedName:'เมล็ดชาเพลิง',matId:'MAT_HERB_CINDER_LEAF_1',tier:1,growSeconds:82,baseYield:3,seedCost:8,season:'SUMMER'},
 jadeLotus:{id:'jadeLotus',name:'บัวหยกเขียวร้อยปี',seedName:'เมล็ดบัวหยก',matId:'MAT_HERB_JADE_LOTUS_2',tier:2,growSeconds:118,baseYield:2,seedCost:20,season:'SPRING'},
 mistOrchid:{id:'mistOrchid',name:'กล้วยไม้หมอกสารท',seedName:'เมล็ดกล้วยไม้หมอก',matId:'MAT_HERB_MIST_ORCHID_2',tier:2,growSeconds:132,baseYield:2,seedCost:24,season:'AUTUMN'},
 bloodGinseng:{id:'bloodGinseng',name:'โสมโลหิตห้าร้อยปี',seedName:'เมล็ดโสมโลหิต',matId:'MAT_HERB_BLOOD_GINSENG_3',tier:3,growSeconds:168,baseYield:1,seedCost:42,season:'AUTUMN'},
 cloudPeony:{id:'cloudPeony',name:'โบตั๋นเมฆาคราม',seedName:'เมล็ดโบตั๋นเมฆาคราม',matId:'MAT_HERB_CLOUD_PEONY_2',tier:2,growSeconds:126,baseYield:2,seedCost:24,season:'SPRING'},
 thunderBamboo:{id:'thunderBamboo',name:'หน่อไผ่อัสนี',seedName:'เหง้าไผ่อัสนี',matId:'MAT_HERB_THUNDER_BAMBOO_3',tier:3,growSeconds:158,baseYield:1,seedCost:38,season:'SUMMER'},
 frostBerry:{id:'frostBerry',name:'ผลจันทราเหมันต์',seedName:'เมล็ดจันทราเหมันต์',matId:'MAT_HERB_FROST_MOON_BERRY_3',tier:3,growSeconds:172,baseYield:1,seedCost:44,season:'WINTER'},
 sunsetOrchid:{id:'sunsetOrchid',name:'กล้วยไม้สนธยา',seedName:'หัวกล้วยไม้สนธยา',matId:'MAT_HERB_SUNSET_ORCHID_4',tier:4,growSeconds:210,baseYield:1,seedCost:68,season:'AUTUMN'},
 soulLotus:{id:'soulLotus',name:'บัววิญญาณเจ็ดสี',seedName:'เมล็ดบัววิญญาณเจ็ดสี',matId:'MAT_HERB_SOUL_LOTUS_3',tier:3,growSeconds:165,baseYield:1,seedCost:46,season:'SPRING'},
 netherMushroom:{id:'netherMushroom',name:'เห็ดหลินจือทมิฬยมโลก',seedName:'สปอร์หลินจือทมิฬ',matId:'MAT_HERB_NETHER_MUSHROOM_3',tier:3,growSeconds:160,baseYield:1,seedCost:45,season:'AUTUMN'},
 starlightGrass:{id:'starlightGrass',name:'หญ้าดาราพันปี',seedName:'เมล็ดหญ้าดาราพันปี',matId:'MAT_HERB_STARLIGHT_GRASS_4',tier:4,growSeconds:205,baseYield:1,seedCost:65,season:'WINTER'}
};
const RESOURCE_NODE_DEFS=[
 {id:'grove',kind:'HERB',nameTh:'แปลงหญ้าน้ำค้างป่า',mat:HERB,locationId:'grove',x:2430,y:2200,qty:28,max:28,regen:.018,tier:1},
 {id:'cinder',kind:'HERB',nameTh:'ทุ่งใบชาเพลิง',mat:'MAT_HERB_CINDER_LEAF_1',locationId:'cinder',x:1940,y:2300,qty:22,max:22,regen:.014,tier:1},
 {id:'lotus',kind:'HERB',nameTh:'สระบัวหยก',mat:'MAT_HERB_JADE_LOTUS_2',locationId:'pond',x:2110,y:2550,qty:12,max:12,regen:.007,tier:2},
 {id:'orchid',kind:'HERB',nameTh:'ดงกล้วยไม้หมอก',mat:'MAT_HERB_MIST_ORCHID_2',locationId:'orchid',x:2480,y:1850,qty:14,max:14,regen:.006,tier:2},
 {id:'ginseng',kind:'HERB',nameTh:'ผาโสมโลหิต',mat:'MAT_HERB_BLOOD_GINSENG_3',locationId:'ginseng',x:1500,y:2500,qty:7,max:7,regen:.003,tier:3},
 {id:'mine',kind:'ORE',nameTh:'เหมืองเหล็กดำ',mat:ORE,locationId:'mine',x:2720,y:1450,qty:32,max:32,regen:.012,tier:1},
 {id:'cinnabar',kind:'ORE',nameTh:'แอ่งชาดปราณ',mat:CIN,locationId:'cinnabar',x:2610,y:1590,qty:16,max:16,regen:.006,tier:1},
 {id:'cloud-peony',kind:'HERB',nameTh:'โบตั๋นเมฆาคราม',mat:'MAT_HERB_CLOUD_PEONY_2',locationId:'bamboo',x:2840,y:2290,qty:16,max:16,regen:.006,tier:2},
 {id:'thunder-bamboo',kind:'HERB',nameTh:'ดงหน่อไผ่อัสนี',mat:'MAT_HERB_THUNDER_BAMBOO_3',locationId:'ember',x:1810,y:2340,qty:12,max:12,regen:.0035,tier:3},
 {id:'frost-berry',kind:'HERB',nameTh:'พุ่มผลจันทราเหมันต์',mat:'MAT_HERB_FROST_MOON_BERRY_3',locationId:'ridge',x:3110,y:830,qty:8,max:8,regen:.002,tier:3},
 {id:'sunset-orchid',kind:'HERB',nameTh:'หน้าผากล้วยไม้สนธยา',mat:'MAT_HERB_SUNSET_ORCHID_4',locationId:'river',x:2240,y:2580,qty:6,max:6,regen:.0015,tier:4},
 {id:'spirit-copper',kind:'ORE',nameTh:'สายแร่ทองแดงสื่อปราณ',mat:'MAT_ORE_SPIRIT_COPPER_2',locationId:'mine',x:2780,y:1380,qty:22,max:22,regen:.005,tier:2},
 {id:'cloud-jade',kind:'ORE',nameTh:'สายแร่หยกเมฆาคราม',mat:'MAT_ORE_CLOUD_JADE_3',locationId:'crystal',x:2910,y:1320,qty:12,max:12,regen:.002,tier:3},
 {id:'thunder-iron',kind:'ORE',nameTh:'สายแร่เหล็กอัสนีคราม',mat:'MAT_ORE_THUNDER_IRON_4',locationId:'ridge',x:3150,y:940,qty:7,max:7,regen:.001,tier:4}
];
const HABITAT_DEFS=[
 {id:'wolf-forest',name:'ป่าเขี้ยวหมอก',locationId:'woods',x:3180,y:2400,pool:['BEAST_MIST_WOLF'],maxAlive:3,initial:3,respawnSeconds:55,tierMin:1,tierMax:1},
 {id:'iron-ridge',name:'เนินเหมืองเหล็ก',locationId:'mine',x:2720,y:1450,pool:['BEAST_IRON_BOAR','BEAST_MIST_WOLF'],maxAlive:3,initial:3,respawnSeconds:70,tierMin:1,tierMax:2},
 {id:'jade-marsh',name:'ดงกล้วยไม้หมอก',locationId:'orchid',x:2480,y:1850,pool:['BEAST_IRON_BOAR','BEAST_EMERALD_PYTHON'],maxAlive:2,initial:2,respawnSeconds:85,tierMin:2,tierMax:3},
 {id:'cloud-bamboo',name:'ป่าไผ่เมฆาคราม',locationId:'bamboo',x:2840,y:2290,pool:['BEAST_CLOUD_FOX','BEAST_CLOUD_ANTLER_DEER','BEAST_MIST_WOLF'],maxAlive:3,initial:2,respawnSeconds:76,tierMin:1,tierMax:2},
 {id:'jade-tide',name:'ธาราเต่าหยก',locationId:'river',x:2240,y:2580,pool:['BEAST_JADE_TIDE_TURTLE','BEAST_CLOUD_ANTLER_DEER'],maxAlive:2,initial:1,respawnSeconds:105,tierMin:2,tierMax:3},
 {id:'ashen-roost',name:'รังอีกาเถ้าดารา',locationId:'ember',x:1810,y:2340,pool:['BEAST_ASHEN_CROW','BEAST_CLOUD_FOX'],maxAlive:2,initial:1,respawnSeconds:112,tierMin:2,tierMax:3},
 {id:'crystal-cave',name:'ถ้ำผลึกศิลา',locationId:'crystal',x:2910,y:1320,pool:['BEAST_CRYSTALBACK_APE','BEAST_IRON_BOAR'],maxAlive:2,initial:1,respawnSeconds:125,tierMin:2,tierMax:3},
 {id:'frost-ridge',name:'สันเขาจันทราเหมันต์',locationId:'ridge',x:3110,y:830,pool:['BEAST_FROST_MOON_LYNX','BEAST_FROST_BEAR'],maxAlive:2,initial:1,respawnSeconds:185,tierMin:4,tierMax:4},
 {id:'sect-sanctuary',name:'อุทยานอสูรสำนักเมฆาคราม',locationId:'sanctuary',x:1510,y:1510,pool:['BEAST_CLOUD_QILIN_CALF','BEAST_CLOUD_ANTLER_DEER'],maxAlive:2,initial:1,respawnSeconds:165,tierMin:2,tierMax:3,requiresBuilding:'sanctuary'}
];
const TRADE_MATERIAL_IDS=[...new Set([...RESOURCE_NODE_DEFS.map(n=>n.mat),HERB,ORE,CIN,FANG,'MAT_HERB_CINDER_LEAF_1','MAT_HERB_JADE_LOTUS_2','MAT_HERB_MIST_ORCHID_2','MAT_HERB_BLOOD_GINSENG_3','wood'])];

function makeRng(s){return new E.SeededRNG(s);}
function ensureExpansionRecipes(world,alchemist,smith){
 const exp=root.JianghuExpansionV111,reg=world?.jianghu?.systemsV140?.recipes?.registry;if(!exp||!reg)return;exp.registerCatalogs?.();
 const hashId=id=>{let h=2166136261;for(const c of String(id)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;};
 for(const tpl of [...exp.recipes,...(exp.recipesV114||[])]){let r=reg[tpl.id];if(!r){r={id:tpl.id,nameTh:tpl.nameTh,craftPath:tpl.craftPath,tier:tpl.tier,minMastery:tpl.minMastery,durationDays:tpl.durationDays,inputs:clone(tpl.inputs),outputType:tpl.outputType,outputSubSlot:tpl.outputSubSlot||null,outputNameTh:tpl.outputNameTh,compatiblePath:tpl.compatiblePath||'ANY',effect:clone(tpl.effect||{}),descTh:tpl.descTh,isPartial:false,missingFragments:0,isTranscendent:false,heritageOnly:false,originatorId:null,originatorNameTh:'สำนักเมฆาคราม',createdYear:Number(world.year)||2026,creationReasonTh:'ตำรับขยายสายการผลิตของสำนัก',parentRecipeId:null,branchType:'ORIGINAL',tradeoffId:'STANDARD',variants:[],recipeSeed:hashId(tpl.id),generatorVersion:140,status:'ACTIVE',scrollHolders:[{holderType:'SECT',holderId:'TH',isOriginal:true}],knowers:[],rightsOwner:{ownerType:'SECT',ownerId:'TH',minMeritOrTrust:tpl.tier*10},authorizedLearners:[],transmissionV160:{secrecy:'OPEN',heirId:null,teacherIds:[],lastPolicyTick:-1}};reg[tpl.id]=r;}
  const artisan=tpl.craftPath==='ALCHEMY'?alchemist:smith;if(artisan?.jianghu){r.originatorId=artisan.id;r.originatorNameTh=artisan.name;r.knowers=[...new Set([...(r.knowers||[]),artisan.id])];r.authorizedLearners=[...new Set([...(r.authorizedLearners||[]),artisan.id])];artisan.jianghu.knownRecipeIdsV140=artisan.jianghu.knownRecipeIdsV140||[];if(!artisan.jianghu.knownRecipeIdsV140.includes(tpl.id))artisan.jianghu.knownRecipeIdsV140.push(tpl.id);}
 }
}
class Frontier{
 constructor(seed=8821,legacy=0){
  this.E=E;this.world=E.createInitialWorld(seed);this.originalIds=Object.keys(this.world.npcs);this.world.tick=0;
  this.world.jianghu.progressionV1100.jobs=[];
  const cs=this.world.jianghu.causalV1180; if(cs){cs.commissions=[];cs.bounties=[];}
  E.invalidateWorldCityIndexV1100(this.world);
  this.city=this.world.states.TH.headquartersId;this.rng=makeRng(seed);this.acc=0;
  this.s={version:11,seed,t:0,speed:1,paused:false,buildings:[],heroIds:[],enemyIds:[],beasts:[],bounties:[],orders:[],log:[],transactions:[],wood:40,villageHP:1000,status:'playing',stable:0,denKills:0,campKnown:false,activation:null,campSupplies:100,raidAt:120,nextId:1,food:100,chapterCleared:false,legacy:Math.min(3,legacy),policy:'balanced',aidAt:-300,merchantStock:{},lastDay:0,combat:[],stats:{kills:0,crafted:0,breakthroughs:0,trades:0},route:{id:'jade',name:'ตลาดหยกตะวันตก',duration:38,risk:.12,capacity:8,stock:48},blueprints:[],seedStock:{dew:4,cinder:3,jadeLotus:1,mistOrchid:1,bloodGinseng:0,cloudPeony:0,thunderBamboo:0,frostBerry:0,sunsetOrchid:0,soulLotus:0,netherMushroom:0,starlightGrass:0},gardenPlots:[],groundDrops:[],ecology:{version:1,habitats:clone(HABITAT_DEFS).map(h=>({...h,nextSpawnAt:55}))}};
  this.bank=this.service('คลังสำนัก','BANK'); E.setSpiritStonesV140(this.bank,1400+Math.min(3,legacy)*40);
  this.alchemist=this.service('หมอซู · โอสถ','ALCHEMY');this.smith=this.service('ช่างหลี่ · โรงหลอม','FORGING');
  this.s.services={bank:this.bank.id,alchemist:this.alchemist.id,smith:this.smith.id};
  for(const [id,q] of [[HERB,12],[ORE,24],[CIN,8],[FANG,3]])this.add(this.bank,id,q,'STARTER_SUPPLY');
  this.s.nodes=clone(RESOURCE_NODE_DEFS);
  const reg=this.world.jianghu.systemsV140.recipes.registry;
  ensureExpansionRecipes(this.world,this.alchemist,this.smith);
  this.recipes=RECIPE_IDS.map(id=>reg[id]).filter(Boolean);
  for(const n of [this.alchemist,this.smith]){n.jianghu.knownRecipeIdsV140=[];n.jianghu.craftMasteryV140[n.stageLocal.service]=70;}
  for(const r of this.recipes){const a=r.craftPath==='ALCHEMY'?this.alchemist:this.smith;if(!a.jianghu.knownRecipeIdsV140.includes(r.id))a.jianghu.knownRecipeIdsV140.push(r.id);r.knowers=[...new Set([...(r.knowers||[]),a.id])];}
  this.configurePublicRecipes();
  for(const h of this.s.ecology.habitats){if(h.requiresBuilding&&!this.built(h.requiresBuilding)){h.nextSpawnAt=this.s.t+h.respawnSeconds;continue;}for(let i=0;i<h.initial;i++)this.spawnBeast(h.id);h.nextSpawnAt=this.s.t+h.respawnSeconds;}
  
  for(let i=0;i<3;i++)this.bandit(i===0,loc('camp').x+(i-1)*120,loc('camp').y+(i%2)*150);
  for(const id of this.originalIds)delete this.world.npcs[id];delete this.originalIds;this.pruneWorld();E.invalidateWorldCityIndexV1100(this.world);
  this.life=new Life.SectLife(this);this.realm=new Realm.LivingJianghu(this);this.progression=new Growth.Progression(this);this.academy=new Academy(this);this.discovery=new root.LivingDiscovery.Discovery(this);this.combatSystem=new Combat(this);this.myriad=Myriad?new Myriad.MyriadWorldsSystem(this):null;this.storyEvents=root.JianghuStoryEvents?new root.JianghuStoryEvents.StoryEventSystem(this):null;for(const b of this.s.beasts)this.myriad?.attachIndividualToMapBeast?.(b);for(const n of Object.values(this.world.npcs))if(n.stageLocal&&!n.stageLocal.pet)this.combatSystem.ensure(n);
  this.life?.syncLegacyPositions?.();
  this.note('เริ่มก่อตั้งสำนักเมฆาคราม · สร้างหอเจ้าสำนัก แล้วรับศิษย์สองคน');
 }
 establish(){const h=this.place('hall',950,1250);if(h.ok)h.building.remaining=0;const tr=this.place('training',1350,1250);if(tr.ok)tr.building.remaining=0;this.recruit();this.recruit();this.life?.syncLegacyPositions?.();this.note('สำนักเปิดประตูแล้ว · ศิษย์ออกแสวงหาตามใจตน เพิ่มอาคารหรือติดประกาศเพื่อชักจูง');}
 pruneWorld(){const w=this.world;w.states={TH:w.states.TH};w.cities=Object.fromEntries(Object.entries(w.cities).filter(([id,c])=>id===this.city||c.stateId==='TH'));for(const key of ['partyV260','kinV250','militaryUnits','armies','ships','camps','dynasties','carriers','alliances','powerNetworks','airForces','navies','chronicle']){if(w[key])w[key]=Array.isArray(w[key])?[]:{};}w.jianghu.rankings={};if(w.newWorld){w.newWorld.routes=[];w.newWorld.maps={};w.newWorld.subsiteDefinitions={};w.newWorld.mines=[];}w.jianghu.systemsV140.ecology.nodes=[];}
 service(name,kind){const role=kind==='BANK'?'storage':'service';const n=this.create(name,{role,preserveName:true});n.stageLocal={service:kind,role,x:600,y:2040};ensureStageNeeds(n);E.setSpiritStonesV140(n,0);return n;}
 isSectStorage(owner){return !!owner&&(owner===this.bank||owner.id===this.s?.services?.bank||owner.stageLocal?.service==='BANK'||owner.stageLocal?.role==='storage');}
 withOwnerCaps(owner,fn){
  const caps=E.PATCH140_CAPS;
  if(!caps||!this.isSectStorage(owner))return fn();
  const prev={materialStacks:caps.materialStacks,pillStacks:caps.pillStacks,equipmentItems:caps.equipmentItems,beastItems:caps.beastItems,scrollsPerOwner:caps.scrollsPerOwner};
  try{
   caps.materialStacks=root.JianghuInfrastructure?.bonuses(this).materialCapacity||640;caps.pillStacks=128;caps.equipmentItems=240;caps.beastItems=96;caps.scrollsPerOwner=240;
   return fn();
  }finally{
   Object.assign(caps,prev);
  }
 }
 isHostileCreature(e){
  if(!e||!e.alive||e.health<=0)return false;
  if(e.stageLocal?.enemy)return true;
  if(e.sanctuaryResident||e.affiliation==='SECT_SANCTUARY'||e.hostile===false||e.habitatId==='sect-sanctuary')return false;
  return true;
 }
 ensureEcologyState(migrate=false){if(!this.s.seedStock)this.s.seedStock={dew:4,cinder:3,jadeLotus:1,mistOrchid:1,bloodGinseng:0,cloudPeony:0,thunderBamboo:0,frostBerry:0,sunsetOrchid:0,soulLotus:0,netherMushroom:0,starlightGrass:0};for(const id of Object.keys(CROPS))if(!Number.isFinite(this.s.seedStock[id]))this.s.seedStock[id]=0;if(!Array.isArray(this.s.gardenPlots))this.s.gardenPlots=[];if(!Array.isArray(this.s.groundDrops))this.s.groundDrops=[];if(!Array.isArray(this.s.beasts))this.s.beasts=[];if(!this.s.ecology?.habitats)this.s.ecology={version:1,habitats:clone(HABITAT_DEFS).map(h=>({...h,nextSpawnAt:(this.s.t||0)+h.respawnSeconds}))};for(const def of HABITAT_DEFS)if(!this.s.ecology.habitats.some(h=>h.id===def.id))this.s.ecology.habitats.push({...clone(def),nextSpawnAt:(this.s.t||0)+def.respawnSeconds});if(!Array.isArray(this.s.nodes))this.s.nodes=[];for(const def of RESOURCE_NODE_DEFS){let node=this.s.nodes.find(n=>n.id===def.id);if(!node)this.s.nodes.push({...def});else Object.assign(node,{kind:def.kind,nameTh:def.nameTh,mat:def.mat,locationId:def.locationId,tier:def.tier,max:node.max||def.max,regen:def.regen});}for(const h of this.s.ecology.habitats){h.nextSpawnAt=Number.isFinite(h.nextSpawnAt)?h.nextSpawnAt:(this.s.t||0)+h.respawnSeconds;}for(const n of this.heroes)if(n.stageLocal){n.stageLocal.known=n.stageLocal.known||[];for(const id of ['bamboo','river','crystal','ember','ridge','sanctuary'])if(!n.stageLocal.known.includes(id))n.stageLocal.known.push(id);}for(const b of this.s.beasts||[]){if(!b.speciesId)b.speciesId=/หมูป่า|อสูรเขี้ยวเหล็ก/.test(b.name||'')?'BEAST_IRON_BOAR':/เหลือม|งู/.test(b.name||'')?'BEAST_EMERALD_PYTHON':'BEAST_MIST_WOLF';const species=(E.PATCH140_DATA?.BEAST_SPECIES_V140||[]).find(x=>x.id===b.speciesId);if(!b.habitatId)b.habitatId=species?.tier>=3?'jade-marsh':species?.tier===2?'iron-ridge':'wolf-forest';const habitat=this.s.ecology.habitats.find(h=>h.id===b.habitatId);b.habitatName=habitat?.name||'ป่าเขี้ยวหมอก';b.tier=species?.tier||1;const isSanctuary=b.habitatId==='sect-sanctuary';b.sanctuaryResident=isSanctuary;b.affiliation=isSanctuary?'SECT_SANCTUARY':'WILD';b.hostile=!isSanctuary;const variant=root.JianghuExpansionV112?.beastVariantsV114?.find(v=>v.id===b.variantId);b.power=Number.isFinite(b.power)?b.power:Math.round((species?.combatPower||95)*(variant?.powerMult||1));b.maxHP=Number.isFinite(b.maxHP)?b.maxHP:Math.round((58+(species?.tier||1)*26)*(variant?.hpMult||1));b.health=Math.max(0,Math.min(Number.isFinite(b.health)?b.health:b.maxHP,b.maxHP));b.home=b.home||{x:habitat?.x||b.x,y:habitat?.y||b.y};b.corpseUntil=b.alive?0:(this.s.t||0)+8;}if(migrate){for(const h of this.s.ecology.habitats){if(h.requiresBuilding&&!this.built(h.requiresBuilding))continue;const aliveCount=(this.s.beasts||[]).filter(b=>b.alive&&b.habitatId===h.id).length;for(let i=aliveCount;i<h.initial;i++)this.spawnBeast(h.id);h.nextSpawnAt=(this.s.t||0)+h.respawnSeconds;}}}
 configurePublicRecipes(){
  const reg=this.world.jianghu.systemsV140.recipes.registry;
  for(const id of LOW_GRADE_PILL_IDS){const r=reg[id];if(!r)continue;r.status='ACTIVE';r.isPartial=false;r.minMastery=Math.min(15,Number(r.minMastery)||15);r.rightsOwner={ownerType:'PUBLIC',ownerId:null,policy:'PUBLIC_BASIC'};r.transmissionV160={...(r.transmissionV160||{}),secrecy:'PUBLIC',teacherIds:[]};const valid=id=>id===this.alchemist?.id||this.s.heroIds.includes(id);r.knowers=(r.knowers||[]).filter(valid);r.authorizedLearners=(r.authorizedLearners||[]).filter(valid);}
  for(const n of [this.alchemist,...(this.heroes||[])])this.teachPublicRecipes(n);
 }
 teachPublicRecipes(n){if(!n?.alive||!n.jianghu)return;const reg=this.world.jianghu.systemsV140.recipes.registry;n.jianghu.knownRecipeIdsV140=n.jianghu.knownRecipeIdsV140||[];for(const id of LOW_GRADE_PILL_IDS){const r=reg[id];if(!r)continue;if(!n.jianghu.knownRecipeIdsV140.includes(id))n.jianghu.knownRecipeIdsV140.push(id);r.knowers=[...new Set([...(r.knowers||[]),n.id])];r.authorizedLearners=[...new Set([...(r.authorizedLearners||[]),n.id])];}}
 createGardenPlots(building){for(let i=0;i<4;i++){const row=Math.floor(i/2),col=i%2;this.s.gardenPlots.push({id:`plot_${building.id}_${i+1}`,buildingId:building.id,slot:i+1,cropId:null,growth:0,moisture:68,care:0,plantedAt:null,reservedBy:null,reservedUntil:0,x:building.x+(col?46:-46),y:building.y+88+row*34});}}
 spawnBeast(habitatId,speciesId=null,opts={}){const h=this.s.ecology?.habitats?.find(x=>x.id===habitatId);if(!h)return null;const catalog=E.PATCH140_DATA?.BEAST_SPECIES_V140||[];const exp=root.JianghuExpansionV112;const useExpanded=(this.s.t>2||opts.lured)&&!(habitatId==='sect-sanctuary'&&this.s.t<=2);const poolIds=useExpanded&&exp?.habitatPoolsV114?.[habitatId]?exp.habitatPoolsV114[habitatId]:h.pool;const candidates=poolIds.map(id=>catalog.find(x=>x.id===id)).filter(Boolean);const species=speciesId?catalog.find(x=>x.id===speciesId):candidates[this.rng.int(0,Math.max(0,candidates.length-1))];if(!species)return null;let variant=exp?.beastVariantsV114?.[0]||{id:'NORMAL',prefixTh:'',hpMult:1,powerMult:1,extraDropCount:0,bonusStones:0};const isSanctuary=h.id==='sect-sanctuary';if(!isSanctuary&&(this.s.t>25||opts.lured)&&exp?.beastVariantsV114){const vList=opts.lured?exp.beastVariantsV114.slice(1):exp.beastVariantsV114;const totalW=vList.reduce((s,v)=>s+(v.weight||10),0);let roll=(this.rng?this.rng.next():((Math.abs(this.s.nextId*9301+Math.floor(this.s.t*17))%1000)/1000))*totalW;for(const v of vList){roll-=(v.weight||10);if(roll<=0){variant=v;break;}}}const maxHP=Math.round((58+species.tier*26)*(variant.hpMult||1));const b={id:'beast'+this.s.nextId++,name:(variant.prefixTh||'')+species.nameTh,speciesId:species.id,tier:species.tier,variantId:variant.id,variantBadgeTh:variant.badgeTh||null,extraDropCount:variant.extraDropCount||0,bonusStones:variant.bonusStones||0,habitatId:h.id,habitatName:h.name,sanctuaryResident:isSanctuary,affiliation:isSanctuary?'SECT_SANCTUARY':'WILD',hostile:!isSanctuary,x:h.x+this.rng.int(-90,90),y:h.y+this.rng.int(-90,90),home:{x:h.x,y:h.y},health:maxHP,maxHP,power:Math.round(species.combatPower*(variant.powerMult||1)),alive:true,target:null,mode:'patrol',nextMove:this.s.t+this.rng.int(1,8),attackAt:0,route:[],corpseUntil:0};this.myriad?.attachIndividualToMapBeast?.(b);this.s.beasts.push(b);return b;}
 lureRareBeast(habitatId,actorId=null){
  const h=this.s.ecology.habitats.find(h=>h.id===habitatId),actor=actorId?this.world.npcs[actorId]:null;
  if(!h)return {ok:false,reason:'ไม่พบถิ่นอาศัยสัตว์อสูร'};
  if(h.requiresBuilding&&!this.built(h.requiresBuilding))return {ok:false,reason:'ต้องสร้างอุทยานอสูรให้เสร็จก่อน'};
  if(this.s.beasts.filter(b=>b.alive&&b.habitatId===h.id).length>=h.maxAlive)return {ok:false,reason:'ประชากรเต็มถิ่นอาศัยแล้ว'};
  if(actorId&&(!alive(actor)||DIST(actor.stageLocal,h)>140))return {ok:false,reason:'ผู้ล่อต้องเดินไปถึงถิ่นอาศัยก่อน'};
  const owner=actor||this.bank,items=owner.jianghu.ledgerV140.beastItems||[],stack=items.find(x=>x.count>0&&x.effect?.lureRareBeast);
  if(!stack)return {ok:false,reason:'ต้องมีกำยานที่มีผลล่ออสูรในสัมภาระผู้ใช้หรือคลังสำนัก'};
  const ids=root.JianghuExpansionV112?.habitatPoolsV114?.[habitatId]||h.pool,catalog=E.PATCH140_DATA.BEAST_SPECIES_V140;
  const species=ids.map(id=>catalog.find(x=>x.id===id)).filter(Boolean).sort((a,b)=>b.tier-a.tier)[0];
  if(!species)return {ok:false,reason:'ไม่พบชนิดอสูรที่เหมาะกับถิ่นนี้'};
  const spawned=this.spawnBeast(h.id,species.id,{lured:true});if(!spawned)return {ok:false,reason:'อสูรไม่ตอบสนอง'};
  stack.count--;this.note((actor?.name||'สำนัก')+' ใช้'+stack.nameTh+' ณ '+h.name+' ดึงดูด '+spawned.name,actor);return {ok:true,beast:spawned};
 }
 dropBeastLoot(beast,attacker){
  if(!this.isHostileCreature(beast)&&beast.sanctuaryResident)return [];
  if(beast.harvestedOnce)return [];
  beast.harvestedOnce=true;
  if(this.myriad){
   this.myriad.attachIndividualToMapBeast(beast);
   const hRes=this.myriad.harvestIndividualCorpse(attacker&&this.s.heroIds.includes(attacker.id)&&alive(attacker)?attacker:this.bank,beast,{onMap:true,originType:'MAP_BEAST_HUNT',originId:beast.habitatId||beast.speciesId});
   const made=(hRes.items||[]).map(x=>({matId:x.matId,count:x.quantity,quality:x.quality}));
   if(hRes.organResult?.recovered)made.push({matId:hRes.organResult.matId,count:1,quality:hRes.organResult.quality,isRareOrgan:true});
   if(beast.bonusStones&&attacker&&this.s.heroIds.includes(attacker.id))E.addSpiritStonesV140(attacker,beast.bonusStones);
   if(made.length)this.note(`${attacker?.name||'ผู้พิทักษ์'} ชำแหละชิ้นส่วนจาก${beast.name}: ${made.map(x=>x.matId.replace('MAT_BP_','')+' ×'+x.count).join(', ')}${hRes.organResult?.recovered?' · 🌟 พบอวัยวะพิเศษ «'+hRes.organResult.nameTh+'»':''}${beast.bonusStones?' · โบนัสปราณอสูร +'+beast.bonusStones+' ศิลา':''}`,attacker||null);
   return made;
  }
  const species=(E.PATCH140_DATA?.BEAST_SPECIES_V140||[]).find(x=>x.id===beast.speciesId);if(!species)return [];const recipient=attacker&&this.s.heroIds.includes(attacker.id)&&alive(attacker)?attacker:this.bank;const drops=(species.partDrops||[]).slice(0,species.maxDropSlots|| (species.tier>=3?3:2)),made=[];const extraFromVariant=Number(beast.extraDropCount||0);for(let i=0;i<drops.length;i++){const d=drops[i],count=(species.tier>=2&&this.rng.chance(.22)?2:1)+(i===0?extraFromVariant:0);let res=this.add(recipient,d.matId,count,'BEAST_HUNT_'+beast.speciesId);if(!res.ok&&recipient!==this.bank)res=this.add(this.bank,d.matId,count,'BEAST_HUNT_'+beast.speciesId);if(res.ok)made.push({matId:d.matId,count});else this.s.groundDrops.push({id:'drop'+this.s.nextId++,matId:d.matId,count,x:beast.x,y:beast.y,source:beast.name,expiresAt:this.s.t+600});}if(beast.bonusStones&&attacker&&this.s.heroIds.includes(attacker.id))E.addSpiritStonesV140(attacker,beast.bonusStones);if(made.length)this.note(`${attacker?.name||'ผู้พิทักษ์'} ชำแหละชิ้นส่วนจาก${beast.name}: ${made.map(x=>x.matId.replace('MAT_BP_','')+' ×'+x.count).join(', ')}${beast.bonusStones?' · โบนัสปราณอสูร +'+beast.bonusStones+' ศิลา':''}`,attacker||null);return made;}
 plant(plotId,cropId,actorId=null){const p=this.s.gardenPlots.find(x=>x.id===plotId),crop=CROPS[cropId],b=p&&this.s.buildings.find(x=>x.id===p.buildingId);if(!p||!crop)return {ok:false,reason:'ไม่พบแปลงหรือเมล็ดพันธุ์'};if(!b||b.hp<=0||b.remaining>0)return {ok:false,reason:'สวนสมุนไพรยังสร้างไม่เสร็จ'};if(p.cropId)return {ok:false,reason:'แปลงนี้มีพืชอยู่แล้ว'};if((this.s.seedStock[cropId]||0)<1)return {ok:false,reason:'เมล็ดพันธุ์ไม่พอ ต้องซื้อหรือเก็บเมล็ดคืนจากการเก็บเกี่ยว'};this.s.seedStock[cropId]--;p.cropId=cropId;p.growth=0;p.moisture=Math.max(55,p.moisture||0);p.care=0;p.plantedAt=this.s.t;p.reservedBy=null;p.reservedUntil=0;this.note(`${actorId?this.world.npcs[actorId]?.name+' ปลูก':'สำนักปลูก'}${crop.name}ในแปลง ${p.slot}`,actorId?this.world.npcs[actorId]:null);return {ok:true,plot:p,crop};}
 water(plotId,actorId=null){const p=this.s.gardenPlots.find(x=>x.id===plotId);if(!p?.cropId)return {ok:false,reason:'แปลงนี้ยังไม่มีพืช'};const crop=CROPS[p.cropId];if(p.growth>=crop.growSeconds)return {ok:false,reason:'พืชสุกแล้ว เก็บเกี่ยวได้เลย'};if(p.moisture>=94)return {ok:false,reason:'ดินชุ่มน้ำเพียงพอแล้ว'};p.moisture=Math.min(100,p.moisture+48);p.care=(p.care||0)+1;p.reservedBy=null;p.reservedUntil=0;this.note(`${actorId?this.world.npcs[actorId]?.name+' รดน้ำ':'สำนักรดน้ำ'}${crop.name} · ความชื้น ${Math.round(p.moisture)}%`,actorId?this.world.npcs[actorId]:null);return {ok:true,moisture:p.moisture};}
 harvestGarden(plotId,actorId=null){const p=this.s.gardenPlots.find(x=>x.id===plotId),crop=p&&CROPS[p.cropId],b=p&&this.s.buildings.find(x=>x.id===p.buildingId);if(!p||!crop||!b||b.remaining>0||b.hp<=0)return {ok:false,reason:'ไม่พบพืชที่เก็บเกี่ยวได้'};if(p.growth<crop.growSeconds)return {ok:false,reason:'พืชยังไม่โตเต็มที่'};const qty=crop.baseYield+(p.moisture>=65&&crop.tier===1?1:0);const actor=actorId&&this.world.npcs[actorId],recipient=actor&&Human.load(actor)+qty<=Human.carryLimit(actor)?actor:this.bank;const res=this.add(recipient,crop.matId,qty,'GARDEN_HARVEST_'+p.id);if(!res.ok)return {ok:false,reason:'คลังเต็ม เก็บเกี่ยวไม่ได้จนกว่าจะจัดพื้นที่'};const seedChance=Math.min(.78,.25+(p.care||0)*.08+(p.moisture>=50?.18:0)),seedReturned=this.rng.chance(seedChance);if(seedReturned)this.s.seedStock[crop.id]=(this.s.seedStock[crop.id]||0)+1;p.cropId=null;p.growth=0;p.moisture=35;p.care=0;p.plantedAt=null;p.reservedBy=null;p.reservedUntil=0;this.note(`${actor?.name||'สำนัก'}เก็บ${crop.name}ได้ ${qty} หน่วย${recipient===this.bank?' เข้าคลังสำนัก':' ใส่สัมภาระศิษย์'}${seedReturned?' · ได้เมล็ดคืน':''}`,actor||null);return {ok:true,matId:crop.matId,count:qty,recipientId:recipient.id,seedReturned};}
 buySeeds(cropId,qty=1){const crop=CROPS[cropId];if(!crop||!Number.isInteger(qty)||qty<1||qty>10)return {ok:false,reason:'จำนวนเมล็ดพันธุ์ไม่ถูกต้อง'};const cost=crop.seedCost*qty;if(!this.money(-cost,'ซื้อ'+crop.seedName+' ×'+qty))return {ok:false,reason:'หินวิญญาณไม่พอ'};this.s.seedStock[cropId]=(this.s.seedStock[cropId]||0)+qty;this.note(`ซื้อ${crop.seedName} ×${qty} ใช้ ${cost} ศิลา`);return {ok:true,cropId,qty,cost};}
 collectDrop(dropId,actorId=null){const d=this.s.groundDrops.find(x=>x.id===dropId);if(!d)return {ok:false,reason:'วัตถุดิบตกพื้นไม่มีอยู่แล้ว'};const actor=actorId&&this.world.npcs[actorId],recipient=actor&&Human.load(actor)+d.count<=Human.carryLimit(actor)?actor:this.bank;const r=this.add(recipient,d.matId,d.count,'GROUND_LOOT_PICKUP');if(!r.ok)return {ok:false,reason:'คลังและสัมภาระเต็ม'};this.s.groundDrops=this.s.groundDrops.filter(x=>x.id!==dropId);this.note(`${actor?.name||'สำนัก'}เก็บวัตถุดิบตกพื้น ${d.matId} ×${d.count}`,actor||null);return {ok:true};}
 sharePill(fromId,toId,pillId,count=1){
  const from=this.world.npcs[fromId],to=this.world.npcs[toId];
  if(!from?.alive||!to?.alive||from.id===to.id)return {ok:false,reason:'ต้องเลือกผู้ให้และผู้รับที่มีชีวิตคนละคน'};
  if(!Number.isInteger(count)||count<1)return {ok:false,reason:'จำนวนโอสถไม่ถูกต้อง'};
  if(this.isSectStorage(from)&&this.s.storyEvents?.active&&root.JianghuSectContributions)return root.JianghuSectContributions.acquire(this,to,'PILL',pillId,'GRANT');
  const src=from.jianghu.ledgerV140.pillStacks.find(x=>x.id===pillId&&x.count>=count);
  if(!src||src.loan||src.rights==='LOAN'||src.canRedistribute===false||[src.ownerNpcId,src.ownerId].some(id=>id&&id!==from.id))return {ok:false,reason:'ผู้ให้ไม่มีสิทธิ์แบ่งโอสถกองนี้'};
  const signature=x=>JSON.stringify(Object.fromEntries(Object.keys(x).sort().filter(k=>!['id','count','ownerId','ownerNpcId','custodianNpcId','originalStackId'].includes(k)).map(k=>[k,x[k]])));
  let dst=to.jianghu.ledgerV140.pillStacks.find(x=>!x.loan&&x.rights!=='LOAN'&&[x.ownerNpcId,x.ownerId].every(id=>!id||id===to.id)&&signature(x)===signature(src));
  if(!dst){const cap=this.isSectStorage(to)?128:16;if(to.jianghu.ledgerV140.pillStacks.length>=cap)return {ok:false,reason:'คลังโอสถผู้รับเต็ม'};dst={...clone(src),id:'PILL_SHARE_'+this.s.nextId++,count:0,ownerNpcId:to.id};if('ownerId'in dst)dst.ownerId=to.id;if('custodianNpcId'in dst)dst.custodianNpcId=to.id;to.jianghu.ledgerV140.pillStacks.push(dst);}
  src.count-=count;dst.count+=count;from.jianghu.ledgerV140.pillStacks=from.jianghu.ledgerV140.pillStacks.filter(x=>x.count>0);E.syncLegacyArraysFromLedgerV140(from);E.syncLegacyArraysFromLedgerV140(to);this.note(`${from.name}แบ่ง${src.nameTh} ×${count} ให้${to.name}`);return {ok:true,count,fromId,toId,pillId:dst.id};
 }

 stepEcology(dt){for(const node of this.s.nodes)node.qty=Math.min(node.max,node.qty+node.regen*dt);for(const p of this.s.gardenPlots){const b=this.s.buildings.find(x=>x.id===p.buildingId),crop=CROPS[p.cropId];if(!crop||!b||b.hp<=0||b.remaining>0||p.growth>=crop.growSeconds)continue;p.moisture=Math.max(0,p.moisture-dt*.48);p.growth=Math.min(crop.growSeconds,p.growth+dt*(p.moisture>=18?1:.28));if(p.growth>=crop.growSeconds)this.note(`${crop.name}ในแปลง ${p.slot} สุกพร้อมเก็บเกี่ยว`);}for(const h of this.s.ecology.habitats){if(h.requiresBuilding&&!this.built(h.requiresBuilding))continue;const living=this.s.beasts.filter(b=>b.alive&&b.habitatId===h.id).length;if(living<h.maxAlive&&this.s.t>=h.nextSpawnAt){const spawned=this.spawnBeast(h.id);h.nextSpawnAt=this.s.t+h.respawnSeconds;if(living===0&&spawned)this.note(`สัตว์อสูรกลับมาอาศัยใน${h.name}`);}}this.s.beasts=this.s.beasts.filter(b=>b.alive||(b.corpseUntil||0)>this.s.t);this.s.groundDrops=this.s.groundDrops.filter(d=>d.expiresAt>this.s.t);}
 harvestNode(nodeId,actorId){const node=this.s.nodes.find(x=>x.id===nodeId),n=this.world.npcs[actorId];if(!node||!n?.alive)return {ok:false,reason:'ไม่พบแหล่งทรัพยากรหรือผู้เก็บ'};const action=node.kind==='HERB'?'herb':'mine',q=Math.min(Human.harvestLimit(n,action),Math.floor(node.qty));if(q<=0)return {ok:false,reason:'แหล่งนี้ถูกเก็บจนหมดชั่วคราว'};const r=this.add(n,node.mat,q,'HARVEST_'+node.id);if(!r.ok)return {ok:false,reason:'สัมภาระเต็ม'};node.qty-=q;E.recordTrackDaoEvidenceV1200(this.world,n,'RESOURCE_GATHERING',4);this.note(`${n.name}เก็บ${node.nameTh} ${q} หน่วย`,n);return {ok:true,count:q,matId:node.mat};}

 create(name,opts={}){
  const w=this.world,role=opts.role||'disciple',isDisciple=role==='disciple'&&!opts.visitor;
  const savedPositions=w.states?.TH?.positions?clone(w.states.TH.positions):null;
  const savedUntracked=w.states?.TH?.jianghu?.untrackedPositions?clone(w.states.TH.jianghu.untrackedPositions):null;
  const res=E.createNpcWithCore(w,{nameTh:name,age:opts.age||22,stage:opts.stage||1,sectId:'TH',untrainedNovice:false});
  if(!res?.ok)throw Error(res?.reason||'NPC creation failed');
  const n=res.npc;
  if(opts.preserveName||role!=='disciple'||opts.visitor){
   n.name=name;
   n.firstName=name.split(' ')[0]||name;
  }
  if(!isDisciple){
   if(savedPositions&&w.states?.TH)w.states.TH.positions=savedPositions;
   if(savedUntracked&&w.states?.TH?.jianghu)w.states.TH.jianghu.untrackedPositions=savedUntracked;
   n.positionId=role==='bandit'?'BANDIT':role==='storage'?'SECT_VAULT':role==='service'?'ARTISAN':'VISITOR';
   n.positionTitle=role==='bandit'?'โจรนอกด่าน':role==='storage'?'คลังสำนัก':role==='service'?'ช่างประจำหอ':'ผู้มาเยือน';
   if(role==='bandit'){n.stateId=null;n.isRogue=true;}
  }
  n.health=100;n.alive=true;n.currentCityId=n.assignedNodeId=n.homeCityId=this.city;
  Object.assign(n.jianghu,{closedDoor:{active:false},inSeclusion:false,captiveBy:null,busyProductionUntilTick:-1,lifeGoalV161:{lastActionTick:-100,task:null},activeNeedsV1180:[],heartDemonsV1180:[],heartDemon:0,internalInjury:0,poisonAccumulated:0,pillToxicity:0,newWorldJourney:null,foundationStability:58,daoComprehension:52,meridiansV150:{}});
  const l=n.jianghu.ledgerV140;for(const k of ['materialStacks','pillStacks','equipmentItems','scrolls','beastItems'])l[k]=[];
  n.jianghu.artifacts=[];n.jianghu.pills=[];n.jianghu.materials=[];n.jianghu.traits=[];n.jianghu.equipmentV140={};E.setSpiritStonesV140(n,25);
  E.syncNpcCultivationIdentityV1200(w,n,{trackOrdinal:1,progress:0});Human.ensure(n,this.s.seed,{fresh:true});
  this.life?.syncLegacyPositions?.();
  return n;
 }
 get heroes(){return this.s.heroIds.map(id=>this.world.npcs[id]);} get enemies(){return this.s.enemyIds.map(id=>this.world.npcs[id]).filter(Boolean);}
 get gold(){return E.getSpiritStonesV140(this.bank);} get ore(){return this.count(this.bank,ORE);}
 ownsMaterial(n,s){return !!s&&!s.loan&&!s.loanedTo&&!s.loanedToNpcId&&s.rights!=='LOAN'&&!s.reservedForFormation&&s.canRedistribute!==false&&[s.ownerNpcId,s.ownerId].every(id=>!id||id===n.id);}
 count(n,id){return (n?.jianghu?.ledgerV140?.materialStacks||[]).filter(s=>s.matId===id&&this.ownsMaterial(n,s)).reduce((sum,s)=>sum+Math.max(0,s.count||0),0);}
 add(n,id,q,source='LOCAL',opts={}){
  return this.withOwnerCaps(n,()=>{
   const def=(E.PATCH140_DATA?.MATERIALS_REGISTRY_V140||[]).find(m=>m.id===id);
   const isTrans=!!(def?.isTranscendent||opts.isTranscendent);
   const payload={
    originType:opts.originType||(isTrans?'HERITAGE_SITE':'STAGE'),
    originId:opts.originId||(isTrans?'LEG_01':source),
    originLabelTh:opts.originLabelTh||source,
    quality:opts.quality||'STANDARD',
    isTranscendent:isTrans,
    allowTransferFromExistingHeritageStack:!!opts.allowTransferFromExistingHeritageStack
   };
   if(!this.canAcceptMaterial(n,id,payload))return {ok:false,reason:'คลังไม่มีช่องรับวัตถุดิบที่เป็นสิทธิ์ของผู้รับ'};
   const ledger=n.jianghu.ledgerV140,sameCohort=s=>this.ownsMaterial(n,s)&&(s.contributionCreditAllowed===false)===(opts.contributionCreditAllowed===false),protectedStacks=ledger.materialStacks.filter(s=>!sameCohort(s));
   ledger.materialStacks=ledger.materialStacks.filter(s=>sameCohort(s));
   try{const r=E.addMaterialToLedgerV140(this.world,n,id,q,payload);if(r.ok)for(const s of ledger.materialStacks)if(s.matId===id){if(opts.contributionCreditAllowed!==undefined)s.contributionCreditAllowed=opts.contributionCreditAllowed;if(opts.sectGrant!==undefined)s.sectGrant=clone(opts.sectGrant);}return r;}
   finally{ledger.materialStacks.push(...protectedStacks);E.syncLegacyArraysFromLedgerV140(n);}
  });
 }
 debitMaterialStack(owner,stack,quantity){
  const before=stack.count,take=Math.max(0,Math.min(before,quantity));
  if(this.isSectStorage(owner)&&(Number.isFinite(stack.storeCount)||stack.sectStore)){
   const store=Number.isFinite(stack.storeCount)?Math.min(before,Math.max(0,stack.storeCount)):before;
   stack.storeCount=Math.max(0,store-Math.max(0,take-(before-store)));stack.sectStore=stack.storeCount>0;
  }
  stack.count-=take;return take;
 }
 consume(n,id,q){if(!Number.isInteger(q)||q<0||this.count(n,id)<q)return false;let left=q;for(const s of n.jianghu.ledgerV140.materialStacks){if(s.matId!==id||!this.ownsMaterial(n,s))continue;const take=Math.min(left,s.count);this.debitMaterialStack(n,s,take);left-=take;if(left<=0)break;}n.jianghu.ledgerV140.materialStacks=n.jianghu.ledgerV140.materialStacks.filter(s=>s.count>0);E.syncLegacyArraysFromLedgerV140(n);return left===0;}
 canAcceptMaterial(owner,matId,opts={}){
  if(!owner?.jianghu?.ledgerV140)return false;
  const def=(E.PATCH140_DATA?.MATERIALS_REGISTRY_V140||[]).find(m=>m.id===matId);
  if(!def)return false;
  const isTrans=!!(def.isTranscendent||opts.isTranscendent);
  const quality=['PERFECT','GOOD','STANDARD','DAMAGED'].includes(opts.quality)?opts.quality:'STANDARD';
  const originId=opts.originId||'UNKNOWN';
  const led=owner.jianghu.ledgerV140;
  const existing=led.materialStacks.find(s=>this.ownsMaterial(owner,s)&&(s.contributionCreditAllowed===false)===(opts.contributionCreditAllowed===false)&&s.matId===def.id&&s.quality===quality&&!!s.isTranscendent===isTrans&&(!isTrans||s.originId===originId));
  if(existing)return true;
  const maxStacks=this.isSectStorage(owner)?(root.JianghuInfrastructure?.bonuses(this).materialCapacity||640):(E.PATCH140_CAPS?.materialStacks||24);
  return led.materialStacks.length<maxStacks;
 }
 transferMaterialStack(from,to,matId,qty,reason='TRANSFER',opts={}){
  if(!from?.jianghu?.ledgerV140||!to?.jianghu?.ledgerV140)return {ok:false,moved:0,reason:'ไม่พบคลังต้นทางหรือปลายทาง'};
  const mayReturn=s=>to.id===this.bank?.id&&opts.returnLoanRunId&&s.loan?.purpose==='SIDEQUEST'&&s.loan?.runId===opts.returnLoanRunId&&s.ownerNpcId===this.bank.id;
  const permitted=s=>opts.returnLoanRunId?mayReturn(s):this.ownsMaterial(from,s);
  const available=from.jianghu.ledgerV140.materialStacks.filter(s=>s.matId===matId&&permitted(s)).reduce((sum,s)=>sum+s.count,0);
  let targetQty=Math.max(0,Math.min(Math.floor(qty||0),available));
  if(targetQty<=0)return {ok:false,moved:0,reason:'ไม่มีวัตถุดิบที่จะโอน'};
  if(this.world.npcs[to.id]?.core?.human&&!this.isSectStorage(to)){
   targetQty=Math.min(targetQty,Math.max(0,Human.carryLimit(to)-Human.load(to)));
  }
  if(targetQty<=0)return {ok:false,moved:0,reason:'สัมภาระผู้รับเต็ม'};
  const srcStacks=from.jianghu.ledgerV140.materialStacks.filter(s=>s.matId===matId&&s.count>0&&permitted(s));
  let moved=0,rem=targetQty;
  for(const st of srcStacks){
   if(rem<=0)break;
   const take=Math.min(rem,st.count);
   if(take<=0)continue;
   const addRes=this.add(to,matId,take,reason,{
    quality:st.quality||'STANDARD',
    isTranscendent:!!st.isTranscendent,
    originType:st.originType||(st.isTranscendent?'HERITAGE_SITE':'STAGE'),
    originId:st.originId||(st.isTranscendent?'LEG_01':reason),
    originLabelTh:st.originLabelTh||reason,
    allowTransferFromExistingHeritageStack:true,
    contributionCreditAllowed:st.contributionCreditAllowed,sectGrant:st.sectGrant,
    ...opts
   });
   if(addRes.ok){
    this.debitMaterialStack(from,st,take);
    moved+=take;
    rem-=take;
   }
  }
  from.jianghu.ledgerV140.materialStacks=from.jianghu.ledgerV140.materialStacks.filter(s=>s.count>0);
  E.syncLegacyArraysFromLedgerV140?.(from);
  E.syncLegacyArraysFromLedgerV140?.(to);
  return {ok:moved>0,moved,attempted:targetQty};
 }
 transferableDepositCount(n){
  if(!n?.jianghu?.ledgerV140)return 0;
  let total=0;
  for(const z of n.jianghu.ledgerV140.materialStacks){
   if(z.count<=0)continue;
   const keep=Math.max(([HERB,ORE].includes(z.matId)?1:0),this.progression?.reserve(n,z.matId)||0);
   const q=Math.max(0,z.count-keep);
   if(q>0&&this.canAcceptMaterial(this.bank,z.matId,{quality:z.quality,isTranscendent:z.isTranscendent,originId:z.originId}))total+=q;
  }
  return total;
 }
 money(delta,reason){if(this.gold+delta<-.001)return false;E.addSpiritStonesV140(this.bank,delta);this.s.transactions.push({t:this.s.t,delta,reason,balance:this.gold});if(this.s.transactions.length>400)this.s.transactions.shift();return true;}
 note(text,n=null){const row={t:Math.round(this.s.t),text};this.s.log.unshift(row);this.s.log=this.s.log.slice(0,180);if(n?.stageLocal){n.stageLocal.history.unshift(row);n.stageLocal.history=n.stageLocal.history.slice(0,40);}}
 built(type){return this.s.buildings.find(b=>b.type===type&&b.hp>0&&b.remaining<=0);}
 footprint(type,x,y){const def=B[type];if(!def)return 'ไม่พบแบบก่อสร้าง';if(x<500||x>1800||y<870||y>1720)return 'วางในเขตสำนักเส้นประสีทอง';const r=def.size/2;
  if(this.s.buildings.some(b=>b.hp>0&&Math.abs(b.x-x)<(B[b.type].size+def.size)/2+45&&Math.abs(b.y-y)<(B[b.type].size+def.size)/2+45))return 'พื้นที่ทับอาคารอื่น';
  if(OBST.some(o=>x+r>o.x&&x-r<o.x+o.w&&y+r>o.y&&y-r<o.y+o.h))return 'ทับภูเขาหรือหน้าผา';if(type==='hall'&&this.s.buildings.some(b=>b.type==='hall'&&b.hp>0))return 'มีหอเจ้าสำนักแล้ว';return '';
 }
 place(type,x,y){const d=B[type],why=this.footprint(type,x,y);if(why)return {ok:false,reason:why};if(type!=='hall'&&!this.built('hall'))return {ok:false,reason:'สร้างหอเจ้าสำนักให้เสร็จก่อน'};
  if(this.gold<d.gold||this.s.wood<d.wood||this.ore<d.ore)return {ok:false,reason:'เงิน ไม้ หรือแร่ไม่เพียงพอ'};
  this.money(-d.gold,'ก่อสร้าง '+d.name);this.s.wood-=d.wood;this.consume(this.bank,ORE,d.ore);
  const b={id:'b'+this.s.nextId++,type,x,y,hp:d.hp,remaining:d.time,occupants:[]};this.s.buildings.push(b);if(type==='garden')this.createGardenPlots(b);this.note('เริ่มก่อสร้าง'+d.name);return {ok:true,building:b};
 }
 recruit(){const hall=this.built('hall');if(!hall)return {ok:false,reason:'ต้องมีหอเจ้าสำนักที่สร้างเสร็จ'};if(this.heroes.filter(alive).length>=this.capacity())return {ok:false,reason:'ที่พักเต็ม สร้างหอฝึกหรือตลาดเพิ่ม'};if(!this.money(-100,'รับศิษย์'))return {ok:false,reason:'ต้องใช้ 100 ศิลา'};
  const names=['หลินเฟิง','ซูเยว่','เย่ชิง','ไป๋หลัน','หานอวี้','จ้าวหมิง','มู่เสวี่ย','เฉินหลง'];const n=this.create(names[this.s.heroIds.length%names.length]+(this.s.heroIds.length>=8?' '+(this.s.heroIds.length+1):''),{role:'disciple'});
  this.initializePerson(n,null,{role:'disciple'});this.provisionTrainingEquipment(n);this.combatSystem?.ensure(n);
  this.s.heroIds.push(n.id);if(this.s.activation===null)this.s.activation=this.s.t;
  this.life?.enrol(n);this.add(n,HERB,1,'RECRUIT_SUPPLY');this.note(n.name+' เข้าสำนัก · '+n.jianghu.subPathNameTh,n);return {ok:true,npc:n};
 }
 provisionTrainingEquipment(n){
  const j=n.jianghu,l=j.ledgerV140;j.equipmentV140||={};
  for(const recipeId of ['L14_ironblade','L14_armor']){
   const r=Growth.RECIPES.find(r=>r.id===recipeId);if(!r||j.equipmentV140[r.effect.slot])continue;
   const item={id:'starter201-'+n.id+'-'+r.effect.slot,recipeId:r.id,nameTh:r.name+' · เสบียงศิษย์ใหม่',slot:r.effect.slot,tier:r.tier,minStageReq:1,quality:'STANDARD',durability:100,maxDurability:100,combatMult:r.effect.combat,defenseMult:r.effect.defense,compatiblePath:'ANY',originLabelTh:'อุปกรณ์พื้นฐานรวมอยู่ในค่ารับศิษย์สำนัก',ownerId:n.id};
   if(!l.equipmentItems.some(it=>it.id===item.id))l.equipmentItems.push(item);j.equipmentV140[item.slot]=item.id;
  }
 }
 assignExternalArts(n){
  const j=n.jianghu,arts=this.progression?.arts||E.getAllTechniquesCatalogV190?.()||[];
  j.knowledgeV190={};j.artMasteryV150={};j.knownArtIdsV150=[];
  for(const slot of ['mantra','technique','lightness','auxiliary','forbidden']){j[slot+'Id']=null;j[slot+'NameTh']=null;}
  for(const slot of ['mantra','technique']){
   const isSlot=a=>slot==='mantra'?/MANTRA/.test(a.category):!/MANTRA|LIGHTNESS|MOVEMENT|FORBIDDEN_ART|AUXILIARY|SUPPORT/.test(a.category);
   let pool=arts.filter(a=>isSlot(a)&&(!a.path||a.path===j.path)&&(a.tier||1)<=1);
   if(!pool.length)pool=arts.filter(a=>isSlot(a)&&(!a.path||a.path===j.path)&&(a.tier||1)<=2);
   pool.sort((a,b)=>(b.subPath===j.subPath)-(a.subPath===j.subPath)||String(a.id).localeCompare(String(b.id)));
   if(pool[0]){
    const a=pool[0];
    j.knowledgeV190[a.id]={artId:a.id,stage:4,mastery:12,reading:100,redistribute:false,source:'EXTERNAL_ORIGIN'};
    j.artMasteryV150[a.id]=12;
    j.knownArtIdsV150.push(a.id);
    j[slot+'Id']=a.id;
    j[slot+'NameTh']=a.nameTh;
   }
  }
 }
 initializePerson(n,at=null,opts={}){const hall=this.built('hall'),isVisitor=!!opts.visitor,role=opts.role||(isVisitor?'visitor':'disciple');
  // Original core selects the path/subpath; the hall imposes no path.
  const traditions=root.LivingDiscovery.TRADITIONS,paths=Object.values(E.CULTIVATION_PATHS).filter(p=>traditions[p.id]),pathOpts=paths.map(p=>Human.option(n,{id:p.id,baseScore:50,personalityWeights:p.id==='BODY'?{courage:.4,discipline:.35}:p.id==='GOD'?{empathy:.4,loyalty:.35}:p.id==='DEMON'?{ambition:.45,courage:.35,aggression:.2}:p.id==='HEART_SOUL'?{composure:.45,creativity:.35,curiosity:.25}:{curiosity:.4,composure:.35},biasTag:'CULTIVATE'},'path:'+p.id));
  const p=E.chooseNpcDecisionOption(this.world,n,pathOpts,{rng:this.rng,temperature:Human.temperature(n),decisionTag:'stage-path'}).chosenId;
  const subs=Object.values(E.CULTIVATION_PATHS[p].subPaths).filter(s=>traditions[p].includes(s.id));const sub=E.chooseNpcDecisionOption(this.world,n,subs.map(a=>Human.option(n,{id:a.id,baseScore:50},'subpath:'+a.id)),{rng:this.rng,temperature:Human.temperature(n),decisionTag:'stage-subpath'}).chosenId;
  n.jianghu.path=p;n.jianghu.subPath=sub;E.syncNpcCultivationIdentityV1200(this.world,n,{trackOrdinal:1,progress:0});
  n.stageLocal={x:at?at.x:(hall?hall.x+this.rng.int(-35,35):950),y:at?at.y:(hall?hall.y+115:1365),role,visitor:isVisitor,originSectId:opts.originSectId||null,target:null,route:[],action:null,job:0,totalJob:0,cooldowns:{},known:['hall','village','market','grove','mine','woods','exit','orchid','cinder','pond','ginseng','cinnabar','scout','bamboo','river','crystal','ember','ridge','sanctuary'],scores:[],history:[],danger:0,goal:'ประเมินโอกาส',nextThink:this.s.t+.2,commitUntil:0,offmap:null,mode:'idle',service:null,pathReason:'เลือกจากค่านิยม บุคลิก ความสนใจ กายภาพ และการคิดของตน',lastWork:null,lastHit:-10,needs:{hunger:20,social:25,safety:10},memories:[],aspiration:null};
  ensureStageNeeds(n);
  const dreams=[{id:'mastery',text:'อยากทะลวงขอบเขตด้วยวิถีของตน',action:'train',pw:{ambition:.6,discipline:.4}},{id:'wealth',text:'อยากสะสมทรัพย์ให้ได้ 240 ศิลา',action:'trade',pw:{curiosity:.25,ambition:.3}},{id:'guardian',text:'อยากปกป้องหมู่บ้านและได้รับการยอมรับ',action:'defend',pw:{empathy:.7,integrity:.5}},{id:'discovery',text:'อยากค้นพบค่ายลับและเดินทางพ้นหุบเขา',action:'scout',pw:{curiosity:.7,courage:.4}},{id:'artisan',text:'อยากมีศาสตราที่สร้างด้วยทรัพยากรของตน',action:'craft',pw:{creativity:.7,discipline:.4}},{id:'companionship',text:'อยากมีสหายที่ไว้ใจได้ในสำนัก',action:'social',pw:{trustfulness:.4,empathy:.5}}];
  const dream=E.chooseNpcDecisionOption(this.world,n,dreams.map(d=>Human.option(n,{id:d.id,baseScore:50,personalityWeights:d.pw},d.action)),{rng:this.rng,temperature:Human.temperature(n),decisionTag:'LIFE_ASPIRATION'});n.stageLocal.aspiration={...dreams.find(d=>d.id===dream.chosenId),fulfilled:false,at:null};
  n.stageLocal.identityDecisions={path:pathOpts.map(o=>({id:o.id,valueWeights:o.valueWeights,human:o.human})),chosenPath:p,chosenSubPath:sub,aspiration:dream.chosenId};
  const alchemyCapacity=Human.capacity(n,'alchemy');n.jianghu.craftMasteryV140.ALCHEMY=Math.max(15,Math.min(42,Math.round(8+alchemyCapacity.aptitude*.32+alchemyCapacity.cognition*.10+(n.personality?.creativity||50)*.04)));
  if(!isVisitor&&role==='disciple'){
   this.teachPublicRecipes(n);
   this.progression?.initialize(n);
   this.discovery?.state(n);
  }else{
   this.assignExternalArts(n);
  }
  this.life?.syncLegacyPositions?.();
  return n;
 }
 enrollVisitor(n){
  if(!n?.stageLocal)return;
  n.stageLocal.visitor=false;
  n.stageLocal.role='disciple';
  n.stateId='TH';
  n.isRogue=false;
  this.teachPublicRecipes(n);
  this.progression?.initialize(n);
  this.discovery?.state(n);
  this.life?.syncLegacyPositions?.();
 }
 get visitors(){const outside=this.s.storyEvents?.treasury?.contributions?.externalTrade,merchants=(outside?.merchantIds||[]).map(id=>this.world.npcs[id]).filter(n=>n?.stageLocal?.externalMerchant&&!n.stageLocal.offmap);return [...new Map([...(this.life?.visitors||[]),...(this.realm?.visitors||[]),...merchants].filter(Boolean).map(n=>[n.id,n])).values()];}
 capacity(){return Math.min(30,6+(this.built('training')?8:0)+(this.built('market')?16:0))+(root.JianghuInfrastructure?.bonuses(this).extraDiscipleCapacity||0);}
 power(n){
  if(root.CombatStats201&&this.combatSystem)return this.combatSystem.rating(n);
  if(n.stageLocal?.pet)return n.power;
  const j=n?.jianghu;if(!j)return 100;
  this.progression?.sanitizeEquippedItems?.(n);
  const band=Math.max(1,Math.min(9,j.realizationBand||j.trackOrdinal||1));
  const stageTable=[0,210,360,560,840,1220,1740,2450,3400,4650];
  const low=Math.floor(band),high=Math.min(9,low+1);
  let base=stageTable[low]+(stageTable[high]-stageTable[low])*(band-low);
  const pathDef=E.CULTIVATION_PATHS?.[j.path]||E.CULTIVATION_PATHS?.XIAN;
  const subDef=pathDef?.subPaths?.[j.subPath];
  base*=Math.max(.92,Math.min(1.08,subDef?.combatBonus||1));
  // Active learned martial arts contribution (only valid learned arts!)
  const active=this.combatSystem?this.combatSystem.activeArts(n):[];
  // More prepared choices do not multiply passive power. Attack contribution
  // is the best learned attack plus bounded breadth; supports are counted once.
  const attacks=active.filter(x=>x.slot==='technique'||x.innate&&['attack','control'].includes(x.role));
  const supports=active.filter(x=>!attacks.includes(x));
  const strength=e=>((e.art.tier||1)*24+Math.min(90,(e.art.power||45)*.45))*(.65+Math.min(100,e.mastery||e.knowledge?.mastery||8)/140);
  const artBonus=(attacks.length?Math.max(...attacks.map(strength))*(1+Math.min(.15,(attacks.length-1)*.025)):0)+Math.min(260,supports.reduce((v,e)=>v+strength(e)*.45,0));
  base+=artBonus;
  if(n.stageLocal?.enemy)base*=n.stageLocal.boss?1.10:0.78;
  const eqMult=root.JianghuExpansionV112?.computeEquipmentResonance?.(n)?.combatMult||1;
  const injuryPenalty=1-Math.min(0.35,(j.internalInjury||0)*0.0025+(j.heartDemon||0)*0.001);
  return Math.round(Math.max(50,base*Human.combat(n)*eqMult*(this.realm?.formationBonus(n,'combat')||1)*injuryPenalty));
 }
 beast(x,y){const data=(root.JianghuCultivationData?.SPIRIT_BEASTS_CATALOG||E.SPIRIT_BEASTS_CATALOG||[]);const species=data.find(d=>/หมาป่า|wolf/i.test(JSON.stringify(d)))||data[0];this.s.beasts.push({id:'wolf'+this.s.nextId++,name:species?.nameTh||'หมาป่าเขี้ยวลม',speciesId:species?.id,x,y,home:{x,y},health:70,maxHP:70,power:260,alive:true,hostile:true,sanctuaryResident:false,affiliation:'WILD',target:null,mode:'patrol',nextMove:0,attackAt:0});}
 bandit(boss,x,y){
  const n=this.create(boss?'เถี่ยหู่ · หัวหน้าโจร':'โจรผาทมิฬ',{role:'bandit',preserveName:true,stage:1});
  n.stageLocal={enemy:true,role:'bandit',boss,x,y,home:{x,y},target:null,route:[],mode:boss?'camp':'patrol',nextMove:0,raid:false,attackAt:0,history:[]};
  ensureStageNeeds(n);
  n.health=boss?240:100;
  const j=n.jianghu;
  j.path='BODY';j.subPath='TIGER_SOVEREIGN';
  E.syncNpcCultivationIdentityV1200(this.world,n,{trackOrdinal:1,progress:boss?65:20});
  j.knowledgeV190={};j.artMasteryV150={};j.knownArtIdsV150=[];
  for(const slot of ['mantra','technique','lightness','auxiliary','forbidden']){j[slot+'Id']=null;j[slot+'NameTh']=null;}
  const banditMantra='NW_ART_074',banditTech='ART190_BODY_001';
  const mastery=boss?34:14;
  for(const [slot,artId] of [['mantra',banditMantra],['technique',banditTech]]){
   j.knowledgeV190[artId]={artId,stage:4,mastery,reading:100,redistribute:false,source:'BANDIT_CAMP'};
   j.artMasteryV150[artId]=mastery;
   j.knownArtIdsV150.push(artId);
   j[slot+'Id']=artId;
  }
  this.s.enemyIds.push(n.id);
  this.combatSystem?.ensure(n);
  return n;
 }
 path(a,b){const size=100,cols=W/size,rows=H/size,key=(x,y)=>y*cols+x,point=k=>({x:(k%cols)*size+50,y:Math.floor(k/cols)*size+50});const start=key(Math.max(0,Math.min(cols-1,Math.floor(a.x/size))),Math.max(0,Math.min(rows-1,Math.floor(a.y/size)))),goal=key(Math.max(0,Math.min(cols-1,Math.floor(b.x/size))),Math.max(0,Math.min(rows-1,Math.floor(b.y/size))));
  const blocked=(k)=>{const q=point(k);return OBST.some(o=>q.x>o.x-30&&q.x<o.x+o.w+30&&q.y>o.y-30&&q.y<o.y+o.h+30)||this.s.buildings.some(z=>z.hp>0&&Math.abs(q.x-z.x)<B[z.type].size/2+10&&Math.abs(q.y-z.y)<B[z.type].size/2+10);};
  const open=[start],cost={[start]:0},prev={},f={[start]:DIST(point(start),point(goal))};let loops=0;
  while(open.length&&loops++<1300){open.sort((a,b)=>f[a]-f[b]);let k=open.shift();if(k===goal){const arr=[{x:b.x,y:b.y}];while(k!==start){arr.unshift(point(k));k=prev[k];}return arr;}
   const x=k%cols,y=Math.floor(k/cols);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=cols||ny>=rows)continue;const q=key(nx,ny);if(q!==goal&&blocked(q))continue;const c=cost[k]+100;if(c<(cost[q]??Infinity)){cost[q]=c;prev[q]=k;f[q]=c+DIST(point(q),point(goal));if(!open.includes(q))open.push(q);}}
  }return [];
 }
 cancelActionSetup(n,action=null){
  const s=n?.stageLocal;if(!s)return;
  if(s.orderId){const o=this.s.orders.find(o=>o.id===s.orderId&&o.status==='funded'&&o.heroId===n.id);if(o)o.heroId=null;s.orderId=null;}
  if(s.gardenPlotId){const plot=this.s.gardenPlots.find(x=>x.id===s.gardenPlotId&&x.reservedBy===n.id);if(plot){plot.reservedBy=null;plot.reservedUntil=0;}s.gardenPlotId=null;}
  this.progression?.cancelTicket?.(n);
  this.academy?.cancelTicket?.(n);
  this.discovery?.cancelTicket?.(n);
 }
 send(n,action,target,duration=12){
  const s=n.stageLocal;
  if(!target||!Number.isFinite(target.x)||!Number.isFinite(target.y)){
   this.cancelActionSetup(n,action);
   s.cooldowns[action]=this.s.t+15;
   return false;
  }
  const nextTarget={id:target.id||action,x:target.x,y:target.y};
  let route=this.path(s,nextTarget);
  if(!route.length&&DIST(s,nextTarget)<=25)route=[{x:nextTarget.x,y:nextTarget.y}];
  if(!route.length){
   this.cancelActionSetup(n,action);
   s.mode='idle';s.target=null;s.action=null;s.cooldowns[action]=this.s.t+15;
   return false;
  }
  if(s.action&&s.action!==action)this.cancelActionSetup(n,s.action);
  s.action=action;
  s.huntTargetId=['hunt','defend'].includes(action)&&(target.health!==undefined||this.world.npcs[target.id])?target.id:(s.growthTarget&&action==='hunt'?s.growthTarget:null);
  s.target=nextTarget;
  s.route=route;
  s.job=duration;
  s.totalJob=duration;
  s.mode='travel';
  s.goal=actionLabel(action);
  s.commitUntil=this.s.t+10;
  s.nextThink=this.s.t+4;
  this.progression?.start(n,action);
  this.academy?.start(n,action);
  this.discovery?.start(n,action);
  return true;
 }
 endpoint(b){return {id:b.id,x:b.x,y:b.y+B[b.type].size/2+45};}
 move(n,dt,speed=48){const s=n.stageLocal||n;if(!s.route?.length)return true;let budget=(this.combatSystem?this.combatSystem.stats(n).moveSpeed*(speed/48):(n.core?Human.travelSpeed(n,speed):speed))*dt;while(budget>0&&s.route.length){const p=s.route[0],d=DIST(s,p),m=Math.min(budget,d);if(d<.01){s.route.shift();continue;}s.x+=(p.x-s.x)/d*m;s.y+=(p.y-s.y)/d*m;budget-=m;if(d<=m+.001)s.route.shift();}return !s.route.length;}
 nearestEnemy(n,r=600){const s=n.stageLocal||n;return [...this.enemies.filter(alive),...this.s.beasts.filter(e=>this.isHostileCreature(e))].map(e=>({e,d:DIST(s,e.stageLocal||e)})).filter(z=>z.d<r).sort((a,b)=>a.d-b.d)[0]?.e;}
 canAdvanceBreakthroughNow(n){
  const j=n?.jianghu;if(!j||(j.cultivationProgress||0)<95)return false;
  const proj=j.breakthroughProjectV1200;
  if(proj&&!['COMPLETE','ABORTED','FAILED'].includes(proj.phase)){
   if(proj.phase==='PAUSED')return (n.health||0)>=65;
   if(proj.phase==='PREPARE_SITE'){
    const ev=E.evaluateCausalBreakthroughV1200(this.world,n);
    const needed=Math.max(0,(ev.costStones||0)-(proj.reservedStones||0));
    return E.getSpiritStonesV140(n)>=needed;
   }
   if(proj.phase==='PROCURE'){
    const ev=E.evaluateCausalBreakthroughV1200(this.world,n);
    return !!ev.mediaEvaluation?.anySatisfied;
   }
   return true;
  }
  const ev=E.evaluateCausalBreakthroughV1200(this.world,n);
  return !!(ev?.ok&&ev.canAttempt);
 }
 chooseRetreatDestination(n,threat){
  const s=n.stageLocal,threatPos=threat?.stageLocal||threat;
  const candidates=[];
  for(const type of ['tower','hall','training','shrine','sanctuary','market']){
   const b=this.built(type);
   if(b)candidates.push({id:b.id,label:B[type].name,...this.endpoint(b),isTower:type==='tower'});
  }
  candidates.push({...loc('village')},{...loc('market')});
  if(threatPos){
   const dx=s.x-threatPos.x,dy=s.y-threatPos.y,len=Math.hypot(dx,dy)||1;
   const kx=Math.max(520,Math.min(3480,Math.round(s.x+(dx/len)*420)));
   const ky=Math.max(520,Math.min(2580,Math.round(s.y+(dy/len)*420)));
   candidates.push({id:'kite-retreat',x:kx,y:ky});
  }
  const hostiles=[...this.enemies.filter(alive),...this.s.beasts.filter(b=>this.isHostileCreature(b))];
  const scored=candidates.map(c=>{
   const minEnemyDist=hostiles.reduce((m,e)=>Math.min(m,DIST(c,e.stageLocal||e)),9999);
   const distFromSelf=DIST(s,c);
   if(distFromSelf<90&&minEnemyDist<240)return {c,score:-9999,minEnemyDist};
   const towerBonus=c.isTower?120:0;
   const allyBonus=this.heroes.filter(h=>h.id!==n.id&&alive(h)&&h.health>55&&DIST(c,h.stageLocal)<260).length*85;
   const score=Math.min(900,minEnemyDist*1.4)+towerBonus+allyBonus-distFromSelf*0.35-(minEnemyDist<240?650:0);
   return {c,score,minEnemyDist};
  }).filter(x=>x.score>-5000).sort((a,b)=>b.score-a.score);
  return scored[0]?.c||(this.built('hall')?this.endpoint(this.built('hall')):loc('village'));
 }
 options(n){this.progression?.refresh(n);const s=n.stageLocal,opts=[];if(this.academy?.reserved(n))return opts;const add=(id,base,target,duration,pw={},extra={})=>{if(!target||((s.cooldowns[id]||0)>this.s.t))return;const busy=target.type?this.s.buildings.filter(b=>b.id===target.id)[0]?.occupants.length:0;
   const memoryBias=Human.memoryBias(n,id,this.s.t);
   const authorityBias=(this.life?.authorityAdjustment(n,id)||0)+(this.realm?.roleAdjustment(n,id)||0);
   const desireBias=!s.aspiration?.fulfilled&&s.aspiration?.action===id?18:0;
   opts.push(Human.option(n,{id,goalAdj:this.progression?.bias(n,id)||0,baseScore:base+(this.progression?.bias(n,id)||0)+memoryBias+desireBias+authorityBias-DIST(s,target)*.009-(s.lastWork===id?12:0)-(busy||0)*3,personalityWeights:pw,riskLevel:extra.risk||0,handler:extra.handler||id.toUpperCase(),target,duration,authorityAdj:authorityBias,reason:extra.reason||['ระยะ '+Math.round(DIST(s,target))+' ม.',desireBias?'ตรงกับความปรารถนา':'',Math.abs(memoryBias)>.2?'อิทธิพลความทรงจำ '+memoryBias.toFixed(1):'',authorityBias?'อิทธิพลสำนัก '+authorityBias.toFixed(1):'',id==='eat'?'ความหิว '+Math.round(s.needs.hunger):'',id==='rest'?'สุขภาพ '+Math.round(n.health)+' / เหนื่อย '+Math.round(n.core.condition.fatigue):''].filter(Boolean).join(' · '),...extra},extra.growthActivity||id));};
  if(this.s.food>0){
   add('eat',s.needs.hunger>30?15+s.needs.hunger*1.25:-100,this.built('hall')?this.endpoint(this.built('hall')):loc('village'),5,{caution:.2});
  }
  if((this.s.food<=0&&s.needs.hunger>22)||(this.s.food<12&&(s.needs.hunger>35||this.s.policy==='resource'))){
   const urgency=this.s.food<=0?48+s.needs.hunger*.9:26+(12-this.s.food)*2;
   add('resupplyFood',urgency,loc('village'),8,{discipline:.25,empathy:.2},{growthActivity:'resupplyFood',reason:'คลังเสบียงเหลือ '+this.s.food+' หน่วย · เดินไปจัดหาเสบียงจากหมู่บ้านชิงหยุน'});
  }
  const hall=this.built('hall'),training=this.built('training'),close=this.nearestEnemy(n,800);s.danger=close?Math.round(100*Math.min(1,this.power(close)/this.power(n))):0;
  add('rest',20+(100-n.health)*1.1+n.core.condition.fatigue*.5,hall?this.endpoint(hall):loc('village'),14,{caution:.4,composure:.2});
  add('train',43+(this.s.policy==='cultivate'?25:0),training?this.endpoint(training):{id:'open-training',x:1400,y:1800},16,{discipline:.4,ambition:.3},{handler:'CULTIVATE'});
  if(Human.load(n)<Human.carryLimit(n)){for(const node of this.s.nodes.filter(x=>x.qty>=1)){const target=loc(node.locationId)||{id:node.id,x:node.x||0,y:node.y||0};const current=this.count(this.bank,node.mat),scarcity=current<(node.tier===1?8:node.tier===2?4:2)?24:0;const action=(node.kind==='HERB'?'herb:':'mine:')+node.id;add(action,20+scarcity+(this.s.policy==='resource'?22:0)-node.tier*2,target,node.kind==='HERB'?10+node.tier*2:12+node.tier*2,{caution:.2,discipline:.25},{handler:'GATHER',growthActivity:node.kind==='HERB'?'herb':'mine',resourceNodeId:node.id});}}
  add('wood',26+(this.s.wood<10?40:0)+(this.s.policy==='resource'?25:0),{id:'bamboo',x:1560,y:2340},12,{discipline:.3});
  if(this.transferableDepositCount(n)>0)add('deposit',48,hall?this.endpoint(hall):loc('market'),3,{integrity:.3});
  if(n.health>55){
   add('scout',(this.s.campKnown?13:44)-(this.realm.threatAt(loc('scout'),400,n)?55:0),loc('scout'),8,{curiosity:.5,courage:.2},{risk:20});
   const nearestBeast=this.s.beasts.filter(b=>this.isHostileCreature(b)).sort((a,b)=>DIST(s,a)-DIST(s,b))[0];if(nearestBeast&&this.power(n)>this.power(nearestBeast)*(.65+(n.personality.caution||50)*.005))add('hunt',28+(this.s.policy==='defend'?15:0)+Math.max(0,3-nearestBeast.tier)*2,nearestBeast,10,{courage:.5,aggression:.2,caution:-.3},{risk:45+nearestBeast.tier*8,handler:'HUNT'});
   const garden=this.built('garden');if(garden){const plots=this.s.gardenPlots.filter(p=>p.buildingId===garden.id&&(!p.reservedBy||p.reservedUntil<=this.s.t||p.reservedBy===n.id));const ripe=plots.find(p=>p.cropId&&p.growth>=(CROPS[p.cropId]?.growSeconds||Infinity));const thirsty=plots.find(p=>p.cropId&&p.growth<(CROPS[p.cropId]?.growSeconds||0)&&p.moisture<28);const empty=plots.find(p=>!p.cropId);if(ripe)add('gardenHarvest:'+ripe.id,34+(this.s.policy==='resource'?18:0),{id:ripe.id,x:ripe.x,y:ripe.y},4,{discipline:.25,curiosity:.1},{handler:'GARDEN',growthActivity:'herb',gardenPlotId:ripe.id});else if(thirsty)add('gardenWater:'+thirsty.id,25+(this.s.policy==='resource'?18:0),{id:thirsty.id,x:thirsty.x,y:thirsty.y},3,{discipline:.3,empathy:.1},{handler:'GARDEN',growthActivity:'herb',gardenPlotId:thirsty.id});else if(empty){const cropId=Object.keys(CROPS).filter(id=>(this.s.seedStock[id]||0)>0).sort((a,b)=>this.count(this.bank,CROPS[a].matId)-this.count(this.bank,CROPS[b].matId)||CROPS[a].tier-CROPS[b].tier)[0];if(cropId)add('gardenPlant:'+empty.id+':'+cropId,22+(this.s.policy==='resource'?18:0),this.endpoint(garden),5,{discipline:.25,curiosity:.1},{handler:'GARDEN',growthActivity:'herb',gardenPlotId:empty.id,gardenCropId:cropId});}}

   const nearbyDrop=this.s.groundDrops.filter(d=>DIST(s,d)<700).sort((a,b)=>DIST(s,a)-DIST(s,b))[0];if(nearbyDrop&&Human.load(n)+nearbyDrop.count<=Human.carryLimit(n))add('loot:'+nearbyDrop.id,32,{id:nearbyDrop.id,x:nearbyDrop.x,y:nearbyDrop.y},3,{curiosity:.2,discipline:.2},{handler:'GATHER',growthActivity:'deposit',dropId:nearbyDrop.id});
   const active=this.s.bounties.filter(b=>b.status==='open');for(const b of active){if(b.target==='camp'&&!s.known.includes('camp'))continue;const target=loc(b.target);const risk=b.target==='camp'?80:b.target==='woods'?60:25;const qualified=n.health>65&&this.power(n)>(b.target==='camp'?220:100);const allies=this.heroes.filter(h=>alive(h)&&h.health>60).length;
    add('bounty:'+b.id,qualified?Math.min(105,30+b.reward*.16)+(this.s.policy==='defend'?15:0)+(allies>=3?10:-10)-risk*.23:-70,target,8,{courage:.45,caution:-.4,integrity:.2},{risk,bountyId:b.id,handler:'HUNT',reason:qualified?'รางวัลเทียบความเสี่ยงและกำลังรบ':'บาดเจ็บหรือกำลังไม่พอ'});
   }
   if(this.s.campKnown&&s.known.includes('camp')&&this.enemies.some(e=>alive(e)&&e.stageLocal.boss))add('assault',this.s.policy==='defend'?42:15,loc('camp'),8,{courage:.45,aggression:.25,caution:-.35},{risk:85});
   if(close&&DIST(s,close.stageLocal||close)<550)add('defend',75+(this.s.policy==='defend'?25:0),close.stageLocal||close,6,{empathy:.4,courage:.5,integrity:.3},{risk:65});
    else if(this.s.storyEvents?.active){const evTarget=[...this.enemies.filter(e=>alive(e)&&e.stageLocal?.storyEventId),...this.s.beasts.filter(b=>this.isHostileCreature(b)&&b.storyEventId)].sort((a,b)=>DIST(s,a.stageLocal||a)-DIST(s,b.stageLocal||b))[0];if(evTarget&&DIST(s,evTarget.stageLocal||evTarget)<1100)add('defend',78+(this.s.policy==='defend'?22:0),evTarget.stageLocal||evTarget,6,{empathy:.4,courage:.55,integrity:.3},{risk:60});}
  }
  if(this.hasUsefulPill(n))add('medicine',52+(n.health<55?20:0),this.built('hall')?this.endpoint(this.built('hall')):loc('village'),3,{caution:.25,discipline:.2},{handler:'MEDICINE'});
  if(n.health<75&&this.count(n,HERB)>0)add('heal',95,hall?this.endpoint(hall):loc('village'),10,{caution:.2});
  add('trade',18+(this.s.policy==='trade'?42:0),loc('exit'),1,{curiosity:.3,courage:.2},{risk:25});
  const herbStock=this.s.merchantStock[HERB]||0,herbAsk=this.life?.marketPrice(8)||8;
  add('buy',herbStock>0&&E.getSpiritStonesV140(n)>=herbAsk&&this.count(n,HERB)===0&&this.canAcceptMaterial(n,HERB)?35:-90,loc('market'),3,{caution:.3});
  add('social',12+s.needs.social*.6,loc('village'),12,{trustfulness:.2,empathy:.3});
  const order=this.s.orders.find(o=>o.status==='funded'&&!o.heroId);if(order){const b=this.built(order.type);if(b)add('craft',70,this.endpoint(b),4,{discipline:.2},{handler:'CRAFT',orderId:order.id});}
  if(this.progression.bestEquipment(n).length)add('equip',65,hall?this.endpoint(hall):loc('market'),3,{discipline:.2});
  if(this.canAdvanceBreakthroughNow(n))add('breakthrough',68,training?this.endpoint(training):loc('village'),14,{ambition:.4,caution:-.1});
  this.life?.courierOptions(n,add);this.realm?.options(n,add);this.progression?.options(n,add);this.academy?.options(n,add,opts);this.discovery?.options(n,add);this.myriad?.options(n,add);root.JianghuSideQuests?.options(this,n,add);root.JianghuSectContributions?.options(this,n,add);return opts;
 }
 decide(n){const s=n.stageLocal;if(this.academy?.reserved(n)){s.nextThink=this.academy.reservationUntil(n);return;}if((n.jianghu.busyProductionUntilTick||-1)>this.world.tick){s.nextThink=this.s.t+Math.min(10,Math.max(1,(n.jianghu.busyProductionUntilTick-this.world.tick)*DAY));return;}const opts=this.options(n);if(!opts.length){s.nextThink=this.s.t+2;return;}const ctx={rng:this.rng,decisionTag:'frontier',temperature:Human.temperature(n)};if(!opts.length)return;const scored=E.scoreNpcDecisionOptions(this.world,n,opts,ctx);const choice=E.chooseNpcDecisionOption(this.world,n,opts,{...ctx,preScoredDecision:scored});
  s.decisionClarity=Human.clarity(n);s.decisionTemperature=ctx.temperature;s.scores=scored.options.map(o=>({id:o.id,score:o.score,contributions:{...o.contributions,...o.option.human,authorityAdj:o.option.authorityAdj||0,goalAdj:o.option.goalAdj||0},reason:o.option.reason||'บุคลิก ความถนัด ระยะทาง และนโยบาย',risk:o.option.riskLevel})).sort((a,b)=>b.score-a.score);
  const a=choice.chosen;s.goal=actionLabel(a.id);s.resourceNodeId=a.resourceNodeId||null;s.gardenPlotId=a.gardenPlotId||null;s.gardenCropId=a.gardenCropId||null;s.dropId=a.dropId||null;s.huntForMatId=a.huntForMatId||null;
  s.growthTarget=a.growthTarget||null;s.academyTargetId=a.academyTargetId||null;s.academyMentorId=a.academyMentorId||null;s.academyArtId=a.academyArtId||null;s.academyPartnerId=a.academyPartnerId||null;s.sceneTarget=a.sceneTarget||null;s.realmTarget=a.realmTarget||null;s.mwTargetId=a.mwTargetId||null;s.mwEntranceId=a.mwEntranceId||null;
  if(a.gardenPlotId){const plot=this.s.gardenPlots.find(p=>p.id===a.gardenPlotId);if(plot){plot.reservedBy=n.id;plot.reservedUntil=this.s.t+(a.duration||4)+12;}}
  if(a.orderId){const o=this.s.orders.find(o=>o.id===a.orderId);if(o)o.heroId=n.id;s.orderId=a.orderId;}
  if(a.bountyId){s.bountyId=a.bountyId;}
  if(!this.send(n,a.id,a.target,a.duration))return;
  if(a.bountyId){const b=this.s.bounties.find(b=>b.id===a.bountyId);if(b&&!b.accepted.includes(n.id)){b.accepted.push(n.id);this.note(n.name+' ประเมินและรับประกาศ '+b.name,n);}}
  this.note(n.name+' เลือก '+s.goal,n);
 }
 finish(n){const s=n.stageLocal,a=s.action;if(!a){s.mode='idle';s.job=0;return;}const before=this.life?.beforeWork(n),special=root.JianghuSectContributions?.finish(this,n,a)||root.JianghuSideQuests?.finish(this,n,a)||this.myriad?.finish(n,a)||this.discovery?.finish(n,a)||this.academy?.finish(n,a)||this.progression?.finish(n,a)||this.realm?.finish(n,a)||this.life?.finishAction(n,a);let success=special?.handled?special.success:true;if(success&&['scout','trade','social'].includes(a))this.discovery?.onExplore(n,a==='scout'?'สำรวจร่องรอยในป่า':a==='trade'?'ข่าวจากเส้นทางค้า':'คำบอกเล่าของชาวบ้าน');s.lastWork=a;s.cooldowns[a]=this.s.t+(special?.cooldown??(a==='trade'?50:8));
  if(a.startsWith('herb:')||a.startsWith('mine:')){const nodeId=s.resourceNodeId||a.split(':')[1];const r=this.harvestNode(nodeId,n.id);success=!!r.ok;}
  if(a.startsWith('gardenPlant:')){const r=this.plant(s.gardenPlotId||a.split(':')[1],s.gardenCropId||a.split(':')[2],n.id);success=!!r.ok;}
  if(a.startsWith('gardenWater:')){const r=this.water(s.gardenPlotId||a.split(':')[1],n.id);success=!!r.ok;}
  if(a.startsWith('gardenHarvest:')){const r=this.harvestGarden(s.gardenPlotId||a.split(':')[1],n.id);success=!!r.ok;}
  if(a.startsWith('loot:')){const r=this.collectDrop(s.dropId||a.split(':')[1],n.id);success=!!r.ok;}
  if(a==='medicine'){const stack=this.chooseUsefulPill(n);if(stack){const beforeQi=Number(n.jianghu.currentQiV190||0),beforeProgress=Number(n.jianghu.cultivationProgress||0);const cs=this.combatSystem?.ensure(n);if(cs){n.jianghu.currentQiV190=cs.qi;n.jianghu.maxQiV190=cs.maxQi;}const r=E.consumePillFromLedgerV150(this.world,n.id,stack.id);success=!!r?.ok;if(cs){cs.qi=Math.max(0,Math.min(cs.maxQi,n.jianghu.currentQiV190));}if(success){const afterQi=Number(n.jianghu.currentQiV190||0),afterProgress=Number(n.jianghu.cultivationProgress||0);const detail=afterQi>beforeQi?` คืนปราณต่อสู้ +${Math.round(afterQi-beforeQi)}`:afterProgress>beforeProgress?` เพิ่มความก้าวหน้าบ่มเพาะ +${Math.round(afterProgress-beforeProgress)}%`:' ฟื้นฟูอาการตามตำรับ';this.note(`${n.name}ใช้${stack.nameTh}${detail}`,n);}}else success=false;}
  if(a==='train'){E.applyNpcCultivationProgressGain(this.world,n,(this.built('training')?9:4)*Human.learningRate(n,'train')*(this.realm?.formationBonus(n,'cultivation')||1),{activity:'TRAINING'});E.syncNpcCultivationIdentityV1200(this.world,n,{progress:Math.min(100,n.jianghu.cultivationProgress)});E.recordTrackDaoEvidenceV1200(this.world,n,'PRACTICE',8);n.core.condition.fatigue=Math.min(100,n.core.condition.fatigue+8);}
  if(a==='wood'){const q=Math.max(1,Math.floor(1.5+Human.capacity(n,'wood').body*.03));this.s.wood+=q;this.note(n.name+' ตัดไผ่ส่งสำนัก +'+q+' ไม้',n);}
  if(a==='deposit'){
   let totalMoved=0,totalAttempted=0;
   if(root.JianghuSectContributions&&this.s.storyEvents?.active){
    for(const matId of new Set(n.jianghu.ledgerV140.materialStacks.map(x=>x.matId))){const r=root.JianghuSectContributions.donate(this,n,'MATERIAL',matId,999);totalMoved+=r.quantity||0;}
   }else for(const z of [...n.jianghu.ledgerV140.materialStacks]){
    if(z.count<=0)continue;
    const keep=Math.max(([HERB,ORE].includes(z.matId)?1:0),this.progression?.reserve(n,z.matId)||0);
    const q=Math.max(0,z.count-keep);
    if(q>0){
     totalAttempted+=q;
     const tr=this.transferMaterialStack(n,this.bank,z.matId,q,'DEPOSIT_'+n.id);
     totalMoved+=tr.moved;
    }
   }
   success=totalMoved>0;
   if(!success){
    s.cooldowns.deposit=this.s.t+35;
    this.note(n.name+' ไม่สามารถส่งวัตถุดิบเข้าคลังได้ (คลังสำนักเต็มหรือไม่มีของเกินสำรอง)',n);
   }else if(totalMoved<totalAttempted){
    this.note(n.name+' ส่งวัตถุดิบเข้าคลังบางส่วน ('+totalMoved+'/'+totalAttempted+' ชิ้น · พื้นที่คลังจำกัด)',n);
   }
  }
  if(a==='rest'||a==='heal'){
   const recovery=Human.recovery(n)*(this.realm?.formationBonus(n,'recovery')||1);
   if(a==='heal'){
    if(this.consume(n,HERB,1)){
     n.health=Math.min(100,n.health+42*recovery);
     n.core.condition.fatigue=Math.max(0,n.core.condition.fatigue-35*recovery);
     Human.recover(n,20*recovery);
     success=true;
    }else{
     success=false;
    }
   }else{
    n.health=Math.min(100,n.health+24*recovery);
    n.core.condition.fatigue=Math.max(0,n.core.condition.fatigue-35*recovery);
    Human.recover(n,20*recovery);
    success=true;
   }
  }
  if(a==='eat'){
   if(this.s.food>0){
    this.s.food--;
    s.needs.hunger=Math.max(0,s.needs.hunger-70);
    n.health=Math.min(100,n.health+4);
    success=true;
   }else{
    this.note(n.name+' พบว่าเสบียงในสำนักหมดเกลี้ยง ต้องออกจัดหาเสบียงจากหมู่บ้าน',n);
    s.cooldowns.eat=this.s.t+18;
    success=false;
   }
  }
  if(a==='resupplyFood'){
   const vLoc=loc('village');
   if(!vLoc||DIST(s,vLoc)>150||this.s.villageHP<=60){
    success=false;
   }else if(this.gold>=6&&this.money(-6,'จัดซื้อเสบียงจากหมู่บ้านชิงหยุน')){
    const added=Math.min(160-this.s.food,8);
    this.s.food+=added;
    if(s.needs.hunger>35){this.s.food=Math.max(0,this.s.food-1);s.needs.hunger=Math.max(0,s.needs.hunger-55);}
    this.life?.credit(n,1,'จัดหาเสบียงเข้าสำนัก');
    this.note(n.name+' จัดซื้อเสบียงจากหมู่บ้านชิงหยุน +'+added+' หน่วย (ใช้ 6 ศิลา)',n);
    success=added>0;
   }else if(E.getSpiritStonesV140(n)>=4){
    E.addSpiritStonesV140(n,-4);
    const added=Math.min(160-this.s.food,6);
    this.s.food+=added;
    if(s.needs.hunger>35){this.s.food=Math.max(0,this.s.food-1);s.needs.hunger=Math.max(0,s.needs.hunger-55);}
    this.life?.credit(n,2,'ออกทุนส่วนตัวซื้อเสบียงเข้าสำนัก');
    this.note(n.name+' ใช้ศิลาส่วนตัว 4 ก้อน จัดซื้อเสบียงเข้าสำนัก +'+added+' หน่วย',n);
    success=added>0;
   }else{
    const added=Math.min(160-this.s.food,5);
    this.s.villageHP=Math.max(50,this.s.villageHP-15);
    this.s.food+=added;
    if(s.needs.hunger>35){this.s.food=Math.max(0,this.s.food-1);s.needs.hunger=Math.max(0,s.needs.hunger-50);}
    this.note(n.name+' ขอปันเสบียงฉุกเฉินจากชาวบ้าน +'+added+' หน่วย (หมู่บ้านลดเสบียงสำรอง 15)',n);
    success=added>0;
   }
  }
  if(a==='social'){s.needs.social=Math.max(0,s.needs.social-65);const other=this.heroes.find(h=>h.id!==n.id&&alive(h)&&!h.stageLocal.offmap&&DIST(s,h.stageLocal)<500);if(other){const r=E.getRelationshipV130(this.world,n,other,true);const insight=Human.capacity(n,'social').cognition/50;r.affinity=Math.min(100,(r.affinity||0)+5*insight);r.bond=Math.min(100,(r.bond||0)+2*insight);this.note(n.name+' ผูกมิตรกับ '+other.name,n);}if(n.jianghu.path==='GOD')E.fulfillGodCovenantDutyV1200(this.world,n,'COMMUNITY_PROTECTION',{allowImmediate:true});}
  if(a==='scout'){this.revealCamp(n);}
  if(a==='trade'){s.offmap={until:this.s.t+this.s.route.duration,departed:this.s.t,reserved:Math.min(this.s.route.capacity,this.s.route.stock)};this.s.route.stock-=s.offmap.reserved;s.mode='offmap';n.currentCityId=null;this.note(n.name+' ออกจากด่านไปตลาดหยกตะวันตก',n);return;}
  if(a==='buy'){
   success=false;
   const stock=this.s.merchantStock[HERB]||0;const ask=this.life?.marketPrice(8)||8;
   if(stock>0&&E.getSpiritStonesV140(n)>=ask&&this.add(n,HERB,1,'VILLAGE_MARKET').ok){
    this.s.merchantStock[HERB]--;E.addSpiritStonesV140(n,-ask);
    this.note(n.name+' ซื้อสมุนไพร 1 ชิ้น ใช้ '+ask+' ศิลา',n);
    success=true;
   }else{
    s.cooldowns.buy=this.s.t+25;
   }
  }
  if(a==='craft')success=!!this.startCommission(n);
  if(a==='equip'){const count=this.progression.equip(n);success=count>0;}
  if(a==='breakthrough'){
   const beforeOrd=n.jianghu.trackOrdinal;
   const beforePhase=n.jianghu.breakthroughProjectV1200?.phase||null;
   const ev=E.evaluateCausalBreakthroughV1200(this.world,n);
   s.breakthroughBlock=ev.reason||ev.blockers?.map(x=>x.reasonTh||x.nameTh||x.code).join(' · ')||ev.code;
   const res=E.startOrAdvanceBreakthroughProjectV1200(this.world,n,{rng:this.rng});
   s.breakthroughBlock=res.reason||res.code||s.breakthroughBlock;
   E.syncNpcCultivationIdentityV1200(this.world,n);
   const afterPhase=n.jianghu.breakthroughProjectV1200?.phase||null;
   if(n.jianghu.trackOrdinal>beforeOrd){
    this.s.stats.breakthroughs++;
    this.note(n.name+' ทะลวงสู่ '+n.jianghu.stageNameTh,n);
    success=true;
   }else{
    success=!!(res?.ok&&(afterPhase!==beforePhase||SECLUSION_LOCK_PHASES.has(afterPhase)));
   }
   s.cooldowns[a]=this.s.t+40;
  }
  if(success){if(!['eat','rest','heal','seekMentor','approachFormulaRecipient','startResearch','continueResearch'].includes(a))Human.learn(n,this.progression.workActivity(n,a),1);this.remember(n,a,3,'สำเร็จ: '+(LABEL[a]||a));}else this.remember(n,a,-2,'งานยังไม่สำเร็จ: '+(LABEL[a]||a));this.checkAspiration(n);if(before)this.life?.onWork(n,a,success,before);this.realm?.onWork(n,a,success);if(special?.keepAction)return;
  if(s.gardenPlotId){const plot=this.s.gardenPlots.find(p=>p.id===s.gardenPlotId);if(plot&&plot.reservedBy===n.id){plot.reservedBy=null;plot.reservedUntil=0;}}s.resourceNodeId=null;s.gardenPlotId=null;s.gardenCropId=null;s.dropId=null;s.huntForMatId=null;s.target=null;s.action=null;s.route=[];s.mode='idle';s.nextThink=this.s.t+1;
 }
 revealCamp(n){const fresh=!this.s.campKnown;if(fresh){this.s.campKnown=true;this.note('ค้นพบค่ายโจรผาทมิฬ · เปิดประกาศค่าหัวหัวหน้าโจร');}for(const h of this.heroes)if(!h.stageLocal.known.includes('camp'))h.stageLocal.known.push('camp');if(n&&fresh)E.recordTrackDaoEvidenceV1200(this.world,n,'EXPLORATION',10);this.payBounty('scout',n);}
 postBounty(target,reward){const defs={scout:['สำรวจสันเขา','scout'],woods:['ปราบฝูงอสูร','woods'],camp:['ปราบหัวหน้าโจร','camp'],village:['คุ้มกันหมู่บ้าน','village']};if(!defs[target])return {ok:false,reason:'เป้าหมายไม่ถูกต้อง'};if(target==='scout'&&this.s.campKnown)return {ok:false,reason:'ค้นพบค่ายแล้ว ไม่จำเป็นต้องสำรวจซ้ำ'};if(target==='woods'&&this.s.denKills>=3)return {ok:false,reason:'ฝูงอสูรถูกปราบแล้ว'};if(target==='camp'&&this.enemies.some(e=>e.stageLocal.boss&&!alive(e)))return {ok:false,reason:'หัวหน้าโจรถูกปราบแล้ว'};if(!Number.isFinite(reward)||reward<60||reward>1000)return {ok:false,reason:'รางวัลต้องอยู่ระหว่าง 60–1,000'};if(target==='camp'&&!this.s.campKnown)return {ok:false,reason:'ต้องสำรวจค่ายโจรก่อน'};if(this.s.bounties.some(b=>b.target===target&&b.status==='open'))return {ok:false,reason:'มีประกาศนี้อยู่แล้ว'};if(!this.money(-reward,'สำรองค่าหัว'))return {ok:false,reason:'เงินไม่เพียงพอ'};const b={id:'q'+this.s.nextId++,target,reward,name:defs[target][0],status:'open',accepted:[],created:this.s.t,expires:this.s.t+420,paidTo:null};this.s.bounties.push(b);this.note('ติดประกาศ '+b.name+' รางวัล '+reward);return {ok:true,bounty:b};}
 cancelBounty(id){const b=this.s.bounties.find(b=>b.id===id);if(!b||b.status!=='open')return false;b.status='cancelled';this.money(b.reward,'คืนค่าหัว');return true;}
 payBounty(target,killer){const b=this.s.bounties.find(b=>b.target===target&&b.status==='open');if(!b)return false;const n=killer&&alive(killer)&&this.s.heroIds.includes(killer.id)?killer:this.heroes.find(h=>alive(h)&&b.accepted.includes(h.id)&&!h.stageLocal.offmap&&DIST(h.stageLocal,loc(target==='scout'?'scout':target))<250);if(!n)return false;b.status='paid';b.paidTo=n.id;b.paidAt=this.s.t;E.addSpiritStonesV140(n,b.reward);this.s.transactions.push({t:this.s.t,delta:0,escrowPaid:b.reward,to:n.id,reason:b.name});this.life?.recordBounty(n);this.note(n.name+' ได้รับค่าหัว '+b.reward+' ศิลา',n);return true;}
 fundOrder(recipeId){const r=this.recipes.find(r=>r.id===recipeId)||this.world?.jianghu?.systemsV140?.recipes?.registry?.[recipeId];if(!r)return {ok:false,reason:'ไม่พบสูตร'};const type=r.craftPath==='ALCHEMY'?'alchemy':'forge';if(!this.built(type))return {ok:false,reason:'ต้องสร้าง'+B[type].name};if(this.s.orders.some(o=>o.type===type&&['funded','working'].includes(o.status)))return {ok:false,reason:'มีงานในคิวอยู่แล้ว'};const budget=80;if(!this.money(-budget,'สำรองค่าจ้างช่าง'))return {ok:false,reason:'ต้องมี 80 ศิลา'};this.s.orders.push({id:'o'+this.s.nextId++,recipeId,type,budget,status:'funded',heroId:null,ownerId:this.bank.id,deliveryTarget:'SECT_STORAGE',created:this.s.t});this.note('ตั้งกองทุนผลิต '+r.outputNameTh);return {ok:true};}
 deliverCommissionItemToStorage(item,container,fallbackNpc=null){
  const bankItems=this.bank?.jianghu?.ledgerV140?.[container];
  const bankCap=container==='pillStacks'?128:container==='beastItems'?96:240;
  let storedInBank=false;
  if(bankItems){
   if(container==='pillStacks'){
    let stack=bankItems.find(x=>x.recipeId===item.recipeId&&x.quality===item.quality&&x.originatorSeal===item.originatorSeal);
    if(!stack&&bankItems.length<bankCap){
     stack={...clone(item),id:'BANK_PILL_'+this.s.nextId++,ownerId:this.bank.id,count:0};
     bankItems.push(stack);
    }
    if(stack){
     stack.count+=(item.count||1);
     storedInBank=true;
    }
   }else if(container==='beastItems'){
    let stack=bankItems.find(x=>x.recipeId===item.recipeId&&x.quality===item.quality);
    if(!stack&&bankItems.length<bankCap){
     stack={...clone(item),id:'BANK_BEAST_'+this.s.nextId++,ownerId:this.bank.id,count:0};
     bankItems.push(stack);
    }
    if(stack){
     stack.count+=(item.count||1);
     storedInBank=true;
    }
   }else if(bankItems.length<bankCap){
    bankItems.push({...clone(item),ownerId:this.bank.id});
    storedInBank=true;
   }
   if(storedInBank)E.syncLegacyArraysFromLedgerV140?.(this.bank);
  }
  return storedInBank;
 }
 shareCommissionPillWithBank(item,producer){
  if(!item||!producer||producer.id===this.bank.id)return false;
  const list=producer.jianghu?.ledgerV140?.pillStacks,stack=list?.find(p=>p.id===item.id&&p.count>0);
  if(!stack)return false;
  if(!this.deliverCommissionItemToStorage({...stack,count:1},'pillStacks',producer))return false;
  stack.count--;if(stack.count<=0)list.splice(list.indexOf(stack),1);
  E.syncLegacyArraysFromLedgerV140?.(producer);return true;
 }
 startCommission(n){const s=n.stageLocal,o=this.s.orders.find(o=>o.id===s.orderId);if(!o||o.status!=='funded')return false;const r=this.recipes.find(r=>r.id===o.recipeId),b=this.built(o.type),artisan=o.type==='alchemy'?this.alchemist:this.smith;if(!r||!b||DIST(s,this.endpoint(b))>100){o.heroId=null;return false;}artisan.stageLocal.x=s.x;artisan.stageLocal.y=s.y;artisan.currentCityId=this.city;
  const transferred=[];const rollback=()=>{for(const x of transferred){this.transferMaterialStack(n,this.bank,x.matId,x.count,'COMMISSION_ROLLBACK');}};for(const inp of r.inputs){const need=Math.max(0,inp.count-this.count(n,inp.matId));if(this.count(this.bank,inp.matId)<need){o.heroId=null;s.cooldowns.craft=this.s.t+20;this.note('งานช่างรอวัตถุดิบ '+inp.matId,n);return false;}}
  for(const inp of r.inputs){const need=Math.max(0,inp.count-this.count(n,inp.matId));if(need>0){const tr=this.transferMaterialStack(this.bank,n,inp.matId,need,'COMMISSION_INPUT');if(tr.moved<need){if(tr.moved>0)transferred.push({matId:inp.matId,count:tr.moved});rollback();o.heroId=null;return false;}transferred.push({matId:inp.matId,count:need});}}
  if(LOW_GRADE_PILL_IDS.includes(r.id)){
   const budget=o.budget;E.addSpiritStonesV140(n,budget);const res=E.produceFromRecipeV140(this.world,n.id,r.id,{rng:this.rng,riskyExperiment:true});
   if(!res?.ok){E.addSpiritStonesV140(n,-budget);rollback();o.heroId=null;o.status='funded';this.note('เริ่มปรุงโอสถไม่ได้: '+(res?.reason||'เงื่อนไขไม่ผ่าน'),n);return false;}
   const fuel=res.pending?Number(res.job?.fuelCost||r.tier*4):Math.max(6,r.tier*4);if(!res.pending)E.addSpiritStonesV140(n,-fuel);const refund=Math.max(0,budget-fuel);if(refund){E.addSpiritStonesV140(n,-refund);this.money(refund,'คืนงบโอสถส่วนเกิน');}o.budget=0;o.heroId=n.id;o.brewerId=n.id;
   if(res.pending&&res.job){o.status='working';o.jobId=res.job.id;o.finishTick=res.job.finishTick;this.note(`${n.name} เริ่มปรุง${r.outputNameTh}ด้วยฝีมือ ${E.getCraftMasteryV140(this.world,n,'ALCHEMY')} · รอ ${r.durationDays} วัน`,n);return true;}
   o.status=res.produced?'delivered':'failed';o.finishTick=this.world.tick;o.jobId=null;
   if(res.produced){
    const shared=res.item&&this.shareCommissionPillWithBank(res.item,n);
    this.s.stats.crafted++;this.note(`${n.name} ปรุง${r.outputNameTh}สำเร็จ · ${shared?'แบ่ง 1 เม็ดเข้าคลังสำนัก':'เก็บโอสถไว้ในสัมภาระผู้ปรุง'}`,n);
   }else this.note(`${n.name} ปรุง${r.outputNameTh}ล้มเหลว · วัตถุดิบที่ใช้แล้วสูญเสียไป`,n);
   return !!res.produced;
  }
  const advanced=o.budget;E.addSpiritStonesV140(n,advanced);const quote=E.planArtisanCommissionV1181(this.world,n,artisan,{recipeId:r.id,materialPolicy:'CLIENT_SUPPLIES'});if(!quote.ok){E.addSpiritStonesV140(n,-advanced);rollback();this.note('ช่างยังรับงานไม่ได้: '+(quote.reason||quote.code),n);o.heroId=null;return false;}if(quote.totalCost>E.getSpiritStonesV140(n)){E.addSpiritStonesV140(n,-advanced);rollback();this.note('ค่าผลิตสูงกว่างบที่สำรอง',n);o.heroId=null;return false;}const res=E.commissionArtisanV1180(this.world,n,artisan,{recipeId:r.id,materialPolicy:'CLIENT_SUPPLIES'});if(!res.ok){E.addSpiritStonesV140(n,-advanced);rollback();this.note('เริ่มงานไม่สำเร็จ: '+(res.reason||res.code),n);o.heroId=null;return false;}const activity=o.type==='alchemy'?'alchemy':'forging',rate=Human.workRate(artisan,activity),c=res.commission,job=res.job||this.world.jianghu.progressionV1100.jobs.find(j=>j.id===c?.jobId);if(c){c.finishTick=this.world.tick+Math.max(1,Math.ceil((c.finishTick-this.world.tick)/rate));c.humanWork={activity,rate,capacity:Human.capacity(artisan,activity)};c.sectFundedOrder=true;artisan.jianghu.busyProductionUntilTick=c.finishTick;}if(job){job.finishTick=this.world.tick+Math.max(1,Math.ceil((job.finishTick-this.world.tick)/rate));job.successChance=Math.max(.1,Math.min(.98,job.successChance+(Human.capacity(artisan,activity).total-50)*.0015));if(c)c.finishTick=job.finishTick;}const returned=Math.max(0,advanced-quote.totalCost);if(returned){E.addSpiritStonesV140(n,-returned);this.money(returned,'คืนทุนช่างส่วนเกิน');}o.budget=0;o.status='working';o.commissionId=res.commission?.id;o.jobId=job?.id||res.commission?.jobId||null;o.finishTick=res.commission?.finishTick||res.job?.finishTick;this.note(n.name+' ว่าจ้าง '+r.outputNameTh+' ใช้วัตถุดิบครบสูตร',n);return true;}
 cancelOrder(id){const o=this.s.orders.find(o=>o.id===id);if(!o||o.status!=='funded')return false;o.status='cancelled';this.money(o.budget,'คืนกองทุนช่าง');o.budget=0;return true;}
 buyMaterial(id,qty=4){if(!TRADE_MATERIAL_IDS.includes(id)||!Number.isInteger(qty)||qty<1||qty>20)return {ok:false,reason:'รายการไม่ถูกต้อง'};const price=this.life?this.life.marketPrice(this.routeBlocked()?9:6,qty):(this.routeBlocked()?9:6)*qty;if((this.s.merchantStock[id]||0)<qty)return {ok:false,reason:'สินค้าหมด รอคาราวานหรือเก็บจากแหล่ง'};if(this.gold<price)return {ok:false,reason:'ศิลาไม่พอ'};
  if(id==='wood')this.s.wood+=qty;else if(!this.add(this.bank,id,qty,'MERCHANT').ok)return {ok:false,reason:'คลังเต็ม'};this.money(-price,'ซื้อเสบียง');this.s.merchantStock[id]-=qty;return {ok:true};}
 routeBlocked(){return this.enemies.some(e=>alive(e)&&e.stageLocal.raid);}
 aid(){if(this.s.t-this.s.aidAt<180)return {ok:false,reason:'ขอแรงชาวบ้านได้ทุก 180 วินาที'};this.s.aidAt=this.s.t;this.money(80,'เงินกู้ชุมชน');this.s.wood+=5;this.add(this.bank,ORE,3,'COMMUNITY_AID');this.s.villageHP=Math.max(1,this.s.villageHP-25);this.note('ชาวบ้านช่วยทุน 80 ไม้ 5 แร่ 3 · หมู่บ้านเสียเสบียง 25');return {ok:true};}
 repair(){if(!this.money(-60,'ซ่อมแนวป้องกัน'))return {ok:false,reason:'ต้องใช้ 60 ศิลา'};this.s.villageHP=Math.min(1000,this.s.villageHP+180);for(const b of this.s.buildings)b.hp=Math.min(root.JianghuInfrastructure?.maxHp(b)||B[b.type].hp,b.hp+120);return {ok:true};}
 remember(n,action,valence,text){if(n?.core?.human)Human.remember(n,action,valence,text,this.s.t);}
 pillScoreForNpc(n,p){
  if(!p||p.count<=0)return 0;
  const j=n?.jianghu||{};
  const eff=Growth.normalizePillEffect?Growth.normalizePillEffect(p,this.world):(p.effect||{});
  if(eff.toxicity>0&&(j.pillToxicity||0)>=72&&!eff.toxicityRelief)return 0;
  const qi=Number(j.currentQiV190||0),max=Number(j.maxQiV190||100);
  const grief=Number(n?.core?.human?.state?.grief||0),pain=Number(n?.core?.human?.state?.pain||0);
  let score=0;
  if(eff.healHealth>0&&n.health<78)score+=38+(78-n.health)*.5;
  if(eff.healInjury>0&&(Number(j.internalInjury||0)>10||pain>12))score+=26;
  if(eff.restoreQi>0&&qi<max*.65)score+=40;
  if(eff.cultivationProgress>0&&Number(j.cultivationProgress||0)<92&&Number(j.pillToxicity||0)<35)score+=16;
  if(eff.heartDemonRelief>0&&Number(j.heartDemon||0)>10)score+=22;
  if(eff.griefRelief>0&&grief>8)score+=20;
  if(eff.clearPoison>0&&Number(j.poisonAccumulated||0)>8)score+=24;
  if(eff.toxicityRelief>0&&Number(j.pillToxicity||0)>8)score+=22;
  if(eff.foundationBonus>0&&Number(j.foundationStability||58)<82&&Number(j.pillToxicity||0)<25)score+=12;
  if(eff.daoComprehensionBonus>0&&Number(j.daoComprehension||52)<85&&Number(j.pillToxicity||0)<25)score+=14;
  if(eff.lifespanBonus>0&&(Number(j.lifespanMax||100)-Number(n.age||22))<35)score+=28;
  return score;
 }
 hasUsefulPill(n){
  const l=n?.jianghu?.ledgerV140;if(!l)return false;
  return l.pillStacks.some(p=>this.pillScoreForNpc(n,p)>0);
 }
 chooseUsefulPill(n){
  const l=n?.jianghu?.ledgerV140;if(!l)return null;
  return l.pillStacks.filter(p=>p.count>0).map(p=>({p,score:this.pillScoreForNpc(n,p)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||String(a.p.id).localeCompare(String(b.p.id)))[0]?.p||null;
 }
 checkAspiration(n){const a=n.stageLocal.aspiration;if(!a||a.fulfilled)return;const j=n.jianghu;const done=a.id==='mastery'?j.trackOrdinal>1:a.id==='wealth'?E.getSpiritStonesV140(n)>=240:a.id==='guardian'?this.s.stats.kills>=4&&this.s.chapterCleared:a.id==='discovery'?this.s.campKnown&&n.stageLocal.history.some(h=>h.text.includes('กลับจากตลาด')):a.id==='artisan'?j.ledgerV140.equipmentItems.length>0:this.heroes.some(h=>h.id!==n.id&&(E.getRelationshipV130(this.world,n,h,false)?.bond||0)>=10);if(done){a.fulfilled=true;a.at=this.s.t;this.remember(n,a.action,12,'สมปรารถนา: '+a.text);this.note(n.name+' สมปรารถนา: '+a.text,n);}}
 recordDamageEvent(target,amount,attacker,info={}){
  const p=target.stageLocal||target;if(p.offmap||!Number.isFinite(p.x)||!Number.isFinite(p.y)||amount<=0)return;
  const value=this.combatSystem?this.combatSystem.fromCondition(target,amount):amount;
  if(info.type==='dot'){
   const existing=this.s.combat.find(e=>e.targetId===target.id&&e.damageType==='dot'&&e.until>this.s.t);
   if(existing){
    existing.x=p.x;existing.y=p.y;
    existing.rawDot=(existing.rawDot||existing.value)+value;
    existing.value=+existing.rawDot.toFixed(1);
    return;
   }
   this.s.combat.push({x:p.x,y:p.y,value:+value.toFixed(1),rawDot:value,kind:'damage',critical:false,label:info.moveName||'',damageType:'dot',artId:info.artId||null,until:this.s.t+1.2,t:this.s.t,targetId:target.id,attackerId:attacker?.id||null});
   if(this.s.combat.length>100)this.s.combat.splice(0,this.s.combat.length-100);
   return;
  }
  this.s.combat.push({x:p.x,y:p.y,value:+value.toFixed(1),kind:info.critical?'critical':'damage',critical:!!info.critical,label:info.moveName||'',damageType:info.type||'environment',artId:info.artId||null,until:this.s.t+(info.critical?1.35:1.0),t:this.s.t,targetId:target.id,attackerId:attacker?.id||null});
  if(this.s.combat.length>100)this.s.combat.splice(0,this.s.combat.length-100);
 }
 damage(target,amount,attacker,skipReaction=false,info={}){
  if(!alive(target)||!Number.isFinite(amount)||amount<=0)return;
  amount/=(this.realm?.formationBonus(target,'protection')||1);
  let counter=0;
  if(!skipReaction&&this.combatSystem){const reaction=this.combatSystem.incoming(target,amount,attacker);amount=reaction.amount;counter=reaction.counter||0;}
  if(amount<=0)return;
  if(target.stageLocal?.pet){
   const before=target.health;this.realm.damagePet(target,amount,attacker);this.recordDamageEvent(target,before-target.health,attacker,info);
   if(counter>0&&alive(attacker))this.damage(attacker,counter,target,true,{combat201:true,secondary:true,type:'reflect'});return;
  }
  if(target.habitatId&&this.myriad)this.myriad.recordDamageTypeOnBeast(target,attacker,info.artId?this.combatSystem?.artMap.get(info.artId):info.damageElement||null,this.combatSystem?.fromCondition(target,Math.min(target.health,amount)));
  if(target.core){if(!info.combat201)amount*=Human.damageMultiplier(target);Human.injure(target,amount,this.s.t);}
  const before=target.health;target.health=Math.max(0,target.health-amount);
  const p=target.stageLocal||target;this.recordDamageEvent(target,before-target.health,attacker,info);
  if(target.health>0){if(counter>0&&alive(attacker))this.damage(attacker,counter,target,true,{combat201:true,secondary:true,type:'reflect'});return;}
  // Credit the keeper for rewards without mislabelling the companion's damage.
  if(attacker?.stageLocal?.pet)attacker=this.world.npcs[attacker.ownerId]||attacker;
  target.alive=false;if(target.habitatId)target.corpseUntil=this.s.t+18;
  this.storyEvents?.recordTargetDefeat(target,attacker);
  if(target.stageLocal?.visitor){if(!this.realm?.onDeath(target))this.life.onDeath(target);return;}
  if(this.s.heroIds.includes(target.id)){this.cancelActionSetup(target,p.action);this.myriad?.onNpcDeath(target);this.progression?.sanitizeEquippedItems?.(target);this.realm?.onDeath(target);p.mode='dead';p.action=null;p.route=[];p.offmap=null;this.note('ศิษย์ '+target.name+' เสียชีวิตถาวร',target);for(const h of this.heroes.filter(alive)){const rel=E.getRelationshipV130(this.world,h,target,false);this.remember(h,'defend',4+(rel?.bond||0)*.1,'ระลึกถึงการตายของ '+target.name);h.core.condition.moodStress=Math.min(100,h.core.condition.moodStress+12);h.core.human.state.grief=Math.min(100,h.core.human.state.grief+12+(rel?.bond||0)*.3);}const order=this.s.orders.find(o=>o.heroId===target.id&&o.status==='funded');if(order)order.heroId=null;this.life?.syncLegacyPositions?.();}
  else {this.s.stats.kills++;this.note((attacker?.name||'หอพิทักษ์')+' ปราบ '+target.name);if(target.habitatId)this.dropBeastLoot(target,attacker);if(attacker&&this.s.heroIds.includes(attacker.id)){if(!target.habitatId)this.add(attacker,FANG,target.stageLocal?1:2,'COMBAT_LOOT');E.addSpiritStonesV140(attacker,12);E.recordTrackDaoEvidenceV1200(this.world,attacker,'COMBAT',10);this.life?.recordKill(attacker);}
   if(target.stageLocal?.boss&&!target.stageLocal.storyEventId){this.payBounty('camp',attacker);this.s.campSupplies=0;}
   if(!target.stageLocal&&!target.storyEventId){this.s.denKills++;if(this.s.denKills>=3)this.payBounty('woods',attacker);}
  }
 }
 attack(n,target){if(this.combatSystem)return this.combatSystem.act(n,target);const s=n.stageLocal;if(this.s.t-(s.lastHit||-100)<1.25)return;s.lastHit=this.s.t;const power=this.power(n),def=target.stageLocal?this.power(target):target.power;const base=s.enemy?(s.boss?5.5:4):7;const damage=base*Math.max(.55,Math.min(2.2,Math.sqrt(power/Math.max(100,def))));this.damage(target,damage,n);n.core.condition.fatigue=Math.min(100,(n.core.condition.fatigue||0)+.4);Human.learn(n,'hunt',.08);}

 updateHero(n,dt){if(!alive(n))return;const s=n.stageLocal;Human.tick(n,dt);this.combatSystem?.tick(n,dt);if(!alive(n))return;if((s.combatState?.staggerUntil||0)>this.s.t)return;
  if(s.needs.hunger>90)n.health=Math.max(1,n.health-dt*.03);
  const proj=n.jianghu.breakthroughProjectV1200,activeProject=proj&&!['COMPLETE','FAILED','ABORTED'].includes(proj.phase);
  const inSeclusionPhase=activeProject&&SECLUSION_LOCK_PHASES.has(proj.phase)&&proj.statusCode!=='WAITING_SPIRIT_STONES';
  if(activeProject&&(n.health<40||(inSeclusionPhase&&this.nearestEnemy(n,170)))){
   E.cancelBreakthroughProjectV1200(this.world,n,'LOCAL_EMERGENCY',n.health<40?'บาดเจ็บรุนแรง ต้องถอนตัว':'ศัตรูบุกประชิดด่านบำเพ็ญ ต้องออกรับศึก');
   s.action=null;s.mode='idle';
  }else if(inSeclusionPhase){
   const trBuilding=this.built('training')||this.built('hall');
   if(!trBuilding){
    proj.phase='PAUSED';proj.statusCode='SITE_DAMAGED';
    s.action=null;s.mode='idle';
   }else{
    s.action='seclusion';s.goal='ปิดด่านทะลวงขั้น ('+proj.phase+')';s.mode='working';
    s.job=Math.max(0,(proj.phaseFinishTick||this.world.tick+1)-this.world.tick)*DAY;
    return;
   }
  }else if(s.action==='seclusion'){
   s.action=null;s.target=null;s.mode='idle';s.nextThink=this.s.t+1;
  }
  if(s.offmap&&(this.myriad?.handleOffmap(n)||this.realm?.handleOffmap(n)))return;this.myriad?.beforeHero(n);this.realm?.beforeHero(n);this.academy?.beforeHero?.(n);this.discovery?.beforeHero(n);
  if(s.offmap){if(this.s.t>=s.offmap.until){const q=s.offmap.reserved,escort=this.progression?.equippedEscortBonus?.(n)||0,baseRisk=this.life?this.life.routeRisk(this.routeBlocked()?.3:this.s.route.risk):(this.routeBlocked()?.3:this.s.route.risk),risk=Math.max(.02,baseRisk-escort*.4);const failed=this.rng.next()<risk;n.currentCityId=this.city;s.x=loc('exit').x;s.y=loc('exit').y;s.offmap=null;s.mode='idle';s.nextThink=this.s.t+1;if(failed){n.health=Math.max(10,n.health-35);Human.injure(n,35,this.s.t);this.remember(n,'trade',-8,'คาราวานถูกจู่โจมและเสียสินค้า');this.note(n.name+' กลับจากการค้า บาดเจ็บและเสียสินค้าที่จอง',n);}else{const price=4*q;if(this.gold>=price&&this.add(n,CIN,q,'OFFMAP_JADE_ROUTE').ok){this.money(-price,'ต้นทุนคาราวาน');this.money(8*q,'ค่าขนส่งคาราวาน');this.s.stats.trades++;this.life?.credit(n,2,'นำสินค้ากลับจากเส้นทางการค้าจริง');Human.learn(n,'trade',2);this.remember(n,'trade',5,'ค้าข้ามด่านกลับมาพร้อมสินค้า');this.checkAspiration(n);this.note(n.name+' กลับจากตลาดหยกพร้อมชาด '+q+' ชิ้น',n);}else this.note(n.name+' กลับจากการค้า แต่ทุนหรือพื้นที่คลังไม่พอ',n);} }return;}
  if(DIST(s,loc('camp'))<540)this.revealCamp(n);
  if(s.huntTargetId&&['hunt','defend'].includes(s.action)){
   const hunted=this.world.npcs[s.huntTargetId]||this.s.beasts.find(b=>b.id===s.huntTargetId);
   const matSatisfied=s.huntForMatId&&this.count(n,s.huntForMatId)>=(this.progression?.reserve(n,s.huntForMatId)||1);
   if(!alive(hunted)||matSatisfied){s.job=0;this.finish(n);s.huntTargetId=null;s.huntForMatId=null;return;}
  }
  const aware=this.nearestEnemy(n,350),threat=aware&&(DIST(s,aware.stageLocal||aware)<190||aware.stageLocal?.enemy||s.combatState?.lastAttackerId===aware.id&&this.s.t-(s.combatState.lastIncomingAt||0)<6)?aware:null,healthThreshold=38+(n.personality.caution??50)*.16+Human.effective(n,'cognition','metacognition')*.03;

  if(threat&&(n.health<healthThreshold||!this.combatSystem.canEngage(n,threat))){
   this.combatSystem.act(n,threat,{defensiveOnly:true});if(!alive(n))return;
   const safePoint=this.chooseRetreatDestination(n,threat);
   const threatDist=DIST(s,threat.stageLocal||threat);
   const corneredAtDestination=DIST(s,safePoint)<95&&threatDist<155;
   if(corneredAtDestination&&n.health>16){
    // Cornered at the retreat destination with enemy in melee range: fight back defensively instead of standing pacified!
    s.mode='combat';
    this.attack(n,threat);
    return;
   }
   if(s.action!=='flee'||!s.target||DIST(s.target,threat.stageLocal||threat)<180){
    this.send(n,'flee',safePoint,10);
    this.note(n.name+' ถอนตัวเข้าแนวปลอดภัยเพราะบาดเจ็บหรือเสียเปรียบ',n);
    this.remember(n,'hunt',-10,'เกือบตายจากการต่อสู้');
    this.remember(n,'assault',-12,'จำความพ่ายแพ้และระวังตัวขึ้น');
   }
   this.move(n,dt,65);
   if(!s.route.length){
    if(threatDist<145){
     // Enemy followed all the way here: defend life!
     this.attack(n,threat);
    }else{
     n.health=Math.min(100,n.health+dt*3.2);
     s.job-=dt;
     if(s.job<=0){s.action=null;s.target=null;s.mode='idle';}
    }
   }
   return;
  }
  if(threat&&n.health>=healthThreshold){s.mode='combat';this.combatSystem?.advance(n,threat,dt);this.attack(n,threat);return;}
  if(s.mode==='combat')s.mode=s.target?'travel':'idle';
  if(s.mode==='travel'){if(this.move(n,dt)){s.mode='working';}return;}
  if(s.mode==='working'){
   const action=s.action;if(action?.startsWith('bounty:')||['hunt','assault','defend'].includes(action)){
    const focused=s.huntTargetId&&(this.world.npcs[s.huntTargetId]||this.s.beasts.find(b=>b.id===s.huntTargetId));
    const target=s.huntTargetId?(alive(focused)?focused:null):this.nearestEnemy(n,950);
    if(target&&n.health>=60&&n.core.condition.fatigue<65&&s.needs.hunger<75){s.target={id:target.id,x:(target.stageLocal||target).x,y:(target.stageLocal||target).y};s.route=this.path(s,s.target);s.mode='travel';return;}
    if(['hunt','defend','assault'].includes(action)){s.job=0;this.finish(n);return;}

    if(action?.startsWith('bounty:')){const b=this.s.bounties.find(b=>b.id===s.bountyId);if(b?.target==='scout')this.revealCamp(n);if(b?.target==='village')this.payBounty('village',n);}
   }
   s.job-=dt*Human.workRate(n,this.academy?.workActivity(n,s.action)||this.progression.workActivity(n,s.action));if(s.action==='rest'||s.action==='heal'){n.health=Math.min(100,n.health+dt*.6*Human.recovery(n));Human.recover(n,dt*.6*Human.recovery(n));}if(s.job<=0)this.finish(n);return;
  }
  if(this.s.t>=s.nextThink)this.decide(n);
 }
 updateEnemy(n,dt){if(!alive(n))return;const s=n.stageLocal;this.combatSystem?.tick(n,dt);if(!alive(n))return;if((s.combatState?.staggerUntil||0)>this.s.t)return;const hero=[...this.heroes,...this.visitors,...(this.realm?.combatPets||[])].filter(h=>alive(h)&&!h.stageLocal.offmap).map(h=>({h,d:DIST(s,h.stageLocal)})).filter(z=>z.d<(s.raid?600:420)).sort((a,b)=>a.d-b.d)[0];
  if(hero){if(hero.d<(this.combatSystem?.reach(n)||150)){this.combatSystem?.advance(n,hero.h,dt);this.attack(n,hero.h);}else this.combatSystem.pursue(n,hero.h,dt);return;}
  if(s.raid){const target=this.built('hall')||loc('village');if(DIST(s,target)<200){if(target.hp!==undefined)target.hp=Math.max(0,target.hp-3*dt);else this.s.villageHP-=4*dt;if(this.s.t>(s.lootAt||0)){s.lootAt=this.s.t+20;this.s.campSupplies+=10;}return;}if(!s.route?.length)s.route=this.path(s,{x:target.x,y:target.y+180});this.move(n,dt,30);}
  else if(!s.boss){if(!s.route?.length&&this.s.t>s.nextMove){s.route=this.path(s,{x:s.home.x+this.rng.int(-180,180),y:s.home.y+this.rng.int(-160,180)});s.nextMove=this.s.t+10;}this.move(n,dt,18);}
 }
 updateBeast(b,dt){
  if(!b.alive)return;
  this.combatSystem?.tickStatuses(b,dt);if(!b.alive)return;
  if((b.combatState?.staggerUntil||0)>this.s.t)return;
  if(this.isHostileCreature(b)&&b.home){
   if(DIST(b,b.home)>(b.tier>=4?700:460))b.returningHome201=true;
   if(b.returningHome201){b.target=null;b.mode='return';if(DIST(b,b.home)<120){b.returningHome201=false;b.route=[];return;}if(!b.route?.length||DIST(b.route.at(-1),b.home)>10)b.route=this.path(b,b.home);this.move(b,dt,48);return;}
  }
  if(!this.isHostileCreature(b)){
   // Peaceful sanctuary spirit beasts stroll calmly within the sect sanctuary and heal nearby companions
   if(!b.route?.length&&this.s.t>b.nextMove){
    b.route=this.path(b,{x:b.home.x+this.rng.int(-95,95),y:b.home.y+this.rng.int(-95,95)});
    b.nextMove=this.s.t+10;
   }
   this.move(b,dt,15);
   b.health=Math.min(b.maxHP,b.health+dt*.25);
   return;
  }
  const hero=[...this.heroes,...this.visitors,...(this.realm?.combatPets||[])].filter(h=>alive(h)&&!h.stageLocal.offmap).map(h=>({h,d:DIST(b,h.stageLocal)})).filter(z=>z.d<310).sort((a,b)=>a.d-b.d)[0];
  if(hero){if(hero.d<135){this.combatSystem.creatureAct(b,hero.h);}else this.combatSystem.pursue(b,hero.h,dt);}else{if(!b.route?.length&&this.s.t>b.nextMove){b.route=this.path(b,{x:b.home.x+this.rng.int(-140,140),y:b.home.y+this.rng.int(-140,140)});b.nextMove=this.s.t+8;}this.move(b,dt,20);}
 }
 settleCommissions(){const w=this.world,sys=w.jianghu.causalV1180;for(const c of sys.commissions){if(c.status==='BREWING'&&c.jobId){const j=w.jianghu.progressionV1100.jobs.find(j=>j.id===c.jobId);if(j&&!['BREWING','WAITING_STORAGE'].includes(j.status))c.status=j.status;}if(['FORGING','WAITING_STORAGE'].includes(c.status)&&w.tick>=c.finishTick){const a=w.npcs[c.artisanId],n=w.npcs[c.clientId],b=this.built(c.craftPath==='ALCHEMY'?'alchemy':'forge');if(!alive(a)||!alive(n)||!b){c.status='FAILED_INTERRUPTED';delete c.outputEscrow;continue;}const out=c.outputEscrow;if(!out){c.status='FAILED';continue;}
   if(out.container==='equipmentItems'){
    const rec=w.jianghu.systemsV140.recipes.registry[c.recipeId];
    for(const [key,value] of Object.entries(rec?.effect||{}))if(out.item[key]===undefined)out.item[key]=clone(value);
    out.item.minStageReq=Number.isFinite(out.item.minStageReq)?out.item.minStageReq:Math.max(1,(out.item.tier||1)-1);
    root.JianghuExpansionV112?.imbueEquipmentDepth?.(out.item,this.rng);
   }
   const items=n.jianghu.ledgerV140[out.container];
   // A sect order has one output, delivered to storage or retained by its
   // courier when storage is full. Never insert it into both inventories.
   const bankStored=c.sectFundedOrder&&this.deliverCommissionItemToStorage(out.item,out.container,n);
   const clientAdded=!bankStored&&items.length<12;
   if(clientAdded){
    out.item.ownerId=n.id;
    items.push(out.item);
    E.syncLegacyArraysFromLedgerV140?.(n);
   }
   if(!clientAdded&&!bankStored){
    c.status='WAITING_STORAGE';continue;
   }
   c.status='DELIVERED';c.deliveredTick=w.tick;delete c.outputEscrow;E.recordArtisanAchievementV1181(w,a,w.jianghu.systemsV140.recipes.registry[c.recipeId],c.id,n.id);}}
  const jobs=w.jianghu.progressionV1100?.jobs||[];for(const o of this.s.orders.filter(o=>o.status==='working'&&o.jobId)){const j=jobs.find(x=>x.id===o.jobId);if(!j)continue;if(j.status==='DELIVERED'){o.status='delivered';o.finishTick=j.terminalTick??w.tick;
   const bearer=this.world.npcs[o.brewerId||o.heroId];
   const rec=this.recipes.find(r=>r.id===o.recipeId);
   const createdPill=bearer?.jianghu?.ledgerV140?.pillStacks?.find(p=>p.recipeId===o.recipeId&&p.count>0);
   const shared=createdPill&&o.deliveryTarget==='SECT_STORAGE'&&this.shareCommissionPillWithBank(createdPill,bearer);
   this.s.stats.crafted++;this.note(`${bearer?.name||'ผู้ปรุง'} ส่งมอบ ${rec?.outputNameTh||'โอสถ'} แล้ว${shared?' · แบ่ง 1 เม็ดเข้าคลังสำนัก':' · เก็บผลผลิตเดิมไว้กับผู้รับ'}`);}else if(['FAILED','FAILED_INTERRUPTED','CANCELLED','INTERRUPTED'].includes(j.status)){o.status='failed';o.finishTick=j.terminalTick??w.tick;this.note(`งานโอสถ ${this.recipes.find(r=>r.id===o.recipeId)?.outputNameTh||''} ล้มเหลว: ${j.status}`);}}
 }
 day(){const w=this.world;w.tick=Math.floor(this.s.t/DAY);
  E.finishAlchemyJobsV1100(w);this.settleCommissions();
  // No legacy day scheduler: local jobs, movement and these interval settlements share s.t.
  for(const n of this.heroes){if(!alive(n))continue;const p=n.jianghu.breakthroughProjectV1200;if(p&&!['COMPLETE','FAILED','ABORTED'].includes(p.phase)){const before=n.jianghu.trackOrdinal;E.stepBreakthroughProjectV1200(w,n,{rng:this.rng});if(n.jianghu.trackOrdinal>before){this.s.stats.breakthroughs++;this.note(n.name+' ทะลวงสำเร็จ',n);}}}
  const tax=Math.round((this.s.villageHP>500?18:10)+(this.built('market')?12:0));this.money(tax,'รายได้หมู่บ้าน');for(const n of this.heroes.filter(alive)){if(this.money(-2,'เบี้ยเลี้ยง '+n.name))E.addSpiritStonesV140(n,2);}
  for(const id of TRADE_MATERIAL_IDS)this.s.merchantStock[id]=Math.min(24,(this.s.merchantStock[id]||0)+(this.routeBlocked()?1:3));
  const villageFoodTribute=(this.s.villageHP>=400&&!this.routeBlocked())?3:1;
  const gardenBonus=this.built('garden')?1:0;
  this.s.food=Math.min(160,this.s.food+villageFoodTribute+gardenBonus);
  this.s.route.stock=Math.min(48,this.s.route.stock+2);
  const commissions=w.jianghu.causalLivingV1180?.commissions||w.jianghu.causalV1180?.commissions||[];
  for(const o of this.s.orders.filter(o=>o.status==='working'&&o.commissionId)){const c=commissions.find(c=>c.id===o.commissionId);if(c&&['DELIVERED','FAILED','CANCELLED','INTERRUPTED','FAILED_INTERRUPTED'].includes(c.status)){o.status=c.status.toLowerCase();if(c.status==='DELIVERED'){const artisan=w.npcs[c.artisanId];if(artisan)Human.learn(artisan,c.craftPath==='ALCHEMY'?'alchemy':'forging',3);this.s.stats.crafted++;this.note('ช่างส่งมอบ '+c.outputNameTh+' ให้ '+w.npcs[o.heroId]?.name);}else this.note('งานช่างสิ้นสุด: '+c.status);}}
  this.life?.syncLegacyPositions?.();
 }
 step(dt=STEP){if(this.s.paused||this.s.status==='lost')return;this.s.t=+(this.s.t+dt).toFixed(6);const d=Math.floor(this.s.t/DAY);if(d>this.s.lastDay){this.s.lastDay=d;this.day();}
  for(const b of this.s.buildings){b.occupants=[];if(b.remaining>0){b.remaining=Math.max(0,b.remaining-dt*(root.JianghuInfrastructure?.bonuses(this).constructionSpeed||1));if(b.remaining===0)this.note('สร้าง'+B[b.type].name+' เสร็จแล้ว');}if(b.hp>0)for(const n of this.heroes)if(alive(n)&&n.stageLocal.mode==='working'&&DIST(n.stageLocal,this.endpoint(b))<110)b.occupants.push(n.id);}
  this.stepEcology(dt);
  root.JianghuInfrastructure?.tick(this,dt);
  this.life?.tick(dt);this.realm?.tick(dt);this.academy?.tick(dt);this.discovery?.tick(dt);this.storyEvents?.tick(dt);for(const n of this.heroes)this.updateHero(n,dt);for(const n of this.enemies)this.updateEnemy(n,dt);for(const b of this.s.beasts)this.updateBeast(b,dt);
  for(const tower of this.s.buildings.filter(b=>b.type==='tower'&&b.hp>0&&b.remaining<=0)){if(this.s.t>=(tower.fireAt||0)){const target=[...this.enemies.filter(alive),...this.s.beasts.filter(b=>this.isHostileCreature(b))].find(e=>DIST(tower,e.stageLocal||e)<420);if(target){tower.fireAt=this.s.t+1;this.damage(target,9,null,false,{moveName:'ศรปราณหอพิทักษ์',type:'art'});}}}
  if(this.s.activation!==null&&this.s.t-this.s.activation>this.s.raidAt&&this.enemies.some(n=>alive(n)&&n.stageLocal.boss)&&this.s.campSupplies>=25){this.s.campSupplies-=25;this.s.raidAt+=80;const raid=this.bandit(false,3220,650);raid.stageLocal.raid=true;this.note('ค่ายโจรใช้เสบียง 25 ส่งหน่วยปล้นเข้าหมู่บ้าน');}
  for(const b of this.s.bounties)if(b.status==='open'&&this.s.t>=b.expires){b.status='expired';this.money(b.reward,'คืนค่าหัวหมดอายุ');}
  this.s.combat=this.s.combat.filter(c=>c.until>this.s.t);
  if(this.s.villageHP<=0||this.s.buildings.some(b=>b.type==='hall'&&b.hp<=0)){this.s.status='lost';this.note('สำนักพ่ายแพ้ · จุดคุ้มครองถูกทำลาย');}
  const bossDead=this.enemies.some(e=>e.stageLocal.boss&&!e.stageLocal.storyEventId&&!alive(e));const clear=!this.enemies.some(e=>alive(e)&&e.stageLocal.raid);
  if(bossDead&&clear&&this.s.denKills>=3&&this.s.villageHP>0){this.s.stable+=dt;if(this.s.stable>=30&&!this.s.chapterCleared){this.s.chapterCleared=true;this.s.status='won';this.s.legacy=Math.min(3,this.s.legacy+1);this.note('ชายแดนสงบ · ได้ตรามรดกสำนัก 1 ดวง');}}else this.s.stable=0;
  for(const n of [...this.heroes,...this.enemies]){if(alive(n))this.progression?.sanitizeEquippedItems(n);const cs=n.stageLocal.combatState;if(alive(n)&&cs&&(cs.qiTier!==n.jianghu.realizationBand||cs.maxQi!==n.jianghu.maxQiV190))this.combatSystem.ensure(n);}
 }
 advance(seconds){let steps=Math.floor((seconds+1e-6)/STEP);for(let i=0;i<steps;i++)this.step(STEP);}
 frame(realSeconds){if(this.s.paused)return;const speed=[1,2,4,8,16].includes(this.s.speed)?this.s.speed:1;this.acc+=Math.min(realSeconds,.3)*speed;let count=0;const maxSteps=48;while(this.acc+1e-9>=STEP&&count<maxSteps){this.step(STEP);this.acc=Math.max(0,this.acc-STEP);count++;}}
 serialize(){return JSON.stringify({version:11,growthSchemaVersion:2,academySchemaVersion:1,humanSchemaVersion:Human.VERSION,sectLifeVersion:Life.VERSION,realmSchemaVersion:Realm.VERSION,combatSchemaVersion:2,combatOverhaulVersion:1,release:'2.08.8-full-economy-performance-and-longrun',patch:'1.17-living-combat',world:this.world,s:this.s,city:this.city,rngState:this.rng.seed,recipes:this.recipes.map(r=>r.id)});}
 static load(text){const d=JSON.parse(text);if(d.s?.storyEvents&&d.s.storyEvents.schemaVersion!==2)throw Error('เซฟใช้เควสคนละรุ่นกับ 2.05 กรุณาเก็บเซฟเดิมไว้และเริ่มหุบเขาใหม่');if(d.combatOverhaulVersion>1)throw Error('เซฟใช้คอมแบทรุ่นใหม่กว่า 2.01');if(d.version!==11||d.patch!=='1.17-living-combat'||d.combatSchemaVersion!==2||d.growthSchemaVersion!==2||d.academySchemaVersion!==1||!d.world?.npcs||!d.s?.services||!Array.isArray(d.s.heroIds)||!Number.isFinite(d.s.t)||!d.s.discovery)throw Error('เซฟนี้ไม่ใช่รุ่น 1.17 กรุณาเริ่มเกมใหม่');if(d.humanSchemaVersion>Human.VERSION)throw Error('เซฟใช้รากฐานตัวตน NPC รุ่นใหม่กว่าเกมนี้');if(d.sectLifeVersion>Life.VERSION)throw Error('เซฟใช้ระบบชีวิตสำนักรุ่นใหม่กว่าเกมนี้');if(d.realmSchemaVersion>Realm.VERSION)throw Error('เซฟใช้ระบบยุทธภพรุ่นใหม่กว่าเกมนี้');const g=Object.create(Frontier.prototype);g.E=E;g.world=d.world;g.s=d.s;g.s.version=11;if(![1,2,4,8,16].includes(g.s.speed))g.s.speed=1;g.city=d.city;g.acc=0;g.rng=makeRng(d.s.seed);if(d.rngState!==undefined)g.rng.seed=d.rngState;E.initializeWorldNpcCore?.(g.world);for(const n of Object.values(g.world.npcs)){Human.ensure(n,g.s.seed);ensureStageNeeds(n);const project=n.jianghu?.breakthroughProjectV1200;if(project?.id&&g.world.jianghu?.cultivationTracksV1200?.projectsById)g.world.jianghu.cultivationTracksV1200.projectsById[project.id]=project;if(n.stageLocal)delete n.stageLocal.fatigue;}g.bank=g.world.npcs[g.s.services.bank];g.alchemist=g.world.npcs[g.s.services.alchemist];g.smith=g.world.npcs[g.s.services.smith];if(g.bank?.stageLocal)g.bank.stageLocal.role='storage';if(g.alchemist?.stageLocal)g.alchemist.stageLocal.role='service';if(g.smith?.stageLocal)g.smith.stageLocal.role='service';ensureExpansionRecipes(g.world,g.alchemist,g.smith);g.recipes=RECIPE_IDS.map(id=>g.world.jianghu.systemsV140.recipes.registry[id]).filter(Boolean);E.invalidateWorldCityIndexV1100(g.world);g.ensureEcologyState(false);g.configurePublicRecipes();for(const n of g.heroes){if(n?.jianghu)E.syncNpcCultivationIdentityV1200?.(g.world,n,{trackOrdinal:n.jianghu.trackOrdinal||n.jianghu.stage||1,progress:n.jianghu.cultivationProgress||0});if(!Number.isFinite(n.jianghu.craftMasteryV140?.ALCHEMY))n.jianghu.craftMasteryV140.ALCHEMY=Math.max(15,Math.min(42,Math.round(8+Human.capacity(n,'alchemy').aptitude*.32+Human.capacity(n,'alchemy').cognition*.10+(n.personality?.creativity||50)*.04)));g.teachPublicRecipes(n);}g.life=new Life.SectLife(g);g.realm=new Realm.LivingJianghu(g);g.progression=new Growth.Progression(g);g.academy=new Academy(g);g.discovery=new root.LivingDiscovery.Discovery(g);g.combatSystem=new Combat(g);g.myriad=Myriad?new Myriad.MyriadWorldsSystem(g):null;g.storyEvents=root.JianghuStoryEvents?new root.JianghuStoryEvents.StoryEventSystem(g):null;for(const b of g.s.beasts)if(!b.individual)g.myriad?.attachIndividualToMapBeast?.(b);for(const id of [...g.s.heroIds,...g.s.enemyIds]){const n=g.world.npcs[id];if(n?.stageLocal&&!n.stageLocal.pet)g.combatSystem.ensure(n);}for(const n of Object.values(g.world.npcs))if(n.stageLocal?.combatState&&!n.stageLocal.pet)g.combatSystem.ensure(n);g.life?.syncLegacyPositions?.();return g;}
}
const LABEL={aidCourier:'ช่วยเหลือผู้ส่งสารบาดเจ็บ',takeCourierCargo:'ชิงสัมภาระผู้ส่งสาร',seekAid:'เดินทางมาขอความช่วยเหลือ',leaveValley:'เดินทางพ้นหุบเขา',returnKindness:'หวนกลับมาทดแทนคุณ',seclusion:'เข้าด่านปิดตายทะลวงขอบเขต',eat:'รับประทานอาหารเติมกำลัง',resupplyFood:'จัดหาเสบียงจากหมู่บ้าน',train:'เดินลมปราณบ่มเพาะตบะ',herb:'ออกเก็บสมุนไพรวิญญาณ',mine:'ขุดสกัดแร่ปราณ',wood:'ตัดไม้ไผ่เมฆาคราม',deposit:'นำทรัพยากรส่งเข้าคลังสำนัก',rest:'เดินปราณพักฟื้นกายใจ',heal:'สมานแผลด้วยสมุนไพร',medicine:'กลืนโอสถรักษาและฟื้นปราณ',hunt:'ออกล่าปราบอสูรไพร',scout:'ลาดตระเวนสำรวจสันเขา',assault:'บุกทลายค่ายโจรผาทมิฬ',defend:'ออกศึกคุ้มภัยผู้คน',trade:'คุมคาราวานค้าข้ามด่าน',buy:'จัดหาตัวยาที่ตลาดชายแดน',social:'เยี่ยมเยือนผูกไมตรีชาวบ้าน',craft:'ว่าจ้างช่างหลอมสร้าง',equip:'ปรับแต่งสวมใส่ศาสตรา',breakthrough:'เตรียมการทะลวงคอขวด',flee:'ถอนตัวล่าถอยรักษาชีวิต',learnFromMentor:'ขอรับคำชี้แนะจากอาจารย์',seekMentor:'เดินทางไปคารวะผู้รู้',startResearch:'เปิดโครงการค้นคว้าตำรับ',continueResearch:'ดำเนินการทดลองตำรับ',shareFormula:'ถ่ายทอดเคล็ดตำรับวิชา',approachFormulaRecipient:'เดินทางไปพบผู้รับถ่ายทอดตำรับ'};
Object.assign(LABEL,Realm.LABELS,Growth.LABELS,root.LivingDiscovery.LABELS,Myriad?.LABELS||{});for(const node of RESOURCE_NODE_DEFS)LABEL[(node.kind==='HERB'?'herb:':'mine:')+node.id]=(node.kind==='HERB'?'เก็บ':'ขุด')+node.nameTh;function actionLabel(id){const questLabel=root.JianghuSideQuests?.actionLabel(id)||root.JianghuSectContributions?.actionLabel(id);if(questLabel)return questLabel;if(!id)return 'กำลังใคร่ครวญมรรคา';if(LABEL[id])return LABEL[id];if(id.startsWith('gardenPlant:'))return 'เพาะปลูกสมุนไพรวิญญาณ';if(id.startsWith('gardenWater:'))return 'รดน้ำบำรุงสวนสมุนไพร';if(id.startsWith('gardenHarvest:'))return 'เก็บเกี่ยวสมุนไพรวิญญาณ';if(id.startsWith('loot:'))return 'เก็บกู้วัตถุดิบตกหล่น';if(id.startsWith('bounty:'))return 'ปฏิบัติภารกิจประกาศค่าหัว';return id;}root.Frontier=Frontier;root.FrontierData={B,LOCS,OBST,W,H,DAY,STEP,HERB,ORE,CIN,FANG,LABEL,CROPS,RESOURCE_NODE_DEFS,HABITAT_DEFS,LOW_GRADE_PILL_IDS,actionLabel};if(typeof module==='object')module.exports={Frontier,FrontierData:root.FrontierData};
})(typeof globalThis!=='undefined'?globalThis:this);
