/* Building and cultivator drawing adapted from the user-provided Gemini 4.0 map. Read-only presentation. */
(function(root){'use strict';const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function roundRectPath(ctx, x, y, w, h, r) {
    const rad = Math.min(r, w * 0.5, h * 0.5);
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.lineTo(x + w - rad, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
    ctx.lineTo(x + w, y + h - rad);
    ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
    ctx.lineTo(x + rad, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
    ctx.lineTo(x, y + rad);
    ctx.quadraticCurveTo(x, y, x + rad, y);
    ctx.closePath();
  }

function create(ctx,context){const state={selectedEntity:null};
  function getCultivatorVisualProfile(npc) {
    const path = npc?.jianghu?.path || 'XIAN';
    const subPath = String(npc?.jianghu?.subPath || '').toUpperCase();
    const gender = npc?.gender || 'M';
    const posId = context.role(npc);
    const isMaster = posId === 'SECT_MASTER';
    const isElder = posId.includes('ELDER');
    const isImmortal = !!npc?.jianghu?.isImmortal;

    let robeMain = '#8369b8';
    let robeTrim = '#d8ccf2';
    let sashColor = '#4c3575';

    if (path === 'XIAN') {
      if (subPath.includes('ICE') || subPath.includes('FROST') || subPath.includes('CLOUD') || subPath.includes('WIND')) {
        robeMain = '#4c8899';
        robeTrim = '#bae6fd';
        sashColor = '#1e4e5f';
      } else if (subPath.includes('WOOD') || subPath.includes('ALCHEM') || subPath.includes('ELIXIR')) {
        robeMain = '#3f7d63';
        robeTrim = '#a7f3d0';
        sashColor = '#1b4332';
      } else {
        robeMain = '#8369b8';
        robeTrim = '#e2d9f7';
        sashColor = '#4a3578';
      }
    } else if (path === 'BODY') {
      if (subPath.includes('BLOOD') || subPath.includes('FIRE') || subPath.includes('STAR') || subPath.includes('METEOR')) {
        robeMain = '#9c4343';
        robeTrim = '#fecdd3';
        sashColor = '#571b1b';
      } else if (subPath.includes('WOOD') || subPath.includes('SPRING')) {
        robeMain = '#3b7a57';
        robeTrim = '#bbf7d0';
        sashColor = '#14532d';
      } else {
        robeMain = '#b57b4c';
        robeTrim = '#fde68a';
        sashColor = '#6b3e1d';
      }
    } else if (path === 'GOD') {
      if (subPath.includes('THUNDER') || subPath.includes('WAR')) {
        robeMain = '#b4832c';
        robeTrim = '#fef08a';
        sashColor = '#713f12';
      } else {
        robeMain = '#bd8e3a';
        robeTrim = '#fef9c3';
        sashColor = '#6e4c11';
      }
    } else if (path === 'DEMON') {
      if (subPath.includes('VENOM') || subPath.includes('GU')) {
        robeMain = '#2f5233';
        robeTrim = '#8ce99a';
        sashColor = '#1b3022';
      } else {
        robeMain = '#4a2545';
        robeTrim = '#f3d9fa';
        sashColor = '#2b1128';
      }
    } else if (path === 'HEART_SOUL') {
      robeMain = '#3b5bdb';
      robeTrim = '#dbe4ff';
      sashColor = '#1e3a8a';
    }

    const eqWeapon = String(context.weapon(npc) || npc?.jianghu?.natalArtifactV1220?.nameTh || '').toLowerCase();
    let weaponKind = 'SWORD';
    if (eqWeapon.includes('ทวน') || eqWeapon.includes('หอก') || subPath.includes('SPEAR')) {
      weaponKind = 'SPEAR';
    } else if (eqWeapon.includes('ดาบ') || eqWeapon.includes('บรรทัด') || path === 'BODY') {
      weaponKind = 'SABER';
    } else if (eqWeapon.includes('พัด') || eqWeapon.includes('ยันต์') || subPath.includes('TALISMAN') || subPath.includes('ARRAY') || subPath.includes('CALLIGRAPHY')) {
      weaponKind = 'FAN';
    } else if (eqWeapon.includes('พิณ') || eqWeapon.includes('ขลุ่ย') || path === 'GOD' || path === 'HEART_SOUL') {
      weaponKind = 'FLUTE';
    }

    if(npc.stageLocal?.enemy){robeMain=npc.stageLocal.boss?'#732f3e':'#965746';robeTrim='#d5ae92';sashColor='#4b2729';}
    if(!eqWeapon)weaponKind='NONE';
    return {
      path,
      subPath,
      gender,
      posId,
      isMaster,
      isElder,
      isImmortal,
      robeMain,
      robeTrim,
      sashColor,
      weaponKind
    };
  }

    function draw2DBuildingSprite(b, x, y, zoomScale) {
      const s = clamp(zoomScale, 0.55, 1.55);
      const isSelected = state.selectedEntity?.kind === 'BUILDING' && state.selectedEntity?.id === b.id;
      const isConstructing = b.status === 'CONSTRUCTING';

      ctx.save();
      ctx.translate(x, y);

      if (isSelected) {
        ctx.beginPath();
        ctx.ellipse(0, 4 * s, 28 * s, 16 * s, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(253, 224, 71, 0.22)';
        ctx.fill();
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.ellipse(0, 9 * s, 23 * s, 7 * s, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(20, 38, 32, 0.28)';
      ctx.fill();

      let roofMain = '#2f5e50';
      let roofDark = '#1d3f35';
      let wallCol = '#dfd7c2';
      let pillarCol = '#5c4636';
      let isDoubleRoof = false;
      let isTower = false;

      if (b.typeId === 'SECT_HQ') {
        roofMain = '#2c5e4f';
        roofDark = '#193b31';
        isDoubleRoof = true;
      } else if (b.typeId === 'TRAINING_HALL') {
        roofMain = '#356155';
        roofDark = '#204239';
        isDoubleRoof = true;
      } else if (b.typeId === 'MARKET_STOREHOUSE') {
        roofMain = '#635341';
        roofDark = '#42362a';
      } else if (b.typeId === 'ALCHEMY_WORKSHOP') {
        roofMain = '#7d4934';
        roofDark = '#522c1d';
      } else if (b.typeId === 'EQUIPMENT_FORGE') {
        roofMain = '#693632';
        roofDark = '#451f1c';
      } else if (b.typeId === 'GUARD_TOWER') {
        roofMain = '#37586e';
        roofDark = '#1f3647';
        isTower = true;
      } else if (b.typeId === 'BEAST_SANCTUARY') {
        roofMain = '#336b4a';
        roofDark = '#1d452d';
      } else if (b.typeId === 'ANCESTRAL_SHRINE') {
        roofMain = '#543b6e';
        roofDark = '#332047';
        isDoubleRoof = true;
      }

      if (isConstructing) {
        ctx.globalAlpha = 0.72;
      }

      roundRectPath(ctx, -19 * s, 3 * s, 38 * s, 6 * s, 2 * s);
      ctx.fillStyle = '#c8bfa8';
      ctx.fill();
      ctx.strokeStyle = '#6e6759';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#d8d0bc';
      ctx.fillRect(-5 * s, 4 * s, 10 * s, 5 * s);

      const wallW = isTower ? 18 * s : 28 * s;
      const wallH = isTower ? 18 * s : 12 * s;
      const wallY = 3 * s - wallH;
      ctx.fillStyle = wallCol;
      ctx.fillRect(-wallW * 0.5, wallY, wallW, wallH);
      ctx.strokeStyle = pillarCol;
      ctx.lineWidth = 1.2;
      ctx.strokeRect(-wallW * 0.5, wallY, wallW, wallH);

      ctx.fillStyle = pillarCol;
      ctx.fillRect(-wallW * 0.5 + 2 * s, wallY, 2.2 * s, wallH);
      ctx.fillRect(wallW * 0.5 - 4.2 * s, wallY, 2.2 * s, wallH);

      const doorW = 6.5 * s;
      const doorH = 8.5 * s;
      roundRectPath(ctx, -doorW * 0.5, 3 * s - doorH, doorW, doorH, 1.5 * s);
      ctx.fillStyle = '#5c3c24';
      ctx.fill();
      if (!isTower) {
        ctx.fillStyle = '#735842';
        ctx.fillRect(-wallW * 0.34, wallY + 3 * s, 3.8 * s, 4 * s);
        ctx.fillRect(wallW * 0.34 - 3.8 * s, wallY + 3 * s, 3.8 * s, 4 * s);
      }

      const drawRoofTier = (yBottom, halfW, height) => {
        ctx.beginPath();
        ctx.moveTo(-halfW * 1.15, yBottom);
        ctx.quadraticCurveTo(-halfW * 0.65, yBottom - height * 0.85, -halfW * 0.35, yBottom - height);
        ctx.lineTo(halfW * 0.35, yBottom - height);
        ctx.quadraticCurveTo(halfW * 0.65, yBottom - height * 0.85, halfW * 1.15, yBottom);
        ctx.closePath();
        ctx.fillStyle = roofMain;
        ctx.fill();
        ctx.strokeStyle = roofDark;
        ctx.lineWidth = 1.4;
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(-halfW * 1.12, yBottom - 0.8 * s);
        ctx.lineTo(halfW * 1.12, yBottom - 0.8 * s);
        ctx.strokeStyle = '#e8dec1';
        ctx.lineWidth = 1.5 * s;
        ctx.stroke();
      };

      drawRoofTier(wallY + 1 * s, (wallW * 0.5) + 4 * s, 9 * s);

      if (isDoubleRoof || isTower) {
        const upW = wallW * 0.66;
        const upWallY = wallY - 7 * s;
        ctx.fillStyle = wallCol;
        ctx.fillRect(-upW * 0.5, upWallY - 4 * s, upW, 5 * s);
        drawRoofTier(upWallY - 3 * s, upW * 0.5 + 3.5 * s, 7.5 * s);

        ctx.beginPath();
        ctx.moveTo(0, upWallY - 10.5 * s);
        ctx.lineTo(0, upWallY - 14.5 * s);
        ctx.strokeStyle = '#eab308';
        ctx.lineWidth = 1.8 * s;
        ctx.stroke();
      }

      ctx.restore();
    }

    function draw2DCultivatorSprite(npc, x, y, zoomScale, isSelected) {
      const s = clamp(zoomScale, 0.65, 1.45);
      const prof = getCultivatorVisualProfile(npc);
      const se = npc.stageLocal || {};
      const isCultivating =
        se.mode === 'working' &&
        (se.action === 'train' || se.action === 'seclusion' || se.action === 'meditateWaterfall');

      ctx.save();
      ctx.translate(x, y);

      if (isSelected) {
        ctx.beginPath();
        ctx.ellipse(0, 7 * s, 15 * s, 7 * s, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(253, 224, 71, 0.28)';
        ctx.fill();
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.ellipse(0, 9 * s, 10 * s, 3.8 * s, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(20, 38, 32, 0.30)';
      ctx.fill();

      if (prof.isImmortal) {
        ctx.beginPath();
        ctx.arc(0, -8 * s, 9.5 * s, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.85)';
        ctx.lineWidth = 2 * s;
        ctx.stroke();
      }

      if (isCultivating) {
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(0, 2 * s, 14 * s, 6.5 * s, -0.18, 0.2, Math.PI * 1.75);
        ctx.strokeStyle = 'rgba(248, 250, 252, 0.90)';
        ctx.lineWidth = 1.8 * s;
        ctx.stroke();

        ctx.beginPath();
        ctx.ellipse(0, 5 * s, 12 * s, 5 * s, 0.15, Math.PI * 0.4, Math.PI * 1.9);
        ctx.strokeStyle = prof.isMaster ? 'rgba(253, 224, 71, 0.85)' : 'rgba(226, 232, 240, 0.78)';
        ctx.lineWidth = 1.4 * s;
        ctx.stroke();
        ctx.restore();
      }

      ctx.beginPath();
      ctx.moveTo(-4.2 * s, -3.5 * s);
      ctx.lineTo(4.2 * s, -3.5 * s);
      ctx.quadraticCurveTo(8.5 * s, 3.5 * s, 9.5 * s, 8.2 * s);
      ctx.quadraticCurveTo(0, 10.5 * s, -9.5 * s, 8.2 * s);
      ctx.quadraticCurveTo(-8.5 * s, 3.5 * s, -4.2 * s, -3.5 * s);
      ctx.closePath();
      ctx.fillStyle = prof.robeMain;
      ctx.fill();
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.45)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-3.2 * s, -3.2 * s);
      ctx.lineTo(0, 2.2 * s);
      ctx.lineTo(3.2 * s, -3.2 * s);
      ctx.strokeStyle = prof.robeTrim;
      ctx.lineWidth = 1.4 * s;
      ctx.stroke();

      ctx.fillStyle = prof.sashColor;
      ctx.fillRect(-5.8 * s, 2.0 * s, 11.6 * s, 1.8 * s);

      ctx.beginPath();
      ctx.arc(0, -7.5 * s, 4.6 * s, 0, Math.PI * 2);
      ctx.fillStyle = (npc.core?.human?.form?.skinTone || '#eed4b7');
      ctx.fill();

      ctx.beginPath();
      ctx.arc(0, -8.3 * s, 4.7 * s, Math.PI * 0.95, Math.PI * 2.05);
      ctx.fillStyle = (npc.core?.human?.form?.hairTone || '#1f2933');
      ctx.fill();

      if (prof.gender === 'F') {
        ctx.beginPath();
        ctx.arc(-3.2 * s, -12.2 * s, 2.1 * s, 0, Math.PI * 2);
        ctx.arc(3.2 * s, -12.2 * s, 2.1 * s, 0, Math.PI * 2);
        ctx.fillStyle = (npc.core?.human?.form?.hairTone || '#1f2933');
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(-4.8 * s, -12.2 * s);
        ctx.lineTo(4.8 * s, -12.2 * s);
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 1.4 * s;
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(0, -12.8 * s, 2.2 * s, 0, Math.PI * 2);
        ctx.fillStyle = (npc.core?.human?.form?.hairTone || '#1f2933');
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(-3.5 * s, -12.8 * s);
        ctx.lineTo(3.5 * s, -12.8 * s);
        ctx.strokeStyle = '#a7f3d0';
        ctx.lineWidth = 1.3 * s;
        ctx.stroke();
      }

      if (prof.isMaster) {
        ctx.beginPath();
        ctx.moveTo(-3.8 * s, -12.5 * s);
        ctx.lineTo(-2.5 * s, -16.5 * s);
        ctx.lineTo(0, -14.5 * s);
        ctx.lineTo(2.5 * s, -16.5 * s);
        ctx.lineTo(3.8 * s, -12.5 * s);
        ctx.closePath();
        ctx.fillStyle = '#facc15';
        ctx.fill();
        ctx.strokeStyle = '#854d0e';
        ctx.lineWidth = 1;
        ctx.stroke();
      } else if (prof.isElder) {
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(-3.2 * s, -14.8 * s, 6.4 * s, 2.5 * s);
      }

      ctx.save();
      if (prof.weaponKind === 'SWORD') {
        ctx.beginPath();
        ctx.moveTo(4.5 * s, 3.5 * s);
        ctx.lineTo(11.8 * s, -8.5 * s);
        ctx.strokeStyle = '#f8fafc';
        ctx.lineWidth = 2.0 * s;
        ctx.lineCap = 'round';
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(3.8 * s, 1.2 * s);
        ctx.lineTo(7.4 * s, 3.2 * s);
        ctx.strokeStyle = '#eab308';
        ctx.lineWidth = 1.6 * s;
        ctx.stroke();
      } else if (prof.weaponKind === 'SABER') {
        ctx.beginPath();
        ctx.moveTo(4.5 * s, 3.5 * s);
        ctx.quadraticCurveTo(10.5 * s, -2.0 * s, 11.5 * s, -8.2 * s);
        ctx.strokeStyle = '#fef3c7';
        ctx.lineWidth = 2.6 * s;
        ctx.lineCap = 'round';
        ctx.stroke();
      } else if (prof.weaponKind === 'SPEAR') {
        ctx.beginPath();
        ctx.moveTo(4.0 * s, 6.5 * s);
        ctx.lineTo(12.5 * s, -10.5 * s);
        ctx.strokeStyle = '#d6d3d1';
        ctx.lineWidth = 1.8 * s;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(10.8 * s, -7.2 * s, 2.0 * s, 0, Math.PI * 2);
        ctx.fillStyle = '#ef4444';
        ctx.fill();
      } else if (prof.weaponKind === 'FAN') {
        ctx.beginPath();
        ctx.arc(6.5 * s, 0, 4.8 * s, -Math.PI * 0.75, Math.PI * 0.05);
        ctx.lineTo(6.5 * s, 0);
        ctx.closePath();
        ctx.fillStyle = '#f8fafc';
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1;
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(8.5 * s, -3.5 * s, 2.8 * s, 0, Math.PI * 2);
        ctx.fillStyle = '#fef08a';
        ctx.fill();
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.2 * s;
        ctx.stroke();
      }
      ctx.restore();

      if (npc.jianghu?.contractBeast && zoomScale >= 0.75) {
        ctx.beginPath();
        ctx.arc(-9.5 * s, 5.5 * s, 3.5 * s, 0, Math.PI * 2);
        ctx.fillStyle = '#1e3a32';
        ctx.fill();
        ctx.strokeStyle = '#a7f3d0';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.font = `${Math.round(7.5 * s)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(npc.jianghu.contractBeast.icon || '🐾', -9.5 * s, 5.5 * s);
      }

      ctx.restore();
    }

return {building:draw2DBuildingSprite,cultivator:draw2DCultivatorSprite,state};}
const api={create};root.RealmSprites=api;if(typeof module==='object')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
