/* Read-only projections of plans, actual recipes, books, rarity tiers, and learned experience (v1.16). */
(function(root){'use strict';const P=root.LivingProgression||(typeof require==='function'?require('./progression'):null),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const material=(g,id)=>g.world.jianghu.systemsV140.materials?.[id]?.nameTh||g.bank.jianghu.ledgerV140.materialStacks.find(x=>x.matId===id)?.nameTh||({'MAT_HERB_DEW_GRASS_1':'หญ้าน้ำค้างปราณ','MAT_ORE_BLACK_IRON_1':'เหล็กดำ','MAT_ORE_CINNABAR_1':'ชาดปราณ','MAT_BP_WOLF_FANG_1':'เขี้ยวหมาป่า','MAT_HERB_MIST_ORCHID_2':'กล้วยไม้หมอก','MAT_HERB_BLOOD_GINSENG_3':'โสมโลหิต'})[id]||id;
function rarityBadge(tier){
 const g=root.JianghuExpansionV112?.rarityGradesV112?.[tier||1]||{badgeTh:'สามัญ',color:'#adb5bd'};
 return `<span class="tag" style="border-color:${g.color};color:${g.color}">ระดับ ${tier||1} · ${esc(g.badgeTh)}</span>`;
}
function profile(g,n){const q=n.stageLocal.growth;if(!q)return '';return `<div class="realm-profile"><b>มรรคาและเป้าหมายที่กำลังมุ่งมั่น</b><p>${esc(q.plan?.label||'กำลังประเมินทิศทางชีวิต')}</p><small>ถนัดศาสตร์${q.career==='alchemy'?'โอสถทิพย์':'หลอมศาสตรา'} · รู้แจ้งตำรับ ${q.knownRecipes.length} แขนง · คัมภีร์ในตัว ${n.jianghu.ledgerV140.scrolls.length} / 24 ม้วน</small><br><button data-hero-tab="growth">ดูแผนชีวิตและคัมภีร์ยุทธ์</button></div>`;}
function heritage(g,n){
 const d=g.discovery,h=d.state(n),labels={HEARD:'ข่าวยังไม่ยืนยัน',TRACED:'พบร่องรอย รอตามต่อ',FOUND:'พบมรดกแล้ว',FALSE:'ข่าวพาไปสู่ทางตัน',LOST:'ยุติเพราะอันตราย',EXPIRED:'ข่าวเก่าเกินติดตาม'};
 const rumors=d.data.rumors.filter(r=>r.npcId===n.id),books=n.jianghu.ledgerV140.scrolls.filter(b=>b.artId);
 return `<div class="banner"><b>มรดกนอกสำนักเป็นทรัพย์ส่วนตัว</b><p>เจ้าของเลือกเก็บ ศึกษา มอบให้สหาย หรือถ่ายทอดเข้าหอสืบทอดตามนิสัยและความสัมพันธ์ ข่าวลืออาจพาไปพบหลักฐาน ทางตัน หรืออันตราย การได้มรดกยังไม่ทำให้เรียนวิชาสำเร็จทันที</p></div><h3>ข่าวที่ผู้นี้ได้ยิน</h3>${rumors.map(r=>`<article class="card"><b>${esc(r.name)}</b><p>${esc(labels[r.status])}</p><small>ได้จาก ${esc(r.source)} · วันที่ ${Math.floor(r.createdAt/20)+1} · ตามรอย ${r.attempts} ครั้ง</small></article>`).join('')||'<p class="meta">ยังไม่มีข่าวลือ อาจได้ยินจากผู้เดินทาง ชาวบ้าน การสำรวจ หรือเส้นทางค้า</p>'}<h3>มรดกที่ครอบครอง</h3>${books.map(b=>{const a=g.progression.artMap.get(b.artId),record=d.data.arts[b.artId],route=a&&d.routeKnown(n,a);return `<article class="card"><b>${esc(b.nameTh||a?.nameTh)}</b><p>${esc(b.mediumTh||'คัมภีร์')} · ${b.rights==='LOAN'?'ยืมจากผู้อื่น':'ของส่วนตัว'}</p><small>ที่มา: ${esc(b.originLabelTh||'ไม่ระบุ')}<br>ผู้ค้นพบ: ${esc(g.world.npcs[b.discoveredByNpcId]?.name||g.world.npcs[record?.firstDiscovererId]?.name||'ไม่ปรากฏ')}<br>ผู้ฝึกสำเร็จคนแรก: ${esc(g.world.npcs[record?.firstPractitionerId]?.name||'ยังไม่มี')}<br>${route?'เข้าใจรากวิถีแล้ว':'ถอดความมรดก '+Math.round(h.deciphered[b.id]||0)+'%'}<br>${d.mayShare(n,b)?'พร้อมพิจารณาถ่ายทอด':'ยังต้องการเก็บมรดกไว้กับตน'}</small>${b.provenance?.length?`<p class="meta">${b.provenance.map(e=>e.kind==='GIFT'?'มอบจาก '+esc(g.world.npcs[e.from]?.name)+' ให้ '+esc(g.world.npcs[e.to]?.name):'ค้นพบวันที่ '+(Math.floor(e.at/20)+1)).join('<br>')}</p>`:''}</article>`;}).join('')||'<p class="meta">ยังไม่มีมรดกส่วนตัว</p>'}<h3>วิถีที่เปิดเผยในหุบเขาแล้ว</h3>${Object.values(d.data.routes).map(r=>`<div class="entry"><b>${esc(root.World2026Engine.CULTIVATION_PATHS[r.path]?.subPaths[r.subPath]?.nameTh||r.subPath)}</b><p>ผู้บุกเบิก ${esc(g.world.npcs[r.firstPractitionerId]?.name)} · วันที่ ${Math.floor(r.at/20)+1}</p></div>`).join('')||'<p class="meta">ยังไม่มีผู้บุกเบิกวิถีใหม่</p>'}`;
}
function render(g,n,section='life',global=false){if(!n?.stageLocal.growth)return '<p>เลือกสมาชิกสำนักเพื่อดูเส้นทางชีวิต</p>';const q=n.stageLocal.growth,j=n.jianghu,p=g.progression;let out=`<div class="realm-intro"><small>แพตช์ 1.16 · มรรคาชีวิตและคัมภีร์วาสนา</small><h3>${esc(n.name)}</h3><p>ความปรารถนา ความถนัด และวาสนาที่พานพบ กำหนดว่าศิษย์แต่ละคนจะเลือกขบคิดคัมภีร์ เทียบเคล็ดอนุมานตำรา หลอมโอสถ หรือออกแสวงโชค</p></div>`;
 if(global)out+=`<div class="realm-fund"><p>นโยบายปัจจุบัน: ${g.s.policy==='craft'?'ส่งเสริมการศึกษาคัมภีร์และงานช่าง':'ดำเนินตามครรลองแห่งสำนัก'}</p><button data-policy="craft">สนับสนุนการเรียนและอาชีพ</button><small>เพิ่มแรงจูงใจในการศึกษาคัมภีร์ คัดลอกตำรา เทียบเคล็ดคัมภีร์ และหลอมสร้างด้วยตนเอง</small></div><label class="realm-select">เลือกผู้ฝึกตน<select data-growth-person aria-label="เลือกเส้นทางของผู้ฝึกตน">${g.heroes.map(x=>`<option value="${x.id}" ${x.id===n.id?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label>`;
 out+=`<div class="inline-actions">${[['life','แผนชีวิต'],['recipes','ตำรับและผลงาน'],['arts','คัมภีร์และการฝึก'],['heritage','ข่าวลือและมรดก'],['academy','สำนักศึกษา']].map(([id,label])=>`<button data-growth-section="${id}" class="${id===section?'gold':''}">${label}</button>`).join('')}</div>`;
 if(section==='heritage')out+=heritage(g,n);
 if(section==='life')out+=`<div class="card"><h3>${esc(q.plan?.label||'กำลังประเมินเป้าหมาย')}</h3><p>${q.plan?.steps?.map((s,i)=>`${i+1}. ${esc(s)}`).join('<br>')||'เมื่อพร้อมจะพิจารณางานที่สนใจ'}</p><small>ปณิธาน: ${esc(n.stageLocal.aspiration?.text)}<br>ความชอบหลอมโอสถ ${Math.round(root.HumanCore.liking(n,'alchemy'))} · ความชอบหลอมศาสตรา ${Math.round(root.HumanCore.liking(n,'forging'))} · แต้มสะสมวาสนาคัมภีร์ ${Math.round(j.fortuneKarmaV113||0)}</small></div><h3>สิ่งที่ตนกำลังเสาะหา</h3>${q.needs.map(x=>`<article class="card"><b>${esc(x.text)}</b>${x.missing?`<p>${x.missing.map(i=>`${esc(material(g,i.matId))} ขาด ${i.missing} · คลังสำนักมี ${g.count(g.bank,i.matId)}`).join('<br>')}</p>`:''}</article>`).join('')||'<p>จิตใจสงบนิ่ง กำลังสั่งสมตบะและหลักฐานมรรคา</p>'}<p class="meta">เมื่อขาดแคลนสิ่งใด ศิษย์จะตัดสินใจเบิกจากคลัง ออกเก็บสมุนไพร ล่าอสูรตามวัตถุดิบ เพ่งศิลาจารึก เข้าฌานใต้น้ำตก ชงชาวิญญาณ หรือเทียบเคล็ดคัมภีร์อนุมานวิชาใหม่ด้วยตนเอง</p>`;
 if(section==='recipes')out+=`<div class="realm-fund"><b>กองทุนศึกษาตำรับ ${g.s.growth.researchFund} ศิลา</b><p>ศึกษาครั้งละ 6 ศิลา ใช้เวลางานและความสามารถจริง เงินส่วนตนจ่ายก่อน กองทุนช่วยเมื่อยังขาดทุน</p><div class="inline-actions"><button data-growth-action="fund">สำรองทุนศึกษา 60</button><button data-growth-action="refund" ${g.s.growth.researchFund?'':'disabled'}>คืนเงินที่ยังไม่ใช้</button></div></div><p class="meta">ตำรับส่วนตัว 12 แบบ แบ่งโอสถ 6 และศาสตรา/เครื่องราง 6 แยกจากการว่าจ้างช่างในหน้าคลัง ศิษย์ต้องเรียนตำรับ ฝีมือถึง มีเครื่องปรุง และเดินมาผลิต</p>${p.allRecipes().map(r=>{const activity=r.workshop==='alchemy'?'alchemy':'forging',cap=root.HumanCore.capacity(n,activity).total;return `<article class="card"><div class="row"><b>${esc(r.name)}</b><span class="tag">${q.knownRecipes.includes(r.id)?'รู้ตำรับ':'ยังไม่เรียน'}</span></div><p class="meta">ระดับ ${r.tier} · ขอบเขตเทียบเคียงปัจจุบัน ${p.tier(n)}<br>ความพร้อม ${Math.round(cap)} / ต้องการ ${r.min} · งานพื้นฐาน ${r.duration} วินาที<br>${r.inputs.map(i=>`${esc(material(g,i.matId))} ${g.count(n,i.matId)} / ${i.count}`).join('<br>')}</p><small>${r.effect.slot?`ช่อง ${esc(({WEAPON:'อาวุธ',ARMOR:'เกราะ',TALISMAN_VESSEL:'เครื่องราง'})[r.effect.slot])}`:Object.entries(r.effect).map(([k,v])=>esc(({heal:'ฟื้นสุขภาพ',pain:'ประคองบาดแผล',progress:'ตบะ',toxicity:'พิษโอสถ',cleanse:'ชำระพิษ',grief:'บรรเทาโศก'})[k]||k)+' '+v).join(' · ')}</small></article>`;}).join('')}`;
 if(section==='academy'){const a=g.academy,active=g.s.growth.researchProjects.filter(x=>x.npcId===n.id&&x.status==='ACTIVE'),knownFormulas=g.s.growth.formulaRegistry.filter(f=>f.knownBy.includes(n.id)),candidates=a?.artCandidates(n)||[],loans=g.s.growth.bookLoans.filter(x=>['ACTIVE','PENDING_RETURN'].includes(x.status)&&(x.ownerNpcId===n.id||x.borrowerNpcId===n.id)),archived=(q.archivedResearchNotes||[]);out+=`<div class="banner">มรรคาและความรู้ต้องแลกมาด้วยความเพียร: คัมภีร์ได้จากจุดวาสนาและแดนลับที่มีระดับความหายาก 7 ขั้น เมื่ออ่านเข้าใจและฝึกจนชำนาญแล้ว สามารถคัดลอกเข้าหอสืบทอด หรือนำคัมภีร์ 2 ม้วนมาเทียบเคล็ดอนุมานเป็นวิชาระดับสูงขึ้นได้โดยต้นฉบับไม่สูญหาย</div><h3>อาจารย์และการถ่ายทอด</h3>${candidates.length?candidates.map(c=>`<article class="card"><div class="row"><b>${esc(c.teacher.name)}</b><span class="tag">พร้อมชี้แนะ</span></div><p>${esc(c.art.nameTh)} · ชำนาญ ${Math.round(c.teacher.jianghu.knowledgeV190[c.artId].mastery)} · ระยะ ${Math.round(c.distance)} ม.</p><small>ผู้เรียนยังไม่เข้าใจวิชานี้เต็มที่ · ความสัมพันธ์และนิสัยของผู้สอนมีผลต่อการยินยอม</small></article>`).join(''):'<p class="meta">ขณะนี้ไม่มีผู้สอนที่พร้อมและมีหนังสือสำหรับวิชาที่สมาชิกคนนี้ยังไม่เข้าใจ</p>'}<h3>คัมภีร์ในสัมภาระและการยืม (${j.ledgerV140.scrolls.length} / 24 ม้วน)</h3>${j.ledgerV140.scrolls.filter(x=>x.artId||x.formulaId||x.kind==='RESEARCH_NOTES').map(book=>{const art=p.artMap.get(book.artId);return `<article class="card"><div class="row"><b>${esc(book.nameTh||art?.nameTh||p.recipe(book.formulaId)?.name||book.artId||book.id)}</b>${rarityBadge(book.tier||art?.tier||1)}</div><p class="meta">${book.rights==='LOAN'?'คัมภีร์ยืมชั่วคราว':book.ownerNpcId===n.id?'ผู้ครอบครองฉบับจริง':'มีฉบับอยู่ในสัมภาระ'}${book.kind==='FORMULA'?' · ต้นตำรับ รุ่น '+(book.formulaRevision||1):book.kind==='RESEARCH_NOTES'?' · บันทึกการทดลอง':''} · ที่มา: ${esc(book.originLabelTh||art?.originTag||'มรดกยุทธภพ')}${art?.loreTh?`<br><i>${esc(art.loreTh)}</i>`:''}${book.loan?`<br>ยืมจาก ${esc(g.world.npcs[book.loan.ownerNpcId]?.name||book.loan.ownerNpcId)}`:''}</p></article>`;}).join('')||'<p class="meta">ยังไม่มีม้วนคัมภีร์อยู่ในสัมภาระ · ออกสำรวจจุดวาสนา เพ่งศิลาจารึก หรือบุกเบิกแดนลับเพื่อค้นหา</p>'}${loans.map(l=>`<p class="meta">${l.borrowerNpcId===n.id?'กำลังยืม':'ให้ยืม'} ${esc(g.world.npcs[l.borrowerNpcId===n.id?l.ownerNpcId:l.borrowerNpcId]?.name||'สมาชิก')} · ${esc(l.bookId)} · ${l.status==='PENDING_RETURN'?'รอที่ว่างคลังเจ้าของเพื่อส่งคืน':'คืนเมื่อจบบทเรียนหรือหมดเวลา'}</p>`).join('')}${archived.length?`<p class="meta">แฟ้มบันทึกการทดลองที่จัดเก็บไว้ (${archived.length} ฉบับ · ช่วยต่อยอดความเข้าใจเมื่อเริ่มวิจัยซ้ำโดยไม่เปลืองพื้นที่สัมภาระ)</p>`:''}<h3>โครงการค้นคว้าตำรับ</h3>${active.map(x=>{const d=a.designs.find(z=>z.id===x.formulaId);return `<article class="card"><div class="row"><b>${esc(d?.name||x.formulaId)}</b><span class="tag">กำลังทดลอง</span></div><div class="row meta"><span>ความคืบหน้า ${x.progress}%</span><span>ทดลอง ${x.trials}/5</span></div><div class="meter"><i style="width:${x.progress}%"></i></div><p class="meta">สำเร็จ ${x.successes} · ล้มเหลว ${x.failures} · ข้อสังเกต ${x.insight}</p></article>`;}).join('')||'<p class="meta">ยังไม่มีโครงการที่กำลังทดลอง</p>'}<h3>ทะเบียนต้นตำรับ</h3>${knownFormulas.map(f=>`<article class="card"><div class="row"><b>${esc(f.recipe.name)}</b><span class="tag">${f.ownerNpcId===n.id?'ผู้คิดค้น':'ได้รับถ่ายทอด'}</span></div><p class="meta">เจ้าของต้นตำรับ ${esc(g.world.npcs[f.ownerNpcId]?.name||f.ownerNpcId)} · รุ่น ${f.revision}<br>${f.recipe.inputs.map(i=>`${esc(material(g,i.matId))} × ${i.count}`).join(' · ')}</p></article>`).join('')||'<p class="meta">ยังไม่มีสูตรที่ค้นพบหรือได้รับถ่ายทอด</p>'}<h3>แบบวิจัยที่มีในสำนัก (${a.designs.length} ตำรับ)</h3>${a.designs.map(d=>{const f=a.formula(d.id),proj=g.s.growth.researchProjects.filter(x=>x.formulaId===d.id).at(-1),parent=p.recipe(d.parentRecipeId);return `<article class="card"><div class="row"><b>${esc(d.name)}</b><span class="tag">${f?(f.knownBy.includes(n.id)?'รู้ตำรับ':'ยังไม่ได้รับถ่ายทอด'):proj?.status==='ACTIVE'?'มีผู้ทดลอง':proj?.status==='FAILED'?'เคยล้มเหลว':'ยังไม่ค้นพบ'}</span></div><p class="meta">ต้องรู้ตำรับตั้งต้น: ${esc(parent?.name||d.parentRecipeId)} · สาขา ${d.workshop==='alchemy'?'โอสถ':'ศาสตรา'} · ความพร้อมขั้นต่ำ ${d.min}<br>วัตถุดิบต่อการทดลอง: ${d.trialInputs.map(i=>`${esc(material(g,i.matId))} × ${i.count}`).join(' · ')}</p></article>`;}).join('')}`;}
 if(section==='arts'){out+=CombatView117.render(g,n);}
 const logs=g.s.growth.receipts.filter(r=>r.npcId===n.id).slice(0,10);out+=`<h3>บันทึกการบำเพ็ญและลงมือทำล่าสุด</h3>${logs.map(r=>`<div class="entry"><small>วันที่ ${Math.floor(r.t/20)+1}</small><p>${esc(({recipe:'ศึกษาตำรับ',material:'เบิกเครื่องปรุง',gather:'เก็บตัวยาตามเป้าหมาย',production:r.success?'หลอมสร้างสำเร็จ':'หลอมสร้างล้มเหลว',readScripture:'ขบคิดคัมภีร์ส่วนตัว',readLibraryScripture:'ศึกษาคัมภีร์หอสืบทอด',practiceScripture:'เคี่ยวกรำวิชายุทธ์',scriptureDonated:'สืบทอดคัมภีร์เข้าหอ',synthesizeScriptures:'เทียบเคล็ดคัมภีร์อนุมานวิชาใหม่',scriptureDeductionFailed:'เทียบเคล็ดคัมภีร์ยังไม่สำเร็จ',comprehendTablet:'เพ่งจิตศิลาจารึกโบราณ',meditateWaterfall:'เข้าฌานใต้น้ำตกหยก',brewTeaDao:'ชงชาวิญญาณชำระจิต',patrolSect:'ลาดตระเวนคุ้มภัยสำนัก',pill:'กลืนโอสถเดินปราณ',equip:'สวมใส่ศาสตรา',fortune:'ค้นพบโชควาสนา',mentorLesson:'รับคำชี้แนะจากอาจารย์',researchStart:'เริ่มค้นคว้าตำรับ',researchTrial:r.success?'ทดลองได้ผล':'ทดลองพบข้อจำกัด',researchFailed:'ค้นคว้าไม่สำเร็จ',formulaDiscovered:'คิดค้นตำรับใหม่',formulaShared:'ถ่ายทอดตำรับ',researchMaterial:'ใช้วัตถุดิบทดลอง'})[r.kind]||r.kind)} · ${esc(p.recipe(r.recipeId)?.name||p.artMap.get(r.artId)?.nameTh||r.name||r.matId&&material(g,r.matId)||'')} ${r.amount?'×'+r.amount:''}</p></div>`).join('')||'<p class="meta">ยังไม่มีบันทึกการลงมือในเส้นทางนี้</p>'}`;return out;
}
root.GrowthView={profile,render};if(typeof module==='object')module.exports={profile,render};
})(typeof globalThis!=='undefined'?globalThis:this);

// Unified Pill Effect Bridge (v1.16): normalizes all pill effect keys across L14_*, REC1100_*, REC1110_*, REC1140_*, and REC140_*
// so every pill applies its exact effects once without double-application or ignored properties.
(function(root){
 const E=root.World2026Engine,H=root.HumanCore;
 if(!E||E.__jianghuV116UnifiedPillBridge)return;
 const previous=E.consumePillFromLedgerV150;
 E.consumePillFromLedgerV150=function(w,npcOrId,pillId,opts={}){
  const n=typeof npcOrId==='string'?w?.npcs?.[npcOrId]:npcOrId;
  const cs=n?.stageLocal?.combatState;
  const stack=n?.jianghu?.ledgerV140?.pillStacks?.find(p=>(p.id===pillId||p.nameTh===pillId)&&p.count>0);
  if(!stack||!n?.alive)return previous.call(E,w,npcOrId,pillId,opts);
  const norm=root.LivingProgression?.normalizePillEffect?root.LivingProgression.normalizePillEffect(stack,w):(stack.effect||stack.livingEffect||{});
  if(cs){n.jianghu.currentQiV190=cs.qi;n.jianghu.maxQiV190=cs.maxQi;}
  const beforeQi=Number(n.jianghu?.currentQiV190||0);
  const beforeHealth=Number(n.health||100);
  const beforeInjury=Number(n.jianghu?.internalInjury||0);
  const beforePain=Number(n.core?.human?.state?.pain||0);
  const beforeGrief=Number(n.core?.human?.state?.grief||0);
  const beforeHeartDemon=Number(n.jianghu?.heartDemon||0);
  const beforePoison=Number(n.jianghu?.poisonAccumulated||0);
  const beforeToxicity=Number(n.jianghu?.pillToxicity||0);
  const beforeProgress=Number(n.jianghu?.cultivationProgress||0);
  const beforeFoundation=Number(n.jianghu?.foundationStability||58);
  const beforeDao=Number(n.jianghu?.daoComprehension||52);
  const beforeLifespan=Number(n.jianghu?.lifespanMax||100);

  // Temporarily map stack.effect to standard V150 keys so previous() applies them cleanly once
  const origEffect=stack.effect;
  stack.effect={
   ...(origEffect||{}),
   healHealth:norm.healHealth,
   healInjury:norm.healInjury,
   cultivationProgress:norm.cultivationProgress,
   clearHeartDemon:norm.heartDemonRelief,
   clearPoison:norm.clearPoison,
   purifyPillToxicity:norm.toxicityRelief,
   foundationBonus:norm.foundationBonus,
   daoComprehensionBonus:norm.daoComprehensionBonus,
   lifespanBonus:norm.lifespanBonus,
   openMeridianBonus:norm.openMeridianBonus,
   toxicity:norm.toxicity
  };
  let result;
  try{
   result=previous.call(E,w,npcOrId,pillId,opts);
  }finally{
   stack.effect=origEffect;
  }
  if(!result?.ok||!n?.jianghu)return result;
  const j=n.jianghu;
  // Apply unified effects that V150 does not natively handle or scale with HumanCore recovery
  if(norm.restoreQi>0){
   const maxQi=Number(j.maxQiV190)||100;
   j.currentQiV190=Math.min(maxQi,beforeQi+norm.restoreQi);
   result.restoredQi=j.currentQiV190-beforeQi;
   result.combatQiApplied=true;
  }
  if(norm.healInjury>0&&n.core?.human?.state){
   H?.recover?.(n,norm.healInjury);
   n.core.human.state.pain=Math.max(0,beforePain-norm.healInjury);
  }
  if(norm.griefRelief>0&&n.core?.human?.state){
   n.core.human.state.grief=Math.max(0,beforeGrief-norm.griefRelief);
   if(j.preparationV1100)j.preparationV1100.clarity=Math.min(100,(j.preparationV1100.clarity||65)+norm.griefRelief);
  }
  if(norm.foundationBonus>0&&j.preparationV1100){
   j.preparationV1100.foundation=Math.min(100,(j.preparationV1100.foundation||beforeFoundation)+norm.foundationBonus);
  }
  if(norm.tribulationResist>0){
   j.preparationV1100=j.preparationV1100||{foundation:j.foundationStability||58,clarity:65,tolerance:{}};
   j.preparationV1100.tribulationShield=norm.tribulationResist;
   j.preparationV1100.tribulationShieldUntil=(w?.tick||0)+15;
  }
  // If both toxicityRelief and toxicity exist, ensure net toxicity delta is exact
  const netTox=Math.max(0,beforeToxicity-norm.toxicityRelief+norm.toxicity);
  j.pillToxicity=Math.min(100,netTox);
  E.syncNpcCultivationIdentityV1200?.(w,n,{progress:j.cultivationProgress});
  if(cs)cs.qi=Math.min(cs.maxQi,j.currentQiV190);
  result.appliedEffects={
   healHealth:Math.max(0,n.health-beforeHealth),
   healInjury:Math.max(0,beforeInjury-j.internalInjury),
   restoreQi:Math.max(0,(j.currentQiV190||0)-beforeQi),
   cultivationProgress:Math.max(0,j.cultivationProgress-beforeProgress),
   heartDemonRelief:Math.max(0,beforeHeartDemon-j.heartDemon),
   griefRelief:Math.max(0,beforeGrief-(n.core?.human?.state?.grief||0)),
   clearPoison:Math.max(0,beforePoison-j.poisonAccumulated),
   toxicityRelief:norm.toxicityRelief,
   foundationBonus:Math.max(0,(j.foundationStability||0)-beforeFoundation),
   daoComprehensionBonus:Math.max(0,(j.daoComprehension||0)-beforeDao),
   lifespanBonus:Math.max(0,(j.lifespanMax||0)-beforeLifespan),
   tribulationResist:norm.tribulationResist,
   toxicity:norm.toxicity
  };
  return result;
 };
 E.__jianghuV116UnifiedPillBridge=true;
 E.__jianghuV115QiPillBridge=true;
})(typeof globalThis!=='undefined'?globalThis:this);
