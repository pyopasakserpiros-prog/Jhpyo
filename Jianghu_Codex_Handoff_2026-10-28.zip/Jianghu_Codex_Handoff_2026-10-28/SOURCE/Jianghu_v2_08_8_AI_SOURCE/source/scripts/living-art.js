/* Living Ink 1.9 + v1.12 Major Expansion. Presentation only: never writes to a game, NPC, ledger or RNG.
   Supports all 5 major cultivation paths (XIAN, BODY, GOD, DEMON, HEART_SOUL) and new contextual NPC actions. */
(function(root){'use strict';
const TAU=Math.PI*2,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function hash(s){let h=2166136261;for(const c of String(s)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function privateRng(seed){let s=seed>>>0;return()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)/4294967296;};}
const DEFAULTS={quality:'rich',motion:true,ambience:true,labels:'smart',uiTheme:'sonnet'};
function preferences(){try{return {...DEFAULTS,...JSON.parse(localStorage.getItem('jianghu-living-ink-19')||'{}')};}catch{return {...DEFAULTS};}}
const PALETTES=[['#537c79','#d2dfc8','#294f53'],['#92775a','#e9d7b0','#5f453b'],['#758578','#e0e3c5','#3e6258'],['#867393','#e4d1df','#57415f'],['#a15e54','#f4d3a7','#643e3d'],['#557f96','#d9e5da','#334e6d'],['#ba9560','#fff0bc','#6e553e'],['#747b9f','#e4ddea','#414d6d'],['#4a2545','#f3d9fa','#2b1128'],['#364fc7','#dbe4ff','#1e3a8a']];
function visualProfile(n){const h=hash(n.id),form=n.core?.human?.form||{},path=n.jianghu?.path||'XIAN';let index=h%8;if(path==='BODY')index=[1,4,6][h%3];else if(path==='GOD')index=[0,2,3][h%3];else if(path==='DEMON')index=[8,4,3][h%3];else if(path==='HEART_SOUL')index=[9,5,7][h%3];return {hash:h,colors:PALETTES[index],height:clamp((form.heightCm||170)/170,.85,1.15),width:clamp(Math.sqrt((form.massKg||65)/65),.8,1.24),skin:form.skinTone||'#d7b48b',hair:form.hairTone||'#263134',trim:h%3,gender:n.gender};}
function ellipse(c,x,y,rx,ry,color,angle=0){c.fillStyle=color;c.beginPath();c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),angle,0,TAU);c.fill();}
function line(c,points,color,width=1){c.strokeStyle=color;c.lineWidth=width;c.beginPath();points.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.stroke();}
function glow(c,x,y,r,color){const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'#0000');c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);}
function rgba(hex,a){return hex+Math.round(clamp(a,0,1)*255).toString(16).padStart(2,'0');}
class LivingInk{
 constructor(ctx,data){this.ctx=ctx;this.d=data;this.settings=preferences();this.motionQuery=typeof matchMedia==='function'?matchMedia('(prefers-reduced-motion: reduce)'):null;this.images={};this.props=[];this.pick=new Map();this.rasters=new Map();this.poses=new Map();this.renderScale=1;this.stats={frames:0,visibleSprites:0,terrainPixels:0};this.ready=Promise.all(Object.entries(root.LivingArtAssets.images).map(([key,src])=>new Promise(resolve=>{const im=new Image();im.onload=()=>{this.images[key]=im;resolve(true);};im.onerror=()=>resolve(false);im.src=src;}))).then(loaded=>{if(loaded.some(ok=>!ok))throw Error('โหลดภาพหุบเขาไม่ครบ กรุณาเปิดไฟล์ HTML เดี่ยวของแพตช์นี้');this.makeTerrain();this.makeProps();return this;});}
 set(key,value){if(!Object.hasOwn(DEFAULTS,key))return;if(key==='quality'&&!['rich','light'].includes(value))return;if(['motion','ambience'].includes(key)&&typeof value!=='boolean')return;if(key==='labels'&&!['smart','all','none'].includes(value))return;if(key==='uiTheme'&&!['sonnet','classic'].includes(value))return;this.settings[key]=value;try{localStorage.setItem('jianghu-living-ink-19',JSON.stringify(this.settings));}catch{}if(key==='quality'||key==='uiTheme')this.makeTerrain();}
 get reduced(){return !this.settings.motion||!!this.motionQuery?.matches;}
 atlas(c,id,x,y,width,alpha=1){const item=root.LivingArtAssets.sprites[id],im=item&&this.images[item.atlas];if(!im)return false;const [sx,sy,sw,sh]=item.rect,h=width*sh/sw,px=clamp(Math.ceil(width*this.renderScale/16)*16,16,768),key=id+':'+px;let raster=this.rasters.get(key);if(!raster){raster=document.createElement('canvas');raster.width=px;raster.height=Math.ceil(px*sh/sw);raster.getContext('2d').drawImage(im,sx,sy,sw,sh,0,0,raster.width,raster.height);if(this.rasters.size>=128)this.rasters.delete(this.rasters.keys().next().value);this.rasters.set(key,raster);}c.save();c.globalAlpha*=alpha;c.drawImage(raster,x-width/2,y-h+width*.025,width,h);c.restore();return true;}
 presentationPosition(n,g){const p=n.stageLocal||n;let old=this.poses.get(n.id);if(!old||Math.hypot(p.x-old.x,p.y-old.y)>130||g.s.t<old.t){old={x:p.x,y:p.y,px:p.x,py:p.y,t:g.s.t};this.poses.set(n.id,old);}else if(g.s.t!==old.t){old.px=old.x;old.py=old.y;old.x=p.x;old.y=p.y;old.t=g.s.t;}const a=g.s.paused||this.reduced?1:clamp((g.acc||0)/this.d.STEP,0,1);return {x:old.px+(old.x-old.px)*a,y:old.py+(old.y-old.py)*a};}
 makeTerrain(){const {W,H,LOCS,OBST}=this.d,rich=this.settings.quality==='rich',scale=rich?.64:.4,cv=document.createElement('canvas');cv.width=Math.round(W*scale);cv.height=Math.round(H*scale);const c=cv.getContext('2d');c.scale(scale,scale);const r=privateRng(541780);let g=c.createLinearGradient(0,0,W,H);g.addColorStop(0,'#9daa86');g.addColorStop(.4,'#b3bc91');g.addColorStop(1,'#789880');c.fillStyle=g;c.fillRect(0,0,W,H);
  for(let i=0;i<(rich?5400:2400);i++){const x=r()*W,y=r()*H,rr=20+r()*95;ellipse(c,x,y,rr,rr*.45,['#cfcea21d','#426b5520','#e2d5ab15','#91af7920'][i%4]);}
  for(let i=0;i<(rich?12500:4500);i++){const x=r()*W,y=r()*H;c.fillStyle=i%3?'#e4ddba32':'#345c4e24';c.fillRect(x,y,1+r()*4,1+r()*3);}
  this.waterPath(c);c.strokeStyle='#d0ccaa';c.lineWidth=115;c.stroke();c.strokeStyle='#779d8f';c.lineWidth=88;c.stroke();c.strokeStyle='#6d9f9e';c.lineWidth=62;c.stroke();c.strokeStyle='#bed5bc50';c.lineWidth=13;c.stroke();
  const road=()=>{c.beginPath();c.moveTo(0,1850);c.lineTo(1100,2050);c.lineTo(1870,1850);c.lineTo(2800,1800);c.lineTo(3300,650);};c.lineCap='round';road();c.strokeStyle='#61775a40';c.lineWidth=117;c.stroke();c.strokeStyle='#b2a27d';c.lineWidth=91;c.stroke();c.strokeStyle='#ccbd96';c.lineWidth=73;c.stroke();c.strokeStyle='#e2d2aa88';c.lineWidth=3;c.stroke();
  line(c,[[1100,2050],[1050,1330]],'#c7ba98',41);line(c,[[2700,1800],[3160,2380]],'#c7ba98',36);line(c,[[2800,1800],[2750,1450]],'#c7ba98',32);
  c.fillStyle='#afb594';c.beginPath();c.roundRect(480,850,1340,900,26);c.fill();c.strokeStyle='#c9c8a7';c.lineWidth=20;c.stroke();c.fillStyle='#bec09d';c.fillRect(500,870,1300,850);
  for(let x=512;x<1790;x+=55)for(let y=885;y<1710;y+=55){c.fillStyle=['#d6d0ae18','#93a68a18','#d8d6b51c','#f0e2c114'][Math.floor(r()*4)];c.fillRect(x,y,51,51);c.strokeStyle='#81977c16';c.lineWidth=1;c.strokeRect(x,y,51,51);if(r()<.15)line(c,[[x+3,y+3],[x+19,y+8],[x+24,y+25]],'#81907822',1);}
  for(let i=0;i<1800;i++){const x=512+r()*1275,y=884+r()*827;c.fillStyle=i%2?'#e7dfba28':'#718c7020';c.fillRect(x,y,1+r()*3,1+r()*2);}
  for(let i=0;i<300;i++){const side=i%4,x=side<2?490+r()*1320:side===2?490+r()*26:1780+r()*26,y=side===0?864+r()*25:side===1?1710+r()*25:875+r()*840;ellipse(c,x,y,4+r()*11,2+r()*5,'#78956a35');}
  line(c,[[1050,1720],[1050,1400]],'#d5ccad',65);for(let y=1450;y<1730;y+=38)line(c,[[1023,y],[1077,y]],'#a3a58d',2);
  for(const o of OBST){c.save();const grd=c.createLinearGradient(o.x,0,o.x+o.w,0);grd.addColorStop(0,'#5e7868');grd.addColorStop(.45,'#8b9e86');grd.addColorStop(1,'#496f62');c.fillStyle=grd;c.beginPath();c.moveTo(o.x-25,o.y+o.h);c.lineTo(o.x+o.w*.08,o.y+o.h*.5);c.lineTo(o.x+o.w*.15,o.y+40);c.lineTo(o.x+o.w*.55,o.y-50);c.lineTo(o.x+o.w*.9,o.y+o.h*.38);c.lineTo(o.x+o.w+30,o.y+o.h*.95);c.closePath();c.fill();line(c,[[o.x+o.w*.55,o.y-50],[o.x+o.w*.44,o.y+o.h*.3],[o.x+o.w*.6,o.y+o.h*.54],[o.x+o.w*.49,o.y+o.h]],'#c7c9ad66',8);for(let i=0;i<34;i++){const x=o.x+r()*o.w,y=o.y+r()*o.h;line(c,[[x,y],[x-14,y+36],[x-5,y+53]],'#334f4c33',2);}c.restore();}
  for(const [x,y,color,rr] of [[3180,2400,'#315f4729',370],[2720,1450,'#8e776e25',240],[2480,1850,'#62b3a32a',195]]){const gg=c.createRadialGradient(x,y,0,x,y,rr);gg.addColorStop(0,color);gg.addColorStop(1,'#0000');c.fillStyle=gg;c.fillRect(x-rr,y-rr,rr*2,rr*2);}
  if(this.settings.uiTheme==='sonnet'){
   const ts=44;
   for(let x=0;x<W;x+=ts)for(let y=0;y<H;y+=ts){
    const hVal=((x*73856093)^(y*19349663))>>>0;
    const idx=hVal%3;
    const inPlaza=x>=480&&x<=1800&&y>=860&&y<=1720;
    const onMainRoad=(Math.abs(y-(1850+(x<1100?(x/1100)*200:x<1870?200-((x-1100)/770)*200:-50)))<58&&x<2950)||(Math.abs(x-1050)<38&&y>=1330&&y<=2050);
    if(inPlaza){
     c.fillStyle=['#d6caae','#cdc2a6','#ddd2b7'][idx];
     c.fillRect(x,y,ts,ts);
     c.strokeStyle='rgba(90,80,60,0.25)';c.lineWidth=1.2;c.strokeRect(x+0.5,y+0.5,ts-1,ts-1);
     if((((x/ts)|0)+((y/ts)|0))%2===0){c.fillStyle='rgba(255,255,255,0.09)';c.fillRect(x,y,ts,ts);}
    }else if(onMainRoad){
     c.fillStyle=['#bbae92','#b3a589','#c2b79b'][idx];
     c.fillRect(x,y,ts,ts);
     c.strokeStyle='rgba(70,60,45,0.22)';c.lineWidth=1;c.strokeRect(x+0.5,y+0.5,ts-1,ts-1);
    }else{
     c.fillStyle=['#78a45555','#6f9a4a55','#82ad5c55'][idx];
     c.fillRect(x,y,ts,ts);
    }
   }
   // Sonnet courtyard central fountain & torches
   const fx=1150,fy=1310;
   ellipse(c,fx,fy+6,38,19,'#9b958a');ellipse(c,fx,fy+4,31,14,'#4f9bc4');
   c.fillStyle='#b7b1a6';c.fillRect(fx-6,fy-14,12,20);
   for(const [tx,ty] of [[920,1180],[1380,1180],[920,1460],[1380,1460],[1010,1640],[1290,1640]]){
    c.fillStyle='#5a3a28';c.fillRect(tx-2,ty-14,4,22);
    ellipse(c,tx,ty-15,5,6,'#f0cf4a');
   }
  }
  this.terrain=cv;this.miniBackground=null;this.backdropKey=null;this.sceneryBaked=false;this.stats.terrainPixels=cv.width*cv.height;if(this.props.length)this.bakeScenery();
 }
 waterPath(c){c.beginPath();c.moveTo(2570,0);c.bezierCurveTo(2300,800,2550,1750,2020,3000);}
 makeProps(){const {W,H,OBST,LOCS}=this.d,r=privateRng(938231),props=[];for(let i=0;i<640;i++){const x=40+r()*(W-80),y=80+r()*(H-120),base=x>400&&x<1870&&y>780&&y<1870,road=Math.abs(y-1870)<175&&x<2950,clear=LOCS.some(p=>Math.hypot(x-p.x,y-p.y)<190),rock=OBST.some(o=>x>o.x-50&&x<o.x+o.w+50&&y>o.y-80&&y<o.y+o.h+50),stream=Math.abs(x-(2520-y*.12))<105;if(base||road||clear||rock||stream)continue;const kind=i%11===0?'plum':i%3===0?'bamboo':'pine';props.push({id:kind,x,y,w:(kind==='bamboo'?95:105)+r()*90,seed:i});}
  for(const p of [{id:'plum',x:415,y:980,w:180},{id:'pine',x:420,y:1570,w:220},{id:'bamboo',x:1850,y:1650,w:155},{id:'plum',x:1450,y:810,w:160},{id:'pine',x:660,y:795,w:210}])props.push({...p,seed:props.length});
  for(const [x,y,w] of [[960,2180,180],[1140,2240,180],[1260,2120,180]])props.push({id:'cottage',x,y,w,seed:props.length});props.push({id:'market',x:600,y:2040,w:215,seed:1},{id:'bridge',x:2380,y:1870,w:230,seed:1});
  for(const p of this.d.OBST)for(let i=0;i<5;i++)props.push({id:'rock',x:p.x+30+i*p.w/5,y:p.y+p.h-10,w:115+i%2*40,seed:i});
  this.props=props.sort((a,b)=>a.y-b.y);this.miniBackground=null;this.bakeScenery();
 }
 bakeScenery(){if(!this.terrain||this.sceneryBaked)return;const c=this.terrain.getContext('2d'),scale=this.terrain.width/this.d.W;c.save();c.setTransform(scale,0,0,scale,0,0);this.renderScale=scale;for(const p of this.props)this.scenery(c,p,0);this.renderScale=1;c.restore();this.sceneryBaked=true;this.miniBackground=null;this.backdropKey=null;}
 backdropFor(view,camera,f){const key=[view.w,view.h,view.dpr,camera.x,camera.y,f].join(':');if(this.backdropKey!==key){const cv=this.backdrop||document.createElement('canvas');cv.width=Math.ceil(view.w*view.dpr);cv.height=Math.ceil(view.h*view.dpr);const c=cv.getContext('2d');c.setTransform(view.dpr,0,0,view.dpr,0,0);c.fillStyle='#547967';c.fillRect(0,0,view.w,view.h);c.translate(view.w/2,view.h/2);c.scale(f,f);c.translate(-camera.x,-camera.y);c.drawImage(this.terrain,0,0,this.d.W,this.d.H);this.backdrop=cv;this.backdropKey=key;}return this.backdrop;}
 scenery(c,p,t,fade=1){c.save();c.translate(p.x,p.y);if(!this.reduced&&['pine','bamboo','plum'].includes(p.id))c.transform(1,0,Math.sin(t*.55+p.seed)*.008,1,0,0);this.atlas(c,p.id,0,0,p.w,fade);c.restore();}
 drawBuilding(c,b,g,t){const d=this.d.B[b.type],width=d.size*1.56;c.save();ellipse(c,b.x+10,b.y+38,width*.46,width*.13,'#16392d24');this.atlas(c,({treasury:'market',missionHall:'shrine',works:'forge'})[b.type]||b.type,b.x,b.y+46,width,b.remaining>0?.56:1);if(b.remaining>0){c.strokeStyle='#d4b87b';c.lineWidth=3;c.setLineDash([12,8]);c.strokeRect(b.x-d.size*.53,b.y-d.size*.63,d.size*1.06,d.size*.95);c.setLineDash([]);for(let i=-1;i<=1;i++)line(c,[[b.x+i*d.size*.42,b.y+48],[b.x+i*d.size*.42,b.y-d.size*.55]],'#b49a6b',5);}else if(!this.reduced&&['forge','alchemy','shrine'].includes(b.type)){for(let i=0;i<4;i++){const phase=(t*.18+i*.25)%1;ellipse(c,b.x+width*.27+Math.sin(phase*5)*8,b.y-width*.64-phase*50,4+phase*10,6+phase*10,rgba('#d8e2d4',(1-phase)*.23));}}
  if(b.hp<d.hp){c.fillStyle='#3d4b3f';c.fillRect(b.x-35,b.y+54,70,5);c.fillStyle='#d2a376';c.fillRect(b.x-35,b.y+54,70*b.hp/d.hp,5);}c.restore();}
 drawNode(c,node,g,t){if(node.qty<1)return;const p=this.d.LOCS.find(z=>z.id===node.locationId)||node;const fullness=clamp(node.qty/node.max,.2,1),id=node.kind==='ORE'?'ore':node.id==='lotus'?'reeds':'herbs';this.atlas(c,id,p.x,p.y+14,95,.5+fullness*.5);if(!this.reduced&&node.kind==='HERB'){for(let k=0;k<2;k++){const phase=(t*.22+k*.5)%1;ellipse(c,p.x-14+k*26,p.y-18-phase*30,1.3,1.3,rgba('#fff2bd',Math.sin(phase*Math.PI)*.7));}}}
 drawPlot(c,p,g,t){const b=g.s.buildings.find(b=>b.id===p.buildingId);if(!b||b.hp<=0)return;c.save();c.translate(p.x,p.y);c.fillStyle=p.moisture>30?'#5e5240':'#847057';c.beginPath();c.roundRect(-18,-11,36,24,3);c.fill();c.strokeStyle='#b3a47b';c.lineWidth=2;c.stroke();for(let y=-5;y<11;y+=7)line(c,[[-13,y],[13,y]],'#a3966f50',1);const crop=this.d.CROPS[p.cropId];if(crop){const f=clamp(p.growth/crop.growSeconds,.1,1);for(let k=-1;k<=1;k++){const h=7+f*14,x=k*9,wind=this.reduced?0:Math.sin(t+k)*f*.8;line(c,[[x,7],[x+wind,-h]],f>=1?'#bdd483':'#7aaf72',2);ellipse(c,x-4+wind,-h*.4,5,2.5,'#659662',-.5);ellipse(c,x+4+wind,-h*.7,5,2.5,'#9ebc78',.5);if(f>=1)ellipse(c,x+wind,-h,3,2.5,crop.tier>1?'#d6b7d5':'#e9dfb2');}}c.restore();}
 drawHuman(c,n,g,t,f,selected){const p=n.stageLocal,profile=visualProfile(n),walking=p.mode==='travel'||p.action==='flee'&&p.route?.length,meditating=['train','seclusion','breakthrough','meditateWaterfall'].includes(p.action)&&p.mode==='working',working=p.mode==='working',cs=p.combatState,attackAge=t-(cs?.lastAttackAt??-99),attackDuration=attackAge>=0&&attackAge<.6?clamp(.35/(g.combatSystem?.stats?.(n)?.attackSpeed||.8),.14,.6):.14,attacking=attackAge>=0&&attackAge<attackDuration,speed=walking?7:1.6,phase=this.reduced?0:t*speed+(profile.hash%30),bob=this.reduced?0:walking?Math.sin(phase)*.65:Math.sin(phase)*.22,dir=p.route?.[0]?Math.sign(p.route[0].x-p.x)||1:(profile.hash%2?1:-1),size=clamp(f*3.15,0.56,2.5)/f;
  c.save();c.translate(p.x,p.y);c.scale(size,size);if(selected){c.strokeStyle='#f8e3a1';c.lineWidth=1.2;c.beginPath();c.ellipse(0,5,13,5.5,0,0,TAU);c.stroke();c.strokeStyle='#f8e3a166';c.beginPath();c.ellipse(0,5,16,7,0,0,TAU);c.stroke();}ellipse(c,1,5,10,3.7,'#203f354d');if(!n.alive||n.health<=0){line(c,[[-6,0],[7,5]],'#826957',5);c.restore();return;}
  if(cs?.guardUntil>t){c.strokeStyle='#c4f1e5aa';c.lineWidth=.9;c.beginPath();c.arc(0,-5,17,-Math.PI*.9,Math.PI*.1);c.stroke();}if(cs?.evadeUntil>t&&cs.evadeCharges>0){c.strokeStyle='#d7e9f777';line(c,[[-15,-8],[-22,-6]],'#d7e9f777',1);line(c,[[-14,-3],[-19,-1]],'#d7e9f777',1);}
  c.scale(profile.width,profile.height);c.translate(0,bob);c.lineCap='round';const [robe,trim,sash]=profile.colors,step=walking?Math.sin(phase)*2:0;
  if(!meditating){ellipse(c,-3+step,4.5,2.5,1.5,'#34413e');ellipse(c,3-step,5.5,2.5,1.5,'#34413e');}
  const fabric=c.createLinearGradient(-9,-8,10,4);fabric.addColorStop(0,robe);fabric.addColorStop(.43,trim+'66');fabric.addColorStop(.52,robe);fabric.addColorStop(1,sash);c.fillStyle=fabric;c.beginPath();c.moveTo(-4,-10);c.quadraticCurveTo(-7,-6,-9+step*.25,3);c.quadraticCurveTo(0,6,9-step*.25,3);c.quadraticCurveTo(7,-6,4,-10);c.closePath();c.fill();
  c.fillStyle='#142d3429';c.beginPath();c.moveTo(1,-9);c.lineTo(5,-2);c.lineTo(8,3);c.lineTo(1,4);c.closePath();c.fill();line(c,[[-3,-9],[1,-4],[4,-9]],trim,1.3);line(c,[[-5,-1],[5,-1]],sash,2.2);line(c,[[1,0],[2+step*.3,4]],trim,.6);if(profile.trim===1)line(c,[[-6,2],[0,3],[6,2]],trim,.55);
  const arm=attacking&&!this.reduced?Math.sin(attackAge/attackDuration*Math.PI)*4:walking?Math.sin(phase)*1.5:working?Math.sin(phase*2)*1.2:0;
  line(c,[[-4,-7],[-8,-3+arm],[-6,0+arm]],robe,4);line(c,[[4,-7],[8,-4-arm],[7,-1-arm]],robe,4);ellipse(c,-6,-.6+arm,1.3,1.4,profile.skin);ellipse(c,7,-1-arm,1.3,1.4,profile.skin);
  if(meditating){ellipse(c,0,3,8,3,robe);line(c,[[-6,2],[0,0],[6,2]],trim,.7);}
  ellipse(c,0,-14,4.25,5.1,profile.skin);ellipse(c,-.5,-16.5,4.3,3.2,profile.hair);ellipse(c,-1,-21,2.2,1.7,profile.hair);line(c,[[-2.7,-20.2],[2.3,-20.2]],trim,.7);line(c,[[dir*2,-14],[dir*2.7,-13]],'#7d6553',.6);if(f>.22){ellipse(c,-1.7+dir*.5,-14.8,.45,.6,'#323b36');ellipse(c,1.4+dir*.5,-14.8,.45,.6,'#323b36');}
  if(profile.trim===2)line(c,[[0,-19],[6,-21]],'#d2c48d',.75);if(g.s.life?.offices?.master?.npcId===n.id){ellipse(c,3,-5,1.2,1.5,'#e6cb88');line(c,[[-3,-19.5],[3,-19.5]],'#e6cb88',1.2);}
  const weaponId=n.jianghu?.equipmentV140?.WEAPON,weapon=n.jianghu?.ledgerV140?.equipmentItems.find(a=>a.id===weaponId);if(weapon){const ox=attacking?6+arm:6;line(c,[[ox,-2-arm],[ox+dir*5,-18-arm]],'#e1e9dd',1.5);line(c,[[ox-2,-4-arm],[ox+3,-3-arm]],'#c5a963',1);}
  if(working&&!meditating){const a=p.action||'';if(/read|Scripture|research|Research|Mentor|comprehendTablet|copyScripture/.test(a)){c.fillStyle='#e3d5ab';c.fillRect(-5,-6,10,5);line(c,[[0,-6],[0,-1]],'#9b8f70',.6);}else if(/gardenWater/.test(a)){c.fillStyle='#a78b5f';c.fillRect(7,-1,4,4);line(c,[[10,-1],[14,1]],'#a78b5f',1.5);}else if(/herb|gather|gardenHarvest/.test(a)){line(c,[[7,-2],[11,3]],'#9c8257',1);ellipse(c,11,2,3.5,1.5,'#86b172',-.5);}else if(/mine|wood/.test(a)){line(c,[[7,-4],[13,4-arm]],'#b39460',1);line(c,[[9,-6-arm],[16,-3-arm]],'#a8b9ac',2);}else if(/PersonalItem|craft|Research/.test(a)){c.fillStyle='#bd9b5b';c.fillRect(6,-4,5,3);}else if(/medicine|Pill|brewTeaDao/.test(a)){c.fillStyle='#ccad6e';c.beginPath();c.roundRect(5,-8,4,5,1);c.fill();}}
  c.restore();
  if(meditating){const rr=clamp(f*3.5,.6,2.5)/f;c.save();c.translate(p.x,p.y);c.scale(rr,rr);const a=this.reduced?0:t*.7;c.strokeStyle=n.jianghu?.path==='DEMON'?'#e599f7aa':n.jianghu?.path==='HEART_SOUL'?'#a5d8ffaa':'#e8e5c6aa';c.lineWidth=.8;c.beginPath();c.ellipse(0,0,15,5,a*.1,a,a+Math.PI*1.55);c.stroke();c.strokeStyle='#bce8da88';c.beginPath();c.ellipse(0,-6,12,4,-.25,a+2,a+5.5);c.stroke();c.restore();}
  if(this.settings.uiTheme==='sonnet'&&n.alive&&n.health>0&&f>0.35){
   const pathCols={XIAN:'#4fb2f2',BODY:'#f0714f',GOD:'#f0cf4a',DEMON:'#b58cf0',HEART_SOUL:'#5fd38a'};
   const pCol=pathCols[n.jianghu?.path]||'#4fb2f2';
   const act=p.action||'idle';
   const actIcon=p.mode==='combat'||/hunt|assault|defend|spar/.test(act)?'⚔':meditating?'🧘':/read|Scripture|research|Research|comprehend|study|decipher/.test(act)?'📖':/herb|garden/.test(act)?'🌿':/mine|wood/.test(act)?'⛏':/craft|PersonalItem|experiment/.test(act)?'🔨':/Myriad|Expedition|Fortune|Rumor|scout/.test(act)?'🧭':/trade|buy|Auction/.test(act)?'🛒':'💬';
   c.save();c.translate(p.x,p.y);c.scale(size,size);
   if(meditating){glow(c,0,-8,20,pCol+'55');}
   // Overhead circular activity bubble (Claude Sonnet 5.5 style)
   c.fillStyle='rgba(255,255,255,0.92)';c.strokeStyle=pCol;c.lineWidth=1.5;
   c.beginPath();c.arc(0,-30,7.2,0,TAU);c.fill();c.stroke();
   c.font='9px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillStyle='#10151c';
   c.fillText(actIcon,0,-29.5);
   c.restore();
  }
 }
 drawBeast(c,b,t,f,selected){const id=b.speciesId||'',boar=/BOAR/.test(id),snake=/PYTHON|SERPENT/.test(id),s=clamp(f*4.7,.7,2.5)/f,phase=this.reduced?0:t*5+hash(b.id),step=Math.sin(phase)*1.3;c.save();c.translate(b.x,b.y);c.scale(s,s);ellipse(c,0,5,12,4,'#173e3440');if(!b.alive){ellipse(c,0,3,9,3,'#887c64');c.restore();return;}if(selected){c.strokeStyle='#f5d296';c.lineWidth=1;c.strokeRect(-15,-12,30,22);}if(snake){c.strokeStyle='#5d7a53';c.lineWidth=5;c.beginPath();c.moveTo(-12,3);c.bezierCurveTo(-9,-7,4,10,5,0);c.quadraticCurveTo(10,-8,13,-3);c.stroke();ellipse(c,12,-4,4,3,'#86a16c');ellipse(c,13,-5,.7,.6,'#e6cd7f');}else{const coat=boar?'#776857':'#7b8b8e';for(let i=-1;i<=1;i+=2){line(c,[[i*6,2],[i*7,7+(i>0?step:-step)]],'#475b55',2);line(c,[[i*3,2],[i*4,6+(i<0?step:-step)]],coat,2);}ellipse(c,-1,0,boar?11:10,boar?7:5.8,coat);ellipse(c,8,-3,5,4,coat);c.fillStyle='#536861';c.beginPath();c.moveTo(4,-5);c.lineTo(6,-11);c.lineTo(9,-6);c.lineTo(12,-10);c.lineTo(13,-3);c.fill();line(c,[[-10,0],[-15,-4],[-17,-8]],coat,2);ellipse(c,10,-4,.7,.65,'#eddb9c');if(boar){line(c,[[10,0],[14,-2]],'#e0d2b4',1.4);for(let x=-7;x<3;x+=3)line(c,[[x,-5],[x-1,-9]],'#5f584f',1);}}
  c.restore();}
 badge(c,text,x,y,size=10,color='#f1e8ce',bg='#173e37dc'){
 const isSonnet=this.settings.uiTheme==='sonnet';
 const finalBg=isSonnet?'#10151ce0':bg;
 const finalCol=isSonnet?'#eef2f6':color;
 const finalBorder=isSonnet?'#2f3f50':'#c3b58355';
 c.save();c.font=`600 ${size}px Thai,sans-serif`;c.textAlign='center';c.textBaseline='middle';const w=c.measureText(text).width+14;c.fillStyle=finalBg;c.strokeStyle=finalBorder;c.lineWidth=.8;c.beginPath();c.roundRect(x-w/2,y-size*.85,w,size*1.85,isSonnet?6:5);c.fill();c.stroke();c.fillStyle=finalCol;c.fillText(text,x,y);c.restore();
}
 combatVfx(c,g,sp,f,t){
  const limit=this.settings.quality==='rich'?24:10,events=(g.s.combat||[]).filter(e=>(e.until??((e.t??t)+1.2))>t).slice(-limit),placed=[],pixelScale=Math.max(1,c.getTransform?.().a||1),width=(c.canvas?.width||390)/pixelScale,height=(c.canvas?.height||640)/pixelScale;
  const onScreen=q=>Number.isFinite(q?.x)&&Number.isFinite(q?.y)&&q.x>=-80&&q.x<=width+80&&q.y>=-80&&q.y<=height+80;
  const entity=id=>g.world.npcs[id]||(g.s.beasts||[]).find(z=>z.id===id)||(g.s.realm?.pets||[]).find(z=>z.id===id),point=n=>n?.stageLocal||n;
  const graphemes=text=>typeof Intl?.Segmenter==='function'?[...new Intl.Segmenter('th',{granularity:'grapheme'}).segment(text)].map(v=>v.segment):Array.from(text).reduce((a,v)=>{if(/\p{Mark}/u.test(v)&&a.length)a[a.length-1]+=v;else a.push(v);return a;},[]);
  const wrap=(text,maxWidth)=>{const tokens=typeof Intl?.Segmenter==='function'?[...new Intl.Segmenter('th',{granularity:'word'}).segment(text)].map(v=>v.segment):graphemes(text),lines=[];let line='';for(const token of tokens){if(c.measureText(line+token).width<=maxWidth){line+=token;continue;}if(line){lines.push(line);line='';}for(const char of graphemes(token)){if(line&&c.measureText(line+char).width>maxWidth){lines.push(line);line='';}line+=char;}}if(line)lines.push(line);return lines;};
  const place=(q,w,h,i,extra=0)=>{const margin=8,initial=q.y-clamp(f*72,26,54)-extra,lanes=[0,-1,1,-2,2],vertical=[0,-1,1,-2,2,-3,3,-4,4,-5,-6],step=h+4;let r;
   for(let a=0;a<160;a++){const column=Math.floor(a/vertical.length),dy=vertical[a%vertical.length]*step,x=clamp(q.x+lanes[column%lanes.length]*(w+6),w/2+margin,Math.max(w/2+margin,width-w/2-margin)),y=clamp(initial+dy,h/2+margin,Math.max(h/2+margin,height-h/2-margin));r={x,y,w,h};if(!placed.some(p=>Math.abs(p.x-x)<(p.w+w)/2+3&&Math.abs(p.y-y)<(p.h+h)/2+3))break;}
   placed.push(r);return r;};
  const drawText=(text,q,{size=14,color='#ffe9be',label=false,extra=0,index=0}={})=>{if(!text||!onScreen(q))return;c.font=`${label?'600':'bold'} ${size}px Thai,"DejaVu Sans",sans-serif`;c.textAlign='center';c.textBaseline='middle';const lines=label?wrap(String(text),Math.min(220,Math.max(80,width-32))):[String(text)],lineHeight=size+6,w=Math.min(width-16,Math.max(...lines.map(line=>c.measureText(line).width))+16),h=lineHeight*lines.length+(label?8:2),r=place(q,w,h,index,extra);
   if(label){c.fillStyle='#142e30ed';c.strokeStyle=color;c.lineWidth=1;c.beginPath();c.roundRect(r.x-w/2,r.y-h/2,w,h,6);c.fill();c.stroke();}
   c.fillStyle=color;c.strokeStyle='#142c2d';c.lineWidth=label?2.5:4;lines.forEach((line,j)=>{const y=r.y+(j-(lines.length-1)/2)*lineHeight;c.strokeText(line,r.x,y);c.fillText(line,r.x,y);});};
  for(const [i,e] of events.entries()){
   const start=e.t??((e.until??t+1)-1),duration=(e.until??start+1.2)-start,age=clamp((t-start)/Math.max(.1,duration),0,1),isMove=e.kind==='move',actor=entity(e.attackerId),caster=entity(e.entityId)||actor,target=entity(e.targetId||e.entityId),pos=point(actor),labelPos=point(caster)||pos,anchor=isMove?point(caster):Number.isFinite(e.x)&&Number.isFinite(e.y)?e:point(target),q=anchor&&sp(anchor),value=Number(e.value)||0,critical=e.critical||e.kind==='critical',miss=['miss','evade','dodge'].includes(e.kind),heal=value<0||e.kind==='heal',role=e.kind==='damage'?actor?.stageLocal?.combatState?.lastRole:e.kind,color=critical?'#ffdf75':miss?'#b8deed':heal?'#b6ead0':role==='control'?'#d4c8ff':role==='forbidden'?'#ffb7a7':'#ffe9be';
   const isDot=e.damageType==='dot'||e.label==='บาดแผลต่อเนื่อง'||e.label==='พิษและบาดแผลกัดกร่อน';if(!onScreen(q)||age>=1||(value!==0&&Math.abs(value)<1))continue;c.save();c.globalAlpha=1-age;
   if(!this.reduced){if(value>0&&!isMove&&!miss&&!isDot&&pos){const from=sp(pos),angle=Math.atan2(q.y-from.y,q.x-from.x);c.save();c.translate(q.x,q.y);c.rotate(angle);c.strokeStyle=color;c.lineWidth=2.8*(1-age)+.5;c.beginPath();c.ellipse(-7,0,15+age*11,10+age*5,0,-1.4,1.4);c.stroke();line(c,[[-24,-2],[-4,1]],rgba(color,.45),1);c.restore();for(let k=0;k<5;k++){const a0=(k*1.7+i)*2,r=age*23;c.fillStyle=color;c.fillRect(q.x+Math.cos(a0)*r,q.y+Math.sin(a0)*r*.6,1.5,1.5);}}else if(['heal','defense','guard','evade','movement','control','miss'].includes(e.kind)){c.strokeStyle=color;c.lineWidth=1.2;c.beginPath();c.ellipse(q.x,q.y-8,8+age*15,5+age*7,0,0,TAU);c.stroke();}}
   const rise=age*(this.reduced?0:19),floating={x:q.x,y:q.y-rise};
   if(isMove)drawText(e.label||e.moveName||'ออกกระบวนท่า',floating,{size:12,color:'#ffe3a4',label:true,extra:30,index:i});
   else if(miss)drawText('หลบ · MISS',floating,{color,size:14,index:i});
   else if(value){const amount=Math.max(1,Math.round(Math.abs(value))),text=(critical?'คริ! ':'')+(heal?'+':'-')+amount;drawText(text,floating,{size:critical?19:14,color,index:i});if(e.label&&!['damage','critical','dot'].includes(e.kind)&&!isDot&&labelPos)drawText(e.label,sp(labelPos),{size:12,color,label:true,extra:30,index:i});}
   else if(e.label)drawText(e.label,floating,{size:12,color,label:true,index:i});
   c.restore();
  }
 }
 render(g,{view,camera,f,selected,labels,screenPoint:sp}){const c=this.ctx,{W,H,B,LOCS}=this.d,t=g.s.t+(g.s.paused?0:clamp(g.acc||0,0,this.d.STEP)),dpr=view.dpr,rich=this.settings.quality==='rich';this.renderScale=f*dpr;this.pick=new Map();this.stats.frames++;this.stats.visibleSprites=0;c.setTransform(dpr,0,0,dpr,0,0);if(!this.terrain)return this.pick;c.drawImage(this.backdropFor(view,camera,f),0,0,view.w,view.h);c.save();c.translate(view.w/2,view.h/2);c.scale(f,f);c.translate(-camera.x,-camera.y);
  if(!this.reduced&&rich){this.waterPath(c);c.setLineDash([18,180,40,240]);c.lineDashOffset=-t*8;c.strokeStyle='#deeee052';c.lineWidth=2;c.stroke();c.setLineDash([]);}
  c.strokeStyle='#ead4a46b';c.lineWidth=1.2/f;c.setLineDash([6/f,7/f]);c.strokeRect(500,870,1300,850);c.setLineDash([]);
  for(const node of g.s.nodes){const p=this.d.LOCS.find(z=>z.id===node.locationId)||node,q=sp(p);if(q.x>-70&&q.x<view.w+70&&q.y>-40&&q.y<view.h+100)this.drawNode(c,node,g,t);}for(const p of g.s.gardenPlots||[]){const q=sp(p);if(q.x>-30&&q.x<view.w+30&&q.y>-30&&q.y<view.h+50)this.drawPlot(c,p,g,t);}
  for(const h of g.s.ecology.habitats){c.strokeStyle='#e4d6ab50';c.lineWidth=1/f;c.setLineDash([3/f,8/f]);c.beginPath();c.ellipse(h.x,h.y,165,100,0,0,TAU);c.stroke();c.setLineDash([]);}
  if(g.s.campKnown){const p=LOCS.find(z=>z.id==='camp');for(let i=-1;i<=1;i++){c.fillStyle=['#715e4c','#8a7255','#9b805d'][i+1];c.beginPath();c.moveTo(p.x+i*130-60,p.y+55);c.lineTo(p.x+i*130,p.y-68);c.lineTo(p.x+i*130+60,p.y+55);c.closePath();c.fill();line(c,[[p.x+i*130,p.y-68],[p.x+i*130,p.y+45]],'#b3a57a',3);}}
  const all=[...g.heroes,...g.visitors,...g.enemies,...g.s.beasts,...g.s.realm.pets],people=all.filter(n=>{const p=n.stageLocal||n;return !p.offmap&&(!p.enemy||g.s.campKnown||p.raid);}),draws=[];
  for(const p of this.props){const q=sp(p);if(q.x<-160||q.x>view.w+160||q.y<-50||q.y>view.h+240)continue;const behind=people.some(n=>{const a=n.stageLocal||n;return Math.abs(a.x-p.x)<p.w*.42&&a.y<p.y&&a.y>p.y-p.w;});if(behind||f>.75)draws.push({y:p.y,draw:()=>this.scenery(c,p,0,behind?.54:1)});}
  for(const b of g.s.buildings.filter(b=>b.hp>0)){const q=sp(b);if(q.x<-250||q.x>view.w+250||q.y<-80||q.y>view.h+300)continue;draws.push({y:b.y+26,draw:()=>{const behind=people.some(n=>{const a=n.stageLocal||n;return Math.abs(a.x-b.x)<B[b.type].size*.65&&a.y<b.y+26&&a.y>b.y-130;});c.save();if(behind)c.globalAlpha=.68;this.drawBuilding(c,b,g,t);c.restore();}});}
  if(this.poses.size>256){const ids=new Set(people.map(n=>n.id));for(const id of this.poses.keys())if(!ids.has(id))this.poses.delete(id);}
  for(const n of people){const p=n.stageLocal||n,pos=this.presentationPosition(n,g),q=sp(pos);if(q.x<-45||q.x>view.w+45||q.y<-35||q.y>view.h+65)continue;this.pick.set(n.id,q);draws.push({y:pos.y,draw:()=>{c.save();c.translate(pos.x-p.x,pos.y-p.y);if(n.core)this.drawHuman(c,n,g,t,f,n.id===selected);else this.drawBeast(c,{...n,...p},t,f,n.id===selected);c.restore();}});}
  draws.sort((a,b)=>a.y-b.y);for(const e of draws){e.draw();this.stats.visibleSprites++;}
  for(const drop of g.s.groundDrops||[]){ellipse(c,drop.x,drop.y,9,6,'#e8c884');if(!this.reduced)glow(c,drop.x,drop.y,22,'#f9db8e55');}
  for(const fortune of g.s.realm.fortunes.filter(v=>!v.claimed&&v.expiresAt>t)){ellipse(c,fortune.x,fortune.y,40,18,'#d8cf8560');c.strokeStyle='#eddf9b';c.lineWidth=2;c.beginPath();c.arc(fortune.x,fortune.y-12,15+(this.reduced?0:Math.sin(t)*3),0,TAU);c.stroke();}
  const selectedNpc=g.world.npcs[selected];if(selectedNpc?.stageLocal?.route?.length){const p=selectedNpc.stageLocal;c.setLineDash([5/f,6/f]);c.strokeStyle='#f8e3a3b3';c.lineWidth=1/f;bPath(c,p);c.stroke();c.setLineDash([]);}c.restore();
  const phase=(t/this.d.DAY)%1,night=this.settings.ambience?Math.max(0,Math.cos(phase*TAU))*.14:0;
  if(night>.01){c.fillStyle=rgba('#182f56',night);c.fillRect(0,0,view.w,view.h);c.save();c.globalCompositeOperation='screen';for(const b of g.s.buildings.filter(z=>z.hp>0&&z.remaining<=0)){const q=sp({x:b.x,y:b.y+10});glow(c,q.x,q.y,clamp(B[b.type].size*f*.6,16,100),rgba('#edb86a',night*.6));}c.restore();}
  const smart=this.settings.labels==='smart',show=labels&&this.settings.labels!=='none';if(show){for(const p of LOCS){if(p.id==='camp'&&!g.s.campKnown)continue;const q=sp(p);if(q.x<0||q.x>view.w||q.y<0||q.y>view.h)continue;if(smart&&camera.z>3.8&&!['village','exit'].includes(p.id))continue;this.badge(c,p.name,q.x,q.y+25,10,'#ede4c8','#24483eda');}for(const b of g.s.buildings.filter(b=>b.hp>0)){const q=sp(b);if(q.x<0||q.x>view.w||q.y<-20||q.y>view.h)continue;const ly=q.y+Math.max(15,60*f),crowded=smart&&[...this.pick.values()].some(a=>Math.abs(a.x-q.x)<55&&Math.abs(a.y-ly)<36);if(!crowded)this.badge(c,b.remaining>0?'ก่อสร้าง '+Math.ceil(b.remaining)+' วิ':B[b.type].name+' · '+(b.level||1)+(b.upgrade?' ↑ '+Math.ceil(b.upgrade.remaining)+' วิ':''),q.x,ly,9,'#f5e5bb','#1c423bdc');}for(const n of g.heroes){const q=this.pick.get(n.id);if(!q)continue;if(n.id===selected||camera.z>4.3){this.badge(c,n.name,q.x,q.y-Math.max(32,clamp(f*3.15,.56,2.5)*27*visualProfile(n).height+19),10);if(n.id===selected)this.badge(c,this.d.actionLabel(n.stageLocal.action),q.x,q.y+18,9,'#d8e5d0','#1c423bd9');}}}
  for(const n of people){const p=n.stageLocal||n,q=this.pick.get(n.id);if(!q||!n.alive||n.health<=0)continue;const max=p.boss?240:n.maxHP||100,top=q.y-(n.core?clamp(f*3.15,.56,2.5)*26*visualProfile(n).height:clamp(f*4.7,.7,2.5)*14)-5;if(n.health<max||n.id===selected){c.fillStyle='#30473d';c.fillRect(q.x-13,top,26,3);c.fillStyle=n.core?'#b9d4a4':'#d5a47a';c.fillRect(q.x-13,top,26*clamp(n.health/max,0,1),3);}if(n.id===selected&&p.combatState){c.fillStyle='#2b4853';c.fillRect(q.x-13,top+5,26,2);c.fillStyle='#b9dae5';c.fillRect(q.x-13,top+5,26*p.combatState.qi/p.combatState.maxQi,2);}}
  this.combatVfx(c,g,sp,f,t);
  if(this.settings.ambience&&rich&&!this.reduced){const tt=t;for(let k=0;k<15;k++){const x=((k*157.37+tt*(3+k%3))%(view.w+70))-35,y=((k*97.31+tt*(2+k%2))%(view.h+80))-40;c.save();c.translate(x,y);c.rotate(k+tt*.4);ellipse(c,0,0,1.7,3.3,'#f2dbca70');c.restore();}if(night>.1)for(let k=0;k<14;k++){const x=(k*213.37+Math.sin(tt*.5+k)*13)%view.w,y=(k*131.3+Math.cos(tt*.4+k)*12)%view.h;glow(c,x,y,5,rgba('#e5ed9b',.16+.12*Math.sin(tt+k)));}}
  if(rich){const v=c.createRadialGradient(view.w*.5,view.h*.45,Math.min(view.w,view.h)*.25,view.w*.5,view.h*.5,Math.max(view.w,view.h)*.72);v.addColorStop(0,'#0000');v.addColorStop(1,'#193e3529');c.fillStyle=v;c.fillRect(0,0,view.w,view.h);}this.renderScale=1;return this.pick;
 }
 minimap(c,g){if(!this.miniBackground&&this.terrain){const mini=document.createElement('canvas');mini.width=312;mini.height=234;mini.getContext('2d').drawImage(this.terrain,0,0,312,234);this.miniBackground=mini;}c.clearRect(0,0,156,117);if(this.miniBackground)c.drawImage(this.miniBackground,0,0,156,117);for(const h of g.s.ecology.habitats){c.strokeStyle='#935941';c.beginPath();c.arc(h.x/this.d.W*156,h.y/this.d.H*117,4,0,TAU);c.stroke();}for(const b of g.s.buildings.filter(b=>b.hp>0)){c.fillStyle='#f5dba1';c.fillRect(b.x/this.d.W*156-2,b.y/this.d.H*117-2,4,4);}}
}
function bPath(c,p){c.beginPath();c.moveTo(p.x,p.y);for(const z of p.route)c.lineTo(z.x,z.y);}
root.LivingInk={create:(ctx,data)=>new LivingInk(ctx,data),visualProfile,hash,privateRng,DEFAULTS};
if(typeof module==='object')module.exports=root.LivingInk;
})(typeof globalThis!=='undefined'?globalThis:this);
