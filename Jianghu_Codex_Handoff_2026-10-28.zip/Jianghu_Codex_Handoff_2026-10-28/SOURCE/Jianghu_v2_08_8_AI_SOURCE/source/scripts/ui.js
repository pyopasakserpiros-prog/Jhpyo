(()=>{'use strict';
const SAVE_KEY=location.search.includes('qa=1')?'jianghu-frontier-qa-combat201':'jianghu-frontier-economy208';const LEGACY_SAVE_KEY='jianghu-frontier-v17',LEGACY_SAVE_KEY_OLD='jianghu-frontier-v16';
const $=s=>document.querySelector(s),{B,LOCS,OBST,W,H,DAY,HERB,ORE,CIN,FANG,LABEL,CROPS,RESOURCE_NODE_DEFS,LOW_GRADE_PILL_IDS,actionLabel}=FrontierData,E=World2026Engine;
const canvas=$('#map'),ctx=canvas.getContext('2d'),mini=$('#minimap'),mc=mini.getContext('2d');
let runtimeFault=null,marketMemberId=null;const reqForm={mode:'GRANT',authorityId:null,npcId:null,item:null};
let game,saveBlocked='',questTab='story',growthSection='life',lifeTab='council',worldSection='myriad',worldFocus=null,logFormat='narrative',logCategory='ALL',pickPositions=new Map(),mapClusters=[],activeSpeech=0,tab=null,selected=null,combatEntityId=null,heroTab='overview',identitySection='motives',compareId=null,follow=false,labels=true,placement=null,preview=null,toastTimer=0,now=performance.now(),lastUI=0,camera={x:1230,y:1390,z:3.1},view={w:390,h:600,dpr:1},needsRender=true;
const sprites=RealmSprites.create(ctx,{role(n){const keys={master:'SECT_MASTER',steward:'EXTERNAL_ELDER',grandElder:'GRAND_ELDER',lawElder:'LAW_ELDER',alchemyElder:'ALCHEMY_ELDER',forgeElder:'FORGE_ELDER',scriptureElder:'SCRIPTURE_ELDER',externalElder:'EXTERNAL_ELDER',chiefDisciple:'CHIEF_DISCIPLE'};return keys[Object.entries(game?.s.life.offices||{}).find(([,o])=>o?.npcId===n.id)?.[0]]||'INNER_DISCIPLE';},weapon(n){const id=n.jianghu.equipmentV140?.WEAPON;return n.jianghu.ledgerV140.equipmentItems.find(i=>i.id===id)?.nameTh||'';}});
const ink=LivingInk.create(ctx,FrontierData);
const jade=JianghuInventory1222.mount({Engine:E,world:()=>game.world,openRelic:id=>toast('รายละเอียดเทววัตถุอยู่ในแถบคุณสมบัติและที่มา')});
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const fmt=n=>Math.floor(n||0).toLocaleString('en-US');const alive=n=>n?.alive&&n.health>0;
function toast(t){$('#toast').textContent=t;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),2800);}
function result(r,t='ดำเนินการเรียบร้อย'){toast(r?.ok===false?r.reason||r.code:t);refresh();return r;}
function factor(){return Math.min(view.w/W,view.h/H)*camera.z;}
function worldPoint(x,y){const f=factor();return {x:camera.x+(x-view.w/2)/f,y:camera.y+(y-view.h/2)/f};}
function screenPoint(p){const f=factor();return {x:(p.x-camera.x)*f+view.w/2,y:(p.y-camera.y)*f+view.h/2};}
function clampCamera(){needsRender=true;const f=factor(),mx=Math.min(W/2,view.w/f/2),my=Math.min(H/2,view.h/f/2);camera.x=Math.max(mx-100,Math.min(W-mx+100,camera.x));camera.y=Math.max(my-100,Math.min(H-my+100,camera.y));}
function zoom(mult,x=view.w/2,y=view.h/2){const before=worldPoint(x,y);camera.z=Math.max(.9,Math.min(12,camera.z*mult));const after=worldPoint(x,y);camera.x+=before.x-after.x;camera.y+=before.y-after.y;clampCamera();}
function resize(){const r=canvas.getBoundingClientRect();view={w:r.width,h:r.height,dpr:Math.min(2,devicePixelRatio||1)};canvas.width=Math.round(r.width*view.dpr);canvas.height=Math.round(r.height*view.dpr);clampCamera();}
function terrainDraw(){}
function renderSpeech(n,q,scale){const speech=n.stageLocal?.speech;if(!speech||speech.until<=game.s.t||activeSpeech>=2||camera.z<1.6)return;activeSpeech++;const words=speech.text.length>52?speech.text.slice(0,50)+'…':speech.text;const lines=words.length>28?[words.slice(0,28),words.slice(28)]:[words],width=Math.min(view.w-30,Math.max(...lines.map(x=>{ctx.font='10px Thai,sans-serif';return ctx.measureText(x).width}))+20),x=Math.max(8,Math.min(view.w-width-8,q.x-width/2)),y=Math.max(8,q.y-58*scale-lines.length*7);ctx.fillStyle='#f3efddeF';ctx.strokeStyle='#688875';ctx.lineWidth=1;ctx.beginPath();ctx.roundRect(x,y,width,lines.length*16+8,7);ctx.fill();ctx.stroke();ctx.fillStyle='#304e44';ctx.textAlign='center';ctx.font='10px Thai,sans-serif';lines.forEach((line,i)=>ctx.fillText(line,x+width/2,y+15+i*16));}
function draw(){if(!game)return;const s=game.s,f=factor();activeSpeech=0;mapClusters=[];pickPositions=ink.render(game,{view,camera,f,selected,labels,screenPoint});
 for(const n of [...game.heroes,...game.visitors]){const q=pickPositions.get(n.id);if(q&&n.core&&labels)renderSpeech(n,q,Math.max(.45,Math.min(1,f*1.8)));}
 if(placement&&preview){const q=screenPoint(preview),size=B[placement].size*f,valid=!game.footprint(placement,preview.x,preview.y);ctx.strokeStyle=valid?'#ffed9d':'#f3a291';ctx.fillStyle=valid?'#f9dfa154':'#ca694054';ctx.lineWidth=2;ctx.fillRect(q.x-size/2,q.y-size/2,size,size);ctx.strokeRect(q.x-size/2,q.y-size/2,size,size);ctx.beginPath();ctx.arc(q.x,q.y,4,0,7);ctx.fill();}
 const len=500*f;$('.ruler i').style.width=Math.min(view.w*.3,len)+'px';$('#scaleLabel').textContent=Math.round(Math.min(view.w*.3,len)/f)+' ม.';
 ink.minimap(mc,game);for(const n of [...game.heroes,...game.visitors].filter(alive)){const p=n.stageLocal;if(p.offmap)continue;mc.fillStyle=p.visitor?'#dfbb63':'#d4eaf0';mc.beginPath();mc.arc(p.x/W*156,p.y/H*117,2,0,7);mc.fill();}mc.strokeStyle='#f7e4ab';mc.lineWidth=1;mc.strokeRect((camera.x-view.w/f/2)/W*156,(camera.y-view.h/f/2)/H*117,view.w/f/W*156,view.h/f/H*117);
}
function applyUiTheme(){const th=ink?.settings?.uiTheme||'sonnet';if(typeof document!=='undefined'&&document.body?.setAttribute)document.body.setAttribute('data-ui-theme',th);}
function sBar(label,v,max=100,customCol=null,txt=null){const pct=Math.max(0,Math.min(100,(Number(v)||0)/Math.max(1,max)*100));const col=customCol||(pct>=71?'#5fd38a':pct>=45?'#4fb2f2':pct>=30?'#f0cf4a':'#e0584a');return `<div class="sonnet-bar"><span class="lb">${escape(label)}</span><div class="tr"><div class="fl" style="width:${pct}%;background:${col}"></div></div><b class="vl">${txt!==null?escape(txt):Math.round(v||0)}</b></div>`;}
function renderArtSettings(){applyUiTheme();titleAndBody('ภาพและบรรยากาศ',`<div class="art-intro"><span>DUAL THEME ENGINE · v2.10</span><h3>สลับธีม UI และกราฟิกแผนที่</h3><p>เลือกใช้ธีมได้ทั้ง <b>ธีม Claude Sonnet 5.5 (Dark Slate · แผนที่ตารางลานหิน · บับเบิลกิจกรรม · แถบสี)</b> และ <b>ธีมดั้งเดิม Living Ink (ภาพวาดหมึกจีนและกระดาษโบราณ)</b></p></div><label class="art-setting">ธีมหน้าจอและแผนที่ (UI & Map Theme)<select data-art-setting="uiTheme"><option value="sonnet" ${(ink.settings.uiTheme||'sonnet')==='sonnet'?'selected':''}>🌙 ธีม Claude Sonnet 5.5 (Dark Slate · แผนที่ตารางลานหิน · แถบสถานะสี)</option><option value="classic" ${ink.settings.uiTheme==='classic'?'selected':''}>📜 ธีมดั้งเดิม Living Ink (ภาพวาดหมึกจีนดั้งเดิม)</option></select></label><label class="art-setting">รายละเอียดฉาก<select data-art-setting="quality"><option value="rich" ${ink.settings.quality==='rich'?'selected':''}>จัดเต็ม · พื้นผิว แสง กลีบดอกไม้</option><option value="light" ${ink.settings.quality==='light'?'selected':''}>เบาสบาย · ลดภาระเครื่อง</option></select></label><label class="art-setting">การเคลื่อนไหว<select data-art-setting="motion"><option value="on" ${ink.settings.motion?'selected':''}>เปิด</option><option value="off" ${!ink.settings.motion?'selected':''}>ลดการเคลื่อนไหว</option></select></label><label class="art-setting">แสงตามเวลา<select data-art-setting="ambience"><option value="on" ${ink.settings.ambience?'selected':''}>รุ่งเช้า · กลางวัน · กลางคืน</option><option value="off" ${!ink.settings.ambience?'selected':''}>แสงกลางวันคงที่</option></select></label><label class="art-setting">ป้ายบนแผนที่<select data-art-setting="labels"><option value="smart" ${ink.settings.labels==='smart'?'selected':''}>พอดีสายตา · ตามระดับซูม</option><option value="all" ${ink.settings.labels==='all'?'selected':''}>ป้ายสถานที่ทั้งหมด</option><option value="none" ${ink.settings.labels==='none'?'selected':''}>ชมฉากอย่างเดียว</option></select></label><div class="banner"><b>ชมวิถีแห่งผู้ฝึกตนใกล้ ๆ</b><p>แตะที่ตัวศิษย์เพื่อดูป้ายสถานะ (Keywords) วิถีบ่มเพาะ และวิชาที่กำลังฝึกฝน</p></div>`);}

function close(){tab=null;$('#sheet').hidden=true;$('#shade').hidden=true;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('active',b.dataset.panel==='map'));}
function open(name){if(name==='map'){close();return;}tab=name;$('#sheet').hidden=false;$('#shade').hidden=false;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('active',b.dataset.panel===name));renderPanel();}
function combatEntity(id){return game?.world.npcs[id]||game?.s.beasts.find(n=>n.id===id)||game?.s.realm.pets.find(n=>n.id===id);}
function openCombatStats(id){combatEntityId=id;open('combatStats');$('#content').scrollTop=0;}
function withCombatStatsLinks(html){return html.replace(/(<button data-realm-focus="([^"]+)")/g,(button,_prefix,id)=>game.s.realm.pets.some(n=>n.id===id)?`<button data-combat-entity="${escape(id)}">คุณสมบัติต่อสู้</button>`+button:button);}
function meter(v,color=''){return `<div class="meter ${color}"><i style="width:${Math.max(0,Math.min(100,v))}%"></i></div>`;}
function morph(a,b){for(const attr of [...a.attributes||[]])if(a.id!=='content'&&attr.name!=='open'&&attr.name!=='data-confirmed'&&!b.hasAttribute(attr.name))a.removeAttribute(attr.name);for(const attr of [...b.attributes||[]])if(a.getAttribute(attr.name)!==attr.value)a.setAttribute(attr.name,attr.value);const saved=a.tagName==='SELECT'?a.value:null;const incoming=[...b.childNodes];for(let i=0;i<incoming.length;i++){const next=incoming[i],old=a.childNodes[i];if(!old){a.appendChild(next.cloneNode(true));continue;}if(old.nodeType!==next.nodeType||old.nodeName!==next.nodeName){a.replaceChild(next.cloneNode(true),old);continue;}if(old.nodeType===3){if(old.textContent!==next.textContent)old.textContent=next.textContent;}else if(!old.hasAttribute('data-confirmed'))morph(old,next);}while(a.childNodes.length>incoming.length)a.lastChild.remove();if(saved!==null&&[...a.options].some(o=>o.value===saved))a.value=saved;}
function titleAndBody(title,html){$('#sheetTitle').textContent=title;const scroll=$('#content').scrollTop;const temp=document.createElement('div');temp.innerHTML=html;morph($('#content'),temp);$('#content').scrollTop=scroll;}
function describe(n){if(!alive(n))return 'สิ้นชีพถาวร';const p=n.stageLocal;if(p.externalMerchant){const phase=p.externalMerchantPhase||'OFFMAP';return ({APPROACHING:'คาราวานกำลังเดินทางเข้าตลาด',TRADING:'ตั้งร้านและเปิดซื้อขาย',DEPARTING:'นำสินค้าเดินทางกลับตลาดภายนอก',OFFMAP:'อยู่ระหว่างการค้าภายนอก'})[phase]||'พ่อค้าคาราวาน';}if(p.offmap)return 'กำลังท่องแดนลับนอกด่าน';if(p.envoy)return ({arriving:'เดินทางมาเยือนตลาด',waiting:'รอเจรจาไมตรีที่ตลาด',leaving:'กำลังเดินทางกลับสำนัก',away:'กลับสำนักแล้ว',dead:'เสียชีวิต'})[p.envoy.phase];if(p.visitor&&game.s.life.story?.actorId===n.id)return SectLifeView.phaseNames[game.s.life.story.phase]||p.goal;const label=actionLabel(p.action)||(p.action?.startsWith('bounty:')?'ปฏิบัติภารกิจค่าหัว':'กำลังใคร่ครวญมรรคา');return (p.mode==='travel'?'มุ่งหน้า · ':p.mode==='combat'?'ปะทะเดือด · ':'')+label;}
function renderNpcKeywords(n,limit=4){
 const fn=window.JianghuExpansionV112?.computeNpcStatusKeywords;
 if(typeof fn!=='function')return '';
 const tags=fn(n).slice(0,limit);
 if(!tags.length)return '';
 return `<div class="life-tags" style="margin-top:4px">${tags.map(t=>`<span class="tag" style="border-color:${t.color};color:${t.color};font-size:11px">${escape(t.labelTh)}</span>`).join('')}</div>`;
}
function renderEcology(){const s=game.s,eco=s.ecology;const habitatHtml=eco.habitats.map(h=>{const live=s.beasts.filter(b=>b.alive&&b.habitatId===h.id),poolIds=window.JianghuExpansionV112?.habitatPoolsV114?.[h.id]||h.pool,pool=poolIds.map(id=>E.PATCH140_DATA.BEAST_SPECIES_V140.find(b=>b.id===id)).filter(Boolean);return `<article class="card"><div class="row"><strong>🐾 ${escape(h.name)}</strong><b>${live.length}/${h.maxAlive}</b></div><p class="meta">สายพันธุ์ในถิ่นอาศัย: ${escape(pool.map(b=>b.nameTh+' (T'+b.tier+')').join(' · '))}<br>จุดเกิด ${escape(LOCS.find(l=>l.id===h.locationId)?.name||h.locationId)} · ฟื้นประชากรทุก ${h.respawnSeconds} วินาที${h.requiresBuilding&&!game.built(h.requiresBuilding)?'<br>ต้องสร้างอุทยานอสูรให้เสร็จก่อนจึงจะเกิดในเขตสำนัก':''}</p><div class="inline-actions">${live.map(b=>`<div class="c201-beast-link"><button data-combat-entity="${b.id}">${escape(b.name)}${b.variantBadgeTh?' ['+escape(b.variantBadgeTh)+']':''} · คุณสมบัติต่อสู้</button><button data-focus-beast="${b.id}" aria-label="ดู ${escape(b.name)} บนแผนที่">ดูบนแผนที่</button></div>`).join('')||'<span class="meta">กำลังฟื้นประชากร</span>'}<button data-lure-beast="${h.id}">🔥 จุดกำยาน/เหยื่อล่ออสูรหายาก</button></div></article>`;}).join('');const nodeHtml=s.nodes.map(n=>`<div class="entry"><div class="row"><b>${n.kind==='HERB'?'🌿':'⛏'} ${escape(n.nameTh)}</b><span>${Math.floor(n.qty)} / ${n.max}</span></div><div class="meta">${escape(matName(n.mat))} · ระดับ ${n.tier} · ฟื้นตัวตามเวลา · ${escape(LOCS.find(l=>l.id===n.locationId)?.name||'พื้นที่ป่า')}</div></div>`).join('');const seedHtml=Object.values(CROPS).map(c=>`<div class="entry"><div class="row"><span>${escape(c.seedName)} → ${escape(c.name)}</span><b>× ${s.seedStock[c.id]||0}</b></div><div class="row"><small>${c.growSeconds} วินาที · ผลผลิตพื้นฐาน ${c.baseYield} · ราคาเมล็ด ${c.seedCost}</small><button data-buy-seed="${c.id}">ซื้อเมล็ด 1 ชุด</button></div></div>`).join('');const gardens=s.gardenPlots.map(p=>{const b=s.buildings.find(x=>x.id===p.buildingId),c=CROPS[p.cropId],ready=!!c&&p.growth>=c.growSeconds;const options=Object.values(CROPS).map(x=>`<option value="${x.id}" ${!(s.seedStock[x.id]>0)?'disabled':''}>${escape(x.name)} · เมล็ด ${s.seedStock[x.id]||0}</option>`).join('');return `<article class="card"><div class="row"><b>แปลง ${p.slot} · ${escape(b?.remaining>0?'กำลังก่อสร้าง':b?.name||'สวนสมุนไพร')}</b><span>${c?ready?'พร้อมเก็บ':Math.floor(100*p.growth/c.growSeconds)+'%':'ว่าง'}</span></div>${c?`<p>${escape(c.name)} · ความชื้น ${Math.round(p.moisture)}% · การดูแล ${p.care||0}</p>${meter(100*p.growth/c.growSeconds,ready?'good':'')}${!ready&&p.moisture<94?`<button data-water="${p.id}">รดน้ำ +48%</button>`:''}${ready?`<button class="gold" data-harvest="${p.id}">เก็บเกี่ยว ${escape(c.name)}</button>`:''}`:`<p class="meta">เลือกเมล็ดที่มีอยู่เพื่อปลูก แปลงจะเติบโตตามเวลาจำลอง</p><div class="row"><select id="plantSelect_${p.id}">${options}</select><button data-plant="${p.id}" ${!b||b.remaining>0||!Object.values(s.seedStock).some(v=>v>0)?'disabled':''}>ปลูก</button></div>`}</article>`;}).join('');const drops=s.groundDrops.map(d=>`<div class="entry row"><span>${escape(matName(d.matId))} ×${d.count} · จาก ${escape(d.source)}</span><button data-collect-drop="${d.id}">เก็บเข้าคลัง</button></div>`).join('');titleAndBody('นิเวศและสวนสมุนไพร',`<div class="banner"><b>ระบบนิเวศมีวงจรจริง</b><p>สัตว์อสูรแต่ละจุดมีประชากรจำกัดและฟื้นตามเวลา ชิ้นส่วนจากการล่าจะเข้าคลังหรือสัมภาระ สมุนไพรป่าเก็บได้จำกัด ส่วนสวนต้องใช้เมล็ด เวลา และน้ำ</p></div><h3>แหล่งสัตว์อสูรและถิ่นอาศัย (${eco.habitats.length} จุด)</h3>${habitatHtml}<h3>สมุนไพรป่าและแหล่งแร่</h3>${nodeHtml}<h3>คลังเมล็ดพันธุ์</h3>${seedHtml}<h3>สวนสมุนไพรวิญญาณ</h3>${s.gardenPlots.length?gardens:'<div class="card"><p>ยังไม่มีสวน · สร้างสวนสมุนไพรวิญญาณก่อนเพื่อเปิดแปลงปลูก 4 แปลง</p><button class="gold" data-panel="build">ไปหน้าก่อสร้าง</button></div>'}<h3>วัตถุดิบที่ตกอยู่</h3>${drops||'<p class="meta">ไม่มีวัตถุดิบตกพื้น</p>'}<p class="meta">ศิษย์เลือกเก็บสมุนไพร ปลูก รดน้ำ เก็บเกี่ยว และเก็บของตกพื้นได้เองตามบุคลิก นโยบาย และความต้องการของสำนัก</p>`);}

function renderChronicleReport(){
 const s=game.s,exp=window.JianghuExpansionV112;
 const categories=exp?.chronicleCategoriesV112||[{id:'ALL',labelTh:'ทั้งหมด',icon:'📜'}];
 const classify=exp?.classifyChronicleEntry||(()=>'CULTIVATION');
 const formatBtns=[
  ['narrative','📜 พงศาวดารยุทธภพ'],
  ['executive','📊 สรุปบริหารสำนัก'],
  ['highlights','⚡ จุดเปลี่ยนสำคัญ']
 ].map(([id,label])=>`<button data-log-format="${id}" class="${logFormat===id?'gold':''}">${label}</button>`).join('');
 const catBtns=categories.map(c=>`<button data-log-category="${c.id}" class="${logCategory===c.id?'gold':''}">${c.icon} ${escape(c.labelTh)}</button>`).join('');

 let body=`<div class="banner"><b>หอจดหมายเหตุและรายงานสำนักเมฆาคราม (แพตช์ 2.05)</b><p>สลับมุมมองรายงานได้ 3 รูปแบบ และกรองตามหมวดหมู่เหตุการณ์จริงในหุบเขา</p></div><div class="inline-actions" style="margin-bottom:8px">${formatBtns}</div><div class="inline-actions" style="margin-bottom:12px">${catBtns}</div>`;

 if(logFormat==='executive'){
  const aliveHeroes=game.heroes.filter(alive);
  const pathCounts={};
  let totalScrolls=0,totalMastered=0;
  for(const h of aliveHeroes){
   const pName=h.jianghu.pathNameTh||h.jianghu.path;
   pathCounts[pName]=(pathCounts[pName]||0)+1;
   totalScrolls+=(h.jianghu.ledgerV140?.scrolls?.length||0);
   totalMastered+=Object.values(h.jianghu.knowledgeV190||{}).filter(k=>k.stage>=4).length;
  }
  const libCount=s.growth?.scriptureLibrary?.length||0;
  const activeFortunes=s.realm?.fortunes?.filter(f=>!f.claimed&&f.expiresAt>s.t).length||0;
  const claimedFortunes=s.realm?.fortunes?.filter(f=>f.claimed).length||0;
  body+=`<article class="card"><h3>1. สถานะกำลังพลและมรรคาบ่มเพาะ</h3><p>ศิษย์มีชีวิต ${aliveHeroes.length} / ${game.capacity()} คน · ทะลวงขอบเขตสำเร็จ ${s.stats.breakthroughs} ครั้ง</p><div class="life-tags">${Object.entries(pathCounts).map(([k,v])=>`<span class="tag">${escape(k)}: ${v} คน</span>`).join('')||'<span class="tag">ยังไม่มีศิษย์</span>'}</div></article>`;
  body+=`<article class="card"><h3>2. มรดกคัมภีร์และหอสืบทอด</h3><p>หอคัมภีร์ส่วนรวม: <b>${libCount} / 120 ม้วน</b> · คัมภีร์ในสัมภาระศิษย์: <b>${totalScrolls} ม้วน</b> · วิชาที่ตีความแจ้งกระจ่างแล้วรวม <b>${totalMastered} แขนง</b></p></article>`;
  body+=`<article class="card"><h3>3. โชควาสนา แดนลับ และศึกยุทธภพ</h3><p>จุดวาสนาที่กำลังปรากฏ: <b>${activeFortunes} จุด</b> (ค้นพบแล้ว ${claimedFortunes} ครั้ง) · ปราบศัตรูและอสูร: <b>${s.stats.kills} ครั้ง</b> · หลอมโอสถและศาสตราสำเร็จ: <b>${s.stats.crafted} ชิ้น</b> · คาราวานการค้าสำเร็จ: <b>${s.stats.trades} เที่ยว</b></p></article>`;
 }

 const filtered=s.log.filter(r=>logCategory==='ALL'||classify(r.text)===logCategory);
 const list=logFormat==='highlights'
  ? filtered.filter(r=>/ทะลวง|คัมภีร์|วาสนา|แดนลับ|ปราบ|สำเร็จ|เข้าสำนัก|สร้าง.*เสร็จ|Edit Hub/.test(r.text))
  : filtered;

 const catMeta=Object.fromEntries(categories.map(c=>[c.id,c]));
 body+=`<h3>รายการบันทึก (${list.length} เหตุการณ์)</h3>`+(list.map(r=>{
  const catId=classify(r.text);
  const cm=catMeta[catId]||catMeta.ALL;
  return `<div class="entry"><div class="row"><small>วันที่ ${Math.floor(r.t/DAY)+1} · ${r.t} วิ</small><span class="tag" style="font-size:10px">${cm?.icon||'📜'} ${escape(cm?.labelTh||catId)}</span></div><p style="margin:4px 0 0">${escape(r.text)}</p></div>`;
 }).join('')||'<p class="meta">ยังไม่มีเหตุการณ์ในหมวดนี้</p>');

 titleAndBody('บันทึกหุบเขาและรายงานสำนัก',body);
}



function renderSectStoreAndWorkshop(tv){
 const C=window.JianghuSectContributions;if(!C)return '';
 const pts=C.inspect(game);
 const store=pts.storeInventory||{all:[],pills:[],equipment:[],scrolls:[],materials:[]};
 const treas=pts.treasuryInventory||{all:[],pills:[],equipment:[],scrolls:[],materials:[]};
 const fly=pts.flywheel||{marketHeat:20,marketHeatLabelTh:'',supplyBounties:[],bonusByCategory:{}};
 const heroes=game.heroes.filter(alive);
 const buyerOpts=heroes.map(h=>{const bal=C.account(game,h).balance;return `<option value="${escape(h.id)}" ${selected===h.id?'selected':''}>${escape(h.name)} (มี ${bal} แต้ม · ${escape(h.jianghu?.subPathNameTh||'')})</option>`;}).join('');
 const marketBuyerId=heroes.some(h=>h.id===marketMemberId)?marketMemberId:(heroes.some(h=>h.id===selected)?selected:heroes[0]?.id||'');
 const marketBuyer=game.world?.npcs?.[marketBuyerId],memberOpts=heroes.map(h=>`<option value="${escape(h.id)}" ${h.id===marketBuyerId?'selected':''}>${escape(h.name)} · ${fmt(E.getSpiritStonesV140(h))} หินวิญญาณ</option>`).join('');
 const pulse=pts.marketPulse||{overallIndex:100,signals:[]};
 let out=`<article class="card" style="border-left:3px solid #f0cf4a"><div class="row"><strong>🔥 วงล้อเศรษฐกิจสำนัก &amp; ความคึกคักร้านค้าสำนัก</strong><span class="tag" style="border-color:#f0cf4a;color:#f0cf4a">ความคึกคัก ${fly.marketHeat}/100</span></div><p style="margin:4px 0"><b>${escape(fly.marketHeatLabelTh)}</b> · ศิษย์มีเป้าหมายใช้แต้ม <b>${fly.activeShoppers||0} คน</b> (กำลังขยันหาแต้มเพิ่ม <b>${fly.hungryForPoints||0} คน</b>)</p><p class="meta">หลักเศรษฐศาสตร์สำนัก: สินค้าทุกชิ้นในคลังและร้านค้าสำนักมาจากศิษย์ที่ออกไปเก็บสมุนไพร ล่าอสูร หรือหลอมสร้างขึ้นจริง (ไม่เสกจากอากาศ) ยิ่งร้านค้ามีของดี ศิษย์ยิ่งต้องการแต้มคุณูปการ และเมื่อมีคนซื้อสินค้า ผู้ที่จัดหาหรือหลอมสินค้านั้นจะได้รับ <b>ปันผลผู้สร้างผลงาน +12%</b> เป็นแต้มคุณูปการเพิ่มด้วย!</p><div class="grid" style="margin-top:6px">${(fly.supplyBounties||[]).map(b=>`<div class="entry"><div class="row"><b>📦 ${escape(b.labelTh)}</b><span class="good">โบนัสจัดหาสูงสุด +${b.bonusPct}%</span></div><small class="meta">${escape(b.reasonTh)}</small></div>`).join('')}</div></article>`;

 const point=pts.pointEconomy||{issued:0,retired:0,circulating:0};
 out+=`<article class="card"><h3>บัญชีแต้มคุณูปการของสำนัก</h3><p>ออกแต้มสะสม <b>${point.issued}</b> · หักออกเมื่อซื้อ <b>${point.retired}</b> · อยู่ในมือศิษย์ <b>${point.circulating}</b></p><p class="meta">แต้มเป็นสิทธิ์แลกของที่สำนักออกให้จากพัสดุและผลงานจริง เมื่อซื้อของ แต้มที่จ่ายจะถูกหักออกจากระบบ ส่วนปันผลผู้จัดหาบันทึกเป็นแต้มออกใหม่ โบนัสจัดหามีเพดานเพื่อให้ซื้อแล้วบริจาควนไม่ได้กำไร</p></article>`;
 const ext=pts.externalTrade||{offers:[],purchaseOrders:[],sales:[]};
 const visit=ext.visitState||null,phaseLabels={APPROACHING:'กำลังเดินทางเข้าตลาด',TRADING:'ตั้งร้าน · ซื้อขายได้',DEPARTING:'กำลังขนสินค้าออกจากหุบเขา',OFFMAP:'อยู่นอกหุบเขา · รอรอบถัดไป'};
 const marketOpen=!visit||visit.phase==='TRADING';
 const offers=(ext.offers||[]).filter(o=>marketOpen&&o.status==='PENDING'&&game.s.t<o.expiresAt);
 const guildTag=ext.guildNameTh?`<p class="meta">🚩 ขบวนคาราวานรอบนี้: <b>${escape(ext.guildNameTh)}</b>${ext.guildSpecialtyTh?` (${escape(ext.guildSpecialtyTh)})`:''}</p>`:'';
 const regional=ext.regionalMarket||{},regionalStocks=regional.stock||{},materialRegional=Object.values(regionalStocks.MATERIAL||{}).reduce((a,b)=>a+(Number(b)||0),0),pillRegional=Object.values(regionalStocks.PILL||{}).reduce((a,b)=>a+(Number(b)||0),0);
 const caravanTag=visit?`<p class="meta">🚚 สถานะคาราวาน: <b>${phaseLabels[visit.phase]||visit.phase}</b>${visit.merchantId&&game.world.npcs[visit.merchantId]?` · ${escape(game.world.npcs[visit.merchantId].name)}`:''}${visit.phase==='TRADING'?` · เก็บร้านใน ${Math.max(0,Math.ceil(visit.departAt-game.s.t))} วินาที`:''}</p>`:`<p class="meta">🚚 ยังไม่มีคาราวานในพื้นที่ · รอบถัดไป ${Math.max(0,Math.ceil((ext.nextVisitAt||game.s.t)-game.s.t))} วินาที</p>`;
 const signals=(pulse.signals||[]).slice(0,3).map(x=>`${escape(x.nameTh)}: ${escape(x.status)} · สต็อก ${x.stock}/${x.target} · ดัชนี ${x.index}`).join(' | ');
 out+=`<article class="card"><div class="row"><h3>พ่อค้าคาราวานและตลาดภายนอก</h3><button data-outside-auto>จัดซื้ออัตโนมัติของสำนัก: ${ext.autoProcure?'เปิด':'ปิด'}</button></div>${guildTag}${caravanTag}<p class="meta">ทุนหมุนเวียนตลาดภายนอก <b>${fmt(regional.liquidity||0)} / ${fmt(regional.liquidityCap||3000)} หินวิญญาณ</b> · สต็อกภูมิภาค ${materialRegional} วัตถุดิบ / ${pillRegional} โอสถ · ส่งออกสะสม ${fmt(regional.totalExports||0)} หน่วย (${fmt(regional.totalExportStones||0)} หินวิญญาณ) · เงินทุนและสินค้าในตลาดภายนอกมีขีดจำกัดและเติมตามรอบผลิตจริง<br>เงินกองกลางสำนัก <b>${fmt(game.gold)} หินวิญญาณ</b> · ราคาคาราวานปรับตามสต็อกจริง ความต้องการสูตรผลิต ความเสี่ยงเส้นทาง และความสัมพันธ์กับกิลด์ · ${signals||'ตลาดกำลังรวบรวมข้อมูลอุปทาน'}${game.routeBlocked()?' · เส้นทางถูกปิด พ่อค้ายังส่งสินค้าไม่ได้':''}</p><div class="row" style="margin:8px 0"><label>ศิษย์ที่จะซื้อ/ขายกับคนนอก: <select id="externalMemberSelect">${memberOpts}</select></label><button data-member-trade-auto>ซื้อขายอัตโนมัติของศิษย์: ${ext.autoMemberTrade!==false?'เปิด':'ปิด'}</button></div><p class="meta">กติกาเงินแยกบัญชี: <b>ศิษย์ซื้อขายกันเองในสำนักใช้แต้มคุณูปการ</b> · <b>สำนักกับคนนอกใช้หินวิญญาณกองกลาง</b> · <b>ศิษย์ซื้อ/ขายกับคนนอกใช้หินวิญญาณส่วนตัว</b> ไม่มีการแปลงแต้มคุณูปการเป็นหินวิญญาณ</p>`;
 out+=offers.length?offers.map(o=>{const one=window.JianghuSectContributions?.quoteMemberExternalOffer(game,marketBuyerId,o.id,1)||{ok:false,reason:'เลือกศิษย์ก่อน'},all=window.JianghuSectContributions?.quoteMemberExternalOffer(game,marketBuyerId,o.id)||{ok:false,reason:'เลือกศิษย์ก่อน'};return `<div class="entry"><div class="row"><b>${escape(o.nameTh)} ×${o.quantity}</b><strong>${o.totalStones} หินวิญญาณ/ชุด</strong></div><small class="meta">${escape(o.sellerNameTh)}${o.guildNameTh?` (${escape(o.guildNameTh)})`:''} · ${o.unitStones} หินวิญญาณ/ชิ้น · เสนอขายอีก ${Math.ceil(o.expiresAt-game.s.t)} วินาที</small><div class="inline-actions"><button class="gold" data-outside-buy="${escape(o.id)}" ${game.gold<o.totalStones?'disabled':''}>${o.kind==='SCROLL'?'สำนักรับเข้าหอคัมภีร์':'สำนักรับเข้าคลัง'} · ${o.totalStones} ศิลา</button><button data-member-outside-buy="${escape(o.id)}:1" ${one.ok?'':'disabled'}>ศิษย์ซื้อ 1 หน่วย · ${one.stones??'—'} ศิลา</button>${o.quantity>1?`<button data-member-outside-buy="${escape(o.id)}:all" ${all.ok?'':'disabled'}>ศิษย์ซื้อทั้งชุด · ${all.stones??'—'} ศิลา</button>`:''}<button data-outside-reject="${escape(o.id)}">ปฏิเสธข้อเสนอของสำนัก</button></div>${one.ok?'':`<small class="meta">บัญชี ${escape(marketBuyer?.name||'ศิษย์')}: ${escape(one.reason||'')}</small>`}</div>`;}).join(''):`<p class="meta">ยังไม่มีข้อเสนอที่เปิดอยู่ คาราวานจะเข้ามาตามรอบเมื่อเส้นทางปลอดภัย</p>`;
 if(ext.history?.length)out+=`<details><summary>ประวัติซื้อจากคนนอก (${ext.history.length})</summary>${ext.history.slice(0,8).map(o=>`<p class="meta">${escape(o.sellerNameTh)} · ${escape(o.nameTh)} ×${o.quantity} · จ่าย ${o.totalStones} หินวิญญาณ</p>`).join('')}</details>`;
 out+='</article>';
 const pOrders=(ext.purchaseOrders||ext.orders||[]).filter(o=>marketOpen&&o.status==='OPEN'&&game.s.t<o.expiresAt);
 out+=`<article class="card"><div class="row"><h3>📜 ใบสั่งซื้อจากคนนอก (สำนักหรือศิษย์ขายของ รับหินวิญญาณ)</h3><button data-outside-sell-auto>ขายส่วนเกินอัตโนมัติ: ${ext.autoSell!==false?'เปิด':'ปิด'}</button></div><p class="meta">พ่อค้ารับซื้อวัตถุดิบ/โอสถสามัญจากคลังสำนักหรือสัมภาระศิษย์ โดยแต่ละทางมีเกณฑ์สำรองของตัวเอง · เงินและโควตารับซื้อของพ่อค้ามีจำกัดและใช้ร่วมกัน · ห้ามขายศาสตรา/คัมภีร์หรือของหายาก · มีโบนัสพิเศษเฉพาะโควตาหน่วยแรกของแต่ละใบสั่งซื้อ</p>`;
 out+=pOrders.length?pOrders.map(o=>{
  const q=o.quote||window.JianghuSectContributions?.quotePurchaseOrder(game,o.id)||{};
  const q1=window.JianghuSectContributions?.quotePurchaseOrder(game,o.id,1)||{};
  const mq=window.JianghuSectContributions?.quotePersonalPurchaseOrder(game,marketBuyerId,o.id)||{};
  const mq1=window.JianghuSectContributions?.quotePersonalPurchaseOrder(game,marketBuyerId,o.id,1)||{};
  const rem=Math.max(0,o.wantQuantity-(o.filled||0));
  const bLeft=Math.max(0,(o.bonusQuota||0)-(o.filled||0));
  const resText=(q.reserveReasons||[]).join(' · ')||`สำรองขั้นต่ำ ${q.reserve||0}`;
  return `<div class="entry"><div class="row"><b>${escape(o.nameTh)} (รับซื้อ ${o.filled||0}/${o.wantQuantity} หน่วย · เหลือ ${rem})</b><strong class="good">${o.unitStones} หินวิญญาณ/หน่วย${bLeft>0?` (+${o.bonusPerUnit||1} โบนัสโควตาแรกอีก ${bLeft} หน่วย)`:' (ครบโควตาโบนัสแล้ว)'}</strong></div><small class="meta">ผู้รับซื้อ: ${escape(o.buyerNameTh)}${o.guildNameTh?` · ${escape(o.guildNameTh)}`:''} · สต็อกคลังรวม <b>${q.totalStock??0}</b> · ต้องกันสำรอง <b>${q.reserve??0}</b> (${escape(resText)}) · ส่วนเกินขายได้ <b>${q.surplusQty??0}</b> หน่วย</small><div class="inline-actions" style="margin-top:4px"><button class="gold" data-outside-sell="${escape(o.id)}:1" ${q1.ok?'':'disabled'}>ขาย 1 หน่วย (+${q1.stones||(o.unitStones+(bLeft>0?(o.bonusPerUnit||0):0))} หินวิญญาณ)</button><button data-outside-sell="${escape(o.id)}:max" ${q.ok&&q.maxSellable>0?'':'disabled'}>สำนักขายส่วนเกิน ×${q.maxSellable||0} (+${q.stones||0} ศิลา)</button><button data-member-outside-sell="${escape(o.id)}:1" ${mq1.ok?'':'disabled'}>ศิษย์ขาย 1 หน่วย (+${mq1.stones||0} ศิลา)</button><button data-member-outside-sell="${escape(o.id)}:max" ${mq.ok&&mq.maxSellable>0?'':'disabled'}>ศิษย์ขายส่วนเกิน ×${mq.maxSellable||0} (+${mq.stones||0} ศิลา)</button></div><small class="meta">ศิษย์ที่เลือก ${escape(marketBuyer?.name||'—')}: มีส่วนเกิน ${mq.totalStock??0} · เก็บไว้ ${mq.reserve??0} · ขายได้สูงสุด ${mq.maxSellable||0} หน่วย</small></div>`;
 }).join(''):`<p class="meta">ยังไม่มีใบสั่งซื้อที่เปิดอยู่ หรือรับซื้อครบจำนวนในรอบนี้แล้ว</p>`;
 if(ext.sales?.length)out+=`<details><summary>ประวัติขายของส่วนเกินให้คนนอก (${ext.sales.length})</summary>${ext.sales.slice(0,8).map(s=>`<p class="meta">${escape(s.sellerNameTh||s.authorityNameTh||'ผู้ดูแลคลัง')} ${s.sellerType==='DISCIPLE'?'ขายของส่วนตัว':'ขายของส่วนเกินสำนัก'} «${escape(s.nameTh)}» ×${s.quantity} ให้ ${escape(s.buyerNameTh)} · รับ +${s.stones} หินวิญญาณ${s.bonusStones?` (รวมโบนัสโควตา +${s.bonusStones})`:''}</p>`).join('')}</details>`;
 out+='</article>';
 out+=`<article class="card"><h3>🏪 ร้านค้าสำนัก (Sect Store · ใช้แต้มคุณูปการซื้อสินค้าที่ศิษย์หามาหรือผลิตขึ้น)</h3><p class="meta">ผู้อาวุโสฝ่ายคลัง (<b>${escape(tv?.distributorName||'ผู้ดูแลคลัง')}</b>) คัดแยกสินค้าจากคลังสำนักมาวางจำหน่ายในร้านค้าสำนัก ราคาสมเหตุสมผลตามระดับ (T1–T7), สีคุณภาพ (เทา/ขาว/เขียว/ฟ้า/ม่วง/ทอง/แดง) และประเภท (วัตถุดิบสีม่วงถูกกว่าโอสถและศาสตราสีม่วงที่คราฟเสร็จแล้วเสมอ)</p><div class="row" style="margin:8px 0"><label>ผู้ซื้อสินค้า: <select id="storeBuyerSelect">${buyerOpts}</select></label><button class="gold" data-treasury-action="curate-store">🏪 ให้ผู้อาวุโสจัดของจากคลังขึ้นร้านค้าสำนัก</button></div>`;
 if(store.all.length){
  out+=store.all.map(it=>{
   const wantedText=(it.wantedBy||[]).length?` · 🎯 ศิษย์เล็งซื้อ: ${it.wantedBy.map(w=>escape(w.name)+(w.canAfford?' (แต้มพอ)':' (ขาด '+w.deficit+' แต้ม)')).join(', ')}`:'';
   return `<div class="entry"><div class="row"><b><span style="color:${it.colorHex}">●</span> [${escape(it.categoryNameTh)} · T${it.tier} · ${escape(it.colorNameTh)}] ${escape(it.nameTh)} ×${it.count}</b><strong style="color:#f0cf4a">${it.unitStorePrice} แต้ม/ชิ้น</strong></div><small class="meta">ที่มา: <b>${escape(it.suppliedByNameTh)}</b> (${escape(it.originLabelTh)}) · มูลค่าบริจาคฐาน ${it.unitDonation} แต้ม${wantedText}</small><div class="inline-actions" style="margin-top:4px"><button class="gold" data-store-buy="${escape(it.kind)}:${escape(it.id)}">🛒 ใช้แต้มซื้อ (${it.unitStorePrice} แต้ม)</button><button data-return-to-treasury="${escape(it.kind)}:${escape(it.id)}">↩ ย้ายกลับคลังสวัสดิการ 1 ชิ้น</button></div></div>`;
  }).join('');
 }else{
  out+=`<p class="meta">ยังไม่มีสินค้าบนชั้นวางร้านค้าสำนัก กดปุ่ม «🏪 ให้ผู้อาวุโสจัดของจากคลังขึ้นร้านค้าสำนัก» หรือให้ศิษย์หลอมโอสถ/ส่งมอบวัตถุดิบเข้าคลังก่อน</p>`;
 }
 out+=`</article>`;

 out+=`<article class="card"><h3>🏛️ คลังสำนัก (Sect Treasury · สำรองแจกฟรีพื้นฐาน &amp; วัตถุดิบสำหรับโรงหลอมสำนัก)</h3><p class="meta">ของที่ศิษย์หามาจากหุบเขาหรือหลอมให้สำนักจะเข้าคลังสำนักก่อน ผู้อาวุโสจะเก็บสำรองโอสถฟื้นฟูระดับต่ำไว้แจกฟรีให้ศิษย์ที่จำเป็น (โควตา 4 หน่วย/วัน) และเก็บสมุนไพร/แร่ไว้ให้ศิษย์เบิกใช้ในโรงหลอมสำนัก ส่วนที่เกินสำรองสามารถส่งขึ้นร้านค้าสำนักได้</p>`;
 if(treas.all.length){
  out+=treas.all.map(it=>`<div class="entry"><div class="row"><b><span style="color:${it.colorHex}">●</span> [${escape(it.categoryNameTh)} · T${it.tier}] ${escape(it.nameTh)} ×${it.count}</b><span>${it.grantEligible?'✓ แจกฟรีพื้นฐานได้':'สงวนสำหรับร้านค้า/โรงหลอม'}</span></div><small class="meta">ที่มา: ${escape(it.suppliedByNameTh)} · ราคาหากขึ้นร้านค้า ${it.unitStorePrice} แต้ม/ชิ้น</small><div class="inline-actions" style="margin-top:4px"><button data-transfer-to-store="${escape(it.kind)}:${escape(it.id)}">🏪 ส่งขึ้นขายที่ร้านค้าสำนัก 1 ชิ้น</button></div></div>`).join('');
 }else{
  out+=`<p class="meta">ขณะนี้พัสดุทั้งหมดถูกจัดขึ้นร้านค้าสำนักแล้ว</p>`;
 }
 out+=`</article>`;

 const lessons=game.s.growth.scriptureLibrary||[];
 out+=`<article class="card"><h3>หอคัมภีร์สำนัก · เรียนวิชาด้วยแต้มคุณูปการ</h3><p class="meta">วิชาพื้นฐานประจำสำนักเรียนฟรี วิชาอื่นชำระค่าเรียนครั้งเดียวต่อคนต่อวิชา ตามระดับคัมภีร์ จากนั้นต้องอ่านและฝึกตามปกติ คัมภีร์ยังอยู่ส่วนกลางให้ผู้อื่นเรียนได้ · ความจุ ${lessons.length}/${window.JianghuSectLibrary?.capacity(game)||120} ม้วน</p>`;
 out+=lessons.length?lessons.map(book=>{const learner=heroes.find(h=>h.id===selected)||heroes[0],q=window.JianghuSectLibrary?.quote(game,learner,book.artId),fits=heroes.filter(h=>window.JianghuSectLibrary?.quote(game,h,book.artId).ok&&!(h.jianghu.knowledgeV190[book.artId]?.stage>=4));return `<div class="entry"><div class="row"><b>${escape(book.nameTh||q?.nameTh)} · T${q?.tier||book.tier||1}</b><strong>${q?.basic?'พื้นฐาน · เรียนฟรี':'ค่าเรียนฐาน '+(q?.baseFee||0)+' แต้ม'}</strong></div><small class="meta">เหมาะกับ: ${fits.map(h=>escape(h.name)).join(', ')||'ยังไม่มีศิษย์ที่พร้อมเรียน'} · ที่มา ${escape(book.suppliedByNameTh||book.originLabelTh||'มรดกสำนัก')}</small><div class="inline-actions"><button data-library-study="${escape(book.artId)}" ${game.built('shrine')?'':'disabled'}>ให้ศิษย์ที่เลือกด้านบนเดินไปศึกษา</button></div></div>`;}).join(''):'<p class="meta">รอศิษย์สืบทอดคัมภีร์ หรือผู้อาวุโสหอคัมภีร์รับซื้อจากคนนอก</p>';
 out+='</article>';

 out+=`<article class="card"><h3>⚗️ โรงหลอมสำนัก (หลอมโอสถและศาสตราให้สำนัก · ใช้ทรัพยากรคลังสำนัก แลกแต้มคุณูปการ)</h3><p class="meta">ศิษย์ไม่ต้องเสียวัตถุดิบหรือหินวิญญาณส่วนตัว เพียงใช้แรงและฝีมือไปที่หอโอสถหรือโรงหลอม ใช้วัตถุดิบของคลังสำนักหลอมโอสถ/ศาสตรา โอสถที่ได้เป็นของสำนัก (เข้าคลังและร้านค้าสำนัก) และผู้หลอมได้รับแต้มคุณูปการ! สูตรพื้นฐานเรียนฟรีทุกคน ส่วนสูตรขั้นสูงอยู่ที่วาสนาของศิษย์แต่ละคน</p><div class="row" style="margin:6px 0"><label>เลือกศิษย์ลงมือหลอมให้สำนัก: <select id="sectCrafterSelect">${heroes.map(h=>`<option value="${escape(h.id)}" ${selected===h.id?'selected':''}>${escape(h.name)} (โอสถ ${Math.round(HumanCore.capacity(h,'alchemy').total)} · หลอม ${Math.round(HumanCore.capacity(h,'forging').total)} · รู้ ${(h.stageLocal?.growth?.knownRecipes||[]).length} สูตร)</option>`).join('')}</select></label></div>`;
 out+=(pts.sectWorkshopRecipes||[]).map(r=>{
  const inpLine=r.inputs.map(i=>`${escape(matName(i.matId))} ${i.inBank}/${i.count}`).join(' · ');
  return `<div class="entry"><div class="row"><b>${r.workshop==='alchemy'?'⚗️':'⚒️'} ${escape(r.nameTh)} (T${r.tier}) ${r.isFreeBasic?'<span class="tag">สูตรพื้นฐานสำนักเรียนฟรี</span>':'<span class="tag" style="border-color:#b197fc;color:#b197fc">สูตรวาสนาเฉพาะตัว</span>'}</b><strong class="good">ค่าแรง +${r.laborPoints} แต้ม</strong></div><small class="meta">วัตถุดิบคลังสำนัก: ${inpLine} · ฝีมือขั้นต่ำ ${r.minMastery} · ราคาขายในร้านค้า ${r.storePrice} แต้ม</small><div class="inline-actions" style="margin-top:4px"><button class="gold" data-sect-craft="${escape(r.id)}" ${r.hasInputs&&game.built(r.workshop)?'':'disabled'}>${!game.built(r.workshop)?'ต้องสร้าง'+(r.workshop==='alchemy'?'หอโอสถ':'โรงหลอม'):r.hasInputs?'🔥 ใช้ทรัพยากรคลังหลอมให้สำนัก (+'+r.laborPoints+' แต้ม)':'รอวัตถุดิบในคลังสำนัก'}</button></div></div>`;
 }).join('');
 out+=`</article>`;
 return out;
}

function renderObjectives(){
 const s=game.s,se=game.storyEvents?.inspect?.();
 if(!se){
  titleAndBody("เควสเนื้อเรื่อง หอคลัง และอีเวนต์ยุทธภพ","<p class=\"meta\">กำลังเตรียมระบบ...</p>");
  return;
 }
 const st=se.state||{};
 const tv=se.treasuryView||{};
 const completedArr=st.completedEpisodes||[];
 const completedNodeIds=se.completedNodeIds||[];
 const historyArr=st.history||[];
 const navBtns=[
  ["story","🌳 เนื้อเรื่องรากต้นไม้ & สภา NPC"],
  ["store","🏪 ร้านค้าสำนัก & งานผลิตสำนัก ("+(tv.storeInventory?.all?.length||0)+")"],
  ["sidequests","📜 งานย่อยสำนัก"],
  ["treasury","🏛️ หอคลัง & แจกจ่ายตามนิสัย ("+(tv.requisitions?.length||0)+")"],
  ["events","⚡ อีเวนต์ & ผลพวงจริง ("+(se.allDynamicEvents?.length||0)+")"],
  ["pools","🐾 พูลอสูร & เกณฑ์ 5 วิถี"],
  ["history","📖 ประวัติ ("+(historyArr.length+completedNodeIds.length)+")"]
 ].map(([id,label])=>`<button data-quest-tab="${id}" class="${questTab===id?"gold":""}">${label}</button>`).join("");

 const ep=se.epDef;
 const activeEv=se.activeDynamicEvent;
 const allCompleted=se.epPhase==="ALL_COMPLETED";
 let html=`<div class="banner"><b>🌳 เควสเนื้อเรื่องรากต้นไม้ (NPC ตัดสินใจ) · 🏛️ หอคลังสำนักตามนิสัย NPC · ⚡ อีเวนต์ผลพวงจริง</b><p>เควสเนื้อเรื่องแตกกิ่งก้านตามการโหวตของ NPC ในสำนัก (${(se.allStoryNodes||[]).length} กิ่งเนื้อเรื่อง EP.1–8) · ระบบคลังสำนักที่เจ้าสำนักแต่งตั้งผู้ดูแลหรือตัดสินใจเองตามนิสัยและสายสัมพันธ์ · อีเวนต์ยุทธภพที่มอบไอเทมจริงและทิ้งผลพวงต่อเนื่อง</p></div><div class="inline-actions" style="margin-bottom:10px">${navBtns}</div>`;

 if(activeEv){
  const remain=Math.max(0,Math.ceil((activeEv.expiresAt||s.t)-s.t));
  html+=`<article class="card" style="border:1px solid #e0a84a"><div class="row"><strong>${activeEv.icon||"⚡"} อีเวนต์ต่อเนื่องกำลังทำงาน: ${escape(activeEv.nameTh)}</strong><span class="tag" style="border-color:#e0a84a;color:#e0a84a">เหลือ ${remain} วิ</span></div><p>${escape(activeEv.situationTh||"")}</p><p class="meta">เป้าหมาย: <b>${escape(activeEv.objectiveTh||"")}</b>${(activeEv.entityIds||[]).length?` · เป้าหมายที่ยังเหลือบนแผนที่: <b>${(se.dynRemainingIds||[]).length} / ${activeEv.entityIds.length}</b>`:""}</p><div class="inline-actions"><button class="gold" data-story-action="focus-event">🎯 ดูจุดเกิดเหตุบนแผนที่</button><button data-story-action="resolve-event" ${se.canResolveDynamicEvent?"":"disabled"}>✓ รับรางวัลเมื่อสำเร็จ</button></div></article>`;
 }

 if((se.activeAftermaths||[]).length){
  html+=`<div class="card" style="border-left:3px solid #4fb2f2"><b>⏳ ผลพวงหลังจบอีเวนต์ที่กำลังส่งผลต่อค่าสถานะจริง (${se.activeAftermaths.length} รายการ)</b>${se.activeAftermaths.map(af=>`<div class="row" style="margin-top:4px"><span>${af.icon||"✨"} <b>${escape(af.nameTh)}</b> · <small class="meta">${escape(af.descTh)}</small></span><span class="tag">เหลือ ${Math.max(0,Math.ceil(af.expiresAt-(s.t||0)))} วิ</span></div>`).join("")}</div>`;
 }

 if(questTab==="story"){
  if(allCompleted){
   html+=`<article class="card"><div class="row"><strong>👑 บรรลุเควสเนื้อเรื่องรากต้นไม้ครบถึงจุดสูงสุด (EP.8) แล้ว!</strong><span class="good">สำเร็จบริบูรณ์</span></div><p>สำนักเมฆาครามก้าวขึ้นสู่มหาสำนักในตำนานตามเส้นทางที่เหล่าศิษย์ได้ร่วมกันเลือกไว้</p></article>`;
  }else if(ep){
   const passedCount=se.conditions.filter(c=>c.passed).length;
   const phaseBadge=se.epPhase==="ACTIVE_TRIAL"?"🔥 กำลังดำเนินบททดสอบเนื้อเรื่อง":"⏳ รอเงื่อนไขปลดล็อก ("+passedCount+"/"+se.conditions.length+" ข้อ)";
   html+=`<article class="card"><div class="row"><strong>📜 ${escape(ep.titleTh)}</strong><span class="tag">${escape(ep.branchBadgeTh||ep.chapterPhaseTh)}</span></div><p class="meta" style="margin:4px 0">สถานะ: <b>${phaseBadge}</b> · ${escape(ep.subtitleTh||"")}</p><p style="margin:6px 0">${escape(ep.loreTh)}</p><p class="meta">🎁 รางวัลจริงเมื่อผ่านกิ่งนี้: <b>${escape(ep.rewardSummaryTh)}</b></p>`;
   if(se.epPhase==="ACTIVE_TRIAL"){
    const totalIds=st.trialEntityIds||[];
    const aliveIds=se.remainingTrialIds||[];
    const slainCount=Math.max(0,totalIds.length-aliveIds.length);
    const isMet=aliveIds.length===0;
    const targetButtons=totalIds.map(tid=>{
     const ent=game.s.beasts.find(b=>b.id===tid)||game.world.npcs[tid];
     const isAlive=aliveIds.includes(tid);
     const tName=ent?.name||tid;
     return `<button data-focus-event-target="${escape(tid)}">${isAlive?"🎯 ":"✓ "}${escape(tName)} (${isAlive?"HP "+Math.round(ent?.health||0)+"/"+Math.round(ent?.maxHP||100):"ปราบแล้ว"})</button>`;
    }).join("");
    html+=`<div class="entry" style="margin-top:8px"><div class="row"><b>⚔️ ${escape(ep.trialTitleTh)}</b><span class="${isMet?"good":""}">${isMet?"✓ บรรลุเป้าหมายแล้ว":"ปราบแล้ว "+slainCount+" / "+totalIds.length}</span></div><p style="margin:4px 0">${escape(ep.trialDescTh)}</p>${targetButtons?`<div class="inline-actions" style="margin-top:6px">${targetButtons}</div>`:""}<div class="inline-actions" style="margin-top:8px"><button class="gold" data-story-action="complete-ep" ${se.canCompleteTrial?"":"disabled"}>${se.canCompleteTrial?"✓ รับรางวัลและให้สภาเลือกกิ่งถัดไป":"กำลังรอศิษย์ผ่านบททดสอบ"}</button></div></div>`;
   }else{
    html+=`<h3 style="margin-top:10px">เงื่อนไขทริกเกอร์เนื้อเรื่องกิ่งปัจจุบัน</h3>${se.conditions.map(c=>`<div class="entry"><div class="row"><b class="${c.passed?"good":""}">${c.passed?"✓":"○"} ${escape(c.labelTh)}</b><span>${fmt(c.current)} / ${fmt(c.target)}</span></div></div>`).join("")}<div class="inline-actions" style="margin-top:10px"><button class="gold" data-story-action="trigger-ep" ${se.allConditionsMet?"":"disabled"}>⚔️ เริ่มบททดสอบเนื้อเรื่อง</button></div>`;
   }
   html+=`</article>`;
  }

  // NPC Council Branch Decision Section
  const council=se.currentTierCouncil||se.nextCouncilPreview;
  if(council){
   const isCurrentTier=!!se.currentTierCouncil;
   html+=`<h3>🗳️ สภาศิษย์ตัดสินใจเลือกกิ่งเนื้อเรื่อง (${isCurrentTier?"มติเลือกกิ่งใน EP."+se.currentEp:"แนวโน้มการแตกกิ่งถัดไปเมื่อผ่าน EP."+se.currentEp})</h3><article class="card"><div class="row"><strong>มติเสียงข้างมากของ NPC: ${escape(council.winnerBadgeTh)}</strong><button class="gold" data-story-action="convene-branch-council">🗳️ ให้สภา NPC ลงมติเลือกกิ่งตามนิสัย</button></div><p class="meta" style="margin:4px 0">กิ่งที่ชนะโหวต: <b>${escape(council.winnerTitleTh)}</b> · คำนวณจากนิสัย ค่านิยม และวิถีบ่มเพาะของศิษย์แต่ละคนจริง</p>`;
   html+=`<div class="grid" style="margin-top:8px">${(council.tallies||[]).map(t=>{
    const isActive=se.currentNodeId===t.nodeId;
    return `<div class="entry" style="${isActive?"border:1px solid #5fd38a":""}"><div class="row"><b>${escape(t.branchBadgeTh)}</b><span>${t.voteCount} เสียง (น้ำหนัก ${t.totalWeight})</span></div><p class="meta" style="margin:3px 0">${escape(t.titleTh)}</p><div class="inline-actions"><button data-select-story-branch="${escape(t.nodeId)}" ${(se.availableBranchIds||[]).includes(t.nodeId)&&se.epPhase!=="ACTIVE_TRIAL"?"":"disabled"} class="${isActive?"gold":""}">${isActive?"✓ กิ่งที่เลือกอยู่":"🧭 สลับมากิ่งนี้"}</button></div></div>`;
   }).join("")}</div>`;
   html+=`<h4 style="margin:10px 0 4px">เหตุผลการโหวตของศิษย์แต่ละคนในสำนัก</h4>${(council.votes||[]).map(v=>`<div class="entry"><div class="row"><b>${v.pathIcon} ${escape(v.npcName)} <small class="meta">(${escape(v.roleLabelTh)} · น้ำหนักโหวต ×${v.weight})</small></b><span class="tag">${escape(v.chosenBadgeTh)} (${v.score})</span></div><small class="meta">เหตุผล: ${escape(v.reasonTh)}</small></div>`).join("")}</article>`;
  }

  if((se.doctrines||[]).length){
   html+=`<h3>🏛️ มติมรรคาสำนักถาวรที่ปลดล็อกจากกิ่งเนื้อเรื่อง (${se.doctrines.length} มติ · ส่งผลต่อค่าสถานะต่อสู้และรายได้จริง)</h3>${se.doctrines.map(d=>`<div class="entry"><div class="row"><b>${d.icon||"🏛️"} ${escape(d.nameTh)}</b><span class="tag">EP.${d.ep}</span></div><p class="meta" style="margin:3px 0 0">${escape(d.descTh)}</p></div>`).join("")}`;
  }

  html+=`<h3>🌳 แผนผังรากต้นไม้แห่งชะตาสำนัก (${(se.allStoryNodes||[]).length} กิ่งเนื้อเรื่อง · EP.1 ถึง EP.8)</h3><p class="meta">แต่ละกิ่งแตกแขนงออกเป็นรากย่อยตามการตัดสินใจของ NPC ในสำนัก สามารถสลับได้เฉพาะกิ่งที่ต่อจากเส้นทางซึ่งสำนักผ่านจริง</p>`;
  for(let epIdx=1;epIdx<=8;epIdx++){
   const nodesInEp=(se.allStoryNodes||[]).filter(n=>n.ep===epIdx);
   html+=`<div class="card"><div class="row"><strong>ระดับรากที่ ${epIdx} (EP.${epIdx}) · ${nodesInEp.length} กิ่งทางเลือก</strong><span class="tag">${completedArr.includes(epIdx)?"✓ ผ่านระดับนี้แล้ว":se.currentEp===epIdx?"🔥 ระดับปัจจุบัน":"รอปลดล็อก"}</span></div>${nodesInEp.map(nd=>{
    const isDone=completedNodeIds.includes(nd.id);
    const isCurr=!allCompleted&&se.currentNodeId===nd.id;
    const nextNames=(nd.nextNodeIds||[]).map(nid=>(se.allStoryNodes||[]).find(x=>x.id===nid)?.branchBadgeTh||nid).join(" / ");
    return `<div class="entry" style="margin-top:6px;${isCurr?"border-left:3px solid #f0cf4a;padding-left:8px":isDone?"border-left:3px solid #5fd38a;padding-left:8px":""}"><div class="row"><b>${isDone?"✓ ":isCurr?"🔥 ":"○ "}${escape(nd.branchBadgeTh)} · ${escape(nd.titleTh)}</b><span>${isDone?"สำเร็จแล้ว":isCurr?"กิ่งปัจจุบัน":""}</span></div><p class="meta" style="margin:3px 0">${escape(nd.subtitleTh||"")}</p><small class="meta">🎁 รางวัลจริง: ${escape(nd.rewardSummaryTh)}${nextNames?`<br>🌿 แตกกิ่งต่อไปยัง: <b>${escape(nextNames)}</b>`:""}</small>${!isDone&&(se.availableBranchIds||[]).includes(nd.id)&&!isCurr&&se.epPhase!=="ACTIVE_TRIAL"?`<div class="inline-actions" style="margin-top:4px"><button data-select-story-branch="${escape(nd.id)}">🧭 เลือกเดินกิ่งนี้</button></div>`:""}</div>`;
   }).join("")}</div>`;
  }
 }

 if(questTab==="store"){
  html+=renderSectStoreAndWorkshop(tv);
 }
 if(questTab==="treasury"){
  const phil=tv.philosophy||{};
  const mEval=tv.masterEval;
  const bank=tv.bankTreasury||{equipment:[],pills:[],scrolls:[],libraryScrolls:[],materials:[]};
  const reqs=tv.requisitions||[];
  const ledger=tv.ledgerHistory||[];
  const memberOpts=game.heroes.filter(alive).map(h=>`<option value="${escape(h.id)}" ${tv.distributorNpcId===h.id?"selected":""}>${escape(h.name)} (${escape(h.jianghu?.subPathNameTh||"")} · เที่ยงธรรม ${Math.round(h.personality?.integrity||50)} · เมตตา ${Math.round(h.personality?.empathy||50)})</option>`).join("");

  html+=`<article class="card"><div class="row"><strong>🏛️ ผู้มีอำนาจแจกจ่ายคลังสำนัก: ${escape(tv.distributorName)}</strong><span class="tag">${escape(tv.distributorRoleTitleTh)}</span></div><p style="margin:6px 0">นิสัยการแจกจ่าย: <b>${escape(phil.styleBadgeTh||"-")}</b> — ${escape(phil.summaryTh||"")}</p><p class="meta">เกณฑ์คะแนนอนุมัติขั้นต่ำ: <b>${phil.approvalThreshold||50} คะแนน</b> · น้ำหนักความเหมาะสม ×${phil.needWeight||1} · น้ำหนักผลงาน ×${phil.meritWeight||1} · น้ำหนักความสนิท/เอนเอียง ×${phil.favoritismWeight||1}</p>${tv.appointmentReasonTh?`<p class="meta" style="margin-top:4px">📌 ที่มาของตำแหน่ง: <i>${escape(tv.appointmentReasonTh)}</i></p>`:""}<div class="inline-actions" style="margin-top:8px"><button class="gold" data-treasury-action="master-decide">👑 ให้เจ้าสำนักตัดสินใจแต่งตั้ง/กุมอำนาจเองตามนิสัย</button><button data-treasury-action="master-direct">✋ ให้เจ้าสำนักลงมาดูแลและอนุมัติคลังเอง</button><button data-treasury-action="toggle-auto">${tv.autoDistribute?"⏸ พักการแจกจ่ายอัตโนมัติ":"▶ เปิดการแจกจ่ายอัตโนมัติ"}</button></div><div class="row" style="margin-top:8px"><select id="treasuryElderSelect" aria-label="เลือกผู้ดูแลคลัง">${memberOpts}</select><button data-treasury-action="appoint-selected">📜 แต่งตั้งเป็นผู้ดูแลคลัง</button></div></article>`;

  if(mEval&&mEval.candidateScores?.length){
   html+=`<details class="card"><summary><b>🔍 ดูการประเมินผู้เหมาะสมเป็นผู้อาวุโสหอคลังในสายตาของเจ้าสำนัก (${escape(mEval.masterName)})</b></summary><p class="meta" style="margin:6px 0">${escape(mEval.decisionReasonTh)}</p>${mEval.candidateScores.map(c=>`<div class="entry"><div class="row"><b>${escape(c.name)} (${escape(c.philosophy?.styleBadgeTh||"")})</b><span>คะแนนในใจเจ้าสำนัก: ${c.score}</span></div><small class="meta">${escape(c.reasonTh)} · ความสนิทกับเจ้าสำนัก ${c.affinityWithMaster>=0?"+":""}${c.affinityWithMaster}</small></div>`).join("")}</details>`;
  }

  const points=window.JianghuSectContributions?.inspect(game);
  if(points){
   const curDay=Math.floor((s.t||0)/20);html+=`<article class="card"><h3>แจกของใช้พื้นฐานในคลังสำนัก &amp; ใช้แต้มคุณูปการในร้านค้าสำนัก</h3><p class="meta">แยกเป็น 2 ช่องทางชัดเจน: <b>คลังสำนัก (Sect Treasury)</b> แจกฟรีของใช้พื้นฐานที่จำเป็นต่อการดำรงชีพ (ไม่เกิน 4 หน่วย/คน/วัน) และเก็บวัตถุดิบส่วนกลางให้ศิษย์ใช้หลอมโอสถ ส่วน <b>ร้านค้าสำนัก (Sect Store)</b> นำสินค้าที่ศิษย์หามาจากข้างนอกหรือหลอมให้สำนักมาวางขายด้วยแต้มคุณูปการ</p>${points.accounts.map(a=>{const used=a.grantDay===curDay?(a.grantQuantity||0):0;const w=a.storeWish;return `<div class="entry"><div class="row"><b>${escape(a.name)}</b><strong>${a.balance} แต้ม</strong></div><small>รับสะสม ${a.earned} · ใช้ไป ${a.spent} · ความดีความชอบ ${Math.round(a.merit*10)/10} · โควตารับแจกวันนี้ ${used}/${window.JianghuInfrastructure?.bonuses(game).welfareDailyLimit||4} หน่วย${w?`<br>🎯 เป้าหมายใช้แต้ม: <b>«${escape(w.nameTh)}» (${w.price} แต้ม)</b> · ${w.canAfford?'<span class="good">แต้มพอพร้อมซื้อ!</span>':'กำลังหาแต้มเพิ่มอีก '+w.deficit+' แต้ม'}`:''}</small></div>`;}).join('')}</article>`;
   if(points.history.length)html+=`<details class="card"><summary>ประวัติมอบของ หลอมให้สำนัก และซื้อจากร้านค้าสำนัก (${points.history.length})</summary>${points.history.slice(0,20).map(h=>`<div class="entry"><b>${escape(h.npcName)}</b> · ${h.kind==='DONATE'?'มอบของเข้าคลัง':h.kind==='SECT_CRAFT'?'หลอมของให้สำนัก':h.kind==='ROYALTY'?'รับปันผลผู้จัดหา':h.kind==='SHOP_BUY'?'ซื้อจากร้านค้าสำนัก':h.kind==='GRANT'?'รับแจกสวัสดิการ':h.kind==='WORK'?'ทำผลงาน':h.kind==='LIBRARY_ENROLL'?'ลงทะเบียนเรียนวิชา':h.kind==='EXTERNAL_BUY'?'รับซื้อจากคนนอก':h.kind==='EXTERNAL_SELL'?'ขายส่วนเกินให้คนนอก':'แลกของ'} ${escape(h.itemName)} ×${h.quantity}<span> · ${h.stones!==undefined?`${h.stones>0?'+':''}${h.stones} หินวิญญาณ`:`${h.points>0?'+':''}${h.points} แต้ม`}</span></div>`).join('')}</details>`;
  }

  html+=`<h3>📋 คำร้องขอเบิกไอเทมจากคนในสำนัก (${reqs.length} คำร้องที่รออนุมัติ)</h3><div class="card"><div class="inline-actions"><button class="gold" data-treasury-action="judge-all">⚖️ ให้ «${escape(tv.distributorName)}» ตัดสินคำร้องทั้งหมดตามนิสัย</button><button data-treasury-action="proactive-distribute">🎁 ให้ «${escape(tv.distributorName)}» เลือกแจกของในคลัง 1 ชิ้นตามนิสัยทันที</button><button data-treasury-action="refresh-reqs">🔄 สำรวจความต้องการของศิษย์ใหม่</button></div></div>`;

  if(reqs.length){
   html+=reqs.map(r=>{
    const ev=r.evaluation||{};
    const bd=ev.breakdown||{};
    const prepared=JianghuStoryEvents.treasuryTools.prepareTransfer(game,r,game.world.npcs[r.requesterId]);
    const charge=prepared.ok&&window.JianghuSectContributions?JianghuSectContributions.prepareRedemption(game,r,game.world.npcs[r.requesterId],prepared.item,prepared.qty||1):null;
    const pointsLabel=charge?(charge.grant?'ขอรับแจกของใช้พื้นฐาน ไม่หักแต้ม':`ราคา ${charge.cost} แต้ม · มี ${JianghuSectContributions.account(game,r.requesterId).balance} แต้ม`):prepared.effectTextTh||'';
    return `<article class="card"><div class="row"><strong>🙋 ${escape(r.requesterName)} ${r.mode==='REDEEM'?'ใช้แต้มแลก':'ขอรับแจก'} «${escape(r.itemNameTh)}»</strong><span class="${ev.approved?"good":""}">${ev.approved?"แนวโน้ม: อนุมัติ":"แนวโน้ม: ปฏิเสธ"} (${ev.totalScore} / เกณฑ์ ${ev.threshold})</span></div><p style="margin:4px 0">${escape(r.requestReasonTh)}</p><p class="meta">${escape(pointsLabel)}${charge&&!charge.ok?" · แต้มยังไม่พอ":""}</p><p class="meta">การประเมินของ <b>${escape(tv.distributorName)}</b>: ${escape(ev.verdictReasonTh)}<br><small>แยกคะแนน: ความจำเป็น +${bd.need} · ผลงานสำนัก +${bd.merit} (ผลงาน ${bd.requesterMerit}) · ความสนิท/เอนเอียง ${bd.bias>=0?"+":""}${bd.bias} (สนิท ${bd.affinity}) · ความเมตตา +${bd.compassion}</small></p><div class="inline-actions">${game.storyEvents.authorities().map(a=>`<button class="gold" data-judge-req="${escape(r.id)}" data-judge-mode="npc" data-judge-authority="${escape(a.npc.id)}">ให้${escape(a.roleTitleTh)} ${escape(a.npc.name)} พิจารณา</button>`).join('')}</div></article>`;
   }).join("");
  }else{
   html+=`<p class="meta">ขณะนี้ไม่มีคำร้องค้างอยู่ กดปุ่ม «🔄 สำรวจความต้องการของศิษย์ใหม่» หรือให้ศิษย์ยื่นคำร้องด้านล่างได้เลย</p>`;
  }

  // Manual Requisition Form so player can also test having any disciple request any item
  const exchangeLabel=(kind,item,qty=1)=>window.JianghuSectContributions?' · '+JianghuSectContributions.quote(game,kind,item,qty).redemption+' แต้ม':'';
  const allowedFree=(kind,item)=>reqForm.mode==='REDEEM'||JianghuSectContributions.grantEligibility(game,kind,item,kind==='MATERIAL'?Math.min(2,item.count):1).ok;
  const allBankItems=[
   ...bank.equipment.filter(e=>allowedFree('EQUIPMENT',e)).map(e=>({val:`EQUIPMENT:${e.id}`,label:`[ศาสตรา/อุปกรณ์] ${e.nameTh} (T${e.tier||2})${exchangeLabel('EQUIPMENT',e)}`})),
   ...bank.pills.filter(p=>allowedFree('PILL',p)).map(p=>({val:`PILL:${p.id}`,label:`[โอสถ ×${p.count}] ${p.nameTh}${exchangeLabel('PILL',p)}`})),
   ...bank.scrolls.filter(s=>allowedFree('SCROLL',s)).map(s=>({val:`SCROLL:${s.id}`,label:`[คัมภีร์] ${s.nameTh}${exchangeLabel('SCROLL',s)}`})),
   ...bank.materials.filter(m=>m.count>0&&allowedFree('MATERIAL',m)).map(m=>({val:`MATERIAL:${m.matId}`,label:`[วัตถุดิบ ×${m.count}] ${m.nameTh||matName(m.matId)} ×${Math.min(2,m.count)}${exchangeLabel('MATERIAL',m,Math.min(2,m.count))}`}))
  ];
  html+=`<article class="card"><h3>➕ ยื่นคำร้องต่อผู้ดูแลคลัง</h3><div class="row"><select id="reqMethodSelect"><option value="GRANT" ${reqForm.mode==='GRANT'?'selected':''}>ขอรับแจกของใช้พื้นฐาน</option><option value="REDEEM" ${reqForm.mode==='REDEEM'?'selected':''}>ใช้แต้มคุณูปการแลกของ</option></select><select id="reqAuthoritySelect"><option value="">ผู้ดูแลคลังตามนโยบายสำนัก</option>${game.storyEvents.authorities().map(a=>`<option value="${a.npc.id}" ${reqForm.authorityId===a.npc.id?'selected':''}>${escape(a.roleTitleTh)} · ${escape(a.npc.name)}</option>`).join('')}</select></div><div class="row"><select id="reqDiscipleSelect">${game.heroes.filter(alive).map(h=>`<option value="${escape(h.id)}" ${reqForm.npcId===h.id?'selected':''}>${escape(h.name)} (${escape(h.jianghu?.stageNameTh||"")})</option>`).join("")}</select><select id="reqItemSelect">${allBankItems.map(i=>`<option value="${escape(i.val)}" ${reqForm.item===i.val?'selected':''}>${escape(i.label)}</option>`).join("")||"<option value=\"\">ไม่มีพัสดุในคลัง</option>"}</select></div><div class="inline-actions" style="margin-top:8px"><button class="gold" data-treasury-action="create-req" ${allBankItems.length?"":"disabled"}>📨 ยื่นคำร้องขอเบิกพัสดุชิ้นนี้</button></div></article>`;

  html+=`<h3>📦 พัสดุที่อยู่ในคลังสำนักพร้อมแจกจ่ายขณะนี้</h3><div class="card"><p><b>ศาสตราและอุปกรณ์ (${bank.equipment.length} ชิ้น):</b> ${bank.equipment.map(e=>`${escape(e.nameTh)} (T${e.tier||1})`).join(" · ")||"ไม่มี"}</p><p><b>โอสถในคลัง (${bank.pills.reduce((a,b)=>a+(b.count||0),0)} เม็ด):</b> ${bank.pills.map(p=>`${escape(p.nameTh)} ×${p.count}`).join(" · ")||"ไม่มี"}</p><p><b>หอคัมภีร์ (${bank.libraryScrolls.length} ม้วน) · วัตถุดิบ (${bank.materials.length} ชนิด)</b></p></div>`;

  html+=renderSectStoreAndWorkshop(tv);
  html+=`<h3>📜 บันทึกการพิจารณาแจกจ่ายคลังสำนัก (${ledger.length} รายการล่าสุด)</h3>${ledger.map(l=>`<div class="entry"><div class="row"><b class="${l.decision==="REJECTED"?"":"good"}">${l.decision==="REJECTED"?"✗ ปฏิเสธ":"✓ อนุมัติ"} · ${escape(l.requesterName)} ← «${escape(l.itemNameTh)}»</b><small>วันที่ ${l.day} · โดย ${escape(l.distributorName)}</small></div><p class="meta" style="margin:3px 0 0">${escape(l.reasonTh)}</p></div>`).join("")||"<p class=\"meta\">ยังไม่มีประวัติการแจกจ่ายคลัง</p>"}`;
 }

 if(questTab==="sidequests"){
  const sq=se.sidequests||{},active=sq.active;
  html+=`<div class="banner"><b>📜 งานย่อยเพื่อชีวิตสำนัก</b><p>เปิดงานได้ครั้งละหนึ่งสัญญา ศิษย์เลือกผู้รับหน้าที่เอง ต้องส่งมอบของหรือทำงานสำเร็จจริงจึงได้รางวัล ยกเลิกหรือหมดเวลาจะคืนทุนส่วนที่ยังสำรองไว้</p></div>`;
  if(active)html+=`<article class="card"><div class="row"><b>${escape(active.nameTh||active.questId)}</b><span class="tag">${active.progress} / ${active.target}</span></div><p>${escape(active.descTh||"")}</p><p class="meta">เหลือ ${Math.max(0,Math.ceil(active.deadlineAt-s.t))} วินาที · ผู้ร่วมงาน ${(active.contributors||[]).map(id=>escape(game.world.npcs[id]?.name||id)).join(" · ")||"รอศิษย์สมัครใจ"}</p><button data-sidequest-cancel="${escape(active.questId)}">ยกเลิกและคืนทุนสำรอง</button></article>`;
  html+=(sq.contracts||[]).map(q=>`<article class="card"><div class="row"><b>${escape(q.nameTh)}</b><span class="tag">${q.progress||0} / ${q.target}</span></div><p>${escape(q.descTh)}</p><p class="meta">ใช้: ${escape(q.costSummaryTh||"-")}<br>รางวัล: ${escape(q.rewardSummaryTh||"-")}</p><button data-sidequest-accept="${escape(q.id)}" ${q.canAccept?"":"disabled"}>เปิดสัญญานี้ให้ศิษย์</button>${q.reason?`<small class="meta"> ${escape(q.reason)}</small>`:""}</article>`).join("");
  html+=`<h3>งานที่สิ้นสุดแล้ว</h3>`+(sq.history||[]).map(h=>`<div class="entry"><b>${escape(h.nameTh)}</b> · ${escape(({COMPLETED:"สำเร็จ",FAILED:"หมดเวลา",CANCELLED:"ยกเลิก"})[h.status]||h.status)}<p class="meta">${escape(h.reason||"")}</p></div>`).join("");
 }
 if(questTab==="events"){
  const pool=se.beastPool;
  const nextIn=Math.max(0,Math.ceil((st.nextEventAt||75)-(s.t||0)));
  html+=`<article class="card"><div class="row"><strong>🎲 จังหวะเหตุการณ์ยุทธภพ (อ้างอิงพูล EP.${se.currentEp})</strong><span>${st.autoEvents!==false?"เปิดอัตโนมัติ":"ปิดอัตโนมัติ"}</span></div><p class="meta">พูลสัตว์อสูรบุกปัจจุบัน: <b>${escape(pool?.poolNameTh||"-")}</b> (${escape(pool?.recommendedStageTh||"-")}) · อีเวนต์อัตโนมัติรอบถัดไปในอีก <b>${nextIn} วินาที</b></p><div class="inline-actions"><button class="gold" data-story-action="roll-random-event">🎲 สุ่มเหตุการณ์ที่พร้อมตามพูล EP.${se.currentEp}</button><button data-story-action="trigger-beast-tide">🌊 เรียกคลื่นสัตว์อสูรบุก (Pool EP.${se.currentEp})</button><button data-story-action="toggle-auto-events">${st.autoEvents!==false?"⏸ ปิดอีเวนต์อัตโนมัติ":"▶ เปิดอีเวนต์อัตโนมัติ"}</button></div></article>`;

  if((se.chainedQueue||[]).length){
   html+=`<h3>🔗 คิวอีเวนต์ผลพวงต่อเนื่องที่กำลังจะเกิดตามมา (${se.chainedQueue.length} เหตุการณ์)</h3>${se.chainedQueue.map(c=>{
    const evDef=(se.allDynamicEvents||[]).find(x=>x.id===c.eventId);
    const waitSec=Math.max(0,Math.ceil(c.triggerAt-(s.t||0)));
    return `<article class="card" style="border:1px solid #f0cf4a"><div class="row"><strong>${evDef?.icon||"🔗"} ${escape(evDef?.nameTh||c.eventId)}</strong><span class="tag">จะเกิดในอีก ${waitSec} วิ</span></div><p class="meta">${escape(c.reasonTh)} (ผลพวงจาก: ${escape(c.fromTitleTh)})</p><div class="inline-actions"><button class="gold" data-trigger-chain="${escape(c.id)}">⚡ เรียกอีเวนต์ผลพวงนี้ทันที</button></div></article>`;
   }).join("")}`;
  }

  const allEpEvents=(se.allDynamicEvents||[]).filter(e=>e.scope==="ALL_EP");
  const branchEvents=(se.allDynamicEvents||[]).filter(e=>e.scope==="BRANCH_EXCLUSIVE");
  const chainEvents=(se.allDynamicEvents||[]).filter(e=>e.scope==="CHAIN_FOLLOWUP");
  const specEvents=(se.allDynamicEvents||[]).filter(e=>e.scope==="EP_SPECIFIC");

  html+=`<h3>🌐 อีเวนต์ที่เกิดได้ทุกช่วงเนื้อเรื่อง (${allEpEvents.length} อีเวนต์ · ดึงความยากและมอบไอเทมจริงตาม Pool EP.${se.currentEp})</h3>${allEpEvents.map(ev=>`<article class="card"><div class="row"><strong>${ev.icon||"⚡"} ${escape(ev.nameTh)}</strong><span class="tag">${ev.kind==="CONTINUOUS"?"⏳ ต่อเนื่อง":"⚡ จบทันที"} · ทุก EP (Pool EP.${se.currentEp})</span></div><p>${escape(ev.descTh)}</p><div class="inline-actions"><button class="gold" data-trigger-event-id="${escape(ev.id)}" ${se.eventAvailability?.[ev.id]?.ok?"":"disabled"} title="${escape(se.eventAvailability?.[ev.id]?.reason||"")}">▶ เริ่มอีเวนต์นี้ (ระดับ EP.${se.currentEp})</button></div></article>`).join("")}`;

  html+=`<h3>🌳 อีเวนต์พิเศษเฉพาะกิ่งเนื้อเรื่องที่สภา NPC เลือก (${branchEvents.length} อีเวนต์)</h3>${branchEvents.map(ev=>`<article class="card"><div class="row"><strong>${ev.icon||"🌿"} ${escape(ev.nameTh)}</strong><span class="tag">${ev.kind==="CONTINUOUS"?"⏳ ต่อเนื่อง":"⚡ จบทันที"} · เฉพาะกิ่งเนื้อเรื่อง</span></div><p>${escape(ev.descTh)}</p><div class="inline-actions"><button class="gold" data-trigger-event-id="${escape(ev.id)}" ${se.eventAvailability?.[ev.id]?.ok?"":"disabled"} title="${escape(se.eventAvailability?.[ev.id]?.reason||"")}">▶ เริ่มอีเวนต์กิ่งนี้</button></div></article>`).join("")}`;

  html+=`<h3>🔗 อีเวนต์ผลพวงต่อเนื่องหลังจบอีเวนต์หลัก (${chainEvents.length} อีเวนต์)</h3>${chainEvents.map(ev=>`<article class="card"><div class="row"><strong>${ev.icon||"🔗"} ${escape(ev.nameTh)}</strong><span class="tag">${ev.kind==="CONTINUOUS"?"⏳ ต่อเนื่อง":"⚡ จบทันที"} · ผลพวงต่อเนื่อง</span></div><p>${escape(ev.descTh)}</p><div class="inline-actions"><button data-trigger-event-id="${escape(ev.id)}" ${se.eventAvailability?.[ev.id]?.ok?"":"disabled"} title="${escape(se.eventAvailability?.[ev.id]?.reason||"")}">▶ เริ่มอีเวนต์ผลพวงนี้</button></div></article>`).join("")}`;

  html+=`<h3>🎯 อีเวนต์เฉพาะช่วงเนื้อเรื่อง (${specEvents.length} อีเวนต์ · เกิดเฉพาะ EP ที่กำหนด)</h3>${specEvents.map(ev=>{
   const inRange=se.currentEp>=ev.minEp&&se.currentEp<=ev.maxEp;
   return `<article class="card"><div class="row"><strong>${ev.icon||"🎯"} ${escape(ev.nameTh)}</strong><span class="tag" style="${inRange?"border-color:#5fd38a;color:#5fd38a":""}">${ev.kind==="CONTINUOUS"?"⏳ ต่อเนื่อง":"⚡ จบทันที"} · เฉพาะ EP.${ev.minEp}–EP.${ev.maxEp}${inRange?" (ตรงช่วงปัจจุบัน)":""}</span></div><p>${escape(ev.descTh)}</p><div class="inline-actions"><button class="${inRange?"gold":""}" data-trigger-event-id="${escape(ev.id)}" ${se.eventAvailability?.[ev.id]?.ok?"":"disabled"} title="${escape(se.eventAvailability?.[ev.id]?.reason||"")}">▶ เริ่มอีเวนต์นี้</button></div></article>`;
  }).join("")}`;
 }

 if(questTab==="pools"){
  html+=`<h3>ตารางระดับขั้นตามวิถีที่ต้องการใน EP.${se.currentEp} (เทียบระดับตบะจริงของแต่ละสาย)</h3><p class="meta">แต่ละวิถีมีจำนวนระดับขั้นรวมและความเก่งในแต่ละขั้นไม่เท่ากัน ระบบใช้ตบะเทียบเคียงเดียวกัน แล้วแสดงขั้นและเปอร์เซ็นต์ที่สายของศิษย์แต่ละคนต้องถึง</p><div class="grid">${(se.pathTable||[]).map(p=>`<article class="card"><div class="row"><b>${p.icon} ${escape(p.nameTh)}</b><span class="tag">ขั้นที่ ${p.requiredOrdinal} / ${p.realmCount}</span></div><p style="margin:4px 0">เกณฑ์ใน EP.${se.currentEp}: <b>${escape(p.sampleStageNameTh)} · ตบะ ${p.requiredProgress}%</b></p><small class="meta">เกณฑ์ตบะเทียบเคียง ${p.requiredBand} · ตารางนี้ยกตัวอย่างสายหลัก ส่วนเกณฑ์สายย่อยดูจากรายศิษย์ด้านล่าง</small></article>`).join("")}</div>`;

  html+=`<h3>ตรวจสอบระดับขั้นของศิษย์ในสำนักสำหรับ EP.${se.currentEp} (${(se.discipleEvaluations||[]).filter(d=>d.qualified).length} / ${(se.discipleEvaluations||[]).length} คนผ่านเกณฑ์)</h3>${(se.discipleEvaluations||[]).map(d=>`<div class="entry"><div class="row"><b class="${d.qualified?"good":""}">${d.qualified?"✓":"○"} ${escape(d.name)} (${d.pathIcon} ${escape(d.pathNameTh)} · ${escape(d.subPathNameTh)})</b><span>ขั้น ${d.currentStage}/${d.maxStage} (เกณฑ์: ${d.requiredStage}/${d.maxStage})</span></div><small class="meta">ระดับปัจจุบัน: <b>${escape(d.stageNameTh)}</b> (ตบะ ${Number(d.currentProgress||0).toFixed(2)}% · เทียบเคียง ${Number(d.currentBand||1).toFixed(2)}) · เกณฑ์ของสายนี้ใน EP.${se.currentEp}: <b>${escape(d.requiredStageNameTh)} ตบะอย่างน้อย ${d.requiredProgress}% (เทียบเคียง ${d.requiredBand})</b></small></div>`).join("")||"<p class=\"meta\">ยังไม่มีศิษย์ในสำนัก</p>"}`;

  html+=`<h3>🐾 ตารางพูลสัตว์อสูรบุก (Beast Tide Pools · EP.1 ถึง EP.8)</h3>${Object.entries(se.allBeastPools||{}).map(([epKey,p])=>{
   const isCurr=Number(epKey)===se.currentEp;
   const spNames=(p.spawns||[]).map(s=>`${s.nameTh} (T${s.tier} · HP ${s.hp} · พลัง ${s.power})`).join(" + ");
   return `<article class="card" style="${isCurr?"border:1px solid #5fd38a":""}"><div class="row"><strong>${escape(p.poolNameTh)} ${isCurr?"(พูลปัจจุบัน)":""}</strong><span class="tag">${escape(p.recommendedStageTh)}</span></div><p style="margin:4px 0">${escape(p.descTh)}</p><p class="meta">อสูรในพูล: <b>${escape(spNames)}</b><br>รางวัลต้านทานสำเร็จ: <b>${p.rewardStones} ศิลาวิญญาณ</b> + วัตถุดิบอสูร ×${p.rewardMatQty} + ดรอปซากอสูรลงพื้นแผนที่</p></article>`;
  }).join("")}`;
 }

 if(questTab==="history"){
  html+=`<h3>🌳 ประวัติการลงมติแตกกิ่งเนื้อเรื่องของสภาศิษย์ (${(se.branchHistory||[]).length} ครั้ง)</h3>${(se.branchHistory||[]).map(b=>`<div class="entry"><div class="row"><b class="good">🌳 ${escape(b.fromTitleTh)} → ${escape(b.chosenBadgeTh)}</b><small>วันที่ ${b.day}</small></div><p class="meta" style="margin:3px 0">${escape(b.chosenTitleTh)}</p><small class="meta">${(b.votes||[]).map(v=>`${escape(v.npcName)} เลือก ${escape(v.chosenBadgeTh)}`).join(" · ")}</small></div>`).join("")||"<p class=\"meta\">ยังไม่มีประวัติการแตกกิ่งเนื้อเรื่อง</p>"}`;

  html+=`<h3>⚡ บันทึกเหตุการณ์เควส หอคลัง และอีเวนต์ยุทธภพ (${historyArr.length} รายการ)</h3>${historyArr.map(h=>`<div class="entry"><div class="row"><b>${escape(h.titleTh)}</b><small>วันที่ ${h.day} · EP.${h.ep}</small></div><p style="margin:4px 0 0">${escape(h.detailTh||"")}</p></div>`).join("")||"<p class=\"meta\">ยังไม่มีประวัติเหตุการณ์</p>"}`;
 }

 titleAndBody("เควสเนื้อเรื่องรากต้นไม้ หอคลัง และอีเวนต์ยุทธภพ",html);
}
function renderInfrastructure(){
 const I=window.JianghuInfrastructure;if(!I)return '';
 const v=I.inspect(game);
 let out=`<article class="card"><div class="row"><h3>อาคารและการยกระดับสำนัก</h3><button data-infrastructure-auto>NPC พัฒนาอาคาร: ${v.autoEnabled?'เปิด':'ปิด'}</button></div><p class="meta">ยกระดับได้สูงสุด 3 ใช้หินวิญญาณ ไม้ และแร่จริง มีเวลาทำงาน อาคารยังใช้ได้ระหว่างยกระดับ เจ้าสำนักและฝ่ายที่เกี่ยวข้องพิจารณาจากความจำเป็น บุคลิก และเงินสำรอง · งานจัดหา/ผลิตเพิ่มประเภทละ ${v.bonuses.extraEconomicWorkers||0} คน</p>${v.lastDecision?`<p class="meta">มติล่าสุด: ${escape(v.lastDecision.reason)}</p>`:''}</article>`;
 out+=v.buildings.map(b=>{const q=b.quote;return `<article class="card"><div class="row"><b>${escape(b.name)} · ระดับ ${b.level}/3</b><span>HP ${Math.ceil(b.hp)}/${Math.ceil(b.maxHp)}</span></div><p class="meta">${escape(b.description)}</p>${b.upgrade?`<p class="good">กำลังยกระดับเป็น ${b.upgrade.targetLevel} · อีก ${Math.ceil(b.upgrade.remaining)} วินาที</p>`:q.cost?`<p class="meta">ระดับ ${q.targetLevel}: ${q.cost.stones} หินวิญญาณ · ไม้ ${q.cost.wood} · แร่ ${q.cost.ore} · เวลา ${Math.ceil(q.duration)} วินาที</p><button data-upgrade-building="${escape(b.id)}" ${q.ok?'':'disabled'}>${q.ok?'เริ่มยกระดับ':escape(q.reason)}</button>`:`<small class="meta">${escape(q.reason||'')}</small>`}</article>`;}).join('');
 return out;
}

function renderPanel(){if(!game||!tab)return;const s=game.s;
 if(tab==='art'){renderArtSettings();}
 if(tab==='npcEdit'){renderNpcEditor();}
 if(tab==='editHub'){renderEditHub();}
 if(tab==='build'){titleAndBody('ก่อสร้างสำนัก',`${renderInfrastructure()}<h3>สร้างอาคารใหม่</h3><p class="meta">เลือกอาคาร แล้วแตะตำแหน่งในเขตสำนัก การก่อสร้างใช้เวลาในเกม</p>${Object.entries(B).map(([id,b])=>`<article class="card"><div class="row"><strong><span class="icon">${b.icon}</span>${b.name}</strong><button class="gold" data-build="${id}">วางอาคาร</button></div><p>${b.desc}</p><div class="meta">${b.gold} ศิลา · ${b.wood} ไม้ · ${b.ore} แร่ · ${b.time} วินาที<br>ความทนทาน ${b.hp} · ความจุ ${b.cap}${id!=='hall'?' · ต้องมีหอเจ้าสำนัก':''}</div></article>`).join('')}`);}
 if(tab==='growth'){const n=game.world.npcs[selected]||game.heroes[0];titleAndBody('เส้นทางชีวิต',GrowthView.render(game,n,growthSection,true));}
 if(tab==='combatGuide'){titleAndBody('วิถีและกระบวนท่า',CombatView117.guide(game));}
 if(tab==='combatStats'){const n=combatEntity(combatEntityId||selected);titleAndBody('คุณสมบัติต่อสู้'+(n?' · '+n.name:''),CombatView117.stats(game,n));}
 if(tab==='heroes'){const members=game.heroes.filter(alive),deceased=game.heroes.filter(n=>!alive(n)),cards=members=>members.map(n=>`<article class="card hero ${alive(n)?'':'dead'}" data-hero="${n.id}"><div class="row"><div class="portrait">${escape(n.name[0])}</div><div class="who"><strong>${escape(n.name)}</strong><small>${escape(SectLifeView.memberLine(game,n))}<br>${escape(n.jianghu.subPathNameTh)} · ${escape(n.jianghu.stageNameTh)}<br>${escape(describe(n))}</small>${renderNpcKeywords(n,3)}</div><b>${fmt(n.health)}<small> HP</small></b></div>${meter(n.health,'hp')}<div class="meta">${escape(n.stageLocal.aspiration?.text||'')} ${n.stageLocal.aspiration?.fulfilled?'✓':''}</div></article>`).join('');titleAndBody('ศิษย์และผู้ฝึกตน',`<div class="row"><span>ที่พัก ${members.length} / ${game.capacity()}</span><button class="gold" data-recruit>＋ รับศิษย์ 100</button></div><p class="meta">เบี้ยเลี้ยงคนละ 2 ศิลาต่อวัน · แตะชื่อเพื่อดูแฟ้มชีวิต ป้ายสถานะ และความคิด</p>${members.length?cards(members):'<div class="banner">ยังไม่มีศิษย์ที่มีชีวิต · เปิดรับผู้ฝึกตนใหม่ได้เมื่อมีที่พัก</div>'}${deceased.length?`<details class="deceased-roster"><summary>บันทึกผู้ล่วงลับ (${deceased.length})</summary>${cards(deceased)}</details>`:''}`);}
 if(tab==='hero'){renderHero();}
 if(tab==='world'){titleAndBody('ยุทธภพมีชีวิต','<button class="gold" data-panel="growth">เส้นทางชีวิต · ตำรับ · คัมภีร์</button>'+withCombatStatsLinks(JianghuRealmView.render(game,worldSection,worldFocus)));}
 if(tab==='life'){titleAndBody('ชีวิตและชะตาสำนัก',SectLifeView.render(game,lifeTab));}
 if(tab==='bounties'){titleAndBody('ประกาศชักจูงศิษย์',`<div class="banner">เงินรางวัลถูกสำรองทันที ศิษย์ประเมินกำลัง ความเสี่ยง และบุคลิกก่อนเลือกเอง จ่ายเพียงครั้งเดียวเมื่อสำเร็จ</div><label>รางวัล <select id="reward"><option value="120">120 ศิลา</option><option value="240" selected>240 ศิลา</option><option value="400">400 ศิลา</option></select></label><div class="grid" style="margin-top:14px">${[['scout','สำรวจสันเขา','ค้นหาค่ายโจรและแบ่งปันข่าว'],['woods','ปราบฝูงอสูร','ปราบหมาป่า 3 ตัวเพื่อให้ป่าสงบ'],['camp','ปราบหัวหน้าโจร',s.campKnown?'กำจัดเถี่ยหู่ หยุดเสบียงปล้น':'ยังไม่ทราบที่ตั้ง ต้องสำรวจก่อน'],['village','คุ้มกันหมู่บ้าน','เดินทางไปเฝ้าหมู่บ้านครบช่วงงาน']].map(([id,name,desc])=>`<article class="card"><b>${name}</b><p>${desc}</p><button data-bounty="${id}" ${id==='camp'&&!s.campKnown?'disabled':''}>ติดประกาศ</button></article>`).join('')}</div><h3>บัญชีประกาศ</h3>${s.bounties.slice().reverse().map(b=>`<article class="card"><div class="row"><b>${b.name}</b><span>${b.reward} ศิลา</span></div><p>${({open:'เปิดรับ',paid:'จ่ายแล้ว',expired:'หมดอายุและคืนทุน',cancelled:'ยกเลิกและคืนทุน'})[b.status]} · ผู้สนใจ ${b.accepted.length} คน${b.paidTo?' · '+escape(game.world.npcs[b.paidTo]?.name):''}</p>${b.status==='open'?`<small>เหลือ ${Math.ceil(b.expires-s.t)} วินาที</small><button data-cancel-bounty="${b.id}" style="float:right">ถอนประกาศ</button>`:''}</article>`).join('')||'<p class="meta">ยังไม่มีประกาศ</p>'}`);}
 if(tab==='sect'){titleAndBody('สำนักเมฆาคราม',`${saveBlocked?`<div class="banner bad"><b>ยังอ่านเซฟเดิมไม่ได้</b><p>${escape(saveBlocked)}<br>เก็บเซฟเดิมไว้แล้ว เกมตัวอย่างนี้ยังไม่บันทึกทับ</p><button data-action="backupStored">ดาวน์โหลดเซฟเดิมสำรอง</button></div>`:''}<div class="banner">${s.chapterCleared?'ชายแดนได้รับการปกป้องแล้ว ชีวิตในสำนักยังดำเนินต่อไป':'ก่อตั้งสำนักและดูแลผู้คนในหุบเขา ศิษย์แต่ละคนมีเส้นทางของตนเอง'}</div><div class="row"><b>หมู่บ้าน ${fmt(s.villageHP)} / 1,000</b><span>มรดก ${s.legacy} / 3</span></div>${meter(s.villageHP/10,'hp')}<div class="life-note"><b>เจ้าสำนัก: ${escape(game.world.npcs[s.life.offices.master?.npcId]?.name||'ยังไม่มีผู้รับหน้าที่')}</b><p>แนวทาง: ${escape(SectLifeSystem.AGENDAS[s.life.agenda?.id]?.name||'กำลังหารือ')}</p><button data-panel="life">เปิดสภาและเรื่องราวสำนัก</button></div><h3>นโยบายที่ผู้ดูแลสนับสนุน</h3><div class="inline-actions">${[['balanced','สมดุล'],['cultivate','สนับสนุนฝึกตน'],['resource','สนับสนุนเก็บทรัพยากร'],['defend','พิทักษ์ผู้คน'],['trade','เปิดเส้นทางค้า'],['craft','สนับสนุนการเรียนและอาชีพ']].map(([id,n])=>`<button data-policy="${id}" class="${s.policy===id?'gold':''}">${n}</button>`).join('')}</div><p class="meta">เพิ่มคะแนนงานที่สนับสนุน ศิษย์ยังคำนึงถึงความหิว สุขภาพ ความทรงจำ และความปรารถนาของตน</p><button data-world-section="academy">หอคัมภีร์ หน้าที่ และค่ายกล</button><button data-panel="log">รายงานและบันทึกหุบเขา</button><h3>ดูแลสำนัก</h3><div class="inline-actions"><button data-action="repair">ซ่อมแซม 60 ศิลา</button><button data-action="aid">ขอแรงชุมชน</button><button class="gold" data-panel="editHub">✎ เปิด Edit Hub</button></div><p class="meta">ชุมชนช่วยทุน 80 ไม้ 5 แร่ 3 ได้ทุก 180 วินาที แลกเสบียงหมู่บ้าน 25</p><h3>รักษาความคืบหน้า</h3><div class="inline-actions"><button data-action="save">บันทึก</button><button data-action="load">โหลด</button><button data-action="export">ส่งออกเซฟ</button><button data-action="import">นำเข้าเซฟ</button></div><p class="meta" id="saveStatus">เซฟอัตโนมัติทุก 45 วินาทีจริง และเมื่อซ่อนแอป</p><details><summary>เริ่มหุบเขาใหม่</summary><p class="meta">เริ่มศิษย์ชุดใหม่ เก็บตรามรดกสูงสุด 3 เพื่อรับทุนเพิ่มเล็กน้อย ส่งออกเซฟก่อนหากต้องการเก็บโลกนี้</p><button data-action="new" class="danger">เริ่มโลกใหม่ (ยืนยันอีกครั้ง)</button></details>`);}
 if(tab==='inventory'){renderInventory();}
 if(tab==='ecology'){renderEcology();}
 if(tab==='log'){renderChronicleReport();}
 if(tab==='objectives'){renderObjectives();}
 if(tab==='ending'){titleAndBody(s.status==='lost'?'สำนักสูญสิ้น':'ชายแดนสงบแล้ว',`<div class="banner">${s.status==='lost'?'หมู่บ้านหรือหอเจ้าสำนักถูกทำลาย ศิษย์ที่มีชีวิตรอดยังคงอยู่ในแฟ้มบันทึก':'ศิษย์ของสำนักปราบภัยสำเร็จและรักษาหมู่บ้านไว้ได้ ได้ตรามรดก 1 ดวง ชีวิตในสำนักยังดำเนินต่อได้'}</div><p>ปราบศัตรู ${s.stats.kills} · ผลงานช่าง ${s.stats.crafted} · การค้า ${s.stats.trades}</p><div class="inline-actions"><button data-action="export">ส่งออกบันทึกโลกนี้</button>${s.status!=='lost'?'<button data-action="continue">กลับไปดูชีวิตศิษย์</button>':''}<button data-action="new" class="gold">เริ่มหุบเขาใหม่</button></div>`);}
}
const itemRows=n=>{const l=n.jianghu.ledgerV140;return [...l.materialStacks.filter(i=>i.count>0).map(i=>({name:i.nameTh||i.matId,qty:i.count,type:'วัตถุดิบ',id:i.matId})),...l.pillStacks.map(i=>({name:i.nameTh||i.id,qty:i.count,type:'โอสถ',id:i.id})),...l.equipmentItems.map(i=>({name:i.nameTh||i.id,qty:1,type:'อุปกรณ์',id:i.id,equip:Object.values(n.jianghu.equipmentV140||{}).includes(i.id)}))];};
function bag(n){return `<div class="i1222" data-inventory1222 data-npc-id="${escape(n.id)}">${JianghuInventory1222.render(E,game.world,n,jade.getState(game.world,n.id))}</div>`;}
function matName(id){return E.PATCH140_DATA?.MATERIALS_REGISTRY_V140?.find(m=>m.id===id)?.nameTh||id;}
function pillSharing(source){const pills=source?.jianghu?.ledgerV140?.pillStacks?.filter(p=>p.count>0)||[];if(!pills.length)return '<p class="meta">ยังไม่มีโอสถให้แบ่งปัน</p>';return pills.map(p=>`<div class="entry"><div class="row"><b>${escape(p.nameTh)}</b><span>× ${p.count} · ${escape(p.quality||'STANDARD')}</span></div><div class="row"><select id="shareTo_${source.id}_${p.id}" aria-label="ผู้รับโอสถ">${game.heroes.filter(h=>alive(h)&&h.id!==source.id).map(h=>`<option value="${h.id}">${escape(h.name)}</option>`).join('')||'<option value="">ไม่มีผู้รับ</option>'}</select><button data-share-from="${source.id}" data-share-pill="${p.id}" ${game.heroes.filter(h=>alive(h)&&h.id!==source.id).length?'':'disabled'}>แบ่ง 1 เม็ด</button></div></div>`).join('');}
function renderInventory(){const s=game.s,tv=game.storyEvents?.inspect?.()?.treasuryView;const treasuryBanner=tv?(`<article class="card" style="border-left:3px solid #f0cf4a"><div class="row"><strong>🏛️ ผู้ดูแลคลังและร้านค้าสำนัก: ${escape(tv.distributorName)}</strong><span class="tag">${escape(tv.philosophy?.styleBadgeTh||"")}</span></div><p class="meta" style="margin:4px 0">${escape(tv.distributorRoleTitleTh)} · สินค้าในร้านค้าสำนัก <b>${tv.storeInventory?.all?.length||0} รายการ</b> · คำร้องรออนุมัติ <b>${tv.requisitions?.length||0} รายการ</b></p><div class="inline-actions"><button class="gold" data-open-store-tab>🏪 เปิดร้านค้าสำนัก &amp; งานผลิตสำนัก</button><button data-open-treasury-tab>🏛️ เปิดหอคลัง &amp; คำร้องขอเบิกของ</button><button data-treasury-action="curate-store">🏪 จัดของขึ้นร้านค้าสำนัก</button></div></article>`+renderSectStoreAndWorkshop(tv)):"";titleAndBody('คลังและงานช่าง',`${treasuryBanner}<div class="row"><b>คลังสำนัก</b><span>${fmt(game.gold)} ศิลา</span></div><div class="entry row"><span>ไม้ไผ่</span><b>× ${s.wood}</b></div><div class="entry row"><span>อาหาร</span><b>× ${s.food}</b></div>${bag(game.bank)}<h3>ซื้อจากตลาดหมู่บ้าน</h3><p class="meta">${game.routeBlocked()?'เส้นทางถูกรบกวน ราคาขึ้นเป็น 9':'เส้นทางเปิด ราคา 6'} ศิลาต่อหน่วย · ขายชุดละ 4</p><div class="inline-actions">${[[HERB,'สมุนไพร'],[ORE,'เหล็กดำ'],[CIN,'ชาด'],[FANG,'เขี้ยวอสูร'],['MAT_HERB_CINDER_LEAF_1','ใบชาเพลิง'],['MAT_HERB_JADE_LOTUS_2','บัวหยก'],['MAT_HERB_MIST_ORCHID_2','กล้วยไม้หมอก'],['wood','ไม้']].map(([id,n])=>`<button data-buy="${id}">${n} (${s.merchantStock[id]||0})</button>`).join('')}</div><h3>แบ่งโอสถจากคลังให้ศิษย์</h3>${pillSharing(game.bank)}<h3>กองทุนว่าจ้างช่างและโอสถพื้นฐาน</h3><p class="meta">สูตรโอสถพื้นฐานเปิดให้ศิษย์เรียนได้ทุกคน ฝีมือและพรสวรรค์กำหนดโอกาสสำเร็จและคุณภาพ การผลิตใช้วัตถุดิบจริงและมีเวลารอ ส่วนโอสถคืนปราณจะฟื้นปราณต่อสู้ ไม่ใช่เพิ่มความก้าวหน้าบ่มเพาะ</p>${game.recipes.map(r=>{const effect=r.effect||{};const effectText=effect.restoreQi?`คืนปราณต่อสู้ ${effect.restoreQi}`:effect.cultivationProgress?`เพิ่มความก้าวหน้าบ่มเพาะ ${effect.cultivationProgress}% (ไม่ใช่ปราณต่อสู้)`:effect.healHealth?`ฟื้นพลังชีวิต ${effect.healHealth}`:r.outputType==='EQUIPMENT'?'อุปกรณ์ต่อสู้':'ผลตามตำรับ';return `<article class="card"><strong>${escape(r.outputNameTh)}</strong><p class="meta">${r.inputs.map(i=>escape(matName(i.matId))+' ×'+i.count).join('<br>')}<br>${escape(effectText)}<br>เวลา ${r.durationDays} วัน · ฝีมือขั้นต่ำ ${r.minMastery} · คุณภาพตามฝีมือผู้ปรุง</p><button data-order="${r.id}" class="gold">สนับสนุนการผลิต 80</button></article>`;}).join('')}<h3>บัญชีงาน</h3>${s.orders.map(o=>`<div class="entry"><div class="row"><b>${escape(game.recipes.find(r=>r.id===o.recipeId)?.outputNameTh)}</b><span>${({funded:'รอศิษย์รับ',working:'กำลังผลิต',delivered:'ส่งมอบแล้ว',failed:'หลอมล้มเหลว',cancelled:'ยกเลิก'})[o.status]||o.status}</span></div><small>${o.heroId?escape(game.world.npcs[o.heroId]?.name):'ยังไม่มีผู้รับ'}${o.finishTick?' · จบวันที่ '+(o.finishTick+1):''}</small>${o.status==='funded'?` <button data-cancel-order="${o.id}">ถอนทุน</button>`:''}</div>`).join('')||'<p class="meta">ยังไม่มีงาน</p>'}<h3>เส้นทางนอกหุบเขา</h3><p class="meta">ตลาดหยกตะวันตก · เที่ยวละ ${s.route.duration} วินาที · สินค้าคงเหลือ ${s.route.stock} · ${game.routeBlocked()?'เสี่ยง 30%':'เสี่ยง 12%'}<br>ศิษย์ต้องเดินถึงถนนออกด่านและกลับที่เดิม สินค้ามีจำนวนจำกัดและมีต้นทุน</p>`);}
function renderHero(){const n=game.world.npcs[selected];if(!n){titleAndBody('แฟ้มผู้ฝึกตน','<p>ยังไม่ได้เลือกศิษย์</p>');return;}const j=n.jianghu,p=n.stageLocal;const tabs=[['overview','ภาพรวม'],['growth','แผนชีวิต'],['mind','ตัวตน'],['cultivation','บ่มเพาะ'],['techniques','วิชา'],['combat','ค่าต่อสู้'],['inventory','สัมภาระ'],['relations','สัมพันธ์'],['ai','ความคิด'],['memory','ความทรงจำ']];let html=`<div class="row hero-profile-actions"><strong>${escape(j.stageNameTh)}</strong><div class="inline-actions"><button data-edit-npc="${n.id}" class="gold">✎ แก้ไข</button><button data-action="follow">${follow?'เลิกติดตาม':'ติดตามบนแผนที่'}</button></div></div><p class="meta">${escape(describe(n))} · ${p.offmap?'นอกหุบเขา':Math.floor(p.x)+', '+Math.floor(p.y)+' ม.'}</p>${renderNpcKeywords(n,5)}<div class="tabs">${tabs.map(([id,name])=>`<button data-hero-tab="${id}" class="${heroTab===id?'active':''}">${name}</button>`).join('')}</div>`;
 if(heroTab==='overview'){
  const topScores=(p.scores||[]).slice(0,5);
  const topScore=topScores[0];
  const whyItems=topScore?Object.entries({
   'ค่านิยมหลัก':topScore.contributions?.valueAdj,
   'บุคลิกภาพ':topScore.contributions?.personalityAdj,
   'ความสนใจ':topScore.contributions?.interestAdj,
   'ความพร้อม/พรสวรรค์':(topScore.contributions?.capabilityAdj||0)+(topScore.contributions?.aptitudeAdj||0),
   'แรงขับชีวิต':topScore.contributions?.needAdj,
   'แผนชีวิต/หน้าที่':(topScore.contributions?.goalAdj||0)+(topScore.contributions?.authorityAdj||0)
  }).filter(([,v])=>Math.abs(Number(v)||0)>=0.1).map(([k,v])=>`<li>${escape(k)} <span class="meta">(${Number(v)>0?'+':''}${Number(v).toFixed(1)})</span></li>`).join(''):'';
  const consideredLine=topScores.length?topScores.map(o=>`${escape(actionLabel(o.id)||o.id)} ${o.score.toFixed(1)}`).join(' · '):'กำลังประเมินทางเลือก';
  const cs=p.combatState||{qi:j.currentQiV190||60,maxQi:j.maxQiV190||60};
  html+=`<h3>กำลังทำอะไร</h3><div class="card"><b>📋 ${escape(p.goal||actionLabel(p.action)||'ประเมินสถานการณ์')}</b>${whyItems?`<p class="meta" style="margin:4px 0 2px">เพราะ:</p><ul class="sonnet-why">${whyItems}</ul>`:""}<p class="meta" style="margin-top:6px">ตัวเลือกที่ชั่งใจ: ${consideredLine}</p></div>`;
  html+=`<h3>สถานะ</h3><div class="card">${sBar('สภาพร่างกาย',n.health,100,'#e0584a',`${fmt(n.health)}/100`)}${sBar('ปราณต่อสู้',cs.qi||0,cs.maxQi||100,'#4fb2f2',`${Math.round(cs.qi||0)}/${Math.round(cs.maxQi||100)}`)}${sBar('อิ่ม',100-(p.needs?.hunger??20),100,'#5fd38a')}${sBar('พักผ่อน',100-(n.core.condition.fatigue||0),100,'#4fb2f2')}${sBar('ความก้าวหน้าตบะ',j.cultivationProgress||0,100,'#f0cf4a',`${fmt(j.cultivationProgress)}%`)}${sBar('ความเครียด',n.core.condition.moodStress||0,100,(n.core.condition.moodStress||0)>60?'#e0584a':'#9db0c2')}${sBar('สังคม',100-(p.needs?.social??25),100,'#b58cf0')}</div>`;
  html+=GrowthView.profile(game,n)+SectLifeView.profile(game,n)+JianghuRealmView.profile(game,n);
  html+=`<div class="card"><b>ปณิธานแห่งมรรคา</b><p>${escape(p.aspiration?.text)}</p><small>${p.aspiration?.fulfilled?'✓ บรรลุความปรารถนาแล้ว':'ยังคงมุ่งมั่นแสวงหา · ส่งผลต่อการเลือกงาน'}</small></div><div class="inline-actions"><button data-hero-tab="combat" class="gold">คุณสมบัติต่อสู้และที่มา</button><button data-hero-tab="mind">สำรวจรากฐานตัวตน 68 แกน</button></div><p class="meta" style="margin-top:8px">ศิลาวิญญาณส่วนตัว ${fmt(E.getSpiritStonesV140(n))} ศิลา · พิษโอสถสะสม ${fmt(j.pillToxicity||0)} · จิตมาร ${fmt(j.heartDemon||0)} · รากวิญญาณ ${escape(n.core.physiology?.spiritRoot?.nameTh||n.core.physiology?.spiritRoot?.gradeId||'ดูรายละเอียดนิสัย')}</p>`;
 }
 if(heroTab==='growth')html+=GrowthView.render(game,n,growthSection);
 if(heroTab==='mind')html+=HumanDossier.render(n,game.world,[...game.heroes,...game.visitors],identitySection,compareId);
 if(heroTab==='cultivation'){const tr=E.getCultivationTrackV1200(j.path,j.subPath);html+=`<h3>${escape(j.pathNameTh)}</h3><p><b>${escape(j.subPathNameTh)}</b></p><div class="card"><b>${escape(j.stageNameTh)}</b><p>ขอบเขต ${j.trackOrdinal} / ${tr.realmCount} · ระดับเทียบเคียง ${j.realizationBand}<br>ความก้าวหน้า ${j.cultivationProgress.toFixed(1)}%</p>${meter(j.cultivationProgress)}<small>${escape(tr.specialtySummaryTh||'')}</small></div><p class="meta">${escape(p.pathReason)}</p><h3>${tr.realmCount} ขอบเขตแห่งมรรคา (${escape(tr.nameTh||j.subPathNameTh)})</h3>${tr.realms.map(r=>`<div class="entry ${r.ordinal===j.trackOrdinal?'good':''}">${r.ordinal<=j.trackOrdinal?'◆':'◇'} ขั้นที่ ${r.ordinal}: ${escape(r.nameTh)}${r.ordinal===j.trackOrdinal?' · ปัจจุบัน':''}</div>`).join('')}<h3>เงื่อนไขการทะลวงด่านถัดไป</h3>${(E.evaluateCausalBreakthroughV1200(game.world,n).hardGates||[]).map(g=>`<div class="entry"><span class="${g.passed?'good':'bad'}">${g.passed?'✓':'○'} ${escape(g.nameTh)}</span><br><small>${escape(g.reasonTh)}</small></div>`).join('')}<p class="meta">ศิษย์ต้องสะสมตบะ หลักฐานความเข้าใจเต๋า และสุขภาพให้พร้อมก่อนเข้าด่านทะลวงคอขวด</p><p>${escape(p.breakthroughBlock||j.breakthroughProjectV1200?.phase||'กำลังสั่งสมตบะและหลักฐานมรรคา')}</p>`;}
 if(heroTab==='techniques'){html+=`<button data-hero-tab="combat">คุณสมบัติต่อสู้และที่มา</button>`+CombatView117.render(game,n);}
 if(heroTab==='combat'){html+=CombatView117.stats(game,n);}
 if(heroTab==='inventory'){const acc=game.s.storyEvents?.treasury?.contributions?.accounts?.[n.id],usedToday=acc?.grantDay===Math.floor((game.s.t||0)/20)?(acc.grantQuantity||0):0,merit=game.life?.member?.(n)?.merit||0;html+=`<h3>สัมภาระของ ${escape(n.name)}</h3><p class="meta">${fmt(E.getSpiritStonesV140(n))} หินวิญญาณส่วนตัว · วัสดุ ${HumanCore.load(n)} / กำลังบรรทุก ${HumanCore.carryLimit(n)} หน่วย · แต้มคุณูปการ ${acc?.balance||0} แต้ม (สะสม ${acc?.earned||0} · ใช้ไป ${acc?.spent||0} · ความดีความชอบ ${Math.round(merit*10)/10} · โควตารับแจกวันนี้ ${usedToday}/${window.JianghuInfrastructure?.bonuses(game).welfareDailyLimit||4})</p><div class="inline-actions" style="margin-bottom:8px"><button class="gold" data-open-treasury-tab>🏛️ เปิดหอคลัง &amp; คำร้องขอเบิกของ</button></div>${bag(n)}<h3>แบ่งโอสถให้ศิษย์ร่วมสำนัก</h3>${pillSharing(n)}`;}
 if(heroTab==='relations'){html+=[...game.heroes,...game.visitors].filter(h=>h.id!==n.id).map(h=>{const r=E.getRelationshipV130(game.world,n,h,false);return `<div class="card"><b>${escape(h.name)} ${alive(h)?'':'· สิ้นชีพ'}</b><p>ความรู้สึกที่ดี ${fmt(r?.affinity)} · สายสัมพันธ์ ${fmt(r?.bond)} · ความนับถือ ${fmt(r?.respect)}</p></div>`;}).join('')||'<p class="meta">ยังไม่มีศิษย์คนอื่น</p>';}
 if(heroTab==='ai'){html+=`<div class="card"><b>เจตจำนงปัจจุบัน: ${escape(p.goal)}</b><p>แผนการ: ${p.mode==='travel'?'กำลังเดินทาง → ':''}${escape(actionLabel(p.action)||p.action||'ประเมินสถานการณ์')} → พักหรือพิจารณาทางเลือกถัดไป<br>พิกัดเป้าหมาย ${p.target?Math.floor(p.target.x)+', '+Math.floor(p.target.y)+' ม.':'ไม่มี'}<br>ระดับภัยคุกคามใกล้ตัว ${p.danger} / 100<br>เวลางานคงเหลือ ${Math.ceil(p.job)} วินาที</p></div><p class="meta">ความกระจ่างชัดของจิตขณะตัดสินใจ ${fmt(p.decisionClarity)} / 100</p><h3>คะแนนประเมินทางเลือกครั้งล่าสุด</h3>${p.scores.map(o=>`<div class="score"><span>${escape(actionLabel(o.id)||(o.id.startsWith('bounty:')?'รับประกาศค่าหัว':o.id))}</span><strong>${o.score.toFixed(1)}</strong><small>${escape(o.reason)} · เสี่ยง ${o.risk||0}<br>ค่านิยม ${o.contributions.valueAdj??0} · บุคลิก ${o.contributions.personalityAdj} · พรสวรรค์ ${o.contributions.aptitudeAdj} · ความเสี่ยง ${o.contributions.riskAdj}<br>ความสนใจ ${o.contributions.interestAdj??0} · ความพร้อม ${o.contributions.capabilityAdj??0} · แรงขับ ${o.contributions.needAdj??0} · สำนัก ${o.contributions.authorityAdj??0} · แผนชีวิต ${o.contributions.goalAdj??0}</small></div>`).join('')}<h3>สถานที่ที่รู้จักในหุบเขา</h3><p class="meta">${p.known.map(id=>escape(LOCS.find(p=>p.id===id)?.name||id)).join(' · ')}</p>`;}
 if(heroTab==='memory'){html+=`<h3>ความทรงจำที่หล่อหลอมการตัดสินใจ</h3>${p.memories.map(m=>`<div class="entry"><small>วันที่ ${Math.floor(m.t/DAY)+1} · อิทธิพล ${m.valence>0?'+':''}${m.valence}</small><br>${escape(m.text)}</div>`).join('')||'<p class="meta">กำลังสั่งสมประสบการณ์ในสำนัก</p>'}<h3>บันทึกเหตุการณ์ประจำตัว</h3>${p.history.map(m=>`<div class="entry"><small>${m.t} วิ</small> ${escape(m.text)}</div>`).join('')}`;}
 titleAndBody(n.name,html);
}
function editField(key,label,value,min=0,max=100,step=1,disabled=false,type='number'){
 return `<label class="edit-field"><span>${escape(label)}</span><input type="${type}" data-npc-field="${escape(key)}" value="${escape(value)}" ${type==='number'?`min="${min}" max="${max}" step="${step}"`:''} ${disabled?'disabled':''}></label>`;
}
function axisFields(n,kind,defs){return defs.map(d=>editField(kind+':'+d.id,JianghuSafeEditor.axisLabel(d),JianghuSafeEditor.axisRead(n,kind,d.id),0,100,1)).join('');}
function renderNpcEditor(){
 const n=game?.world?.npcs?.[selected];if(!n){titleAndBody('แก้ไข NPC','<p class="meta">กรุณาเลือก NPC ก่อน</p>');return;}
 const D=E.NPC_CORE_DATA,dead=!n.alive,hpMax=n.stageLocal?.boss?240:100,ageMax=Math.max(1,(n.jianghu.lifespanMax||10000)-1),track=E.getCultivationTrackV1200?.(n.jianghu.path,n.jianghu.subPath),stageMax=track?.realmCount||n.jianghu.maxStage||9;
 const allPaths=Object.values(E.CULTIVATION_PATHS||{});
 const pathSelect=`<label class="edit-field"><span>วิถีใหญ่ (Major Path)</span><select data-npc-field="path" id="npcEditPathSelect">${allPaths.map(p=>`<option value="${escape(p.id)}" ${p.id===n.jianghu.path?'selected':''}>${escape(p.shortTh||p.nameTh)}</option>`).join('')}</select></label>`;
 const subSelect=`<label class="edit-field"><span>สายการบ่มเพาะ (Subpath · รวม 41 สาย)</span><select data-npc-field="subPath" id="npcEditSubPathSelect">${allPaths.flatMap(p=>Object.values(p.subPaths||{}).map(s=>`<option value="${escape(s.id)}" data-parent-path="${escape(p.id)}" ${s.id===n.jianghu.subPath?'selected':''}>[${escape(p.shortTh||p.id)}] ${escape(s.nameTh)}</option>`)).join('')}</select></label>`;
 const basics=`${editField('name','ชื่อ NPC',n.name,0,80,1,false,'text')}${editField('age','อายุ',n.age||1,1,ageMax,1)}${editField('health','พลังชีวิต',Math.max(1,n.health||1),1,hpMax,1,dead)}${editField('stones','ศิลาวิญญาณส่วนตัว',E.getSpiritStonesV140(n),0,1000000000,1)}${pathSelect}${subSelect}${editField('cultivationStage','ขั้นขอบเขตพลัง',n.jianghu.trackOrdinal||n.jianghu.stage||1,1,stageMax,1)}${editField('progress','ความก้าวหน้าบ่มเพาะ (%)',n.jianghu.cultivationProgress||0,0,100,.1)}`;
 const details=`<div class="edit-intro"><span>JIANGHU · SAFE NPC EDITOR</span><h3>${escape(n.name)}</h3><p>แก้ข้อมูลตัวละคร วิถีบ่มเพาะ (5 วิถี 41 สาย) และแกนตัวตน 68 มิติ ระบบจะตรวจสอบความถูกต้องโดยไม่ทำให้โครงสร้างเซฟเสียหาย</p></div>
 <section class="card"><div class="row"><b>ข้อมูลพื้นฐานและมรรคา</b><span class="meta">${dead?'เสียชีวิตแล้ว · ปรับพลังชีวิตไม่ได้':'มีชีวิต'}</span></div><div class="edit-grid">${basics}</div></section>
 <details class="edit-group"><summary>อุปนิสัย · 14 แกน</summary><div class="edit-grid">${axisFields(n,'personality',D.PERSONALITY_AXES_14||[])}</div></details>
 <details class="edit-group"><summary>ค่านิยมหลัก · 8 แกน และพรสวรรค์ · 6 แกน</summary><h4>ค่านิยมหลัก</h4><div class="edit-grid">${axisFields(n,'value',D.VALUE_DIMENSIONS_8||[])}</div><h4>พรสวรรค์</h4><div class="edit-grid">${axisFields(n,'aptitude',D.APTITUDE_DOMAINS_6||[])}</div></details>
 <details class="edit-group"><summary>สมรรถภาพร่างกาย · 14 แกน</summary><div class="edit-grid">${axisFields(n,'body',HumanCore.bodyDefs||[])}</div></details>
 <details class="edit-group"><summary>การคิดและการรับรู้ · 12 แกน</summary><div class="edit-grid">${axisFields(n,'cognition',HumanCore.cognitiveDefs||[])}</div></details>
 <details class="edit-group"><summary>ความสนใจ · 14 แกน</summary><div class="edit-grid">${axisFields(n,'interest',HumanCore.interestDefs||[])}</div></details>
 <div class="edit-actions"><button class="gold" data-save-npc-edit>บันทึกการแก้ไข</button><button data-cancel-npc-edit>ยกเลิก</button></div>`;
 titleAndBody('แก้ไข NPC · '+n.name,details);
}
function renderEditHub(){
 const s=game.s,mats=JianghuSafeEditor.materialCatalog(),items=JianghuSafeEditor.itemRecipeCatalog(game),manuals=JianghuSafeEditor.manualCatalog?.()||[],npcs=JianghuSafeEditor.listNpcs(game);
 const categoryName={HERB:'สมุนไพร',ORE:'แร่',BEAST_PART:'ชิ้นส่วนอสูร',PILL:'โอสถ',MATERIAL:'วัตถุดิบ',SEED:'เมล็ดพันธุ์'};
 const materialOptions=mats.map(m=>`<option value="${escape(m.id)}">${escape(m.nameTh)} · T${m.tier||1} · ${escape(categoryName[m.category]||m.category||'วัตถุดิบ')}</option>`).join('');
 const itemOptions=items.map(r=>`<option value="${escape(r.id)}">${({PILL:'โอสถ',EQUIPMENT:'อุปกรณ์',BEAST_ITEM:'ไอเท็มอสูร'})[r.outputType]||r.outputType} · ${escape(r.outputNameTh)} · ระดับ ${r.tier||1}</option>`).join('');
 const manualOptions=manuals.map(m=>`<option value="${escape(m.id)}">[ระดับ ${m.tier} · ${escape(m.rarityBadgeTh||'สามัญ')}] ${escape(m.nameTh)} (${escape(m.path)})</option>`).join('');
 const byCat=JianghuSafeEditor.listNpcsByCategory?JianghuSafeEditor.listNpcsByCategory(game):{disciples:npcs,visitors:[],enemies:[]};
 const npcOptions=npcs.map(n=>`<option value="${escape(n.id)}">[ศิษย์สำนัก] ${escape(n.name)} · ${escape(n.jianghu?.subPathNameTh||'')} · ${n.alive?'มีชีวิต':'เสียชีวิต'}</option>`).join('');
 const allEditableOptions=[
  ...(byCat.disciples||[]).map(n=>`<option value="${escape(n.id)}">[ศิษย์สำนัก] ${escape(n.name)} · ${escape(n.jianghu?.subPathNameTh||'')} · ${n.alive?'มีชีวิต':'เสียชีวิต'}</option>`),
  ...(byCat.visitors||[]).map(n=>`<option value="${escape(n.id)}">[ผู้มาเยือน] ${escape(n.name)} · ${escape(n.jianghu?.subPathNameTh||'')} · ${n.alive?'มีชีวิต':'เสียชีวิต'}</option>`),
  ...(byCat.enemies||[]).map(n=>`<option value="${escape(n.id)}">[ศัตรู/ค่ายโจร] ${escape(n.name)} · ${n.alive?'มีชีวิต':'เสียชีวิต'}</option>`)
 ].join('');
 const logs=(s.editHubHistory||[]).slice(0,8).map(r=>`<div class="entry"><div class="row"><b>${escape(r.summary||r.kind)}</b><small>วัน ${Math.floor((r.t||0)/DAY)+1}</small></div><p class="meta">${escape(r.kind)}${r.targetId?' · '+escape(r.targetId):''}</p></div>`).join('')||'<p class="meta">ยังไม่มีประวัติการแก้ไข</p>';
 titleAndBody('Edit Hub · ผู้ดูแลโลก',`<div class="edit-intro"><span>JIANGHU · ADMIN TOOLS v1.17</span><h3>แก้ไขโลก มอบคัมภีร์ และปรับเปลี่ยนวิถี</h3><p>ปรับทรัพยากร เสกวัตถุดิบ โอสถ ศาสตรา มอบคัมภีร์วิชายุทธ์ทั้ง 66 เล่มใหม่ หรือเปิดตัวแก้ไข NPC</p></div>
 <section class="card"><h3>ทรัพยากรสำนัก</h3><div class="edit-grid">${editField('hub:stones','ศิลาวิญญาณสำนัก',game.gold,0,1000000000)}${editField('hub:wood','ไม้',s.wood,0,1000000000)}${editField('hub:food','อาหาร',s.food,0,1000000000)}${editField('hub:ore','แร่เหล็กดำสามัญ',game.ore,0,1000000000)}</div><button class="gold" data-save-hub-resources>บันทึกทรัพยากร</button></section>
 <section class="card"><h3>มอบคัมภีร์วิชายุทธ์ (66 คัมภีร์ใหม่ · 7 ระดับความหายาก)</h3><label class="edit-field"><span>เลือกคัมภีร์</span><select id="editManualSelect">${manualOptions}</select></label><label class="edit-field"><span>มอบให้ผู้ฝึกตน หรือ หอสืบทอด</span><select id="editManualNpcSelect"><option value="SECT_LIBRARY">🏛️ หอคัมภีร์ส่วนรวมของสำนัก (Sect Library)</option>${npcOptions}</select></label><button class="gold" data-grant-manual ${manuals.length&&npcs.length?'':'disabled'}>＋ มอบคัมภีร์เข้าสัมภาระ</button><p class="meta">ผู้รับจะอ่านตีความและฝึกฝนคัมภีร์นี้ตามระบบการเรียนรู้จริง</p></section>
 <section class="card"><h3>เสกวัตถุดิบเข้าคลังสำนัก</h3><label class="edit-field"><span>เลือกวัตถุดิบ</span><select id="editMaterialSelect">${materialOptions}</select></label><div class="edit-grid">${editField('hub:materialQty','จำนวนที่เสก',10,1,100000)}</div><button class="gold" data-grant-material>＋ เสกเข้าคลัง</button></section>
 <section class="card"><h3>เสกไอเท็มจากทะเบียนจริง</h3><label class="edit-field"><span>เลือกไอเท็ม</span><select id="editItemSelect">${itemOptions||'<option value="">ไม่มีไอเท็มที่รองรับ</option>'}</select></label><div class="edit-grid">${editField('hub:itemQty','จำนวนไอเท็ม',1,1,10000)}</div><button class="gold" data-grant-item ${items.length?'':'disabled'}>＋ เสกไอเท็มเข้าคลัง</button></section>
 <section class="card"><h3>แก้ไข NPC และสายการบ่มเพาะ</h3><label class="edit-field"><span>เลือก NPC ในหุบเขา</span><select id="editHubNpcSelect">${allEditableOptions||npcOptions||'<option value="">ไม่พบ NPC</option>'}</select></label><button data-hub-edit-npc ${npcs.length?'':'disabled'}>เปิดตัวแก้ไข NPC</button></section>
 <h3>ประวัติ Edit Hub ล่าสุด</h3>${logs}`);
}
function refresh(){needsRender=true;if(!game)return;const s=game.s;$('#resources').innerHTML=`<span>◆ <b>${fmt(game.gold)}</b></span><span>ไม้ <b>${s.wood}</b></span><span>แร่ <b>${game.ore}</b></span><span>อาหาร <b>${s.food}</b></span><span>ศิษย์ <b>${game.heroes.filter(alive).length}</b></span>`;
 $('#clock').textContent='วันที่ '+(Math.floor(s.t/DAY)+1)+' · '+Math.floor((s.t%DAY)/DAY*24).toString().padStart(2,'0')+':00';$('#pause').textContent=s.paused?'▶':'Ⅱ';$('#pause').setAttribute('aria-label',s.paused?'เล่นต่อ':'หยุดเวลา');$('#speed').textContent=s.speed+'×';$('#speed').setAttribute('aria-label','ความเร็วจำลอง '+s.speed+' เท่า · แตะเพื่อเปลี่ยน');
 const n=game.world.npcs[selected];if(n?.stageLocal&&!placement){$('#selection').hidden=false;$('#selection').innerHTML=`<strong>${escape(n.name)}</strong><div>${escape(describe(n))}</div>${meter(n.health,'hp')}<span>${escape(n.jianghu.subPathNameTh)} · ${escape(n.jianghu.stageNameTh)}</span>${renderNpcKeywords(n,3)}<br><button data-detail>เปิดแฟ้ม</button> <button data-combat-entity="${n.id}">ค่าต่อสู้</button> <button data-edit-npc="${n.id}">แก้ไข</button> <button data-action="follow">${follow?'เลิกตาม':'ติดตาม'}</button>`;}else {const a=combatEntity(selected);if(a&&!placement){$('#selection').hidden=false;$('#selection').innerHTML=`<strong>${escape(a.name)}</strong><div>${a.stageLocal?.pet||a.ownerId?'อสูรคู่หู':'สัตว์อสูร'} · HP ${Math.round(a.health||0)} / ${Math.round(a.maxHP||1)}</div>${meter(100*(a.health||0)/Math.max(1,a.maxHP||1),'hp')}<button data-combat-entity="${escape(a.id)}">คุณสมบัติต่อสู้และที่มา</button>`;}else $('#selection').hidden=true;}
 const seHud=game.storyEvents?.inspect?.();
 let objective=!game.built('hall')?'ก่อตั้งสำนัก · สร้างหอเจ้าสำนัก':game.heroes.length<2?'เปิดรับศิษย์ · ต้องการอย่างน้อย 2 คน':s.status==='lost'?'สำนักสูญสิ้น':seHud?(seHud.epPhase==='ALL_COMPLETED'?'👑 จบเนื้อเรื่องครบ 8 บท · มหาสำนักเทียมฟ้า':`📜 ${seHud.epDef?.titleTh||'EP.1'} (${seHud.epPhase==='ACTIVE_TRIAL'?'กำลังทดสอบ':seHud.conditions.filter(c=>c.passed).length+'/'+seHud.conditions.length})`):(s.chapterCleared?'ชายแดนสงบ · มรรคายังดำเนินต่อ':'ขจัดภัย · ปกป้องหมู่บ้าน');
 const subObjective=seHud?.activeDynamicEvent?`⚡ อีเวนต์: ${escape(seHud.activeDynamicEvent.nameTh)} (เหลือ ${Math.max(0,Math.ceil((seHud.activeDynamicEvent.expiresAt||s.t)-s.t))} วิ)`:`พูลอีเวนต์ EP.${seHud?.currentEp||1} · หมู่บ้าน ${fmt(s.villageHP/10)}% · แตะดูเควสและอีเวนต์`;
 $('#objective').innerHTML=`<small>หุบเขาเมฆาคราม · เควสเนื้อเรื่องและอีเวนต์</small><b>${escape(objective)}</b><small>${subObjective}</small>`;
 $('#ticker').textContent=s.log[0]?.text||'สายลมปราณพัดผ่านหุบเขาเมฆาคราม…';if(placement&&preview){const why=game.footprint(placement,preview.x,preview.y);$('#placeError').textContent=why||'วางได้ · '+Math.round(preview.x)+', '+Math.round(preview.y)+' ม.';$('#confirmPlace').disabled=!!why;}
 if(tab&&!['npcEdit','editHub'].includes(tab))renderPanel();}
document.addEventListener('click',async e=>{if(!game)return;const b=e.target.closest('button,[data-hero]');if(!b)return;
 if(b.hasAttribute('data-open-store-tab')){questTab='store';open('objectives');return;}
 if(b.hasAttribute('data-open-treasury-tab')){questTab='treasury';open('objectives');return;}
 if(b.dataset.outsideBuy){result(window.JianghuSectContributions.acceptExternalOffer(game,b.dataset.outsideBuy),'รับซื้อสินค้าแล้ว');return;}
 if(b.dataset.memberOutsideBuy){const [offerId,qtyArg]=b.dataset.memberOutsideBuy.split(':');const npcId=$('#externalMemberSelect')?.value||marketMemberId||selected||game.heroes.find(alive)?.id;const qty=qtyArg==='all'?null:Number(qtyArg);result(window.JianghuSectContributions.buyExternalOffer(game,npcId,offerId,qty),'ศิษย์ซื้อสินค้าจากคนนอกแล้ว');return;}
 if(b.dataset.memberOutsideSell){const [orderId,qtyArg]=b.dataset.memberOutsideSell.split(':');const npcId=$('#externalMemberSelect')?.value||marketMemberId||selected||game.heroes.find(alive)?.id;const qty=qtyArg==='max'?null:Number(qtyArg);result(window.JianghuSectContributions.sellPersonalToPurchaseOrder(game,npcId,orderId,qty),'ศิษย์ขายสินค้าให้คนนอกแล้ว');return;}
 if(b.hasAttribute('data-member-trade-auto')){const s=window.JianghuSectContributions.externalMarket(game);s.autoMemberTrade=s.autoMemberTrade===false;result({ok:true,reason:s.autoMemberTrade?'เปิดการซื้อขายอัตโนมัติของศิษย์กับคนนอก':'ปิดการซื้อขายอัตโนมัติของศิษย์แล้ว'});return;}
 if(b.dataset.outsideReject){result(window.JianghuSectContributions.rejectExternalOffer(game,b.dataset.outsideReject),'ปฏิเสธข้อเสนอแล้ว');return;}
 if(b.hasAttribute('data-outside-auto')){const s=window.JianghuSectContributions.externalMarket(game);s.autoProcure=!s.autoProcure;result({ok:true,reason:s.autoProcure?'เปิดผู้ดูแลคลังจัดซื้ออัตโนมัติ':'ปิดการจัดซื้ออัตโนมัติแล้ว'});return;}
 if(b.dataset.outsideSell){
  const [orderId,qtyArg]=b.dataset.outsideSell.split(':');
  const qty=qtyArg==='1'?1:null;
  result(window.JianghuSectContributions.sellToPurchaseOrder(game,orderId,qty),'ขายของส่วนเกินแล้ว');
  return;
 }
 if(b.hasAttribute('data-outside-sell-auto')){const s=window.JianghuSectContributions.externalMarket(game);s.autoSell=s.autoSell===false;result({ok:true,reason:s.autoSell?'เปิดผู้ดูแลคลังขายของส่วนเกินอัตโนมัติ':'ปิดการขายของส่วนเกินอัตโนมัติแล้ว'});return;}
 if(b.dataset.libraryStudy){const id=$('#storeBuyerSelect')?.value||selected||game.heroes.find(alive)?.id,n=game.world.npcs[id],q=window.JianghuSectLibrary.quote(game,n,b.dataset.libraryStudy);if(!q.ok||!q.canAfford||q.learned){result({ok:false,reason:q.learned?'ศิษย์เรียนวิชานี้เข้าใจแล้ว':q.reason});return;}if(n.stageLocal.mode!=='idle'){result({ok:false,reason:'ศิษย์กำลังทำงานอื่น รอให้ว่างก่อน'});return;}const shrine=game.built('shrine');if(!shrine){result({ok:false,reason:'ต้องมีหอคัมภีร์ก่อน'});return;}n.stageLocal.growthTarget=b.dataset.libraryStudy;const sent=game.send(n,'readLibraryScripture',game.endpoint(shrine),16);result({ok:sent,reason:sent?'เดินไปศึกษา ค่าเรียนจะหักเมื่อเริ่มบทเรียนจริง':'ไม่มีเส้นทางไปหอคัมภีร์'});return;}
 if(b.dataset.upgradeBuilding){result(window.JianghuInfrastructure.requestUpgrade(game,b.dataset.upgradeBuilding),'เริ่มงานยกระดับแล้ว');return;}
 if(b.hasAttribute('data-infrastructure-auto')){window.JianghuInfrastructure.tick(game,0);game.s.infrastructure.autoEnabled=!game.s.infrastructure.autoEnabled;result({ok:true,reason:game.s.infrastructure.autoEnabled?'เปิดการประเมินยกระดับอาคารโดย NPC':'ปิดการยกระดับอัตโนมัติแล้ว'});return;}
 if(b.dataset.storeBuy){
  const [kind,...rest]=b.dataset.storeBuy.split(':'),id=rest.join(':');
  const buyerId=$('#storeBuyerSelect')?.value||selected||game.heroes.find(alive)?.id;
  result(window.JianghuSectContributions?.buyFromStore(game,buyerId,kind,id,1),'ซื้อสินค้าจากร้านค้าสำนักแล้ว');
  return;
 }
 if(b.dataset.transferToStore){
  const [kind,...rest]=b.dataset.transferToStore.split(':'),id=rest.join(':');
  result(window.JianghuSectContributions?.transferToStore(game,kind,id,1),'ส่งพัสดุขึ้นร้านค้าสำนักแล้ว');
  return;
 }
 if(b.dataset.returnToTreasury){
  const [kind,...rest]=b.dataset.returnToTreasury.split(':'),id=rest.join(':');
  result(window.JianghuSectContributions?.returnToTreasury(game,kind,id,1),'ย้ายพัสดุกลับคลังสำนักแล้ว');
  return;
 }
 if(b.dataset.sectCraft){
  const crafterId=$('#sectCrafterSelect')?.value||selected||game.heroes.find(alive)?.id;
  const n=game.world.npcs[crafterId],c=window.JianghuSectContributions?.canCraftForSect(game,n,b.dataset.sectCraft);
  if(!c?.ok){result(c,'เริ่มงานไม่ได้');return;}
  if(n.stageLocal.mode!=='idle'){result({ok:false,reason:'ศิษย์กำลังทำกิจกรรมอื่นอยู่ รอให้ว่างก่อน'});return;}
  game.send(n,'sectCraft:'+b.dataset.sectCraft,game.endpoint(c.workshopBuilding),Math.max(8,c.recipe.duration/(window.JianghuInfrastructure?.bonuses(game).perWorkshop?.[c.recipe.workshop]?.craftSpeed||1)));
  result({ok:true,reason:'ศิษย์เดินไปโรงหลอมและใช้เวลาผลิตจริง วัตถุดิบจะตรวจซ้ำเมื่อเริ่มหลอม'},'มอบหมายงานผลิตแล้ว');
  return;
 }
 if(b.dataset.questTab){questTab=b.dataset.questTab;renderPanel();$('#content').scrollTop=0;return;}
 if(b.dataset.selectStoryBranch){result(game.storyEvents?.selectStoryBranch(b.dataset.selectStoryBranch,false),'เปลี่ยนกิ่งเนื้อเรื่องแล้ว');return;}
 if(b.dataset.triggerChain){result(game.storyEvents?.triggerQueuedChainNow(b.dataset.triggerChain),'เรียกอีเวนต์ผลพวงต่อเนื่องแล้ว');return;}
 if(b.dataset.judgeReq){
  const mode=b.dataset.judgeMode;
  const force=mode==='approve'?true:mode==='reject'?false:null;
  result(game.storyEvents?.judgeRequisition(b.dataset.judgeReq,force,b.dataset.judgeAuthority||null),'ดำเนินการพิจารณาคำร้องแล้ว');
  return;
 }
 if(b.dataset.treasuryAction){
  const ta=b.dataset.treasuryAction;
  if(ta==='curate-store')result(window.JianghuSectContributions?.curateStore(game),'ผู้อาวุโสฝ่ายคลังจัดสรรสินค้าขึ้นร้านค้าสำนักแล้ว');
  else if(ta==='master-decide')result(game.storyEvents?.letMasterDecideTreasuryAuthority(),'เจ้าสำนักตัดสินใจแต่งตั้งผู้ดูแลคลังตามนิสัยแล้ว');
  else if(ta==='master-direct')result(game.storyEvents?.setTreasuryAuthority('MASTER_DIRECT'),'เจ้าสำนักลงมาคุมและแจกจ่ายคลังด้วยตนเองแล้ว');
  else if(ta==='appoint-selected'){const id=$('#treasuryElderSelect')?.value;result(game.storyEvents?.setTreasuryAuthority('APPOINTED_ELDER',id),'แต่งตั้งผู้อาวุโสหอคลังแล้ว');}
  else if(ta==='toggle-auto')result(game.storyEvents?.toggleAutoTreasuryDistribute(),'สลับสถานะการแจกจ่ายคลังอัตโนมัติแล้ว');
  else if(ta==='judge-all')result(game.storyEvents?.judgeAllRequisitionsByNpcPersonality(),'ผู้ดูแลคลังพิจารณาคำร้องตามนิสัยแล้ว');
  else if(ta==='proactive-distribute')result(game.storyEvents?.proactiveDistributeFromTreasury(),'ผู้ดูแลคลังแจกจ่ายพัสดุตามนิสัยแล้ว');
  else if(ta==='refresh-reqs')result(game.storyEvents?.refreshDiscipleRequisitions(),'สำรวจคำร้องขอเบิกของจากศิษย์แล้ว');
  else if(ta==='create-req'){
   const npcId=$('#reqDiscipleSelect')?.value;
   const rawItem=$('#reqItemSelect')?.value||'';
   const [kind,itemId]=rawItem.split(':');
   if(npcId&&kind&&itemId)result(game.storyEvents?.createManualRequisition(npcId,kind,itemId,reqForm.mode,reqForm.authorityId),'ยื่นคำร้องขอเบิกของแล้ว');
  }
  return;
 }
 if(b.dataset.sidequestAccept){result(JianghuSideQuests.accept(game,b.dataset.sidequestAccept),'เปิดสัญญาให้ศิษย์เลือกทำแล้ว');return;}
 if(b.dataset.sidequestCancel){result(JianghuSideQuests.cancel(game,b.dataset.sidequestCancel),'ยกเลิกและคืนทุนแล้ว');return;}
 if(b.dataset.storyAction){
  const act=b.dataset.storyAction;
  if(act==='trigger-ep')result(game.storyEvents?.triggerCurrentEpisodeTrial(false),'เปิดบททดสอบเนื้อเรื่องแล้ว');
  
  else if(act==='complete-ep')result(game.storyEvents?.completeCurrentEpisode(),'ผ่านบทเนื้อเรื่องและรับรางวัลแล้ว');
  else if(act==='roll-random-event')result(game.storyEvents?.rollRandomDynamicEvent(),'เกิดเหตุการณ์ยุทธภพแล้ว');
  else if(act==='trigger-beast-tide')result(game.storyEvents?.triggerDynamicEvent('EVT_BEAST_TIDE'),'คลื่นสัตว์อสูรบุกตามพูล EP ปัจจุบัน!');
  else if(act==='toggle-auto-events')result(game.storyEvents?.toggleAutoEvents(),'สลับสถานะอีเวนต์อัตโนมัติแล้ว');
  else if(act==='resolve-event')result(game.storyEvents?.resolveActiveEvent(),'คลี่คลายอีเวนต์ต่อเนื่องแล้ว');
  else if(act==='convene-branch-council')result(game.storyEvents?.conveneNpcCouncilNow(),'สภาศิษย์ลงมติเลือกกิ่งเนื้อเรื่องตามนิสัยแล้ว');
  else if(act==='focus-event'){
   const ev=game.storyEvents?.inspect?.()?.activeDynamicEvent;
   const tid=(ev?.entityIds||[])[0];
   const t=game.s.beasts.find(x=>x.id===tid)||game.world.npcs[tid];
   const p=t?.stageLocal||t||ev?.focusPoint;
   if(p&&Number.isFinite(p.x)){camera.x=p.x;camera.y=p.y;camera.z=Math.max(camera.z,2.4);follow=false;close();clampCamera();refresh();}
   else toast('ไม่พบพิกัดเป้าหมายบนแผนที่');
  }
  return;
 }
 if(b.dataset.triggerEventId){result(game.storyEvents?.triggerDynamicEvent(b.dataset.triggerEventId),'ทริกเกอร์อีเวนต์แล้ว');return;}
 if(b.dataset.focusEventTarget){
  const tid=b.dataset.focusEventTarget;
  const t=game.s.beasts.find(x=>x.id===tid)||game.world.npcs[tid];
  const p=t?.stageLocal||t;
  if(p&&Number.isFinite(p.x)){camera.x=p.x;camera.y=p.y;camera.z=Math.max(camera.z,2.5);follow=false;selected=t.id;close();clampCamera();refresh();}
  return;
 }
 if(b.dataset.logFormat){logFormat=b.dataset.logFormat;renderPanel();return;}
 if(b.dataset.logCategory){logCategory=b.dataset.logCategory;renderPanel();return;}
 if(b.dataset.growthAction)result(b.dataset.growthAction==='fund'?game.progression.support():game.progression.refund(),'จัดเตรียมทุนแล้ว ศิษย์เลือกศึกษาด้วยตนเอง');
 if(b.dataset.growthSection){growthSection=b.dataset.growthSection;renderPanel();$('#content').scrollTop=0;}
 if(b.dataset.worldSection){worldSection=b.dataset.worldSection;worldFocus=null;open('world');}
 if(b.dataset.mwAction==='claim-deferred'){const r=game.myriad?.claimDeferredItems?.();toast(r?.moved?`เบิกของตกค้างเข้าคลังสำนักแล้ว ${r.moved} ชิ้น`:'คลังสำนักยังเต็มอยู่ กรุณาจัดพื้นที่ก่อน');renderPanel();return;}
 if(b.dataset.encTab){if(window.JianghuRealmView?.encState){window.JianghuRealmView.encState.tab=b.dataset.encTab;renderPanel();}return;}
 if(b.dataset.sectTrade){const [factionId,direction,matId,qtyRaw]=b.dataset.sectTrade.split(':');const qty=Number(qtyRaw);const r=direction==='BUY_FROM_SECT'?game.realm.buyFromFaction(factionId,matId,qty):direction==='SELL_TO_SECT'?game.realm.sellToFaction(factionId,matId,qty):{ok:false,reason:'ทิศทางการค้าไม่ถูกต้อง'};result(r,'ทำธุรกรรมระหว่างสำนักแล้ว');return;}
 if(b.dataset.realmAction){const action=b.dataset.realmAction;let r;if(action.startsWith('fund-'))r=game.realm.support(action.slice(5));else if(action.startsWith('refund-'))r=game.realm.refund(action.slice(7));else if(action==='invite')r=game.realm.invite(b.dataset.realmId);else if(action==='formation')r=game.realm.requestFormation(b.dataset.realmId);else if(action==='cancel-formation')r=game.realm.cancelFormation();result(r,'จัดเตรียมโอกาสแล้ว สมาชิกยังเลือกด้วยตนเอง');}
 if(b.dataset.realmFocus){const id=b.dataset.realmFocus,entity=game.s.realm.pets.find(x=>x.id===id)||game.s.realm.fortunes.find(x=>x.id===id);if(entity){const p=entity.stageLocal||entity;camera.x=p.x;camera.y=p.y;camera.z=3;follow=false;worldFocus=id;close();clampCamera();}}
 if(b.dataset.lifeTab){lifeTab=b.dataset.lifeTab;renderPanel();}
 if(b.dataset.lifeAction){const a=b.dataset.lifeAction;result(a==='council'?game.life.requestCouncil():a==='fund'?game.life.fundRelief():game.life.refundRelief(),a==='council'?'สมาชิกประชุมและตัดสินใจแล้ว':a==='fund'?'สำรองกองทุนแล้ว ศิษย์ยังเลือกเอง':'คืนเงินที่ยังไม่ใช้แล้ว');}
 if(b.dataset.panel)open(b.dataset.panel);
 if(b.dataset.build){placement=b.dataset.build;preview=null;close();camera={x:1150,y:1300,z:2.1};clampCamera();$('#placement').hidden=false;$('#selection').hidden=true;$('#placeLabel').textContent=B[placement].name+' · '+B[placement].gold+' ศิลา';$('#placeError').textContent='เลือกจุดวางบนแผนที่';$('#confirmPlace').disabled=true;}
 if(b.hasAttribute('data-recruit'))result(game.recruit(),'ศิษย์ใหม่เลือกเข้าร่วมสำนักแล้ว');
 if(b.dataset.hero){selected=b.dataset.hero;heroTab='overview';open('hero');}
 if(b.hasAttribute('data-detail')){heroTab='overview';open('hero');}
 if(b.dataset.editNpc){selected=b.dataset.editNpc;open('npcEdit');}
 if(b.hasAttribute('data-save-npc-edit')){const fields={};$('#content').querySelectorAll('[data-npc-field]').forEach(el=>{fields[el.dataset.npcField]=el.value;});const r=JianghuSafeEditor.editNpc(game,selected,fields);if(r.ok){toast(r.reason);await save();refresh();renderNpcEditor();}else toast(r.reason);}
 if(b.hasAttribute('data-cancel-npc-edit')){heroTab='overview';open('hero');}
 if(b.hasAttribute('data-save-hub-resources')){const fields={};$('#content').querySelectorAll('[data-hub-resource]').forEach(el=>{fields[el.dataset.hubResource]=el.value;});$('#content').querySelectorAll('[data-npc-field^="hub:"]').forEach(el=>{fields[el.dataset.npcField.slice(4)]=el.value;});const r=JianghuSafeEditor.setResources(game,fields);if(r.ok){toast(r.reason);await save();refresh();renderEditHub();}else toast(r.reason);}
 if(b.hasAttribute('data-grant-material')){const id=$('#editMaterialSelect')?.value,qty=$('#content [data-npc-field="hub:materialQty"]')?.value;const r=JianghuSafeEditor.grantMaterial(game,id,qty);if(r.ok){toast(r.reason);await save();refresh();renderEditHub();}else toast(r.reason);}
 if(b.hasAttribute('data-grant-item')){const id=$('#editItemSelect')?.value,qty=$('#content [data-npc-field="hub:itemQty"]')?.value;const r=JianghuSafeEditor.grantItem(game,id,qty);if(r.ok){toast(r.reason);await save();refresh();renderEditHub();}else toast(r.reason);}
 if(b.hasAttribute('data-grant-manual')){const artId=$('#editManualSelect')?.value,npcId=$('#editManualNpcSelect')?.value;const r=JianghuSafeEditor.grantScrollManual(game,npcId,artId);if(r.ok){toast(r.reason);await save();refresh();renderEditHub();}else toast(r.reason);}
 if(b.hasAttribute('data-hub-edit-npc')){const id=$('#editHubNpcSelect')?.value;if(id){selected=id;open('npcEdit');}else toast('กรุณาเลือก NPC ก่อน');}
 if(b.dataset.combatEntity){openCombatStats(b.dataset.combatEntity);return;}
 if(b.dataset.heroTab){heroTab=b.dataset.heroTab;renderPanel();}
 if(b.dataset.identitySection){identitySection=b.dataset.identitySection;renderPanel();$('#content').scrollTop=0;}
 if(b.dataset.bounty){const val=Number($('#reward')?.value||240);result(game.postBounty(b.dataset.bounty,val),'ติดประกาศแล้ว');}
 if(b.dataset.cancelBounty){game.cancelBounty(b.dataset.cancelBounty);refresh();}
 if(b.dataset.policy){game.s.policy=b.dataset.policy;game.note('สำนักปรับนโยบายบริหาร');refresh();}
 if(b.dataset.buy)result(game.buyMaterial(b.dataset.buy),'ซื้อเสบียงแล้ว');
 if(b.dataset.buySeed)result(game.buySeeds(b.dataset.buySeed,1),'ซื้อเมล็ดพันธุ์แล้ว');
 if(b.dataset.plant){const crop=$('#plantSelect_'+b.dataset.plant)?.value;result(game.plant(b.dataset.plant,crop),'ปลูกเมล็ดแล้ว');}
 if(b.dataset.water)result(game.water(b.dataset.water),'รดน้ำแล้ว');
 if(b.dataset.harvest)result(game.harvestGarden(b.dataset.harvest),'เก็บเกี่ยวแล้ว');
 if(b.dataset.collectDrop)result(game.collectDrop(b.dataset.collectDrop),'เก็บวัตถุดิบเข้าคลังแล้ว');
 if(b.dataset.sharePill&&b.dataset.shareFrom){const sel=$('#shareTo_'+b.dataset.shareFrom+'_'+b.dataset.sharePill),to=sel?.value;if(to)result(game.sharePill(b.dataset.shareFrom,to,b.dataset.sharePill,1),'แบ่งโอสถแล้ว');}
 if(b.dataset.focusBeast){const beast=game.s.beasts.find(x=>x.id===b.dataset.focusBeast);if(beast){camera.x=beast.x;camera.y=beast.y;camera.z=Math.max(camera.z,2.2);follow=false;selected=beast.id;close();clampCamera();refresh();}}
 if(b.dataset.lureBeast)result(game.lureRareBeast(b.dataset.lureBeast),'จุดกำยานล่ออสูรวิญญาณหายากแล้ว');
 if(b.dataset.order)result(game.fundOrder(b.dataset.order),'สำรองกองทุนแล้ว ศิษย์จะประเมินคำขอ');
 if(b.dataset.cancelOrder){game.cancelOrder(b.dataset.cancelOrder);refresh();}
 if(b.dataset.action){const a=b.dataset.action;if(a==='runtimeReport'){const payload={release:'2.08.6-sect-to-sect-spirit-stone-trade',fault:runtimeFault,save:JSON.parse(game.serialize())},url=URL.createObjectURL(new Blob([JSON.stringify(payload)],{type:'application/json'})),link=document.createElement('a');link.href=url;link.download='Jianghu_Runtime_Report_v2_08_6.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;}if(a==='repair')result(game.repair(),'แนวป้องกันได้รับการซ่อม');if(a==='aid')result(game.aid(),'ชุมชนส่งแรงช่วยแล้ว');if(a==='save')save(true);if(a==='load'){try{const raw=localStorage.getItem(SAVE_KEY);if(!raw)throw Error('ยังไม่มีเซฟ');game=Frontier.load(await unpackSave(raw));saveBlocked='';rootGame();selected=null;toast('โหลดสำเร็จ');refresh();}catch(e){toast(e.message);}}if(a==='follow'){follow=!follow;if(follow)close();refresh();}if(a==='export'){const blob=new Blob([game.serialize()],{type:'application/json'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='Jianghu_Cloud_Sect_Save_v2_08_6.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('ส่งออกเซฟแล้ว');}if(a==='backupStored'){const raw=localStorage.getItem(SAVE_KEY);if(raw){const url=URL.createObjectURL(new Blob([raw],{type:'text/plain'})),a=document.createElement('a');a.href=url;a.download='Jianghu_Stored_Save_Backup_v1_16.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}}if(a==='import')$('#importFile').click();if(a==='continue'){close();game.s.paused=false;}if(a==='new'){if(b.dataset.confirmed!=='yes'){b.dataset.confirmed='yes';b.textContent='กดอีกครั้งเพื่อเริ่มใหม่';return;}const legacy=game.s.legacy;$('#loading').hidden=false;setTimeout(()=>{try{game=new Frontier(Math.floor(Date.now()%10000000),legacy);game.establish();saveBlocked='';endShown=false;selected=null;rootGame();close();refresh();}catch(e){toast(e.message);}$('#loading').hidden=true;},60);}}
});
document.addEventListener('change',e=>{
 if(e.target.id==='externalMemberSelect'){marketMemberId=e.target.value;renderPanel();return;}
 const formKeys={reqMethodSelect:'mode',reqAuthoritySelect:'authorityId',reqDiscipleSelect:'npcId',reqItemSelect:'item'};if(formKeys[e.target.id]){reqForm[formKeys[e.target.id]]=e.target.value||null;if(e.target.id==='reqMethodSelect'){reqForm.item=null;renderPanel();}return;}
 if(e.target.hasAttribute('data-growth-person')){selected=e.target.value;renderPanel();}
 if(e.target.id==='humanSection'){identitySection=e.target.value;renderPanel();$('#content').scrollTop=0;}
 if(e.target.id==='humanCompare'){compareId=e.target.value;renderPanel();}
 if(e.target.id==='npcEditPathSelect'){
  const chosenPath=e.target.value,subSel=$('#npcEditSubPathSelect');
  if(subSel){
   const firstMatch=[...subSel.options].find(o=>o.dataset.parentPath===chosenPath);
   if(firstMatch)subSel.value=firstMatch.value;
  }
 }
});
$('#artSettings').onclick=()=>open('art');
if($('#themeToggle'))$('#themeToggle').onclick=()=>{const next=(ink.settings.uiTheme||'sonnet')==='sonnet'?'classic':'sonnet';ink.set('uiTheme',next);applyUiTheme();needsRender=true;if(tab==='art')renderArtSettings();toast(next==='sonnet'?'สลับเป็นธีม Claude Sonnet 5.5 แล้ว':'สลับเป็นธีมดั้งเดิม Living Ink แล้ว');};
document.addEventListener('change',e=>{const key=e.target.dataset.artSetting;if(key){needsRender=true;ink.set(key,['motion','ambience'].includes(key)?e.target.value==='on':e.target.value);applyUiTheme();renderArtSettings();}});
$('#pause').onclick=()=>{if(runtimeFault){toast('โปรดสำรองข้อมูลแล้วโหลดเซฟล่าสุดก่อนเล่นต่อ');return;}game.s.paused=!game.s.paused;refresh();};$('#speed').onclick=()=>{const speeds=[1,2,4,8,16],i=speeds.indexOf(game.s.speed);game.s.speed=speeds[(i<0?0:i+1)%speeds.length];refresh();};$('#recruit').onclick=()=>result(game.recruit(),'รับศิษย์เข้าร่วมสำนักแล้ว');$('#menu').onclick=()=>open('sect');$('#closeSheet').onclick=close;$('#shade').onclick=close;$('#objective').onclick=()=>open(game.s.status==='lost'?'ending':'objectives');
$('#zoomIn').onclick=()=>zoom(1.25);$('#zoomOut').onclick=()=>zoom(.8);$('#home').onclick=()=>{follow=false;camera={x:1230,y:1390,z:3.1};clampCamera();};$('#overview').onclick=()=>{follow=false;camera={x:W/2,y:H/2,z:1};clampCamera();};$('#overlays').onclick=()=>{labels=!labels;needsRender=true;};
$('#cancelPlace').onclick=()=>{placement=null;preview=null;$('#placement').hidden=true;};$('#confirmPlace').onclick=()=>{if(!placement||!preview)return;const r=game.place(placement,preview.x,preview.y);result(r,'เริ่มก่อสร้างแล้ว');if(r.ok){placement=null;preview=null;$('#placement').hidden=true;}};
const pointers=new Map();let gesture=null,pinched=false;
canvas.addEventListener('pointerdown',e=>{if(!game)return;canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.offsetX,y:e.offsetY});if(pointers.size===1){gesture={x:e.offsetX,y:e.offsetY,cx:camera.x,cy:camera.y,moved:false};pinched=false;}else{pinched=true;gesture=null;}});
canvas.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;const old=[...pointers.values()];pointers.set(e.pointerId,{x:e.offsetX,y:e.offsetY});if(pointers.size===2){const a=[...pointers.values()],od=Math.hypot(old[0].x-old[1].x,old[0].y-old[1].y),nd=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(od>5)zoom(nd/od,(a[0].x+a[1].x)/2,(a[0].y+a[1].y)/2);follow=false;return;}if(gesture&&!pinched){const dx=e.offsetX-gesture.x,dy=e.offsetY-gesture.y;if(Math.hypot(dx,dy)>5){gesture.moved=true;follow=false;}if(gesture.moved){camera.x=gesture.cx-dx/factor();camera.y=gesture.cy-dy/factor();clampCamera();}}});
function release(e){
 if(pointers.size===1&&gesture&&!gesture.moved&&!pinched&&e.type==='pointerup'){
  const p=worldPoint(e.offsetX,e.offsetY);
  if(placement){preview={x:Math.round(p.x/25)*25,y:Math.round(p.y/25)*25};refresh();}
  else {
   const cluster=mapClusters.find(c=>Math.hypot(c.q.x-e.offsetX,c.q.y-e.offsetY)<19);
   if(cluster){camera.x=cluster.x;camera.y=cluster.y;camera.z=Math.min(12,camera.z*1.45);follow=false;clampCamera();}
   else {
    const hits=[...game.heroes,...game.visitors,...game.enemies,...game.s.beasts,...game.s.realm.pets].filter(n=>{const p=n.stageLocal||n;return !p.offmap&&(!p.enemy||game.s.campKnown||p.raid);}).map(n=>{const q=pickPositions.get(n.id)||screenPoint(n.stageLocal||n);return {n,d:Math.hypot(q.x-e.offsetX,q.y-Math.min(24,12*Math.max(.56,Math.min(2.5,factor()*3.15)))-e.offsetY)}}).filter(x=>x.d<24).sort((a,b)=>a.d-b.d);
    if(hits.length){const id=hits[0].n.id;if(hits[0].n.stageLocal?.pet){worldSection='companions';worldFocus=id;open('world');}else if(!hits[0].n.core){selected=id;follow=false;openCombatStats(id);refresh();}else if(selected===id){heroTab='overview';open('hero');}else{selected=id;follow=false;refresh();}}
    else {const fortune=game.s.realm.fortunes.find(f=>!f.claimed&&f.expiresAt>game.s.t&&Math.hypot(screenPoint(f).x-e.offsetX,screenPoint(f).y-e.offsetY)<23);if(fortune){worldSection='fortunes';worldFocus=fortune.id;open('world');}else{const b=game.s.buildings.find(b=>Math.hypot(b.x-p.x,b.y-p.y)<130);if(b)toast(B[b.type].name+' · ระดับ '+(b.level||1)+' · HP '+Math.ceil(b.hp)+' · ผู้ใช้งาน '+b.occupants.length);else selected=null;refresh();}}
   }
  }
 }
 pointers.delete(e.pointerId);if(pointers.size===0){gesture=null;pinched=false;}
}
canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1.13:.885,e.offsetX,e.offsetY);},{passive:false});
mini.onclick=e=>{const r=mini.getBoundingClientRect();camera.x=(e.clientX-r.left)/r.width*W;camera.y=(e.clientY-r.top)/r.height*H;follow=false;clampCamera();};
async function packSave(raw){if(typeof CompressionStream==='undefined')return raw;const bytes=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=16384)binary+=String.fromCharCode(...bytes.subarray(i,i+16384));return 'GZ1:'+btoa(binary);}
async function unpackSave(raw){if(!raw.startsWith('GZ1:'))return raw;if(typeof DecompressionStream==='undefined')throw Error('เบราว์เซอร์นี้อ่านเซฟบีบอัดไม่ได้ ใช้นำเข้าเซฟ JSON');const bytes=Uint8Array.from(atob(raw.slice(4)),c=>c.charCodeAt(0));return new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();}
let lastSave=0,saving=false;async function save(show=false){if(runtimeFault){if(show)toast('เกมมีข้อผิดพลาด กรุณาสำรองข้อมูลหรือโหลดเซฟล่าสุดก่อน');return;}if(saveBlocked){if(show)toast('เก็บเซฟเดิมไว้: นำเข้าเซฟที่อ่านได้ หรือยืนยันเริ่มเกมใหม่ก่อน');return;}if(saving)return;saving=true;const owner=game;try{const raw=owner.serialize(),packed=await packSave(raw);if(owner===game&&!runtimeFault)localStorage.setItem(SAVE_KEY,packed);if(show)toast('บันทึกเกมแล้ว');}catch(e){if(show)toast('พื้นที่บันทึกไม่พอ ใช้ส่งออกเซฟแทน');}finally{saving=false;}}
document.addEventListener('change',e=>{
 if(e.target.hasAttribute('data-realm-section')){worldSection=e.target.value;worldFocus=null;renderPanel();}
 if(e.target.id==='encTierFilter'&&window.JianghuRealmView?.encState){window.JianghuRealmView.encState.tier=e.target.value;renderPanel();}
 if(e.target.id==='encCatFilter'&&window.JianghuRealmView?.encState){window.JianghuRealmView.encState.cat=e.target.value;renderPanel();}
});
document.addEventListener('input',e=>{
 if(e.target.id==='encSearchInput'&&window.JianghuRealmView?.encState){window.JianghuRealmView.encState.q=e.target.value;renderPanel();}
});
$('#importFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const g=Frontier.load(await unpackSave(await f.text()));game=g;saveBlocked='';rootGame();selected=null;close();refresh();toast('นำเข้าเซฟแล้ว');}catch(e){toast('นำเข้าไม่ได้: '+e.message);}e.target.value='';};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&game)save();now=performance.now();});window.addEventListener('resize',resize);
function rootGame(){runtimeFault=null;$('#runtimeFault').hidden=true;now=performance.now();if(!location.search.includes('qa=1'))game?.storyEvents?.activate?.();window.JIANGHU={get runtimeFault(){return runtimeFault;},get graphics(){return ink;},get game(){return game;},open,refresh,get camera(){return camera;},worldPoint,screenPoint,select(id){selected=id;if(game.world.npcs[id])open('hero');else openCombatStats(id);},combatStats:openCombatStats,setCamera(x,y,z=2){camera.x=x;camera.y=y;camera.z=z;},advance(t){game.advance(t);refresh();},editNpc:(id,fields)=>JianghuSafeEditor.editNpc(game,id,fields),setResources:fields=>JianghuSafeEditor.setResources(game,fields),grantMaterial:(id,qty)=>JianghuSafeEditor.grantMaterial(game,id,qty),grantPill:(id,qty)=>JianghuSafeEditor.grantPill(game,id,qty),grantScrollManual:(npcId,artId)=>JianghuSafeEditor.grantScrollManual(game,npcId,artId),debug:true};}
let endShown=false,lastPaint=0;
function reportRuntimeFault(error,stage){
 runtimeFault={stage,message:String(error?.message||error),stack:String(error?.stack||''),t:game?.s.t,episode:game?.s.storyEvents?.currentEp,node:game?.s.storyEvents?.currentNodeId,phase:game?.s.storyEvents?.epPhase};
 if(game)game.s.paused=true;
 $('#runtimeFault').hidden=false;
 console.error('Jianghu runtime paused',runtimeFault);
}
function frame(t){
 let stage='simulation';
 try{
  if(!game||runtimeFault)return;
  const dt=Math.max(0,Math.min(.25,(t-now)/1000));now=t;game.frame(dt);
  const n=game.world.npcs[selected];if(follow&&n?.stageLocal&&!n.stageLocal.offmap){camera.x=n.stageLocal.x;camera.y=n.stageLocal.y;clampCamera();}
  stage='map';if((!game.s.paused&&t-lastPaint>=1000/30)||needsRender){draw();lastPaint=t;needsRender=false;}
  stage='interface';if(t-lastUI>700){lastUI=t;refresh();if(game.s.status!=='playing'&&!endShown){endShown=true;open('ending');}}
  if(t-lastSave>45000){lastSave=t;save();}
 }catch(error){reportRuntimeFault(error,stage);}
 finally{requestAnimationFrame(frame);}
}
setTimeout(async()=>{try{await ink.ready;applyUiTheme();terrainDraw();let raw;try{raw=localStorage.getItem(SAVE_KEY);}catch(e){}if(raw&&!location.search.includes('fresh=1')){try{game=Frontier.load(await unpackSave(raw));saveBlocked='';}catch(e){saveBlocked=e.message;console.warn('Preserved unreadable saved game',e.message);}}if(!game){game=new Frontier(8821);game.establish();}rootGame();resize();refresh();$('#loading').hidden=true;if(saveBlocked){game.s.paused=true;open('sect');}requestAnimationFrame(frame);}catch(e){$('#loading p').textContent='เปิดเกมไม่ได้: '+e.message;console.error(e);}},50);
})();
