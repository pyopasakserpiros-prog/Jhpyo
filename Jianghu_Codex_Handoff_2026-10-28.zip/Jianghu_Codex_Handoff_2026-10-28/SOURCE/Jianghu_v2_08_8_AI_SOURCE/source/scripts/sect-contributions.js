/* Spendable contribution points, Sect Store (ร้านค้าสำนัก) vs Sect Treasury (คลังสำนัก),
   rational Tier/Color/Category pricing, Sect-Sponsored Alchemy/Forging, and Demand-Supply Economic Flywheel (v2.06).
   Physical custody remains in the native ledgers with zero thin-air item generation. */
(function(root){'use strict';
const E=root.World2026Engine,H=root.HumanCore;
const keys={EQUIPMENT:'equipmentItems',PILL:'pillStacks',SCROLL:'scrolls',MATERIAL:'materialStacks'};
const clone=x=>JSON.parse(JSON.stringify(x)),time=g=>Number(g.s.t)||0;
const tools=()=>root.JianghuStoryEvents.treasuryTools;

const FREE_SECT_RECIPES=[
 'L14_remedy','L14_qi','L14_clarity','L14_pure','L14_ironblade',
 'REC1100_SUPPORT_RECOVERY','REC1100_SUPPORT_QI','REC1100_SUPPORT_CLARITY','REC140_ALC_QI_DEW_1'
];
const FORTUITOUS_RECIPES=[
 'L14_ginseng','L14_lotus','L14_armor','L14_guard','L14_flame','L14_jade','L14_scholar'
];

const QUALITY_META={
 DAMAGED:     {mult:0.35,colorCode:'GRAY',  colorNameTh:'สีเทา (ชำรุด)',      colorHex:'#868e96'},
 POOR:        {mult:0.50,colorCode:'GRAY',  colorNameTh:'สีเทา (ด้อยคุณภาพ)',  colorHex:'#868e96'},
 CRUDE:       {mult:0.65,colorCode:'GRAY',  colorNameTh:'สีเทา (หยาบ)',       colorHex:'#adb5bd'},
 COMMON:      {mult:1.00,colorCode:'WHITE', colorNameTh:'สีขาว (สามัญ)',      colorHex:'#dee2e6'},
 STANDARD:    {mult:1.00,colorCode:'WHITE', colorNameTh:'สีขาว (ทั่วไป)',     colorHex:'#dee2e6'},
 NORMAL:      {mult:1.00,colorCode:'WHITE', colorNameTh:'สีขาว (ทั่วไป)',     colorHex:'#dee2e6'},
 MORTAL:      {mult:1.00,colorCode:'WHITE', colorNameTh:'สีขาว (สามัญ)',      colorHex:'#dee2e6'},
 GOOD:        {mult:1.25,colorCode:'GREEN', colorNameTh:'สีเขียว (ดี)',       colorHex:'#69db7c'},
 REFINED:     {mult:1.45,colorCode:'GREEN', colorNameTh:'สีเขียว (ปราณีต)',    colorHex:'#51cf66'},
 RARE:        {mult:1.60,colorCode:'BLUE',  colorNameTh:'สีฟ้า (หายาก)',      colorHex:'#4dabf7'},
 MYSTIC:      {mult:1.60,colorCode:'BLUE',  colorNameTh:'สีฟ้า (ลี้ลับ)',      colorHex:'#4dabf7'},
 SUPERIOR:    {mult:1.85,colorCode:'PURPLE',colorNameTh:'สีม่วง (ชั้นเลิศ)',   colorHex:'#b197fc'},
 EXCELLENT:   {mult:1.95,colorCode:'PURPLE',colorNameTh:'สีม่วง (ยอดเยี่ยม)',  colorHex:'#b197fc'},
 MASTERWORK:  {mult:2.00,colorCode:'PURPLE',colorNameTh:'สีม่วง (เอกอุ)',     colorHex:'#9775fa'},
 EPIC:        {mult:1.95,colorCode:'PURPLE',colorNameTh:'สีม่วง (มหากาพย์)',  colorHex:'#b197fc'},
 EARTH:       {mult:1.90,colorCode:'PURPLE',colorNameTh:'สีม่วง (ปฐพี)',      colorHex:'#b197fc'},
 PERFECT:     {mult:2.35,colorCode:'GOLD',  colorNameTh:'สีทอง (สมบูรณ์แบบ)',  colorHex:'#ffd43b'},
 HEAVEN:      {mult:2.40,colorCode:'GOLD',  colorNameTh:'สีทอง (สวรรค์)',     colorHex:'#ffd43b'},
 LEGENDARY:   {mult:2.65,colorCode:'ORANGE',colorNameTh:'สีส้ม (ตำนาน)',      colorHex:'#ff922b'},
 IMMORTAL:    {mult:2.75,colorCode:'ORANGE',colorNameTh:'สีส้ม (เซียน)',      colorHex:'#ff922b'},
 MYTHIC:      {mult:3.10,colorCode:'RED',   colorNameTh:'สีแดง (เทวตำนาน)',    colorHex:'#ff6b6b'},
 TRANSCENDENT:{mult:3.25,colorCode:'RED',   colorNameTh:'สีแดง (ข้ามภพ)',     colorHex:'#ff6b6b'}
};

const CATEGORY_NAMES={
 MATERIAL:'วัตถุดิบ',
 PILL:'โอสถสำเร็จรูป',
 SCROLL:'คัมภีร์ยุทธ์',
 EQUIPMENT:'ศาสตรา/อุปกรณ์'
};

if(H?.registerActivity){
 if(!H.activities?.sectCraft){
  H.registerActivity({
   ...H.descriptor('alchemy'),
   id:'sectCraft',
   label:'หลอมโอสถและศาสตราให้สำนัก',
   skillDomain:'alchemy',
   valueWeights:{sectDuty:.4,knowledgeCraft:.35,wealthResource:.25},
   personalityWeights:{discipline:.3,integrity:.25,creativity:.2}
  });
 }
 if(!H.activities?.sectShopBuy){
  H.registerActivity({
   ...H.descriptor('deposit'),
   id:'sectShopBuy',
   label:'ใช้แต้มซื้อสินค้าในร้านค้าสำนัก',
   skillDomain:'logistics',
   valueWeights:{martialPeak:.35,wealthResource:.35,sectDuty:.2},
   personalityWeights:{ambition:.25,caution:.25,rationality:.2}
  });
 }
 if(!H.activities?.sectGather){
  H.registerActivity({
   ...H.descriptor('herb'),
   id:'sectGather',
   label:'เก็บสมุนไพรและแร่เข้าคลังสำนักแลกแต้ม',
   skillDomain:'gathering',
   valueWeights:{sectDuty:.4,wealthResource:.35,familyClan:.2},
   personalityWeights:{discipline:.3,caution:.2,integrity:.2}
  });
 }
}

function state(g){
 const t=g.storyEvents.ensureState(true).treasury;
 const c=t.contributions||(t.contributions={version:2,accounts:{},history:[],storeCuratedAt:-1});
 if(!c.version||c.version<2)c.version=2;
 if(!Array.isArray(c.history))c.history=[];
 if(!c.accounts||typeof c.accounts!=='object')c.accounts={};
 return c;
}
function accountView(g,n){return g.s.storyEvents?.treasury?.contributions?.accounts?.[typeof n==='string'?n:n.id]||{balance:0,earned:0,spent:0,lastEmergencyAt:null};}
function account(g,n){
 const s=state(g),id=typeof n==='string'?n:n.id;
 return s.accounts[id]||(s.accounts[id]={balance:0,earned:0,spent:0,lastEmergencyAt:null});
}
function owned(n,item){
 return !!item&&!item.loan&&!item.loanedTo&&!item.loanedToNpcId&&item.rights!=='LOAN'&&item.canRedistribute!==false&&!item.reservedForFormation&&[item.ownerNpcId,item.ownerId].every(id=>!id||id===n.id);
}
function bankOwned(g,item){
 return !!item&&item.count!==0&&!item.loan&&!item.loanedTo&&!item.loanedToNpcId&&item.rights!=='LOAN'&&item.access!=='PRIVATE'&&item.canRedistribute!==false&&!item.reservedForFormation&&[item.ownerNpcId,item.ownerId].every(id=>!id||id===g.bank?.id);
}
let _matMap=null;
function matDef(id){
 if(!id)return null;
 if(!_matMap&&E?.PATCH140_DATA?.MATERIALS_REGISTRY_V140){
  _matMap=new Map(E.PATCH140_DATA.MATERIALS_REGISTRY_V140.map(d=>[d.id,d]));
 }
 return _matMap?_matMap.get(id):null;
}
function resolveRecipe(g,item){
 if(!item)return null;
 const recId=item.recipeId||item.catalogId;
 if(!recId)return null;
 return g?.progression?.recipe?.(recId)||(g?.recipes||[]).find(r=>r.id===recId)||g?.world?.jianghu?.systemsV140?.recipes?.registry?.[recId]||null;
}
function matRawBase(g,matId,fallbackTier=1){
 const def=matDef(matId);
 const tier=Math.max(1,Number(def?.tier||fallbackTier)||1);
 const stones=Number(def?.baseValueStones)||(tier*8);
 return Math.max(4,Math.min(tier*10,Math.round(stones*0.35)));
}
function colorMeta(g,kind,item){
 if(!item)return {tier:1,qualityKey:'COMMON',colorCode:'WHITE',colorNameTh:'สีขาว (สามัญ)',colorHex:'#dee2e6',categoryNameTh:CATEGORY_NAMES[kind]||kind,mult:1};
 const def=kind==='MATERIAL'?matDef(item.matId):null;
 const rec=(kind==='PILL'||kind==='EQUIPMENT')?resolveRecipe(g,item):null;
 const art=kind==='SCROLL'?g?.progression?.artMap?.get(item.artId):null;
 const tier=Math.max(1,Number(item.tier||rec?.tier||art?.tier||def?.tier)||1);
 const explicitQ=(item.quality&&!['STANDARD','COMMON','NORMAL'].includes(item.quality))?item.quality:(item.rarity||item.rarityGrade||item.quality||null);
 const fallbackByTier=tier>=6?'IMMORTAL':tier===5?'HEAVEN':tier===4?'EARTH':tier===3?'MYSTIC':tier===2?'REFINED':'COMMON';
 const qualityKey=(explicitQ&&QUALITY_META[explicitQ])?explicitQ:(item.quality&&QUALITY_META[item.quality]?item.quality:fallbackByTier);
 const qm=QUALITY_META[qualityKey]||QUALITY_META.COMMON;
 return {
  tier,
  qualityKey,
  colorCode:qm.colorCode,
  colorNameTh:qm.colorNameTh,
  colorHex:qm.colorHex,
  mult:qm.mult,
  categoryNameTh:CATEGORY_NAMES[kind]||kind
 };
}

/* Rational Pricing Model (v2.06):
   - Every Tier (1..7) and Color/Quality (Gray -> White -> Green -> Blue -> Purple -> Gold -> Orange -> Red) scales monotonically.
   - Strict Category Hierarchy at the same Tier & Color:
     MATERIAL (raw input) < PILL (crafted elixir) < SCROLL (scripture manual) < EQUIPMENT (crafted weapon/armor/talisman).
   - Every crafted item (PILL or EQUIPMENT) is strictly worth more than the sum of its recipe input materials + crafting labor.
   - Specifically: a Purple (SUPERIOR/EXCELLENT/MASTERWORK/EPIC/EARTH) raw material is always cheaper than a Purple finished crafted item of the same tier. */
function quote(g,kind,item,quantity=1){
 if(!item||!keys[kind])return {donation:0,redemption:0,storePrice:0,quantity:0};
 const def=kind==='MATERIAL'?matDef(item.matId):null;
 const rec=(kind==='PILL'||kind==='EQUIPMENT')?resolveRecipe(g,item):null;
 const art=kind==='SCROLL'?g?.progression?.artMap?.get(item.artId):null;
 const tier=Math.max(1,Number(item.tier||rec?.tier||art?.tier||def?.tier)||1);
 const qKey=(item.quality&&!['STANDARD','COMMON','NORMAL'].includes(item.quality))?item.quality:(item.rarity||item.rarityGrade||item.quality||'COMMON');
 const qm=QUALITY_META[qKey]||QUALITY_META.COMMON;
 const condition=kind==='EQUIPMENT'?Math.max(0,Math.min(1,Number(item.durability??100)/Math.max(1,Number(item.maxDurability)||100))):1;

 let base=4;
 const useRecInputs=rec?.inputs?.length&&(!item.tier||Number(item.tier)===Number(rec.tier));
 if(kind==='MATERIAL'){
  base= (!item.tier||!def||Number(item.tier)===Number(def.tier))
   ? matRawBase(g,item.matId,tier)
   : Math.max(4,Math.round(6*Math.pow(tier,1.45)));
 }else if(kind==='PILL'){
  const inputBase=useRecInputs?rec.inputs.reduce((s,i)=>s+matRawBase(g,i.matId,tier)*(i.count||1),0):Math.round(9*Math.pow(tier,1.45));
  base=Math.max(Math.round(16*Math.pow(tier,1.55)),Math.round(inputBase*1.35+tier*5));
 }else if(kind==='SCROLL'){
  base=Math.round(26*Math.pow(tier,1.6));
 }else if(kind==='EQUIPMENT'){
  const inputBase=useRecInputs?rec.inputs.reduce((s,i)=>s+matRawBase(g,i.matId,tier)*(i.count||1),0):Math.round(14*Math.pow(tier,1.5));
  base=Math.max(Math.round(34*Math.pow(tier,1.65)),Math.round(inputBase*1.55+tier*10));
 }

 const unit=Math.max(1,Math.floor(base*qm.mult*condition*(item.isTranscendent?1.2:1)));
 const unitRedemption=Math.ceil(unit*1.35)+1;
 const qty=Math.max(1,Math.floor(Number(quantity)||1));
 return {
  donation:item.contributionCreditAllowed===false?0:unit*qty,
  redemption:unitRedemption*qty,
  storePrice:unitRedemption*qty,
  quantity:qty,
  unitDonation:unit,
  unitRedemption,
  tier,
  colorCode:qm.colorCode,
  colorNameTh:qm.colorNameTh,
  colorHex:qm.colorHex,
  categoryNameTh:CATEGORY_NAMES[kind]||kind
 };
}

function ensureBasicSectRecipes(g,targetNpc=null){
 if(!g)return;
 const list=targetNpc?[targetNpc]:(g.heroes||[]);
 for(const n of list){
  if(!n?.alive||!n.stageLocal?.growth)continue;
  const kr=n.stageLocal.growth.knownRecipes||(n.stageLocal.growth.knownRecipes=[]);
  for(const id of ['L14_remedy','L14_qi','L14_clarity','L14_pure','L14_ironblade']){
   if(!kr.includes(id))kr.push(id);
  }
  g.teachPublicRecipes?.(n);
 }
}

function tryFortuitousRecipeDiscovery(g,n,sourceLabelTh='วาสนาในหุบเขา'){
 if(!g?.s?.storyEvents?.active||!n?.alive||!n.stageLocal?.growth)return null;
 const kr=n.stageLocal.growth.knownRecipes||(n.stageLocal.growth.knownRecipes=[]);
 const candidates=FORTUITOUS_RECIPES.map(id=>g.progression?.recipe?.(id)).filter(r=>r&&!kr.includes(r.id)&&r.tier<=Math.max(2,Math.ceil(g.progression.tier(n))+1));
 if(!candidates.length)return null;
 let h=2166136261^((Number(g.s.seed)||8821)+Math.round(time(g)*10));
 for(const ch of (String(n.id)+":"+String(sourceLabelTh))){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}
 const roll=((h>>>0)%10000)/10000;
 const chance=0.25+Math.min(0.20,((n.personality?.curiosity||50)-50)*0.002+((n.jianghu?.fortuneKarmaV113||0)*0.004));
 if(roll>=chance)return null;
 const preferred=candidates.filter(r=>r.workshop===n.stageLocal.growth.career);
 const pool=preferred.length?preferred:candidates;
 const chosen=pool[(h>>>8)%pool.length]||pool[0];
 if(!chosen)return null;
 kr.push(chosen.id);
 g.progression?.receipt?.('fortuitousRecipe',n,{recipeId:chosen.id,recipeNameTh:chosen.name,sourceLabelTh});
 g.note(`✨ วาสนาตำรับลับ: ${n.name} ได้พบเคล็ดตำรับ «${chosen.name}» จาก${sourceLabelTh}!`,n);
 return chosen;
}

function reserve(g,n,matId){
 let keep=Math.max([root.FrontierData.HERB,root.FrontierData.ORE].includes(matId)?1:0,g.progression.reserve(n,matId)||0);
 const a=g.s.storyEvents?.sidequests?.active,d=root.JianghuSideQuests?.catalog?.find(x=>x.id===a?.questId);
 if(d?.kind==='DELIVERY'&&d.matId===matId)keep=Math.max(keep,d.quantity);
 if(d?.kind==='CRAFT')for(const r of g.progression.allRecipes())if(n.stageLocal.growth?.knownRecipes?.includes(r.id)&&g.built(r.workshop))keep=Math.max(keep,r.inputs.find(i=>i.matId===matId)?.count||0);
 return keep;
}
function log(g,n,kind,item,quantity,points,extra={}){
 const s=state(g);
 s.history.unshift({
  id:'contrib_'+g.s.nextId++,
  t:time(g),
  npcId:n?.id||null,
  npcName:n?.name||'สำนัก',
  kind,
  itemName:item?.nameTh||item?.name||item?.matId||item?.id||'พัสดุสำนัก',
  quantity,
  points,
  ...extra
 });
 s.history.splice(120);
}

/* ============================================================================
   SECT TREASURY (คลังสำนัก) vs SECT STORE (ร้านค้าสำนัก) COMPARTMENTS
   - Items brought from outside or crafted for the sect enter the Sect Treasury first.
   - The Treasury Elder / Sect Master curates items onto the Sect Store shelves
     while keeping basic welfare reserves and raw material crafting reserves in the Treasury.
   ============================================================================ */
function storeCountOf(kind,item){
 if(!item)return 0;
 if(kind==='EQUIPMENT'||kind==='SCROLL')return item.sectStore?1:0;
 const total=Math.max(0,Number(item.count)||0);
 if(Number.isFinite(item.storeCount))return Math.max(0,Math.min(total,Math.floor(item.storeCount)));
 return item.sectStore?total:0;
}
function treasuryCountOf(kind,item){
 if(!item)return 0;
 if(kind==='EQUIPMENT'||kind==='SCROLL')return item.sectStore?0:1;
 const total=Math.max(0,Number(item.count)||0);
 return Math.max(0,total-storeCountOf(kind,item));
}
// Sect-sponsored workshops must not silently consume items already on the store shelves.
// Count only unlisted, sect-owned material units; the native g.count() includes both compartments.
function treasuryMaterialAvailable(g,matId){
 return (g.bank?.jianghu?.ledgerV140?.materialStacks||[])
  .filter(s=>s.matId===matId&&bankOwned(g,s))
  .reduce((total,s)=>total+treasuryCountOf('MATERIAL',s),0);
}

function curateStore(g,actorNpc=null){
 if(!g?.bank?.jianghu?.ledgerV140)return {ok:false,movedCount:0,reason:'ไม่พบสมุดบัญชีคลังสำนัก'};
 const auths=g.storyEvents?.authorities?.()||[];
 const curator=actorNpc?auths.find(x=>x.npc.id===actorNpc.id)?.npc:auths[0]?.npc;
 if(!curator)return {ok:false,movedCount:0,reason:'ต้องมีเจ้าสำนักหรือผู้อาวุโสฝ่ายคลังที่พร้อมจัดสินค้า'};
 const curatorName=curator?.name||'ผู้อาวุโสฝ่ายคลัง';
 const b=g.bank.jianghu.ledgerV140;
 let movedCount=0;

 // 1. Equipment: Keep 1 ordinary Tier-1 per slot in Treasury for emergency welfare GRANT; put everything else in Sect Store
 const welfareSlotKept={WEAPON:false,ARMOR:false,TALISMAN_VESSEL:false};
 for(const eq of (b.equipmentItems||[])){
  if(!bankOwned(g,eq)||(eq.durability!==undefined&&eq.durability<=0))continue;
  const basicOk=grantEligibility(g,'EQUIPMENT',eq,1).ok;
  const slot=eq.slot||'WEAPON';
  if(basicOk&&!welfareSlotKept[slot]){
   welfareSlotKept[slot]=true;
   if(eq.sectStore){eq.sectStore=false;delete eq.storeCount;}
  }else if(!eq.sectStore){
   eq.sectStore=true;
   eq.curatedByNpcId=curator?.id||null;
   eq.curatedByNameTh=curatorName;
   eq.curatedAt=time(g);
   movedCount++;
  }
 }

 // 2. Scrolls: All owned scrolls in bank go to the Sect Store to be redeemed with Contribution Points
 for(const sc of (b.scrolls||[])){
  if(!bankOwned(g,sc)||!g.progression?.artMap?.has(sc.artId))continue;
  if(!sc.sectStore){
   sc.sectStore=true;
   sc.curatedByNpcId=curator?.id||null;
   sc.curatedByNameTh=curatorName;
   sc.curatedAt=time(g);
   movedCount++;
  }
 }

 const pillReserve=new Map();
 for(const p of b.pillStacks||[]){if(bankOwned(g,p)&&grantEligibility(g,'PILL',p,1).ok){const k=p.recipeId||p.nameTh;const total=(b.pillStacks||[]).filter(x=>bankOwned(g,x)&&(x.recipeId||x.nameTh)===k&&grantEligibility(g,'PILL',x,1).ok).reduce((sum,x)=>sum+x.count,0);pillReserve.set(k,total>1?Math.min(2,total-1):total);}}
 // 3. Pills: Non-grant pills go 100% to Store; basic recovery pills keep up to 2 doses in Treasury for free GRANT and put surplus in Store
 for(const p of (b.pillStacks||[])){
  if(!bankOwned(g,p)||(p.count||0)<=0)continue;
  const basicOk=grantEligibility(g,'PILL',p,1).ok;
  const prevStore=storeCountOf('PILL',p);
  let targetStore=0;
  if(!basicOk){
   targetStore=p.count;
  }else{
   const k=p.recipeId||p.nameTh,keep=Math.min(p.count,pillReserve.get(k)||0);
   pillReserve.set(k,(pillReserve.get(k)||0)-keep);targetStore=p.count-keep;
  }
  p.storeCount=targetStore;
  p.sectStore=targetStore>0;
  if(targetStore>prevStore){
   p.curatedByNpcId=curator?.id||null;
   p.curatedByNameTh=curatorName;
   p.curatedAt=time(g);
   movedCount+=(targetStore-prevStore);
  }
 }

 const materialReserve=new Map();
 // A single rare ingredient should not be auto-shelved if a sect member already
 // knows a recipe that needs it. Keep at least one complete recipe input batch.
 const knownForSect=new Set([...FREE_SECT_RECIPES,...(g.heroes||[]).filter(n=>n.alive).flatMap(n=>n.stageLocal?.growth?.knownRecipes||[])]);
 const recipeMaterialNeeds=new Map();
 for(const r of g.progression?.allRecipes?.()||[]){
  if(!knownForSect.has(r.id)||!['alchemy','forge'].includes(r.workshop)||!g.built(r.workshop)||r.effect?.beastItem)continue;
  for(const inp of r.inputs||[])recipeMaterialNeeds.set(inp.matId,Math.max(recipeMaterialNeeds.get(inp.matId)||0,inp.count));
 }
 // 4. Materials: Keep raw material reserve in Treasury for Sect-Sponsored Alchemy/Forging (sectCraft) and put surplus on Sect Store
 for(const m of (b.materialStacks||[])){
  if(!bankOwned(g,m)||(m.count||0)<=0)continue;
  if(!m.id)m.id='economic_mat_'+g.s.nextId++;
  const def=matDef(m.matId);
  const tier=Number(def?.tier||m.tier)||1;
  const ordinary=['COMMON','STANDARD','GOOD'].includes(m.quality||'STANDARD');
  const prevStore=storeCountOf('MATERIAL',m);
  const recipeNeed=recipeMaterialNeeds.get(m.matId)||0;
  const treasuryReserve=Math.max((tier===1&&ordinary)?6:2,recipeNeed);
  const reserveKey=m.matId+':'+(ordinary?'BASIC':'SPECIAL');
  const budget=materialReserve.has(reserveKey)?materialReserve.get(reserveKey):treasuryReserve;
  let keep=Math.min(budget,m.count);
  if(tier>=3||!ordinary)keep=Math.min(keep,Math.max(Math.min(m.count,recipeNeed),Math.max(0,m.count-1)));
  materialReserve.set(reserveKey,budget-keep);
  const targetStore=m.count-keep;
  m.storeCount=targetStore;
  m.sectStore=targetStore>0;
  if(targetStore>prevStore){
   m.curatedByNpcId=curator?.id||null;
   m.curatedByNameTh=curatorName;
   m.curatedAt=time(g);
   movedCount+=(targetStore-prevStore);
  }
 }

 state(g).storeCuratedAt=time(g);invalidateMarketCache(g);
 return {ok:true,movedCount,curatorName,reason:movedCount>0?`${curatorName} คัดแยกพัสดุจากคลังสำนักขึ้นวางขายที่ร้านค้าสำนัก +${movedCount} รายการ`:`${curatorName} ตรวจสอบสต็อกคลังและร้านค้าสำนักเรียบร้อยแล้ว`};
}

function transferToStore(g,kind,id,quantity=1){
 if(!keys[kind]||!g?.bank?.jianghu?.ledgerV140)return {ok:false,reason:'ประเภทพัสดุไม่ถูกต้อง'};
 const list=g.bank.jianghu.ledgerV140[keys[kind]]||[];
 const item=list.find(x=>(x.id===id||(kind==='MATERIAL'&&x.matId===id))&&bankOwned(g,x));
 if(!item)return {ok:false,reason:'ไม่พบพัสดุในคลังสำนัก'};
 const avail=treasuryCountOf(kind,item);
 if(avail<=0)return {ok:false,reason:'พัสดุชิ้นนี้อยู่ในร้านค้าสำนักทั้งหมดแล้ว'};
 const move=kind==='EQUIPMENT'||kind==='SCROLL'?1:Math.min(avail,Math.max(1,Math.floor(Number(quantity)||1)));
 if(kind==='EQUIPMENT'||kind==='SCROLL'){
  item.sectStore=true;
 }else{
  item.storeCount=storeCountOf(kind,item)+move;
  item.sectStore=item.storeCount>0;
 }
 item.curatedAt=time(g);invalidateMarketCache(g);
 return {ok:true,moved:move,reason:`ย้าย «${item.nameTh||item.matId||item.id}» ×${move} จากคลังสำนักขึ้นร้านค้าสำนักแล้ว`};
}

function returnToTreasury(g,kind,id,quantity=1){
 if(!keys[kind]||!g?.bank?.jianghu?.ledgerV140)return {ok:false,reason:'ประเภทพัสดุไม่ถูกต้อง'};
 const list=g.bank.jianghu.ledgerV140[keys[kind]]||[];
 const item=list.find(x=>(x.id===id||(kind==='MATERIAL'&&x.matId===id))&&bankOwned(g,x));
 if(!item)return {ok:false,reason:'ไม่พบพัสดุในร้านค้าสำนัก'};
 const avail=storeCountOf(kind,item);
 if(avail<=0)return {ok:false,reason:'พัสดุชิ้นนี้อยู่ในคลังสำนักอยู่แล้ว'};
 const move=kind==='EQUIPMENT'||kind==='SCROLL'?1:Math.min(avail,Math.max(1,Math.floor(Number(quantity)||1)));
 if(kind==='EQUIPMENT'||kind==='SCROLL'){
  item.sectStore=false;
 }else{
  item.storeCount=Math.max(0,avail-move);
  item.sectStore=item.storeCount>0;
 }
 invalidateMarketCache(g);return {ok:true,moved:move,reason:`ย้าย «${item.nameTh||item.matId||item.id}» ×${move} กลับเข้าคลังสำนักแล้ว`};
}

function enrichItemView(g,kind,item,countOverride){
 const qty=countOverride??(kind==='EQUIPMENT'||kind==='SCROLL'?1:(item.count||1));
 const q=quote(g,kind,item,1);
 const def=kind==='MATERIAL'?matDef(item.matId):null;
 const art=kind==='SCROLL'?g.progression?.artMap?.get(item.artId):null;
 return {
  kind,
  id:item.id||item.matId,
  stackId:item.id||item.matId,
  nameTh:item.nameTh||art?.nameTh||def?.nameTh||item.matId||item.id,
  count:qty,
  totalBankCount:kind==='EQUIPMENT'||kind==='SCROLL'?1:(item.count||1),
  storeCount:storeCountOf(kind,item),
  treasuryCount:treasuryCountOf(kind,item),
  tier:q.tier,
  quality:item.quality||'STANDARD',
  colorCode:q.colorCode,
  colorNameTh:q.colorNameTh,
  colorHex:q.colorHex,
  categoryNameTh:q.categoryNameTh,
  unitDonation:q.unitDonation,
  unitStorePrice:q.unitRedemption,
  storePrice:q.unitRedemption,
  grantEligible:grantEligibility(g,kind,item,1).ok,
  makerNameTh:item.makerNameTh||null,
  suppliedByNameTh:item.suppliedByNameTh||item.makerNameTh||item.originatorNameTh||'คลังบุกเบิกสำนัก',
  curatedByNameTh:item.curatedByNameTh||null,
  provenanceMode:item.provenanceMode||(item.makerNameTh?'SECT_WORKSHOP_CRAFT':'GATHER_OR_DONATION'),
  originLabelTh:item.originLabelTh||def?.nameTh||'พัสดุสำนัก',
  slot:item.slot||null,
  recipeId:item.recipeId||null,
  artId:item.artId||null,
  raw:item
 };
}

const marketCache=new WeakMap();
function invalidateMarketCache(g){if(g)marketCache.delete(g);}
function bankSig(g){
 const b=g?.bank?.jianghu?.ledgerV140;if(!b)return '';
 return Object.entries(keys).map(([kind,key])=>kind+':'+(b[key]||[]).map(x=>[x.id,x.matId,x.artId,x.recipeId,x.count,x.storeCount,x.sectStore,x.quality,x.tier,x.durability,x.ownerNpcId,x.ownerId,x.rights,x.access,!!x.loan,x.contributionCreditAllowed,x.suppliedByNpcId].join(',')).join('|')).join(';');
}
function getCachedMarket(g){
 if(!g)return null;
 const sig=bankSig(g),hit=marketCache.get(g);
 if(hit&&hit.sig===sig)return hit;
 const store=storeInventoryRaw(g);
 const treasury=treasuryInventoryRaw(g);
 const flywheel=computeMarketFlywheelRaw(g,store,treasury);
 const entry={sig,store,treasury,flywheel};
 marketCache.set(g,entry);
 return entry;
}

function storeInventory(g){return getCachedMarket(g)?.store||storeInventoryRaw(g);}
function storeInventoryRaw(g){
 const b=g?.bank?.jianghu?.ledgerV140||{};
 const equipment=(b.equipmentItems||[]).filter(i=>bankOwned(g,i)&&(i.durability===undefined||i.durability>0)&&storeCountOf('EQUIPMENT',i)>0).map(i=>enrichItemView(g,'EQUIPMENT',i,1));
 const pills=(b.pillStacks||[]).filter(p=>bankOwned(g,p)&&storeCountOf('PILL',p)>0).map(p=>enrichItemView(g,'PILL',p,storeCountOf('PILL',p)));
 const scrolls=(b.scrolls||[]).filter(s=>bankOwned(g,s)&&g.progression?.artMap?.has(s.artId)&&storeCountOf('SCROLL',s)>0).map(s=>enrichItemView(g,'SCROLL',s,1));
 const materials=(b.materialStacks||[]).filter(m=>bankOwned(g,m)&&storeCountOf('MATERIAL',m)>0).map(m=>enrichItemView(g,'MATERIAL',m,storeCountOf('MATERIAL',m)));
 return {
  equipment,
  pills,
  scrolls,
  materials,
  all:[...pills,...equipment,...scrolls,...materials]
 };
}

function treasuryInventory(g){return getCachedMarket(g)?.treasury||treasuryInventoryRaw(g);}
function treasuryInventoryRaw(g){
 const b=g?.bank?.jianghu?.ledgerV140||{};
 const equipment=(b.equipmentItems||[]).filter(i=>bankOwned(g,i)&&(i.durability===undefined||i.durability>0)&&treasuryCountOf('EQUIPMENT',i)>0).map(i=>enrichItemView(g,'EQUIPMENT',i,1));
 const pills=(b.pillStacks||[]).filter(p=>bankOwned(g,p)&&treasuryCountOf('PILL',p)>0).map(p=>enrichItemView(g,'PILL',p,treasuryCountOf('PILL',p)));
 const scrolls=(b.scrolls||[]).filter(s=>bankOwned(g,s)&&g.progression?.artMap?.has(s.artId)&&treasuryCountOf('SCROLL',s)>0).map(s=>enrichItemView(g,'SCROLL',s,1));
 const materials=(b.materialStacks||[]).filter(m=>bankOwned(g,m)&&treasuryCountOf('MATERIAL',m)>0).map(m=>enrichItemView(g,'MATERIAL',m,treasuryCountOf('MATERIAL',m)));
 return {
  equipment,
  pills,
  scrolls,
  materials,
  all:[...pills,...equipment,...scrolls,...materials]
 };
}

/* ============================================================================
   DEMAND & SUPPLY ECONOMIC FLYWHEEL (วงล้อเศรษฐกิจร้านค้าสำนัก)
   - More good items in the Sect Store -> higher Store Prestige & Market Heat ->
     more disciples covet items (wantedBy) -> stronger motivation to work/hunt/gather/craft for points!
   - Scarce items that disciples need -> higher Category Supply Bonus (+10%..+35% bonus points) ->
     motivates disciples to gather herbs, craft pills/weapons, or donate surplus!
   - When an item sells in the Sect Store, its original supplier/maker earns a +12% Creator Royalty!
   ============================================================================ */
function computeMarketFlywheel(g){return getCachedMarket(g)?.flywheel||computeMarketFlywheelRaw(g,storeInventoryRaw(g),treasuryInventoryRaw(g));}
function computeMarketFlywheelRaw(g,store,treasury){
 const heroes=(g?.heroes||[]).filter(h=>h?.alive&&h.health>0);
 const wantedMap=new Map();
 let activeShoppers=0,hungryForPoints=0;
 let needPills=0,needEquipment=0,needScrolls=0,needMaterials=0;

 for(const h of heroes){
  const j=h.jianghu||{},l=j.ledgerV140||{};
  const healPills=(l.pillStacks||[]).filter(p=>p.count>0&&g.progression?.normalizePill?.(p)?.healHealth>0).reduce((s,p)=>s+p.count,0);
  if(h.health<85||healPills<2||(j.cultivationProgress||0)>=40)needPills++;
  if(['WEAPON','ARMOR','TALISMAN_VESSEL'].some(sl=>!j.equipmentV140?.[sl]))needEquipment++;
  if((g.progression?.inspectSlotAndComboState?.(h)?.openAttackSlots||0)>0)needScrolls++;
  const wish=h.stageLocal?.storeWish;
  if(wish){
   activeShoppers++;
   if(wish.deficit>0)hungryForPoints++;
   const k=wish.kind+':'+wish.id;
   const arr=wantedMap.get(k)||[];
   arr.push({npcId:h.id,name:h.name,urgency:wish.urgency,canAfford:wish.canAfford,deficit:wish.deficit});
   wantedMap.set(k,arr);
  }
 }

 for(const item of store.all){
  const w=wantedMap.get(item.kind+':'+item.id)||[];
  item.wantedBy=w;
  item.demandCount=w.length;
 }

 const basicHerbs=g?.count?.(g.bank,root.FrontierData?.HERB||'MAT_HERB_DEW_GRASS_1')||0;
 const basicOres=g?.count?.(g.bank,root.FrontierData?.ORE||'MAT_ORE_BLACK_IRON_1')||0;
 if(basicHerbs<8||basicOres<8)needMaterials=Math.max(2,heroes.length);

 const totalStorePills=store.pills.reduce((s,p)=>s+p.count,0)+treasury.pills.reduce((s,p)=>s+p.count,0);
 const pillBonusPct=totalStorePills<4?30:totalStorePills<8?18:needPills>=3?12:5;
 const eqBonusPct=store.equipment.length<2?25:needEquipment>=2?15:5;
 const scrollBonusPct=store.scrolls.length<2?25:needScrolls>=2?15:5;
 const matBonusPct=basicHerbs<6?30:basicHerbs<12?18:5;

 const highGradeStoreCount=store.all.filter(x=>x.tier>=2||!['WHITE','GRAY'].includes(x.colorCode)).length;
 const marketHeat=Math.min(100,Math.round(
  20+store.all.length*6+highGradeStoreCount*9+activeShoppers*11+hungryForPoints*7
 ));

 const supplyBounties=[
  {kind:'PILL',labelTh:'โอสถฟื้นฟูและบำรุงปราณ',bonusPct:pillBonusPct,reasonTh:totalStorePills<6?'สต็อกโอสถในคลังและร้านค้าเหลือน้อย ศิษย์ต้องการใช้ประจำวัน':'มีความต้องการโอสถสำรองออกศึก'},
  {kind:'MATERIAL',labelTh:'สมุนไพรหุบเขาและแร่ปราณ',bonusPct:matBonusPct,reasonTh:basicHerbs<8?'โรงหลอมโอสถต้องการสมุนไพรสดมาป้อนเตาหลอม':'สะสมวัตถุดิบสำรองสำหรับโรงหลอมสำนัก'},
  {kind:'EQUIPMENT',labelTh:'ศาสตราและเกราะยุทธ์',bonusPct:eqBonusPct,reasonTh:store.equipment.length<2?'ชั้นวางศาสตราในร้านค้ายังขาดแคลนของดี':'ศิษย์กำลังมองหาอุปกรณ์ยกระดับพลังรบ'},
  {kind:'SCROLL',labelTh:'คัมภีร์วิชายุทธ์',bonusPct:scrollBonusPct,reasonTh:'คัมภีร์ในร้านค้าช่วยดึงดูดให้ศิษย์ขยันหาแต้มคุณูปการ'}
 ].sort((a,b)=>b.bonusPct-a.bonusPct);

 return {
  marketHeat,
  marketHeatLabelTh:marketHeat>=75?'🔥 คึกคักสูงสุด (สินค้าดีดึงดูดศิษย์ทั่วสำนัก)':marketHeat>=45?'⚖️ หมุนเวียนสมดุล (มีผู้ผลิตและผู้ซื้อต่อเนื่อง)':'🌱 เริ่มต้นสะสมสินค้าเข้าร้านค้าสำนัก',
  activeShoppers,
  hungryForPoints,
  highGradeStoreCount,
  bonusByCategory:{PILL:pillBonusPct,MATERIAL:matBonusPct,EQUIPMENT:eqBonusPct,SCROLL:scrollBonusPct},
  supplyBounties
 };
}

function donate(g,n,kind,id,quantity=1,opts={}){
 const fail=reason=>({ok:false,reason});
 if(!Number.isInteger(quantity)||quantity<=0)return fail('จำนวนบริจาคต้องเป็นจำนวนเต็มบวก');
 if(!keys[kind]||!tools().memberAvailable(g,n))return fail('ผู้บริจาคต้องเป็นศิษย์ที่อยู่ในสำนักและพร้อมส่งมอบ');
 const l=n.jianghu.ledgerV140,b=g.bank.jianghu.ledgerV140,key=keys[kind],items=l[key]||[];
 let item=items.find(x=>(kind==='MATERIAL'?x.matId:x.id)===id&&owned(n,x)&&(x.count??1)>0);
 if(!item)return fail('ไม่พบของที่เป็นสิทธิ์ของผู้บริจาค หรือพัสดุติดสิทธิ์ยืม');
 if(kind==='EQUIPMENT'&&(Object.values(n.jianghu.equipmentV140||{}).includes(item.id)||Number(item.durability??100)<=0))return fail('ต้องเก็บของที่กำลังสวมใส่ไว้ และซ่อมของพังก่อนส่งมอบ');
 let qty=kind==='EQUIPMENT'||kind==='SCROLL'?1:Math.max(1,Math.floor(Number(quantity)||1));
 let pts=0,moved=0,demandBonus=0;
 if(kind==='MATERIAL'){
  const candidates=items.filter(x=>x.matId===id&&owned(n,x)&&x.count>0),all=candidates.reduce((s,x)=>s+x.count,0);
  const keep=opts.keepOverride!==undefined?Math.max(1,opts.keepOverride):reserve(g,n,id);
  qty=Math.min(qty,Math.max(0,all-keep));if(!qty)return fail('ต้องเก็บวัตถุดิบที่จำเป็นต่อการฝึก งานผลิต หรือสัญญารองไว้ก่อน');
  for(const x of candidates){const amount=Math.min(qty-moved,x.count);if(amount<=0)break;
   const q=supplyQuote(g,kind,x,amount,opts.applyMarketBonus!==false);
   const r=depositMaterialLot(g,g.bank,id,amount,clone(x),{suppliedByNpcId:n.id,suppliedByNameTh:n.name,suppliedAt:time(g),provenanceMode:'GATHER_DEPOSIT'});
   if(!r.ok)break;
   pts+=q.donation;demandBonus+=q.demandBonus;x.count-=amount;moved+=amount;
  }
  l[key]=items.filter(x=>x.count>0);
 }else{
  const cap=kind==='EQUIPMENT'?240:kind==='PILL'?128:240;
  if((b[key]||[]).length>=cap)return fail('คลังสำนักเต็ม จึงยังไม่รับของและไม่เพิ่มแต้ม');
  if(kind==='SCROLL'&&!g.progression.artMap.has(item.artId))return fail('ไม่พบวิชาของคัมภีร์นี้');
  if(kind==='PILL')qty=Math.min(qty,item.count);
  const dq=supplyQuote(g,kind,item,qty,opts.applyMarketBonus!==false);
  const sent=kind==='PILL'&&qty<item.count?{...clone(item),id:'donation_pill_'+g.s.nextId++,count:qty}:item;
  if(sent===item)items.splice(items.indexOf(item),1);else item.count-=qty;
  sent.ownerNpcId=g.bank.id;if('ownerId'in sent)sent.ownerId=g.bank.id;if('custodianNpcId'in sent)sent.custodianNpcId=g.bank.id;
  sent.sectStore=false;sent.storeCount=0;
  sent.suppliedByNpcId=n.id;sent.suppliedByNameTh=n.name;sent.suppliedAt=time(g);
  sent.provenanceMode=sent.makerNameTh===n.name?'PERSONAL_CRAFT_DONATION':'PERSONAL_DONATION';
  if(kind==='SCROLL'){sent.access='SECT';sent.rights='OWNER';g.discovery?.onTransfer(sent,n,g.bank,'DONATION');}
  (b[key]||(b[key]=[])).push(sent);pts=dq.donation;demandBonus=dq.demandBonus;moved=qty;
 }
 if(!moved)return fail('คลังสำนักไม่มีพื้นที่รับพัสดุนี้');
 const a=account(g,n);a.balance+=pts;a.earned+=pts;
 E.syncLegacyArraysFromLedgerV140(n);E.syncLegacyArraysFromLedgerV140(g.bank);E.invalidateNpcCoreCache(n);
 g.life.credit(n,Math.min(3,pts/20),'บริจาคพัสดุที่เป็นสิทธิ์ของตนให้สำนัก');
 invalidateMarketCache(g);log(g,n,'DONATE',item,moved,pts,{compartment:'TREASURY',demandBonus});
 g.note(n.name+' มอบ '+(item.nameTh||item.matId)+' ×'+moved+' เข้าคลังสำนัก · ได้แต้มคุณูปการ +'+pts+(demandBonus?` (รวมโบนัสความต้องการตลาด +${demandBonus})`:''),n);
 return {ok:true,quantity:moved,points:pts,demandBonus,compartment:'TREASURY',reason:'ส่งมอบของจริงเข้าคลังสำนักและเพิ่มแต้มคุณูปการแล้ว'};
}

function creditLibraryDonation(g,n,book){
 if(!g.s.heroIds.includes(n?.id)||!g.s.growth.scriptureLibrary.includes(book)||book.donatedByNpcId!==n.id||!book.originalItemId||book.contributionCredited)return {ok:false};
 const pts=quote(g,'SCROLL',book).donation,a=account(g,n);book.contributionCredited=true;a.balance+=pts;a.earned+=pts;log(g,n,'DONATE',book,1,pts,{destination:'SCRIPTURE_LIBRARY'});return {ok:true,points:pts};
}

function grantEligibility(g,kind,item,quantity=1){
 const def=kind==='MATERIAL'?matDef(item.matId):null;
 const rec=(kind==='PILL'||kind==='EQUIPMENT')?resolveRecipe(g,item):null;
 const tier=Number(item.tier||def?.tier||rec?.tier)||1;
 const ordinary=['COMMON','STANDARD','GOOD','DAMAGED'].includes(item.quality||'STANDARD');
 const rare=item.isTranscendent||['RARE','EPIC','LEGENDARY','MYTHIC','TRANSCENDENT'].includes(item.rarity||'COMMON');
 let allowed=false;
 if(ordinary&&!rare&&kind==='MATERIAL')allowed=tier===1&&/^MAT_(HERB|ORE)_/.test(item.matId||'')&&quantity<=2;
 if(ordinary&&!rare&&kind==='EQUIPMENT')allowed=tier===1;
 if(ordinary&&!rare&&kind==='PILL'){
  const e=g.progression.normalizePill(item);
  const recovery=['healHealth','restoreQi','clearPoison','griefRelief','toxicityRelief','healInjury'].some(k=>e[k]>0);
  const advancement=['cultivationProgress','foundationBonus','daoComprehensionBonus','lifespanBonus','tribulationResist','openMeridianBonus'].some(k=>e[k]>0);
  allowed=tier<=2&&recovery&&!advancement;
 }
 return {ok:allowed,reason:allowed?'ของใช้พื้นฐานที่ผู้มีอำนาจพิจารณาแจกฟรีจากคลังสำนักได้':'ของหายาก คุณภาพสูง คัมภีร์ และอุปกรณ์ขั้นสูงสงวนไว้ซื้อด้วยแต้มที่ร้านค้าสำนัก'};
}

// Resolve physical lots before pricing. Shop purchases cannot reach welfare reserves.
function prepareStock(g,req,source,n){
 const kind=req.itemKind,shop=!!req.shopPurchase,grant=req.mode!=='REDEEM';
 let qty=req.quantity??(kind==='MATERIAL'?Math.min(2,Math.max(0,H.carryLimit(n)-H.load(n))):1);
 if(!Number.isInteger(qty)||qty<=0||qty>20)return {ok:false,reason:'จำนวนสินค้าต้องเป็นจำนวนเต็มบวกไม่เกิน 20'};
 if(kind!=='MATERIAL'){
  if(qty!==1)return {ok:false,reason:'รายการนี้โอนครั้งละหนึ่งชิ้น'};
  const stock=shop?storeCountOf(kind,source):grant?treasuryCountOf(kind,source):(source.count??1);
  return stock>=qty?{ok:true,quantity:qty}:{ok:false,reason:shop?'สินค้านี้ยังไม่ได้ขึ้นร้านค้า หรือขายหมดแล้ว':'ไม่มีของสำรองในคลังสำหรับแจกฟรี'};
 }
 const stacks=g.bank.jianghu.ledgerV140.materialStacks.filter(x=>bankOwned(g,x)&&x.matId===source.matId&&(!req.sourceStackId||x.id===req.sourceStackId));
 if(req.quantity===undefined)qty=Math.min(qty,stacks.reduce((sum,item)=>sum+(shop?storeCountOf(kind,item):grant?treasuryCountOf(kind,item):item.count),0));
 if(qty<=0)return {ok:false,reason:'ไม่มีวัตถุดิบในส่วนที่ขอ'};
 let left=qty;const lots=[];
 for(const item of stacks){
  const available=shop?storeCountOf(kind,item):grant?treasuryCountOf(kind,item):item.count;
  const take=Math.min(left,available);if(take>0){lots.push({item,quantity:take,storeBefore:storeCountOf(kind,item)});left-=take;}if(left===0)break;
 }
 if(left>0||qty>H.carryLimit(n)-H.load(n))return {ok:false,reason:'สินค้าในส่วนที่ขอหรือพื้นที่สัมภาระมีไม่พอ'};
 return {ok:true,quantity:qty,lots};
}
function transferStock(g,n,stock,flags){
 let moved=0;
 for(const lot of stock.lots){
  const x=lot.item,r=g.add(n,x.matId,lot.quantity,'SECT_HANDOFF',{...clone(x),...flags,allowTransferFromExistingHeritageStack:true});
  if(!r.ok)return {ok:false,moved};
  x.count-=lot.quantity;
  // Paid stock comes off shelves first; free grants leave shelves untouched.
  x.storeCount=Math.max(0,Math.min(x.count,lot.storeBefore-(flags.sectGrant?0:Math.min(lot.quantity,lot.storeBefore))));
  x.sectStore=x.storeCount>0;moved+=lot.quantity;
 }
 g.bank.jianghu.ledgerV140.materialStacks=g.bank.jianghu.ledgerV140.materialStacks.filter(x=>x.count>0);
 return {ok:true,moved};
}
// Keep real suppliers in separate lots even when the native material ledger merges by quality.
function depositMaterialLot(g,owner,matId,quantity,sample,metadata){
 const l=owner.jianghu.ledgerV140,all=l.materialStacks;
 const peer=all.find(x=>g.ownsMaterial(owner,x)&&x.matId===matId&&x.quality===(sample.quality||'STANDARD')&&x.originId===sample.originId&&x.suppliedByNpcId===metadata.suppliedByNpcId&&x.provenanceMode===metadata.provenanceMode&&Number(x.outsidePurchaseCostPerUnit||0)===Number(metadata.outsidePurchaseCostPerUnit||0)&&(x.contributionCreditAllowed===false)===(sample.contributionCreditAllowed===false));
 const cap=g.isSectStorage(owner)?(root.JianghuInfrastructure?.bonuses(g).materialCapacity||640):(E.PATCH140_CAPS?.materialStacks||24);
 if(!peer&&all.length>=cap)return {ok:false};
 l.materialStacks=peer?[peer]:[];
 try{
  const r=g.add(owner,matId,quantity,'ECONOMIC_SUPPLY',{...sample,allowTransferFromExistingHeritageStack:true});
  if(r.ok)for(const s of l.materialStacks){Object.assign(s,metadata);if(!s.id)s.id='economic_mat_'+g.s.nextId++;if(sample.contributionCreditAllowed!==undefined)s.contributionCreditAllowed=sample.contributionCreditAllowed;}
  return r;
 }finally{l.materialStacks=[...all.filter(x=>x!==peer),...l.materialStacks];E.syncLegacyArraysFromLedgerV140(owner);}
}
function supplyQuote(g,kind,item,quantity=1,withBonus=true){
 const q=quote(g,kind,item,quantity),fly=computeMarketFlywheel(g);
 const stock=kind==='MATERIAL'?g.count(g.bank,item.matId):kind==='PILL'?(g.bank.jianghu.ledgerV140.pillStacks||[]).filter(x=>x.recipeId===item.recipeId&&bankOwned(g,x)).reduce((s,x)=>s+x.count,0):0;
 const target=Math.max(kind==='MATERIAL'?10:4,g.heroes.filter(x=>x.alive).length*(kind==='MATERIAL'?3:2));
 const pct=withBonus&&stock<target?(fly.bonusByCategory?.[kind]||0):0;
 // Donation bounty + the 12% first-sale royalty must stay below the buyer's retired points.
 const maximum=Math.floor(q.redemption*.85);
 const bonus=Math.max(0,Math.min(Math.round(q.donation*pct/100),maximum-q.donation));
 return {...q,donation:q.donation+bonus,demandBonus:bonus,bonusPct:pct,stock,target};
}

function prepareRedemption(g,req,n,source,quantity=1){
 if(req.mode!=='REDEEM'){
  const stock=prepareStock(g,{...req,quantity},source,n);if(!stock.ok)return stock;
  for(const lot of stock.lots||[{item:source,quantity}]){const allowed=grantEligibility(g,req.itemKind,lot.item,lot.quantity);if(!allowed.ok)return allowed;}
  const a=account(g,n),day=Math.floor(time(g)/20),used=a.grantDay===day?(a.grantQuantity||0):0;
  const quota=root.JianghuInfrastructure?.bonuses(g).welfareDailyLimit||4;
  if(used+quantity>quota)return {ok:false,reason:'รับของใช้พื้นฐานครบโควตาวันนี้แล้ว รอวันถัดไปหรือใช้แต้มซื้อที่ร้านค้าสำนัก'};
  return {ok:true,cost:0,quantity,grant:true};
 }
 const stock=prepareStock(g,{...req,quantity},source,n);if(!stock.ok)return stock;
 const price=quote(g,req.itemKind,source,quantity),a=account(g,n);
 if(stock.lots)price.redemption=stock.lots.reduce((sum,lot)=>sum+quote(g,'MATERIAL',lot.item,lot.quantity).redemption,0);
 if(a.balance>=price.redemption)return {ok:true,cost:price.redemption,quantity,emergency:false};
 return {ok:false,cost:price.redemption,reason:'แต้มคุณูปการไม่พอสำหรับซื้อในร้านค้าสำนัก: ต้องการ '+price.redemption+' · มี '+a.balance};
}

function commitRedemption(g,req,n,item,charge){
 const a=account(g,n);
 a.balance-=charge.cost;
 a.spent+=charge.cost;
 if(charge.grant){
  const day=Math.floor(time(g)/20);
  if(a.grantDay!==day){a.grantDay=day;a.grantQuantity=0;}
  a.grantQuantity+=charge.quantity;
  if(item&&Number.isFinite(item.storeCount))item.storeCount=Math.min(item.count||0,item.storeCount);
 }else if(item&&req.itemKind!=='MATERIAL'){
  if(Number.isFinite(item.storeCount)){
   item.storeCount=Math.max(0,Math.min(item.count||0,(item.storeCount||0)-charge.quantity));
   item.sectStore=item.storeCount>0;
  }else if(item.ownerNpcId===n.id){
   delete item.sectStore;
   delete item.storeCount;
  }
 }
 invalidateMarketCache(g);log(g,n,charge.grant?'GRANT':(req.shopPurchase?'SHOP_BUY':'REDEEM'),item,charge.quantity,-charge.cost,{compartment:charge.grant?'TREASURY':'SECT_STORE'});
}

function transferFlags(g,req,item){
 return req.mode==='REDEEM'
  ?{contributionCreditAllowed:true,sectGrant:null}
  :{contributionCreditAllowed:false,sectGrant:{sectId:'TH',rootItemId:item.sectGrant?.rootItemId||item.id||item.matId}};
}

function creditWork(g,n,amount,reason){
 if(!g.s.storyEvents?.active||!(amount>0)||/บริจาค|นำวัสดุเข้าคลัง|นำคัมภีร์เข้าหอสืบทอด|หลอมสร้างพัสดุเข้าคลังสำนัก/.test(reason||''))return;
 if(!/ปกป้อง|คุ้มภัย|ปราบภัย|ประกาศสำเร็จ|ส่งไม้ไผ่ให้สำนัก|เสบียง|ช่วยชีวิตผู้ส่งสาร|เจรจากับผู้แทน|คัดลอกคัมภีร์เข้าหอสืบทอด|ค้นพบที่ตั้งค่าย|จัดหางานช่าง|นำสินค้ากลับจากเส้นทาง/.test(reason||''))return;
 const easy=/ส่งไม้ไผ่|เสบียง/.test(reason),danger=/ปราบภัย|ปกป้อง|คุ้มภัย/.test(reason);
 const category=easy?(/ไม้ไผ่/.test(reason)?'WOOD':'FOOD'):danger?'DANGER':'SERVICE';
 const a=account(g,n),day=Math.floor(time(g)/20);if(a.workDay!==day){a.workDay=day;a.workByClass={};}
 const cap=easy?6:danger?18:8,used=a.workByClass[category]||0;
 const pts=Math.max(0,Math.min(easy?Math.min(2,Math.ceil(amount)):Math.round(amount*3),cap-used));if(!pts)return;
 a.workByClass[category]=used+pts;a.balance+=pts;a.earned+=pts;log(g,n,'WORK',{nameTh:reason||'ผลงานสำนัก'},1,pts);

}

function autoMethod(g,n,kind,item){
 const quantity=kind==='MATERIAL'?Math.min(2,item.count):1,canPay=account(g,n).balance>=quote(g,kind,item,quantity).redemption,free=prepareRedemption(g,{itemKind:kind,mode:'GRANT'},n,item,quantity).ok;
 return canPay&&(!free||(n.personality.integrity||50)>=55)?'REDEEM':free?'GRANT':canPay?'REDEEM':null;
}

function acquire(g,n,kind,id,mode='REDEEM',authorityNpcId=null,quantity=undefined){
 const rejected=r=>{if(n.stageLocal?.cooldowns)n.stageLocal.cooldowns['sectWithdraw:'+kind+':'+id]=time(g)+60;return {...r,ok:false};};
 const source=tools().source(g,kind,id);if(!source)return rejected({reason:'ไม่พบพัสดุส่วนรวมที่ขอ'});
 const spec={...tools().spec(g,kind,source),mode,...(quantity===undefined?{}:{quantity})},prepared=tools().prepareTransfer(g,spec,n);if(!prepared.ok)return rejected({reason:prepared.effectTextTh});
 const charge=prepareRedemption(g,spec,n,source,prepared.qty||1);if(!charge.ok)return rejected(charge);
 const r=g.storyEvents.createManualRequisition(n.id,kind,id,mode,authorityNpcId);if(!r.ok)return rejected(r);
 if(quantity!==undefined)r.req.quantity=quantity;
 const decision=g.storyEvents.judgeRequisition(r.req.id,mode==='REDEEM'?true:null,authorityNpcId);
 return decision.ok&&decision.approved?{...decision,count:prepared.qty||1,cost:charge.cost}:rejected({...decision,reason:decision.reason||'ผู้ดูแลคลังยังไม่อนุมัติ'});
}

function buyFromStore(g,n,kind,id,quantity=1,authorityNpcId=null){
 const actor=typeof n==='string'?g.world?.npcs?.[n]:n;
 if(!actor||!tools().memberAvailable(g,actor))return {ok:false,reason:'ผู้ซื้อต้องเป็นศิษย์ที่อยู่ในสำนักและพร้อมรับสินค้า'};
 if(!keys[kind]||!Number.isInteger(quantity)||quantity<1||quantity>20||((kind==='EQUIPMENT'||kind==='SCROLL'||kind==='PILL')&&quantity!==1))return {ok:false,reason:'จำนวนสินค้าต้องเป็นจำนวนเต็มบวกตามชนิดสินค้า'};
 const source=kind==='MATERIAL'?(g.bank.jianghu.ledgerV140.materialStacks||[]).find(x=>bankOwned(g,x)&&(x.id===id||x.matId===id)&&storeCountOf(kind,x)>0):tools().source(g,kind,id);
 if(!source||storeCountOf(kind,source)<quantity)return {ok:false,reason:'ไม่พบสินค้านี้บนชั้นวางร้านค้าสำนัก หรือจำนวนไม่พอ'};
 const supplierNpcId=source.suppliedByNpcId||source.craftedByNpcId||null;
 const supplier=source.makerNameTh||source.suppliedByNameTh||'ศิษย์ร่วมสำนัก';
 const spec={...tools().spec(g,kind,source),mode:'REDEEM',shopPurchase:true,quantity,sourceStackId:kind==='MATERIAL'?source.id:null};
 const prepared=tools().prepareTransfer(g,spec,actor);
 if(!prepared.ok)return {ok:false,reason:prepared.effectTextTh};
 const qty=prepared.qty||1;
 const charge=prepareRedemption(g,spec,actor,source,qty);
 if(!charge.ok)return charge;
 const req=g.storyEvents.createManualRequisition(actor.id,kind,id,'REDEEM',authorityNpcId);
 if(!req.ok)return req;
 req.req.shopPurchase=true;req.req.quantity=quantity;req.req.sourceStackId=spec.sourceStackId;
 const decision=g.storyEvents.judgeRequisition(req.req.id,true,authorityNpcId);
 if(!decision.ok||!decision.approved)return {ok:false,reason:decision.reason||'ไม่สามารถทำรายการซื้อจากร้านค้าสำนักได้'};

 // Supplier/Creator Royalty: when another disciple buys your crafted/donated item from the Sect Store, you earn a +12% royalty & respect!
 let royaltyPts=0;
 if(supplierNpcId&&supplierNpcId!==actor.id&&g.s.heroIds.includes(supplierNpcId)){
  const supNpc=g.world?.npcs?.[supplierNpcId];
  if(supNpc?.alive){
   royaltyPts=Math.max(1,Math.round(charge.cost*0.12));
   const supAcc=account(g,supNpc);
   supAcc.balance+=royaltyPts;
   supAcc.earned+=royaltyPts;
   log(g,supNpc,'ROYALTY',{nameTh:spec.itemNameTh},qty,royaltyPts,{buyerName:actor.name,compartment:'SECT_STORE'});
   g.life?.relate?.(actor,supNpc,4,2);
  }
 }

 g.note(`🏪 ${actor.name} ใช้แต้มคุณูปการ ${charge.cost} แต้ม ซื้อ «${spec.itemNameTh}» ×${qty} จากร้านค้าสำนัก (ที่มา: ${supplier}${royaltyPts?` · ผู้จัดหารับปันผล +${royaltyPts} แต้ม`:''})`,actor);
 return {
  ok:true,
  quantity:qty,
  cost:charge.cost,
  royaltyPts,
  itemNameTh:spec.itemNameTh,
  supplierNameTh:supplier,
  balance:account(g,actor).balance,
  reason:`ซื้อ «${spec.itemNameTh}» ×${qty} จากร้านค้าสำนักสำเร็จ (ใช้ ${charge.cost} แต้ม)`
 };
}

/* ============================================================================
   MODE A: SECT-SPONSORED ALCHEMY & FORGING (หลอมโอสถ/ศาสตราให้สำนักแลกแต้ม)
   - Uses raw materials from the Sect Treasury (g.bank) — 0 personal materials & 0 personal stones.
   - Disciple contributes labor & skill at the Alchemy Hall or Forge.
   - Output belongs to the Sect (enters Sect Treasury first, then Elder curates to Sect Store).
   - Disciple earns Contribution Points (แต้มคุณูปการ) + Market Demand Bonus for their labor.
   ============================================================================ */
function canCraftForSect(g,n,recipeId){
 const actor=typeof n==='string'?g.world?.npcs?.[n]:n;
 if(!actor||!tools().memberAvailable(g,actor))return {ok:false,reason:'ผู้หลอมต้องเป็นศิษย์ที่อยู่ในสำนัก'};
 ensureBasicSectRecipes(g,actor);
 const r=g.progression?.recipe?.(recipeId);
 if(!r)return {ok:false,reason:'ไม่พบตำรับการหลอม'};
 if(r.effect?.beastItem||!['alchemy','forge'].includes(r.workshop)||!(r.effect?.slot||Object.keys(g.progression.normalizePill(r.effect)).length))return {ok:false,reason:'ตำรับนี้ไม่ใช่โอสถหรือศาสตราที่โรงหลอมสำนักรองรับ'};
 const b=g.built(r.workshop);
 if(!b)return {ok:false,reason:`ต้องสร้าง${r.workshop==='alchemy'?'หอโอสถ':'โรงหลอม'}ให้เสร็จก่อน`};
 const known=actor.stageLocal?.growth?.knownRecipes||[];
 if(!known.includes(r.id)&&!FREE_SECT_RECIPES.includes(r.id)){
  return {ok:false,reason:`${actor.name} ยังไม่รู้สูตร «${r.name}» (ต้องค้นพบจากวาสนาหรือศึกษาก่อน)`};
 }
 if(g.progression.tier(actor)<r.tier)return {ok:false,reason:`ขอบเขตของ ${actor.name} ยังไม่ถึงระดับตำรับ (T${r.tier})`};
 const activity=r.workshop==='alchemy'?'alchemy':'forging';
 const cap=H.capacity(actor,activity).total+(root.JianghuInfrastructure?.bonuses(g).perWorkshop?.[r.workshop]?.craftSkillBonus||0)+(g.progression.equippedCraftBonus?.(actor,r.discipline||r.craftPath||r.workshop)||0);
 if(cap<r.min)return {ok:false,reason:`ฝีมือ${activity==='alchemy'?'ปรุงโอสถ':'หลอมศาสตรา'}ยังไม่ถึงเกณฑ์ (${Math.round(cap)}/${r.min})`};
 // Preflight all ingredients, including recipes that repeat the same material ID.
 // A unit listed for sale is not an available treasury ingredient.
 const required=new Map();
 for(const inp of r.inputs)required.set(inp.matId,(required.get(inp.matId)||0)+inp.count);
 const missing=[...required].filter(([matId,count])=>treasuryMaterialAvailable(g,matId)<count)
  .map(([matId,count])=>({matId,count,available:treasuryMaterialAvailable(g,matId)}));
 if(missing.length){
  return {ok:false,missing,reason:`คลังสำนักมีวัตถุดิบที่ยังไม่วางขายไม่พอ (${missing.map(m=>m.matId+' ขาด '+(m.count-m.available)).join(', ')})`};
 }
 const bankLedger=g.bank.jianghu.ledgerV140;
 const outKey=r.effect?.slot?'equipmentItems':r.effect?.beastItem?'beastItems':'pillStacks';
 const outCap=outKey==='pillStacks'?128:outKey==='beastItems'?96:240;
 if((bankLedger[outKey]||[]).length>=outCap)return {ok:false,reason:'คลังสำนักไม่มีพื้นที่เก็บผลผลิตเพิ่ม'};
 return {ok:true,recipe:r,workshopBuilding:b,activity,effectiveCapacity:cap};
}

function consumeBankMaterialForSectCraft(g,matId,qty){
 if(!Number.isInteger(qty)||qty<1||treasuryMaterialAvailable(g,matId)<qty)return false;
 const stacks=(g.bank?.jianghu?.ledgerV140?.materialStacks||[]).filter(s=>s.matId===matId&&bankOwned(g,s)&&treasuryCountOf('MATERIAL',s)>0);
 stacks.sort((a,b)=>treasuryCountOf('MATERIAL',b)-treasuryCountOf('MATERIAL',a));
 let left=qty;
 for(const s of stacks){
  if(left<=0)break;
  const take=Math.min(left,treasuryCountOf('MATERIAL',s));
  s.count-=take;
  left-=take;
  // Store allocation is intentionally unchanged: these units were never on sale.
  s.sectStore=storeCountOf('MATERIAL',s)>0;
 }
 g.bank.jianghu.ledgerV140.materialStacks=g.bank.jianghu.ledgerV140.materialStacks.filter(s=>s.count>0);
 E.syncLegacyArraysFromLedgerV140?.(g.bank);
 return left===0;
}

function craftForSect(g,n,recipeId,opts={}){
 const actor=typeof n==='string'?g.world?.npcs?.[n]:n;
 const check=canCraftForSect(g,actor,recipeId);
 if(!check.ok)return check;
 const {recipe:r,workshopBuilding:b,activity,effectiveCapacity:effCap}=check;
 if(opts.requireAtWorkshop&&Math.hypot((actor.stageLocal?.x||0)-g.endpoint(b).x,(actor.stageLocal?.y||0)-g.endpoint(b).y)>145){
  return {ok:false,reason:'ผู้หลอมยังเดินไปไม่ถึงโรงหลอมของสำนัก'};
 }
 for(const inp of r.inputs){
  if(!consumeBankMaterialForSectCraft(g,inp.matId,inp.count)){
   return {ok:false,reason:'เบิกวัตถุดิบจากคลังสำนักไม่สำเร็จ'};
  }
 }
 const chance=Math.max(0.45,Math.min(0.95,0.52+effCap*0.006-r.tier*0.05));
 const roll=opts.forceSuccess?0.01:g.rng.next();
 H.learn(actor,activity,3);
 if(actor.core?.condition)actor.core.condition.fatigue=Math.min(100,(actor.core.condition.fatigue||0)+6);
 g.progression?.receipt?.('sectProduction',actor,{recipeId:r.id,chance,roll,success:roll<chance,inputs:clone(r.inputs),stones:0});

 if(roll>=chance){
  const consolationPts=Math.max(1,r.tier);
  const acc=account(g,actor);
  acc.balance+=consolationPts;acc.earned+=consolationPts;
  log(g,actor,'SECT_CRAFT_FAIL',{nameTh:r.name},1,consolationPts,{recipeId:r.id});
  g.remember(actor,'sectCraft',-2,'หลอม '+r.name+' ให้สำนักล้มเหลว ได้แต้มค่าแรงปลอบใจ '+consolationPts);
  g.note(`${actor.name} ลงแรงหลอม «${r.name}» ให้สำนักแต่ไฟปราณสะดุด (ใช้วัตถุดิบคลังสำนัก · ได้ค่าแรง ${consolationPts} แต้ม)`,actor);
  return {ok:false,produced:false,points:consolationPts,reason:`การหลอม «${r.name}» ล้มเหลว เสียวัตถุดิบคลังสำนัก แต่ได้ค่าแรง ${consolationPts} แต้ม`};
 }

 const quality=effCap>=82?'SUPERIOR':effCap>=66?'REFINED':effCap>=50?'GOOD':'COMMON';
 const isEquipment=!!r.effect?.slot;
 const isBeastItem=!!r.effect?.beastItem;
 const kind=isEquipment?'EQUIPMENT':isBeastItem?'MATERIAL':'PILL';
 const batchCount=(!isEquipment&&!isBeastItem&&r.tier===1&&effCap>=55)?2:1;
 const bankLedger=g.bank.jianghu.ledgerV140;
 let storedItem=null;

 if(isEquipment){
  storedItem={
   ...clone(r.effect),
   id:'sect_eq_'+(g.s.nextId++),
   recipeId:r.id,
   catalogId:r.id,
   nameTh:r.name,
   tier:r.tier,
   minStageReq:Number.isFinite(r.minStageReq??r.effect.minStageReq)?(r.minStageReq??r.effect.minStageReq):Math.max(1,(r.tier||1)-1),
   isTranscendent:!!r.isTranscendent,
   quality,
   slot:r.effect.slot,
   compatiblePath:r.compatiblePath||'ANY',
   durability:100,
   maxDurability:100,
   combatMult:r.effect.combat??r.effect.combatMult??0,
   defenseMult:r.effect.defense??r.effect.defenseMult??0,
   studyBonus:r.effect.study??r.effect.studyBonus??0,
   dissectionBonus:r.effect.dissectionBonus||0,
   ownerNpcId:g.bank.id,
   ownerId:g.bank.id,
   makerNameTh:actor.name,
   craftedByNpcId:actor.id,
   suppliedByNpcId:actor.id,
   suppliedByNameTh:actor.name,
   suppliedAt:time(g),
   provenanceMode:'SECT_WORKSHOP_CRAFT',
   sectStore:false,
   originLabelTh:`หลอมสร้างให้สำนักโดย ${actor.name} (ใช้วัตถุดิบคลังสำนัก)`
  };
  root.JianghuExpansionV112?.imbueEquipmentDepth?.(storedItem,g.rng);
  bankLedger.equipmentItems.push(storedItem);
 }else{
  const normEff=g.progression.normalizePill(r.effect);
  let stack=bankLedger.pillStacks.find(p=>bankOwned(g,p)&&p.recipeId===r.id&&p.quality===quality&&p.makerNameTh===actor.name);
  if(!stack){
   stack={
    id:'sect_pill_'+(g.s.nextId++),
    recipeId:r.id,
    catalogId:r.id,
    nameTh:r.name,
    tier:r.tier,
    quality,
    count:0,
    storeCount:0,
    sectStore:false,
    livingEffect:clone(r.effect),
    effect:normEff,
    ownerNpcId:g.bank.id,
    ownerId:g.bank.id,
    makerNameTh:actor.name,
    craftedByNpcId:actor.id,
    suppliedByNpcId:actor.id,
    suppliedByNameTh:actor.name,
    suppliedAt:time(g),
    provenanceMode:'SECT_WORKSHOP_CRAFT',
    originLabelTh:`ปรุงให้สำนักโดย ${actor.name} (ใช้สมุนไพรคลังสำนัก)`
   };
   bankLedger.pillStacks.push(stack);
  }
  stack.count+=batchCount;
  stack.suppliedAt=time(g);
  storedItem=stack;
 }

 E.syncLegacyArraysFromLedgerV140?.(g.bank);
 g.s.stats.crafted++;
 const fullQuote=quote(g,kind,storedItem,batchCount);
 const fly=computeMarketFlywheel(g);
 const demandBonusPct=fly.bonusByCategory?.[kind]||0;
 const baseLaborPts=Math.max(5*r.tier,Math.round(fullQuote.donation*0.65));
 const demandBonusPts=Math.round(baseLaborPts*(demandBonusPct/100));
 const laborPts=baseLaborPts+demandBonusPts;
 const acc=account(g,actor);
 acc.balance+=laborPts;
 acc.earned+=laborPts;
 g.life?.credit?.(actor,Math.min(3,1+r.tier*0.5),'หลอมสร้างพัสดุเข้าคลังสำนัก');
 log(g,actor,'SECT_CRAFT',storedItem,batchCount,laborPts,{recipeId:r.id,quality,demandBonusPts,compartment:'TREASURY'});
 const cur=curateStore(g);
 g.note(`⚗️ ${actor.name} ใช้ทรัพยากรคลังสำนักหลอม «${r.name}» (${quality}) ×${batchCount} เข้าคลังสำนัก · รับค่าแรง +${laborPts} แต้มคุณูปการ${demandBonusPts?` (โบนัสความต้องการตลาด +${demandBonusPts})`:''}${cur.movedCount?` · ${cur.curatorName} จัดขึ้นร้านค้าสำนักทันที`:''}`,actor);
 return {
  ok:true,
  produced:true,
  item:storedItem,
  quantity:batchCount,
  quality,
  points:laborPts,
  demandBonusPts,
  curatedMoved:cur.movedCount,
  reason:`${actor.name} หลอม «${r.name}» ×${batchCount} ให้สำนักสำเร็จ ได้รับ +${laborPts} แต้มคุณูปการ`
 };
}

/* ============================================================================
   AUTONOMOUS NPC SECT STORE WISHLIST, SHOPPING & POINT-SEEKING MOTIVATION
   ============================================================================ */
const desireCache=new WeakMap();
function evaluateStoreDesires(g,n,write=true){
 if(!g||!n?.alive||!n.jianghu)return {desires:[],topWish:null};
 const l0=n.jianghu.ledgerV140;
 const sig=bankSig(g)+JSON.stringify([accountView(g,n).balance,n.health,n.jianghu.internalInjury,n.jianghu.poisonAccumulated,n.jianghu.pillToxicity,n.jianghu.cultivationProgress,n.stageLocal?.combatState?.qi,l0.pillStacks,l0.equipmentItems,l0.scrolls,l0.materialStacks,n.jianghu.knowledgeV190,n.jianghu.equipmentV140,n.stageLocal?.growth?.plan,g.s.growth.scriptureLibrary,g.s.storyEvents?.treasury?.contributions?.learningLicenses?.[n.id]]);
 const hit=desireCache.get(n);if(write&&hit&&hit.sig===sig){if(n.stageLocal)n.stageLocal.storeWish=hit.val.topWish?{...hit.val.topWish,balance:accountView(g,n).balance,canAfford:hit.val.topWish.deficit===0}:null;return hit.val;}
 const store=storeInventory(g);
 const j=n.jianghu,l=j.ledgerV140,q=n.stageLocal?.growth;
 const bal=accountView(g,n).balance;
 const desires=[];

 // 1. Pills in Sect Store (healing, Qi recovery, cultivation progress, cleanse)
 const personalHealPills=(l.pillStacks||[]).filter(p=>p.count>0&&g.progression.normalizePill(p).healHealth>0).reduce((s,p)=>s+p.count,0);
 const injured=n.health<82||(j.internalInjury||0)>5||(j.poisonAccumulated||0)>5;
 for(const p of store.pills){
  const eff=g.progression.normalizePill(p.raw);
  if(p.tier>Math.max(1,Math.ceil(g.progression.tier(n))+1))continue;
  const heldFor=key=>(l.pillStacks||[]).filter(x=>owned(n,x)&&g.progression.normalizePill(x)[key]>0).reduce((sum,x)=>sum+(x.count||0),0);
  let urgency=0,reasonTh='';
  if(((eff.healHealth>0&&personalHealPills<2)||(eff.healInjury>0&&(j.internalInjury||0)>5&&heldFor('healInjury')<2)||(eff.clearPoison>0&&(j.poisonAccumulated||0)>5&&heldFor('clearPoison')<2))){
   urgency=injured?(n.health<65?99:86):58;
   reasonTh=injured?`ต้องการซื้อ «${p.nameTh}» จากร้านค้าสำนักมารักษาอาการบาดเจ็บ`:`ต้องการซื้อ «${p.nameTh}» จากร้านค้าสำนักเก็บสำรองยามออกศึก`;
  }else if(eff.cultivationProgress>0&&heldFor('cultivationProgress')<2&&(j.cultivationProgress||0)<95&&(n.personality?.ambition||50)>=45&&(j.pillToxicity||0)<30){
   urgency=62+Math.min(12,p.tier*3);reasonTh=`ต้องการซื้อ «${p.nameTh}» เพื่อใช้บ่มเพาะตบะ`;
  }else if(eff.restoreQi>0&&heldFor('restoreQi')<2){
   urgency=57;reasonTh=`ต้องการซื้อ «${p.nameTh}» สำรองฟื้นปราณต่อสู้`;
  }else if(eff.toxicityRelief>0&&(j.pillToxicity||0)>8&&heldFor('toxicityRelief')<1){
   urgency=74;reasonTh=`ต้องการซื้อ «${p.nameTh}» เพื่อลดพิษโอสถ`;
  }

  if(urgency>0&&(l.pillStacks||[]).length<15){
   desires.push({kind:'PILL',id:p.id,nameTh:p.nameTh,price:p.unitStorePrice,urgency,reasonTh,tier:p.tier,colorNameTh:p.colorNameTh});
  }
 }

 // 2. Equipment upgrades in Sect Store
 if((l.equipmentItems||[]).length<11){
  for(const eq of store.equipment){
   if(!g.progression?.canEquipItem?.(n,eq.raw,{ignoreOwnership:true})?.ok)continue;
   const slot=eq.slot||'WEAPON';
   const curId=j.equipmentV140?.[slot];
   const curEq=(l.equipmentItems||[]).filter(x=>x.slot===slot&&g.progression.canEquipItem(n,x).ok).sort((a,b)=>g.progression.effectScore(n,b)-g.progression.effectScore(n,a))[0];
   const newScore=g.progression.effectScore(n,eq.raw);
   const curScore=curEq?g.progression.effectScore(n,curEq):0;
   if(!curEq||newScore>curScore+0.25){
    const urgency=!curEq?78:Math.min(88,64+Math.round((newScore-curScore)*4)+(eq.tier>=2?6:0));
    desires.push({
     kind:'EQUIPMENT',
     id:eq.id,
     nameTh:eq.nameTh,
     price:eq.unitStorePrice,
     urgency,
     reasonTh:!curEq?`ต้องการซื้อ «${eq.nameTh}» จากร้านค้าสำนักมาสวมใส่ช่อง ${slot}`:`ต้องการซื้อ «${eq.nameTh}» (${eq.colorNameTh}) จากร้านค้าสำนักมาแทนของเดิม`,
     tier:eq.tier,
     colorNameTh:eq.colorNameTh
    });
   }
  }
 }

 // 3. Compatible unlearned Scripture Manuals in Sect Store
 if((l.scrolls||[]).length<22){
  for(const sc of store.scrolls){
   const art=g.progression?.artMap?.get(sc.artId);
   const k=j.knowledgeV190?.[sc.artId];
   if(art&&!(l.scrolls||[]).some(x=>x.artId===sc.artId&&owned(n,x))&&(!k||k.stage<4)&&g.progression.compatible(n,art)&&g.progression.canStudyArtTier(n,art)&&(!g.discovery||g.discovery.canStudy(n,art))){
    const suit=g.progression.scoreArtSuitability?.(n,art)||{score:25};
    const urgency=Math.min(88,66+Math.round((suit.score||20)*0.25));
    desires.push({
     kind:'SCROLL',
     id:sc.id,
     nameTh:sc.nameTh,
     price:sc.unitStorePrice,
     urgency,
     reasonTh:`ต้องการใช้แต้มแลกคัมภีร์ «${sc.nameTh}» จากร้านค้าสำนักมาฝึกวิชา`,
     tier:sc.tier,
     colorNameTh:sc.colorNameTh
    });
   }
  }
 }

 // 4. Missing Personal Crafting Materials in Sect Store
 const targetRec=g.progression?.recipe?.(q?.plan?.targetId||q?.careerPlan?.targetId);
 if(targetRec&&H.load(n)<H.carryLimit(n)){
  for(const inp of (targetRec.inputs||[])){
   const need=inp.count-g.count(n,inp.matId);
   if(need<=0)continue;
   const m=store.materials.find(x=>x.raw.matId===inp.matId&&x.count>0);
   if(m){
    const take=Math.min(2,need,m.count);
    const cost=quote(g,'MATERIAL',m.raw,1).redemption;
    desires.push({
     kind:'MATERIAL',
     id:m.id,
     nameTh:m.nameTh,
     price:cost,
     urgency:60,
     reasonTh:`ต้องการซื้อวัตถุดิบ «${m.nameTh}» ×1 จากร้านค้าสำนักไปหลอม «${targetRec.name}» ใช้เอง`,
     tier:m.tier,
     colorNameTh:m.colorNameTh
    });
   }
  }
 }

 desires.push(...(root.JianghuSectLibrary?.desires(g,n)||[]));
 desires.sort((a,b)=>b.urgency-a.urgency||a.price-b.price);
 const topWish=desires[0]?{...desires[0],deficit:Math.max(0,desires[0].price-bal)}:null;
 if(write&&n.stageLocal){
  n.stageLocal.storeWish=topWish?{
   kind:topWish.kind,
   id:topWish.id,
   nameTh:topWish.nameTh,
   price:topWish.price,
   balance:bal,
   canAfford:bal>=topWish.price,
   deficit:Math.max(0,topWish.price-bal),
   urgency:topWish.urgency,
   reasonTh:topWish.reasonTh
  }:null;
 }
 const val={desires,topWish};desireCache.set(n,{sig,val});return val;
}

function shoppingAvailable(g,n){return tools().memberAvailable(g,n)&&n.health>=35&&(n.stageLocal.needs?.hunger||0)<85&&(n.core.condition.fatigue||0)<85&&!g.nearestEnemy(n,500);}
function available(g,n){
 return tools().memberAvailable(g,n)&&n.health>=65&&(n.stageLocal.needs?.hunger||0)<75&&(n.core.condition.fatigue||0)<70&&!g.nearestEnemy(n,500);
}

function surplus(g,n){
 const l=n.jianghu.ledgerV140,out=[];
 const wantsPoints=(n.stageLocal?.storeWish?.deficit||0)>0||account(g,n).balance<45||(n.core?.values?.sectDuty||50)>=58;
 for(const item of l.equipmentItems||[]){
  if(!owned(n,item)||Object.values(n.jianghu.equipmentV140||{}).includes(item.id)||Number(item.durability??100)<=0)continue;
  const current=l.equipmentItems.find(x=>x.id===n.jianghu.equipmentV140?.[item.slot]);
  const wrongPath=item.compatiblePath&&!['ANY',n.jianghu.path].includes(item.compatiblePath);
  if(wrongPath||(current&&g.progression.canEquipItem(n,current).ok&&g.progression.effectScore(n,current)>=g.progression.effectScore(n,item)))
   out.push({kind:'EQUIPMENT',id:item.id,quantity:1,item});
 }
 for(const item of l.scrolls||[]){
  const art=g.progression.artMap.get(item.artId),k=n.jianghu.knowledgeV190?.[item.artId];
  if(owned(n,item)&&art&&(k?.stage>=4||!g.progression.compatible(n,art))&&g.discovery.mayShare(n,item))
   out.push({kind:'SCROLL',id:item.id,quantity:1,item});
 }
 for(const item of l.pillStacks||[]){
  if(!owned(n,item)||item.contributionCreditAllowed===false)continue;
  const keepCount=wantsPoints&&n.health>=78?1:3;
  if(item.count>keepCount&&n.health>=78){
   out.push({kind:'PILL',id:item.id,quantity:item.count-keepCount,item});
  }
 }
 for(const matId of new Set((l.materialStacks||[]).filter(x=>owned(n,x)&&x.count>0&&x.contributionCreditAllowed!==false).map(x=>x.matId))){
  const total=(l.materialStacks||[]).filter(x=>x.matId===matId&&owned(n,x)&&x.count>0).reduce((s,x)=>s+x.count,0);
  const keep=reserve(g,n,matId);
  if(total>keep&&g.canAcceptMaterial?.(g.bank,matId,{quality:'STANDARD'})){
   const sample=l.materialStacks.find(x=>x.matId===matId&&owned(n,x)&&x.count>0);
   out.push({kind:'MATERIAL',id:matId,quantity:total-keep,item:sample});
  }
 }
 return out;
}

function actionLabel(id){
 if(!id)return null;
 if(id.startsWith('sectDonate:'))return 'นำพัสดุมอบเข้าคลังสำนักแลกแต้มคุณูปการ';
 if(id.startsWith('sectCraft:'))return 'หลอมโอสถและศาสตราให้สำนักแลกแต้มคุณูปการ';
 if(id.startsWith('sectShopBuy:'))return 'ใช้แต้มคุณูปการซื้อสินค้าจากร้านค้าสำนัก';
 if(id.startsWith('sectGather:'))return 'ออกเก็บสมุนไพรและแร่ส่งสำนักแลกแต้มคุณูปการ';
 return null;
}

function workActivity(id){
 if(!id)return null;
 if(id.startsWith('sectDonate:')||id.startsWith('sectShopBuy:'))return 'deposit';
 if(id.startsWith('sectCraft:'))return /ironblade|armor|guard|flame|jade|scholar|FRG/.test(id)?'forging':'alchemy';
 if(id.startsWith('sectGather:'))return /mine|cinnabar|copper|jade|iron/.test(id)?'mine':'herb';
 return null;
}

function recipeDemand(g,r){
 const b=g.bank.jianghu.ledgerV140,kind=r.effect?.slot?'EQUIPMENT':'PILL';
 const stock=kind==='PILL'?(b.pillStacks||[]).filter(x=>bankOwned(g,x)&&x.recipeId===r.id).reduce((s,x)=>s+x.count,0):(b.equipmentItems||[]).filter(x=>bankOwned(g,x)&&x.recipeId===r.id).length;
 const need=(g.heroes||[]).filter(n=>n.alive&&(kind==='PILL'?(n.jianghu.ledgerV140.pillStacks||[]).filter(x=>x.recipeId===r.id&&x.count>0).reduce((s,x)=>s+x.count,0)<2:!(n.jianghu.ledgerV140.equipmentItems||[]).some(x=>x.slot===r.effect.slot&&g.progression.canEquipItem(n,x).ok))).length;
 return Math.max(0,(kind==='PILL'?Math.max(3,need*2):Math.max(1,need))-stock);
}
function economicWorkload(g,excludeNpcId=null){
 const heroes=(g.heroes||[]).filter(n=>n.alive),extra=root.JianghuInfrastructure?.bonuses(g).extraEconomicWorkers||0;
 const busy=heroes.filter(n=>n.id!==excludeNpcId&&!n.stageLocal?.offmap&&['working','moving','travel'].includes(n.stageLocal?.mode));
 return {gathering:busy.filter(n=>n.stageLocal.action?.startsWith('sectGather:')).length,crafting:busy.filter(n=>n.stageLocal.action?.startsWith('sectCraft:')).length,
  gatheringLimit:Math.max(1,Math.ceil(heroes.length/3))+extra,craftingLimit:Math.max(1,Math.ceil(heroes.length/4))+extra};
}
function options(g,n,add){
 if(!g.s.storyEvents?.active||!shoppingAvailable(g,n))return;
 const hall=g.built('hall');if(!hall)return;
 if(!available(g,n)){const bal=account(g,n).balance,wish=evaluateStoreDesires(g,n).desires.find(d=>d.kind==='PILL'&&d.urgency>=80&&d.price<=bal);if(wish)add('sectShopBuy:PILL:'+wish.id,wish.urgency,g.endpoint(g.built('market')||hall),5,{caution:.2},{growthActivity:'deposit',reason:wish.reasonTh+' · ซื้อยารักษาก่อนกลับไปทำงาน'});return;}
 // Accepted contracts take priority over starting additional economic errands.
 if(g.s.storyEvents?.sidequests?.active)return;
 if(g.built('alchemy')||g.built('forge'))ensureBasicSectRecipes(g,n);
 const market=g.built('market')||hall;
 const {desires,topWish}=evaluateStoreDesires(g,n);
 const fly=computeMarketFlywheel(g);
 const bal=account(g,n).balance;
 const heatBoost=Math.round((fly.marketHeat||20)*0.08);
 const wishMotivation=(topWish?Math.min(26,10+Math.round(topWish.urgency*0.22)):(bal<45?10:3))+heatBoost;
 const wishTag=topWish&&topWish.price>bal?` · สะสมแต้มซื้อ «${topWish.nameTh}» (${bal}/${topWish.price} แต้ม)`:'';

 // 1. Donate surplus personal items (equipment, scrolls, personal pills, or excess materials) to Sect Treasury for points
 const s=surplus(g,n).sort((a,b)=>supplyQuote(g,b.kind,b.item,b.quantity).donation-supplyQuote(g,a.kind,a.item,a.quantity).donation)[0];
 if(s){
  const pts=supplyQuote(g,s.kind,s.item,s.quantity).donation;
  const bonusPct=supplyQuote(g,s.kind,s.item,s.quantity).demandBonus;
  const estTotal=pts;
  if(pts>0){
   add('sectDonate:'+s.kind+':'+s.id,44+wishMotivation*0.5+(n.core.values.sectDuty-50)*.2+(n.personality.empathy-50)*.1,g.endpoint(hall),6,{integrity:.25,empathy:.2},{
    growthActivity:'deposit',
    reason:`นำ «${s.item.nameTh||s.item.matId}» ×${s.quantity} มอบเข้าคลังสำนัก · ได้ +${estTotal} แต้มคุณูปการ${bonusPct?` (รวมโบนัสตลาด ${bonusPct} แต้ม)`:''}${wishTag}`
   });
  }
 }

 // 2. Buy desired item from the Sect Store (ร้านค้าสำนัก) using Contribution Points
 const affordableWish=desires.find(d=>d.kind!=='LESSON'&&bal>=d.price&&(n.stageLocal.cooldowns?.['sectShopBuy:'+d.kind+':'+d.id]||0)<=time(g));
 if(affordableWish){
  add('sectShopBuy:'+affordableWish.kind+':'+affordableWish.id,Math.max(55,affordableWish.urgency+heatBoost*0.5),g.endpoint(market),5,{ambition:.25,rationality:.2,caution:.15},{
   growthActivity:'deposit',
   reason:`${affordableWish.reasonTh} · ใช้ ${affordableWish.price} แต้มคุณูปการ (มี ${bal} แต้ม)`
  });
 }

 const lesson=desires.find(d=>d.kind==='LESSON'&&bal>=d.price);
 const shrine=g.built('shrine');
 if(lesson&&shrine)add('readLibraryScripture',lesson.urgency,g.endpoint(shrine),16,{curiosity:.2,discipline:.15},{growthTarget:lesson.id,growthActivity:'readLibraryScripture',reason:lesson.reasonTh});

 // 3. Mode A: Craft Pills or Equipment for the Sect (หลอมโอสถ/ศาสตราให้สำนัก) using Sect Treasury materials
 const workload=economicWorkload(g,n.id),activeCrafters=workload.crafting;
 const known=n.stageLocal?.growth?.knownRecipes||[];
 const bankPillsCount=(g.bank.jianghu.ledgerV140.pillStacks||[]).filter(p=>bankOwned(g,p)).reduce((sum,p)=>sum+(p.count||0),0);
 const sectCraftCandidates=activeCrafters>=workload.craftingLimit?[]:[...FREE_SECT_RECIPES,...FORTUITOUS_RECIPES,...known]
  .filter((id,idx,arr)=>arr.indexOf(id)===idx&&(known.includes(id)||FREE_SECT_RECIPES.includes(id)))
  .map(id=>canCraftForSect(g,n,id))
  .filter(c=>c.ok&&recipeDemand(g,c.recipe)>0);

 if(sectCraftCandidates.length){
  sectCraftCandidates.sort((a,b)=>{
   const aPill=!a.recipe.effect?.slot?1:0,bPill=!b.recipe.effect?.slot?1:0;
   if(bankPillsCount<6&&aPill!==bPill)return bPill-aPill;
   return recipeDemand(g,b.recipe)-recipeDemand(g,a.recipe)||b.recipe.tier-a.recipe.tier;
  });
  const bestCraft=sectCraftCandidates[0];
  const r=bestCraft.recipe;
  const kind=r.effect?.slot?'EQUIPMENT':'PILL';
  const bonusPct=fly.bonusByCategory?.[kind]||0;
  const basePts=Math.max(5*r.tier,Math.round(quote(g,kind,{recipeId:r.id,tier:r.tier,quality:'COMMON'},1).donation*0.65));
  const estPts=basePts+Math.round(basePts*(bonusPct/100));
  const pillScarcity=bankPillsCount<6&&!r.effect?.slot?16:4;
  const score=42+pillScarcity+wishMotivation*0.65+(n.core.values.sectDuty-50)*0.22+(H.liking(n,bestCraft.activity)-50)*0.18;
  add('sectCraft:'+r.id,score,g.endpoint(bestCraft.workshopBuilding),Math.max(8,Math.round(r.duration*0.75/(root.JianghuInfrastructure?.bonuses(g).perWorkshop?.[r.workshop]?.craftSpeed||1))),{discipline:.3,integrity:.25,creativity:.2},{
   growthActivity:bestCraft.activity,
   reason:`ใช้สมุนไพร/แร่ของคลังสำนักหลอม «${r.name}» ให้สำนัก (ไม่เสียของส่วนตัว) · ได้ค่าแรง ~${estPts} แต้มคุณูปการ${wishTag}`
  });
 }

 // 4. Gather Valley Herbs/Ores for the Sect Treasury when Treasury needs alchemy herbs or disciple wants points
 if(H.load(n)<H.carryLimit(n)){
  const activeGatherers=workload.gathering;
 const herbNeedNodes=activeGatherers>=workload.gatheringLimit?[]:(g.s.nodes||[]).filter(nd=>nd.qty>=2&&nd.tier<=Math.max(2,Math.ceil(g.progression.tier(n)))&&!g.realm?.threatAt?.({x:nd.x,y:nd.y},380,n));
  if(herbNeedNodes.length){
   herbNeedNodes.sort((a,b)=>{
    const ca=g.count(g.bank,a.mat),cb=g.count(g.bank,b.mat);
    const aBasic=[root.FrontierData.HERB,'MAT_HERB_CINDER_LEAF_1',root.FrontierData.CIN,root.FrontierData.ORE].includes(a.mat)?1:0;
    const bBasic=[root.FrontierData.HERB,'MAT_HERB_CINDER_LEAF_1',root.FrontierData.CIN,root.FrontierData.ORE].includes(b.mat)?1:0;
    // If disciple needs high-price store items, also consider higher-tier nodes for bigger point payouts!
    if((topWish?.deficit||0)>=40&&a.tier!==b.tier)return b.tier-a.tier;
    if(aBasic!==bBasic)return bBasic-aBasic;
    return ca-cb||a.tier-b.tier;
   });
   const node=herbNeedNodes[0];
   const bankStock=g.count(g.bank,node.mat);
   if(bankStock<10||(topWish&&topWish.price>bal)){
    const estUnit=quote(g,'MATERIAL',{matId:node.mat,tier:node.tier,quality:'STANDARD'},2).donation;
    const gatherScore=38+(bankStock<6?14:4)+wishMotivation*0.6+(n.core.values.sectDuty-50)*0.18;
    add('sectGather:'+node.id,gatherScore,{id:node.id,x:node.x,y:node.y},10+node.tier*2,{discipline:.25,caution:.2},{
     growthActivity:node.kind==='HERB'?'herb':'mine',
     resourceNodeId:node.id,
     reason:`ออกเก็บ «${node.nameTh}» ในหุบเขานำมาส่งสำนักเพื่อแลกแต้มคุณูปการ (~+${estUnit} แต้ม)${wishTag}`
    });
   }
  }
 }
}

function finish(g,n,id){
 if(!id)return null;
 const fail={handled:true,success:false,cooldown:20},p=n.stageLocal;

 if(id.startsWith('sectDonate:')){
  const b=g.built('hall'),at=b&&g.endpoint(b);
  if(!available(g,n)||!at||p.mode!=='working'||p.action!==id||p.job>0||Math.hypot(p.x-at.x,p.y-at.y)>140)return fail;
  const [,kind,...parts]=id.split(':'),itemId=parts.join(':'),s=surplus(g,n).find(x=>x.kind===kind&&x.id===itemId);if(!s)return fail;
  const r=donate(g,n,kind,itemId,s.quantity);
  return {handled:true,success:r.ok,cooldown:30};
 }

 if(id.startsWith('sectCraft:')){
  const recipeId=id.slice('sectCraft:'.length);
  const r=g.progression?.recipe?.(recipeId),b=r&&g.built(r.workshop),at=b&&g.endpoint(b);
  if(!available(g,n)||!at||p.mode!=='working'||p.action!==id||p.job>0||Math.hypot(p.x-at.x,p.y-at.y)>145)return fail;
  const res=craftForSect(g,n,recipeId,{requireAtWorkshop:true});
  return {handled:true,success:!!res.ok,cooldown:40};
 }

 if(id.startsWith('sectShopBuy:')){
  const [,kind,...parts]=id.split(':'),itemId=parts.join(':');
  const b=g.built('market')||g.built('hall'),at=b&&g.endpoint(b);
  if(!shoppingAvailable(g,n)||!at||p.mode!=='working'||p.action!==id||p.job>0||Math.hypot(p.x-at.x,p.y-at.y)>145)return fail;
  const res=buyFromStore(g,n,kind,itemId,1);
  if(!res.ok&&p.cooldowns)p.cooldowns[id]=time(g)+45;
  return {handled:true,success:!!res.ok,cooldown:35};
 }

 if(id.startsWith('sectGather:')){
  const nodeId=id.slice('sectGather:'.length);
  const node=(g.s.nodes||[]).find(x=>x.id===nodeId);
  if(!available(g,n)||!node||p.mode!=='working'||p.action!==id||p.job>0||Math.hypot(p.x-node.x,p.y-node.y)>150)return fail;
  const hRes=g.harvestNode(nodeId,n.id);
  if(!hRes.ok)return fail;

  tryFortuitousRecipeDiscovery(g,n,node.nameTh);
  return {handled:true,success:true,cooldown:18};
 }

 return null;
}

/* Outside visitors carry finite cargo in the same NPC ledger. Contribution points
   never leave the sect; accepted proposals transfer spirit stones to the seller.
   Two-way outsider trade (v2.08): specialized merchant guilds also post finite
   Purchase Orders (ใบสั่งซื้อรับซื้อของส่วนเกิน) with tiered quota bonuses. */
const CARAVAN_GUILDS=[
 {
  id:'HERB_GUILD',
  labelTh:'ขบวนค้าสมุนไพรหุบเขาหมอก',
  specialtyTh:'สมุนไพรและวัตถุดิบปรุงยา · รับซื้อโอสถพื้นฐานและสมุนไพรส่วนเกิน',
  orders:[
   {kind:'PILL',ids:['L14_remedy','L14_qi'],wantQuantity:6,bonusQuota:2,bonusPct:25},
   {kind:'MATERIAL',ids:['MAT_HERB_CINDER_LEAF_1','MAT_HERB_DEW_GRASS_1','MAT_ORE_BLACK_IRON_1'],wantQuantity:8,bonusQuota:3,bonusPct:25}
  ]
 },
 {
  id:'FORGE_GUILD',
  labelTh:'กองคาราวานช่างหลอมพเนจร',
  specialtyTh:'แร่ปราณและศาสตรา · รับซื้อแร่เหล็กดำ ชาดปราณ และโอสถสำรองเดินทาง',
  orders:[
   {kind:'MATERIAL',ids:['MAT_ORE_BLACK_IRON_1','MAT_ORE_CINNABAR_1','MAT_HERB_DEW_GRASS_1'],wantQuantity:8,bonusQuota:3,bonusPct:25},
   {kind:'PILL',ids:['L14_remedy','L14_clarity'],wantQuantity:5,bonusQuota:2,bonusPct:25}
  ]
 },
 {
  id:'ELIXIR_GUILD',
  labelTh:'หอการค้าโอสถเมฆาคราม',
  specialtyTh:'โอสถและตัวยา · รับซื้อสมุนไพรคัดเกรดและโอสถฟื้นฟูลมปราณ',
  orders:[
   {kind:'MATERIAL',ids:['MAT_HERB_DEW_GRASS_1','MAT_HERB_CINDER_LEAF_1','MAT_ORE_CINNABAR_1'],wantQuantity:7,bonusQuota:3,bonusPct:25},
   {kind:'PILL',ids:['L14_qi','L14_remedy','L14_pure'],wantQuantity:6,bonusQuota:2,bonusPct:25}
  ]
 },
 {
  id:'SCRIPTURE_GUILD',
  labelTh:'ขบวนนักปราชญ์และตำราโบราณ',
  specialtyTh:'คัมภีร์และวิชา · รับซื้อโอสถบำรุงจิตและแร่ชาดสำหรับจารึกตำรา',
  orders:[
   {kind:'MATERIAL',ids:['MAT_ORE_CINNABAR_1','MAT_ORE_BLACK_IRON_1','MAT_HERB_DEW_GRASS_1'],wantQuantity:7,bonusQuota:3,bonusPct:25},
   {kind:'PILL',ids:['L14_clarity','L14_remedy'],wantQuantity:5,bonusQuota:2,bonusPct:25}
  ]
 },
 {
  id:'CURIO_GUILD',
  labelTh:'สมาคมวานิชแดนไกล',
  specialtyTh:'ของหายากจากต่างแดน · รับซื้อวัตถุดิบและโอสถส่วนเกินหลากหลายชนิด',
  orders:[
   {kind:'MATERIAL',ids:['MAT_ORE_BLACK_IRON_1','MAT_HERB_CINDER_LEAF_1','MAT_ORE_CINNABAR_1','MAT_HERB_DEW_GRASS_1'],wantQuantity:8,bonusQuota:3,bonusPct:25},
   {kind:'PILL',ids:['L14_remedy','L14_qi','L14_clarity'],wantQuantity:6,bonusQuota:2,bonusPct:25}
  ]
 }
];

function regionalMaterialIds(){return [...new Set([root.FrontierData?.HERB,root.FrontierData?.ORE,root.FrontierData?.CIN,'MAT_HERB_CINDER_LEAF_1','MAT_HERB_DEW_GRASS_1'].filter(Boolean))];}
function ensureRegionalMarket(g,s){
 const now=time(g),ids=regionalMaterialIds();
 if(!s.regionalStock||typeof s.regionalStock!=='object')s.regionalStock={MATERIAL:{},PILL:{L14_remedy:5,L14_qi:4,L14_clarity:4},EQUIPMENT:{L14_ironblade:2},SCROLL:8};
 if(!s.regionalStock.MATERIAL||typeof s.regionalStock.MATERIAL!=='object')s.regionalStock.MATERIAL={};
 if(!s.regionalStock.PILL||typeof s.regionalStock.PILL!=='object')s.regionalStock.PILL={L14_remedy:5,L14_qi:4,L14_clarity:4};
 if(!s.regionalStock.EQUIPMENT||typeof s.regionalStock.EQUIPMENT!=='object')s.regionalStock.EQUIPMENT={L14_ironblade:2};
 ids.forEach((id,i)=>{if(!Number.isFinite(s.regionalStock.MATERIAL[id]))s.regionalStock.MATERIAL[id]=i<3?12:8;});
 for(const [id,q] of Object.entries({L14_remedy:5,L14_qi:4,L14_clarity:4}))if(!Number.isFinite(s.regionalStock.PILL[id]))s.regionalStock.PILL[id]=q;
 if(!Number.isFinite(s.regionalStock.EQUIPMENT.L14_ironblade))s.regionalStock.EQUIPMENT.L14_ironblade=2;
 if(!Number.isFinite(s.regionalStock.SCROLL))s.regionalStock.SCROLL=8;
 if(!Number.isFinite(s.regionalLiquidity))s.regionalLiquidity=1600;
 if(!Number.isFinite(s.regionalLiquidityCap))s.regionalLiquidityCap=3000;
 if(!Number.isFinite(s.regionalDay))s.regionalDay=Math.floor(now/20);
 if(!Array.isArray(s.exports))s.exports=[];
 if(!Array.isArray(s.regionalLedger))s.regionalLedger=[];
 if(!s.visitState||typeof s.visitState!=='object')s.visitState=null;
 if(!s.visitorPhase)s.visitorPhase='OFFMAP';
 if(!Number.isFinite(s.lastMovementAt))s.lastMovementAt=now;
 if(!Number.isFinite(s.totalExports))s.totalExports=0;
 if(!Number.isFinite(s.totalExportStones))s.totalExportStones=0;
}
function externalState(g){
 const s=state(g);
 if(!s.externalTrade)s.externalTrade={version:4,autoProcure:true,autoSell:true,autoMemberTrade:true,nextVisitAt:time(g),nextDecisionAt:time(g)+20,nextMemberDecisionAt:time(g)+20,visit:0,merchantIds:[],offers:[],orders:[],sales:[],history:[],guildRelations:{}};
 if(!Array.isArray(s.externalTrade.orders))s.externalTrade.orders=[];
 if(!Array.isArray(s.externalTrade.sales))s.externalTrade.sales=[];
 if(!Array.isArray(s.externalTrade.history))s.externalTrade.history=[];
 if(!Array.isArray(s.externalTrade.merchantIds))s.externalTrade.merchantIds=[];
 if(!s.externalTrade.guildRelations||typeof s.externalTrade.guildRelations!=='object')s.externalTrade.guildRelations={};
 if(s.externalTrade.autoSell===undefined)s.externalTrade.autoSell=true;
 if(s.externalTrade.autoMemberTrade===undefined)s.externalTrade.autoMemberTrade=true;
 if(!Number.isFinite(s.externalTrade.nextMemberDecisionAt))s.externalTrade.nextMemberDecisionAt=time(g)+20;
 ensureRegionalMarket(g,s.externalTrade);
 s.externalTrade.version=4;
 return s.externalTrade;
}
function isOrdinarySurplusLot(item){
 if(!item||item.isTranscendent||item.unique||item.sectRelic)return false;
 const q=item.quality||'STANDARD',r=item.rarity||item.rarityGrade||q;
 if(!['COMMON','STANDARD','NORMAL','MORTAL','GOOD'].includes(q))return false;
 if(['RARE','MYSTIC','SUPERIOR','EXCELLENT','MASTERWORK','EPIC','EARTH','PERFECT','HEAVEN','LEGENDARY','IMMORTAL','MYTHIC','TRANSCENDENT'].includes(r))return false;
 return true;
}
function orderLots(g,o){
 if(!o||!['MATERIAL','PILL'].includes(o.kind))return [];
 const bl=g?.bank?.jianghu?.ledgerV140;if(!bl)return [];
 if(o.kind==='MATERIAL'){
  return (bl.materialStacks||[]).filter(x=>bankOwned(g,x)&&x.matId===o.targetId&&(x.count||0)>0&&isOrdinarySurplusLot(x)).sort((a,b)=>treasuryCountOf('MATERIAL',b)-treasuryCountOf('MATERIAL',a));
 }
 if(o.kind==='PILL'){
  return (bl.pillStacks||[]).filter(x=>bankOwned(g,x)&&(x.recipeId||x.catalogId||x.id)===o.targetId&&(x.count||0)>0&&isOrdinarySurplusLot(x)).sort((a,b)=>treasuryCountOf('PILL',b)-treasuryCountOf('PILL',a));
 }
 return [];
}
function orderReserve(g,o){
 const alive=(g?.heroes||[]).filter(n=>n?.alive);
 const base=o.kind==='MATERIAL'?(o.tier===1?6:2):Math.max(4,alive.length);
 let craft=0;
 if(o.kind==='MATERIAL'){
  const known=new Set([...FREE_SECT_RECIPES,...alive.flatMap(n=>n.stageLocal?.growth?.knownRecipes||[])]);
  for(const r of g?.progression?.allRecipes?.()||[]){
   if(known.has(r.id)&&g.built(r.workshop)){
    const inp=(r.inputs||[]).find(i=>i.matId===o.targetId);
    if(inp)craft=Math.max(craft,inp.count*2);
   }
  }
 }
 const a=g?.s?.storyEvents?.sidequests?.active,d=root.JianghuSideQuests?.catalog?.find(x=>x.id===a?.questId);
 const quest=(o.kind==='MATERIAL'&&d?.kind==='DELIVERY'&&d.matId===o.targetId)?(Number(d.quantity)||0):0;
 const upgrade=(o.kind==='MATERIAL'&&o.targetId===root.FrontierData?.ORE)?8:0;
 const wishers=alive.filter(n=>{
  const w=n.stageLocal?.storeWish;if(!w||w.kind!==o.kind)return false;
  if(o.kind==='MATERIAL')return w.id===o.targetId||(g.bank?.jianghu?.ledgerV140?.materialStacks||[]).some(m=>m.id===w.id&&m.matId===o.targetId);
  return w.id===o.targetId||(g.bank?.jianghu?.ledgerV140?.pillStacks||[]).some(p=>p.id===w.id&&(p.recipeId||p.catalogId)===o.targetId);
 }).length;
 const wish=wishers*2;
 const reserve=Math.max(base+wish,craft+quest+wish,upgrade+wish);
 const reasons=[`สำรองคลังขั้นต่ำ ${base}`];
 if(craft>0)reasons.push(`สำรองวัตถุดิบโรงหลอม ${craft}`);
 if(upgrade>0)reasons.push(`สำรองแร่ก่อสร้าง/อัปเกรด ${upgrade}`);
 if(quest>0)reasons.push(`สำรองภารกิจส่งมอบ ${quest}`);
 if(wish>0)reasons.push(`ศิษย์ต้องการซื้อ ${wish}`);
 return {reserve,base,craft,quest,upgrade,wish,reasons};
}
function marketClamp(v,lo=0,hi=1){return Math.max(lo,Math.min(hi,Number(v)||0));}
function guildRelation(g,guildId){
 const s=g?.s?.storyEvents?.treasury?.contributions?.externalTrade;
 return marketClamp(Number(s?.guildRelations?.[guildId])||0,-50,50);
}
function shiftGuildRelation(g,guildId,delta=1){
 if(!guildId)return 0;const s=externalState(g);
 s.guildRelations[guildId]=marketClamp((Number(s.guildRelations[guildId])||0)+delta,-50,50);
 return s.guildRelations[guildId];
}
function marketStock(g,kind,targetId){
 const owners=[g.bank,...(g.heroes||[]).filter(n=>n?.alive)];
 if(kind==='MATERIAL')return owners.reduce((sum,n)=>sum+(n.jianghu?.ledgerV140?.materialStacks||[]).filter(x=>x.matId===targetId&&g.ownsMaterial(n,x)).reduce((a,x)=>a+Math.max(0,Number(x.count)||0),0),0);
 if(kind==='PILL')return owners.reduce((sum,n)=>sum+(n.jianghu?.ledgerV140?.pillStacks||[]).filter(x=>(x.recipeId||x.catalogId)===targetId&&g.ownsMaterial(n,x)).reduce((a,x)=>a+Math.max(0,Number(x.count)||0),0),0);
 return 0;
}
function marketPressure(g,kind,targetId){
 const alive=(g.heroes||[]).filter(n=>n?.alive).length;
 const stock=marketStock(g,kind,targetId);
 let target=kind==='MATERIAL'?Math.max(8,alive*2):Math.max(4,alive*1.5);
 if(kind==='MATERIAL'){
  let recipeNeed=0;const knownIds=new Set(FREE_SECT_RECIPES);
  for(const n of (g.heroes||[]).filter(x=>x?.alive))for(const id of n.stageLocal?.growth?.knownRecipes||[])knownIds.add(id);
  for(const id of knownIds){const r=g.progression?.recipe?.(id);if(!r)continue;const need=(r.inputs||[]).filter(i=>i.matId===targetId).reduce((a,i)=>a+i.count,0);if(need)recipeNeed=Math.max(recipeNeed,need*Math.max(1,Math.ceil(alive/3)));}
  target=Math.max(target,recipeNeed);
 }
 const shortage=marketClamp((target-stock)/Math.max(1,target));
 const abundance=marketClamp((stock-target*1.8)/Math.max(1,target*2.2));
 const routeBase=Number(g.s?.route?.risk);
 const routeRisk=g.life?.routeRisk?g.life.routeRisk(Number.isFinite(routeBase)?routeBase:.12):marketClamp(Number.isFinite(routeBase)?routeBase:.12,0,.65);
 return {kind,targetId,stock,target,shortage,abundance,routeRisk,index:Math.round(100+shortage*25-abundance*12+routeRisk*10)};
}
function externalAskPrice(g,kind,item,base,guildId=null){
 const targetId=kind==='MATERIAL'?item?.matId:(kind==='PILL'?(item?.recipeId||item?.catalogId):null);
 if(!targetId||!['MATERIAL','PILL'].includes(kind))return Math.max(1,Math.ceil(Number(base)||1));
 const p=marketPressure(g,kind,targetId),relation=guildRelation(g,guildId);
 const multiplier=1+p.shortage*.18-p.abundance*.10+p.routeRisk*.10-relation*.0012;
 return Math.max(2,Math.ceil((Number(base)||1)*multiplier));
}
function computeMarketPulse(g){
 const ids=[root.FrontierData?.HERB,root.FrontierData?.ORE,root.FrontierData?.CIN,'MAT_HERB_CINDER_LEAF_1','MAT_HERB_DEW_GRASS_1'].filter(Boolean);
 const unique=[...new Set(ids)].map(id=>{const d=matDef(id),p=marketPressure(g,'MATERIAL',id);return {...p,nameTh:d?.nameTh||id,status:p.shortage>=.45?'ขาดแคลน':p.abundance>=.25?'ล้นตลาด':'สมดุล',priceMultiplier:+(1+p.shortage*.18-p.abundance*.10+p.routeRisk*.10).toFixed(2)};});
 const mean=unique.length?Math.round(unique.reduce((a,x)=>a+x.index,0)/unique.length):100;
 return {overallIndex:mean,signals:unique.sort((a,b)=>b.index-a.index),guildRelations:{...((g.s.storyEvents?.treasury?.contributions?.externalTrade||{}).guildRelations||{})},rule:'ราคาเปลี่ยนตามสต็อกจริง ความต้องการสูตรผลิต ความเสี่ยงเส้นทาง และความสัมพันธ์กับกิลด์'};
}

function createPurchaseOrder(g,s,seller,guild,kind,targetId,tpl,now){
 if(!['MATERIAL','PILL'].includes(kind)||!targetId)return null;
 let nameTh=targetId,tier=1,minOfferBuy=6,rawUnit=3;
 if(kind==='MATERIAL'){
  const d=matDef(targetId);if(!d)return null;
  nameTh=d.nameTh||targetId;tier=Number(d.tier)||1;
  minOfferBuy=Math.max(3,Math.ceil((d.baseValueStones||8)*.65));
  rawUnit=Math.max(3,Math.floor((d.baseValueStones||8)*.5));
 }else{
  const r=g.progression?.recipe?.(targetId);if(!r)return null;
  nameTh=r.name||targetId;tier=Number(r.tier)||1;
  const q=quote(g,'PILL',{recipeId:r.id,tier:r.tier,quality:'COMMON'},1);
  minOfferBuy=Math.max(12,Math.ceil(q.unitDonation*.8));
  rawUnit=Math.max(6,Math.floor(q.unitDonation*.55));
 }
 const pressure=marketPressure(g,kind,targetId);
 rawUnit=Math.max(2,Math.round(rawUnit*(1+pressure.shortage*.18-pressure.abundance*.08)));
 const bonusPct=Math.max(10,Number(tpl.bonusPct)||25);
 const maxSafeUnit=Math.max(2,Math.floor((minOfferBuy-1)/(1+bonusPct/100)));
 const unitStones=Math.max(2,Math.min(rawUnit,maxSafeUnit));
 const bonusPerUnit=Math.max(1,Math.floor(unitStones*bonusPct/100));
 const effectiveBonusPct=Math.round((bonusPerUnit/unitStones)*100);
 const wantQuantity=Math.max(2,Number(tpl.wantQuantity)||6);
 const bonusQuota=Math.max(1,Math.min(wantQuantity-1,Number(tpl.bonusQuota)||2));
 const maxOrderStones=unitStones*wantQuantity+bonusPerUnit*bonusQuota;
 const purseStones=maxOrderStones+12;
 const alreadyReserved=(s.orders||[]).filter(x=>x.status==='OPEN').reduce((sum,x)=>sum+Math.max(0,(x.purseStones||0)-(x.stonesPaid||0)),0);
 const freeWallet=Math.max(0,E.getSpiritStonesV140(seller)-alreadyReserved);
 const fundingNeeded=Math.max(0,purseStones-freeWallet);
 if(fundingNeeded>s.regionalLiquidity)return null;
 if(fundingNeeded>0){s.regionalLiquidity-=fundingNeeded;const funded=E.addSpiritStonesV140(seller,fundingNeeded);if(!funded?.ok){s.regionalLiquidity+=fundingNeeded;return null;}}
 const order={
  id:`outside_order_${s.visit}_${s.orders.length+1}`,
  visit:s.visit,
  buyerNpcId:seller.id,
  buyerNameTh:seller.name,
  guildId:guild.id,
  guildNameTh:guild.labelTh,
  kind,
  targetId,
  nameTh,
  tier,
  wantQuantity,
  filled:0,
  unitStones,
  minOfferBuyStones:minOfferBuy,
  bonusQuota,
  bonusPct:effectiveBonusPct,
  bonusPerUnit,
  bonusUsed:0,
  purseStones,
  stonesPaid:0,
  createdAt:now,
  expiresAt:now+100,
  status:'OPEN'
 };
 s.orders.push(order);
 return order;
}
function quotePurchaseOrder(g,id,requested=null){
 const s=g?.s?.storyEvents?.treasury?.contributions?.externalTrade;
 const o=(s?.orders||[]).find(x=>x.id===id);
 if(!o)return {ok:false,reason:'ไม่พบใบสั่งซื้อจากพ่อค้าคนนอก'};
 if(!['MATERIAL','PILL'].includes(o.kind))return {ok:false,reason:'สำนักห้ามขายศาสตราและคัมภีร์วิชาให้พ่อค้าคนนอก'};
 if(o.status!=='OPEN'||time(g)>=o.expiresAt)return {ok:false,reason:'ใบสั่งซื้อนี้สิ้นสุดหรือรับของครบจำนวนแล้ว'};
 const lots=orderLots(g,o);
 const totalStock=lots.reduce((sum,x)=>sum+(x.count||0),0);
 const res=orderReserve(g,o);
 const surplusQty=Math.max(0,totalStock-res.reserve);
 const remainingDemand=Math.max(0,o.wantQuantity-(o.filled||0));
 // An order's budget is a spending limit, not a second wallet. The buyer must
 // still have the actual stones, which can change after other transactions.
 const buyer=g.world?.npcs?.[o.buyerNpcId];
 const purseLeft=Math.max(0,Math.min((o.purseStones||0)-(o.stonesPaid||0),E.getSpiritStonesV140(buyer)));
 const bonusPerUnit=o.bonusPerUnit!==undefined?o.bonusPerUnit:Math.floor(o.unitStones*(o.bonusPct||0)/100);
 const bonusLeft=Math.max(0,(o.bonusQuota||0)-(o.filled||0));
 let maxAffordable=0,runningCost=0;
 for(let i=1;i<=Math.min(surplusQty,remainingDemand);i++){
  const uCost=o.unitStones+(i<=bonusLeft?bonusPerUnit:0);
  if(runningCost+uCost>purseLeft)break;
  runningCost+=uCost;
  maxAffordable=i;
 }
 const maxSellable=Math.min(surplusQty,remainingDemand,maxAffordable);
 const qty=requested===null||requested===undefined?maxSellable:Number(requested);
 if(!Number.isInteger(qty)||qty<=0){
  return {
   ok:false,
   orderId:o.id,
   totalStock,
   reserve:res.reserve,
   reserveReasons:res.reasons,
   surplusQty,
   remainingDemand,
   bonusLeft,
   maxSellable,
   quantity:0,
   stones:0,
   baseStones:0,
   bonusStones:0,
   bonusUnits:0,
   reason:surplusQty<=0?`สต็อกในคลัง (${totalStock}) ยังไม่เกินเกณฑ์สำรองของสำนัก (${res.reserve})`:remainingDemand<=0?'พ่อค้ารับซื้อครบจำนวนแล้ว':maxSellable<=0?'หินวิญญาณจริงหรือวงเงินใบสั่งซื้อของพ่อค้าไม่เพียงพอ':'จำนวนที่ต้องการขายไม่ถูกต้อง'
  };
 }
 if(qty>remainingDemand)return {ok:false,totalStock,reserve:res.reserve,reserveReasons:res.reasons,surplusQty,remainingDemand,bonusLeft,maxSellable,reason:`พ่อค้าต้องการรับซื้ออีกเพียง ${remainingDemand} หน่วย`};
 if(qty>surplusQty)return {ok:false,totalStock,reserve:res.reserve,reserveReasons:res.reasons,surplusQty,remainingDemand,bonusLeft,maxSellable,reason:`ขายได้เฉพาะส่วนเกินสำรองคลัง (มี ${totalStock} · ต้องสำรอง ${res.reserve} · ขายได้สูงสุด ${surplusQty})`};
 const bonusUnits=Math.min(qty,bonusLeft);
 const baseStones=qty*o.unitStones;
 const bonusStones=bonusUnits*bonusPerUnit;
 const stones=baseStones+bonusStones;
 if(stones>purseLeft)return {ok:false,totalStock,reserve:res.reserve,reserveReasons:res.reasons,surplusQty,remainingDemand,bonusLeft,maxSellable,reason:'ถุงเงินหินวิญญาณของพ่อค้าคนนอกไม่พอรับซื้อจำนวนนี้'};
 return {
  ok:true,
  orderId:o.id,
  quantity:qty,
  unitStones:o.unitStones,
  bonusPerUnit,
  bonusUnits,
  regularUnits:qty-bonusUnits,
  baseStones,
  bonusStones,
  stones,
  totalStock,
  reserve:res.reserve,
  reserveReasons:res.reasons,
  surplusQty,
  remainingDemand,
  bonusLeft,
  maxSellable,
  reason:`พร้อมขายส่วนเกิน ×${qty} รับหินวิญญาณ +${stones}${bonusStones>0?` (รวมโบนัสโควตาแรก +${bonusStones} หินวิญญาณ สำหรับ ${bonusUnits} หน่วยแรก)`:''}`
 };
}
function sellToPurchaseOrder(g,id,quantity=null,authorityNpcId=null){
 const s=externalState(g),o=(s.orders||[]).find(x=>x.id===id);
 if(!o)return {ok:false,reason:'ไม่พบใบสั่งซื้อจากพ่อค้าคนนอก'};
 if(g.routeBlocked())return {ok:false,reason:'เส้นทางการค้าถูกปิดกั้น ยังส่งมอบสินค้าไม่ได้'};
 const auths=g.storyEvents.authorities();
 const authority=auths.find(x=>!authorityNpcId||x.npc.id===authorityNpcId);
 if(!authority)return {ok:false,reason:'ต้องมีเจ้าสำนักหรือผู้อาวุโสฝ่ายคลังเป็นผู้เจรจาขายของส่วนเกิน'};
 const q=quotePurchaseOrder(g,id,quantity);
 if(!q.ok)return q;
 const buyer=g.world.npcs[o.buyerNpcId];
 if(!buyer?.alive)return {ok:false,reason:'พ่อค้าผู้รับซื้อไม่อยู่ในพื้นที่แล้ว'};
 if(E.getSpiritStonesV140(buyer)<q.stones)return {ok:false,reason:'พ่อค้ามีหินวิญญาณจริงไม่พอรับซื้อ'};
 const lots=orderLots(g,o);
 let rem=q.quantity;
 const plan=[];
 for(const lot of lots){
  if(rem<=0)break;
  const take=Math.min(rem,lot.count||0);
  if(take>0){plan.push({lot,quantity:take});rem-=take;}
 }
 if(rem>0)return {ok:false,reason:'พัสดุส่วนเกินที่เข้าเกณฑ์ไม่เพียงพอ'};
 const bl=g.bank.jianghu.ledgerV140,sl=buyer.jianghu.ledgerV140;
 const sample=plan[0].lot;
 if(o.kind==='MATERIAL'&&!g.canAcceptMaterial(buyer,o.targetId,sample))return {ok:false,reason:'สัมภาระของพ่อค้าคนนอกเต็ม ไม่สามารถรับของเพิ่มได้'};
 const debit=E.addSpiritStonesV140(buyer,-q.stones);
 if(!debit?.ok)return {ok:false,reason:'พ่อค้ามีหินวิญญาณจริงไม่พอรับซื้อ'};
 if(o.kind==='MATERIAL'){
  const dep=depositMaterialLot(g,buyer,o.targetId,q.quantity,sample,{suppliedBySectId:'TH',purchasedAt:time(g),provenanceMode:'EXTERNAL_TRADE_SALE',regionalExportEligible:true,outsidePurchaseCostPerUnit:Math.ceil(q.stones/Math.max(1,q.quantity))});
  if(!dep.ok){E.addSpiritStonesV140(buyer,q.stones);return {ok:false,reason:'ส่งมอบวัตถุดิบให้พ่อค้าคนนอกไม่สำเร็จ'};}
 }else{
  const outsideCost=Math.ceil(q.stones/Math.max(1,q.quantity));const existing=(sl.pillStacks||[]).find(p=>(p.recipeId||p.catalogId)===o.targetId&&p.quality===(sample.quality||'COMMON')&&p.provenanceMode==='EXTERNAL_TRADE_SALE'&&Number(p.outsidePurchaseCostPerUnit||0)===outsideCost);
  if(existing){
   existing.count=(existing.count||0)+q.quantity;
  }else{
   sl.pillStacks.push({...clone(sample),id:`outside_bought_${s.visit}_${s.sales.length+1}`,ownerNpcId:buyer.id,ownerId:buyer.id,count:q.quantity,storeCount:0,sectStore:false,provenanceMode:'EXTERNAL_TRADE_SALE',regionalExportEligible:true,outsidePurchaseCostPerUnit:outsideCost});
  }
 }
 for(const p of plan){
  const shelf=storeCountOf(o.kind,p.lot);
  const unShelved=Math.max(0,(p.lot.count||0)-shelf);
  p.lot.count-=p.quantity;
  if(p.quantity>unShelved){
   p.lot.storeCount=Math.max(0,shelf-(p.quantity-unShelved));
  }
  p.lot.sectStore=(p.lot.storeCount||0)>0;
 }
 bl[keys[o.kind]]=(bl[keys[o.kind]]||[]).filter(x=>(x.count??1)>0);
 g.money(q.stones,'ขายของส่วนเกินให้คนนอก '+o.nameTh);
 o.filled=(o.filled||0)+q.quantity;
 o.stonesPaid=(o.stonesPaid||0)+q.stones;
 o.bonusUsed=(o.bonusUsed||0)+q.bonusUnits;
 if(o.filled>=o.wantQuantity)o.status='FILLED';
 const saleRecord={
  id:`outside_sale_${s.visit}_${s.sales.length+1}`,
  orderId:o.id,
  t:time(g),
  authorityNpcId:authority.npc.id,
  authorityNameTh:authority.npc.name,
  buyerNpcId:buyer.id,
  buyerNameTh:buyer.name,
  guildNameTh:o.guildNameTh||'',
  kind:o.kind,
  targetId:o.targetId,
  nameTh:o.nameTh,
  quantity:q.quantity,
  unitStones:q.unitStones,
  bonusUnits:q.bonusUnits,
  baseStones:q.baseStones,
  bonusStones:q.bonusStones,
  stones:q.stones,
  reserveKept:q.reserve
 };
 s.sales.unshift(saleRecord);s.sales.splice(40);shiftGuildRelation(g,o.guildId,1);
 E.syncLegacyArraysFromLedgerV140(g.bank);E.syncLegacyArraysFromLedgerV140(buyer);invalidateMarketCache(g);
 log(g,authority.npc,'EXTERNAL_SELL',sample,q.quantity,0,{stones:q.stones,baseStones:q.baseStones,bonusStones:q.bonusStones,bonusUnits:q.bonusUnits,buyerName:buyer.name,orderId:o.id});
 g.note(`💰 ${authority.npc.name} ขายส่วนเกิน «${o.nameTh}» ×${q.quantity} ให้ ${buyer.name} · รับหินวิญญาณ +${q.stones} เข้าคลังสำนัก (คงสำรองคลัง ${q.reserve} หน่วย)`,authority.npc);
 return {
  ok:true,
  ...q,
  orderStatus:o.status,
  sale:saleRecord,
  reason:`ขาย «${o.nameTh}» ×${q.quantity} ให้ ${buyer.name} สำเร็จ · รับหินวิญญาณ +${q.stones}`
 };
}
function autoSellSurplus(g,s,auth){
 if(!auth||s.autoSell===false||g.routeBlocked())return null;
 const candidates=[];
 for(const o of s.orders||[]){
  if(o.status!=='OPEN'||time(g)>=o.expiresAt)continue;
  const q=quotePurchaseOrder(g,o.id);
  if(!q.ok||q.maxSellable<=0)continue;
  const safetyBuffer=o.kind==='MATERIAL'?6:4;
  const safeSurplus=q.surplusQty-safetyBuffer;
  if(safeSurplus<=0)continue;
  const sellQty=Math.min(q.maxSellable,safeSurplus);
  const sim=quotePurchaseOrder(g,o.id,sellQty);
  if(!sim.ok)continue;
  const wealthVal=auth.core?.values?.wealthResource||50;
  const cautionVal=auth.personality?.caution||auth.core?.values?.caution||50;
  const needStones=g.gold<800?14:g.gold<1800?6:0;
  const score=sim.stones*.45+sim.bonusStones*1.1+safeSurplus*1.5+needStones+(wealthVal-50)*.18-(cautionVal-50)*.1;
  if(score>=10)candidates.push({o,sellQty,score,sim});
 }
 candidates.sort((a,b)=>b.score-a.score||b.sim.stones-a.sim.stones);
 if(candidates.length){
  return sellToPurchaseOrder(g,candidates[0].o.id,candidates[0].sellQty,auth.id);
 }
 return null;
}
function regionalStockValue(s,kind,id){
 const r=s.regionalStock||{};if(kind==='SCROLL')return Math.max(0,Number(r.SCROLL)||0);
 return Math.max(0,Number(r[kind]?.[id])||0);
}
function regionalStockCap(kind){return ({MATERIAL:24,PILL:10,EQUIPMENT:4,SCROLL:12})[kind]||24;}
function adjustRegionalStock(s,kind,id,delta){
 if(kind==='SCROLL'){s.regionalStock.SCROLL=Math.max(0,Math.min(regionalStockCap(kind),(Number(s.regionalStock.SCROLL)||0)+delta));return s.regionalStock.SCROLL;}
 const map=s.regionalStock[kind]||(s.regionalStock[kind]={});map[id]=Math.max(0,Math.min(regionalStockCap(kind),(Number(map[id])||0)+delta));return map[id];
}
function tickRegionalMarket(g,s,now=time(g)){
 const day=Math.floor(now/20),priorDay=Number.isFinite(s.regionalDay)?s.regionalDay:day,elapsed=Math.max(0,Math.min(30,day-priorDay));
 if(!elapsed)return;
 const ids=regionalMaterialIds();let producedMaterials=0,producedPills=0;
 for(let d=0;d<elapsed;d++){
  ids.forEach((id,i)=>{const add=(i<3?2:1),before=regionalStockValue(s,'MATERIAL',id);adjustRegionalStock(s,'MATERIAL',id,add);producedMaterials+=regionalStockValue(s,'MATERIAL',id)-before;});
  for(const id of ['L14_remedy','L14_qi','L14_clarity']){const before=regionalStockValue(s,'PILL',id);adjustRegionalStock(s,'PILL',id,1);producedPills+=regionalStockValue(s,'PILL',id)-before;}
  if((priorDay+d+1)%3===0)adjustRegionalStock(s,'SCROLL','*',1);
  if((priorDay+d+1)%4===0)adjustRegionalStock(s,'EQUIPMENT','L14_ironblade',1);
 }
 const liquidityBefore=s.regionalLiquidity;s.regionalLiquidity=Math.min(s.regionalLiquidityCap,s.regionalLiquidity+elapsed*36);
 s.regionalDay=day;
 const row={t:now,kind:'REGIONAL_PRODUCTION',days:elapsed,materials:producedMaterials,pills:producedPills,liquidityAdded:s.regionalLiquidity-liquidityBefore,liquidity:s.regionalLiquidity};
 s.regionalLedger.unshift(row);s.regionalLedger.splice(60);
}
function regionalExportPrice(g,kind,item,cost){
 const key=kind==='MATERIAL'?item.matId:(item.recipeId||item.catalogId),baseCost=Math.max(1,Number(cost)||1);
 let wholesale=baseCost;
 if(kind==='MATERIAL'){
  const def=matDef(key),base=Math.max(4,Number(def?.baseValueStones||8)*.35),p=marketPressure(g,'MATERIAL',key);
  wholesale=Math.ceil(base*(1.45+p.shortage*.18-p.abundance*.08));
 }else if(kind==='PILL'){
  const q=quote(g,'PILL',item,1);wholesale=Math.ceil((q.unitDonation||baseCost)*.62);
 }
 // The outside wholesale buyer must cover a modest merchant margin; this is a real
 // transfer from regional liquidity, not a generated payment.
 return Math.max(Math.ceil(baseCost*1.12),wholesale,2);
}
function settleCaravanExports(g,seller,s,now){
 const ledger=seller?.jianghu?.ledgerV140;if(!ledger)return {quantity:0,stones:0};
 let totalQuantity=0,totalStones=0;
 for(const kind of ['MATERIAL','PILL']){
  const list=ledger[keys[kind]]||[];
  for(const item of list){
   if(!item||!item.regionalExportEligible||!['EXTERNAL_TRADE_SALE','MEMBER_EXTERNAL_TRADE'].includes(item.provenanceMode))continue;
   const key=kind==='MATERIAL'?item.matId:(item.recipeId||item.catalogId),stock=regionalStockValue(s,kind,key),cap=kind==='MATERIAL'?24:10,demand=Math.max(0,cap-stock),cost=Math.max(1,Number(item.outsidePurchaseCostPerUnit)||1),price=regionalExportPrice(g,kind,item,cost);
   const affordable=Math.floor(Math.max(0,s.regionalLiquidity)/price),qty=Math.min(Math.max(0,Math.floor(Number(item.count)||0)),demand,affordable);
   if(qty<=0)continue;
   const stones=qty*price,credit=E.addSpiritStonesV140(seller,stones);if(!credit?.ok)continue;
   s.regionalLiquidity-=stones;adjustRegionalStock(s,kind,key,qty);item.count-=qty;totalQuantity+=qty;totalStones+=stones;
   const row={id:'regional_export_'+g.s.nextId++,t:now,visit:s.visit,merchantNpcId:seller.id,merchantNameTh:seller.name,kind,itemId:key,nameTh:item.nameTh||matDef(key)?.nameTh||key,quantity:qty,unitStones:price,stones,costPerUnit:cost,profitStones:stones-cost*qty,destination:'ตลาดภายนอก',status:'SOLD'};
   s.exports.unshift(row);s.exports.splice(60);s.totalExports+=qty;s.totalExportStones+=stones;
  }
  ledger[keys[kind]]=list.filter(x=>(Number(x.count)||0)>0);
 }
 E.syncLegacyArraysFromLedgerV140(seller);
 if(totalQuantity){s.regionalLedger.unshift({t:now,kind:'OUTBOUND_EXPORT',merchantNpcId:seller.id,quantity:totalQuantity,stones:totalStones,regionalLiquidity:s.regionalLiquidity});s.regionalLedger.splice(60);g.note(`${seller.name} ส่งสินค้าส่วนเกิน ${totalQuantity} หน่วยออกขายตลาดภายนอก · รับ ${totalStones} หินวิญญาณจากกองทุนตลาดจริง`,seller);}
 return {quantity:totalQuantity,stones:totalStones};
}
function returnRegionalCargo(g,seller,s,now){
 const ledger=seller?.jianghu?.ledgerV140;if(!ledger)return 0;let returned=0,retained=0;
 for(const kind of ['MATERIAL','PILL','EQUIPMENT','SCROLL']){
  const list=ledger[keys[kind]]||[];
  for(const item of list){
   if(!item?.regionalOrigin)continue;
   const key=kind==='MATERIAL'?item.matId:(kind==='SCROLL'?(item.artId||item.id):(item.recipeId||item.catalogId||item.id));
   const qty=kind==='MATERIAL'||kind==='PILL'?Math.max(0,Math.floor(Number(item.count)||0)):1;
   const room=Math.max(0,regionalStockCap(kind)-regionalStockValue(s,kind,key)),fit=Math.min(qty,room);
   if(fit>0){adjustRegionalStock(s,kind,key,fit);returned+=fit;}
   const left=qty-fit;retained+=left;
   if(kind==='MATERIAL'||kind==='PILL')item.count=left;
   else if(left===0)item.count=0;
  }
  ledger[keys[kind]]=list.filter(x=>(Number(x.count??1)||0)>0);
 }
 if(returned||retained){s.regionalLedger.unshift({t:now,kind:'RETURN_UNSOLD_CARGO',merchantNpcId:seller.id,quantity:returned,retained,reason:retained?'สต็อกภูมิภาคเต็มบางส่วน จึงเก็บสินค้าส่วนเกินไว้กับคาราวาน':'คืนสินค้าที่ขายไม่ออกครบแล้ว'});s.regionalLedger.splice(60);}
 E.syncLegacyArraysFromLedgerV140(seller);return returned;
}
function marketPoint(g){const b=g.built('market')||g.built('hall');return b?g.endpoint(b):(g.s.nodes.find(x=>x.id==='market')||{x:2200,y:1700});}
function exitPoint(g){return g.s.nodes.find(x=>x.id==='exit')||{x:3380,y:2500};}
function advanceCaravan(g,s,now=time(g)){
 const visit=s.visitState;if(!visit)return;
 const seller=g.world?.npcs?.[visit.merchantId],p=seller?.stageLocal;if(!seller||!p)return;
 const dt=Math.max(0,Math.min(1,now-(Number(s.lastMovementAt)||now)));s.lastMovementAt=now;
 if(visit.phase==='APPROACHING'){
  const target=marketPoint(g),distance=Math.hypot(p.x-target.x,p.y-target.y);
  if(now>=visit.departAt&&distance>65){for(const o of s.offers||[])if(o.status==='PENDING')o.status='EXPIRED';for(const o of s.orders||[])if(o.status==='OPEN')o.status='EXPIRED';visit.phase='DEPARTING';visit.departingAt=now;s.visitorPhase='DEPARTING';p.externalMerchantPhase='DEPARTING';p.mode='travel';p.action='leaveMarket';p.target=exitPoint(g);p.route=g.path(p,p.target);if(!p.route?.length)p.route=[{x:p.target.x,y:p.target.y}];p.goal='เส้นทางปิด · กลับตลาดภายนอก';return;}
  if(g.routeBlocked())return;
  if(!Array.isArray(p.route))p.route=[];
  if(!p.route.length&&distance>45)p.route=g.path(p,target);
  if(!p.route.length&&distance>45)p.route=[{x:target.x,y:target.y}];
  if(p.route.length)g.move(seller,dt,54);
  if(Math.hypot(p.x-target.x,p.y-target.y)<=65||!p.route.length){p.x=target.x;p.y=target.y;p.route=[];p.target=null;p.mode='waiting';p.action=null;p.goal='ตั้งร้านค้าคาราวาน';p.externalMerchantPhase='TRADING';visit.phase='TRADING';visit.arrivedAt=now;s.visitorPhase='TRADING';g.realm?.speak?.(seller,`${visit.guildNameTh||'คาราวาน'} มาถึงแล้ว! รับซื้อและจำหน่ายสินค้าตามอุปสงค์ของตลาด`,'trade');g.note(`${seller.name} เดินทางถึงตลาดสำนัก เปิดร้านค้าและใบสั่งซื้อจากภายนอกแล้ว`,seller);}
 }else if(visit.phase==='TRADING'&&now>=visit.departAt){
  for(const o of s.offers||[])if(o.status==='PENDING')o.status='EXPIRED';for(const o of s.orders||[])if(o.status==='OPEN')o.status='EXPIRED';
  visit.phase='DEPARTING';visit.departingAt=now;s.visitorPhase='DEPARTING';p.externalMerchantPhase='DEPARTING';p.mode='travel';p.action='leaveMarket';p.target=exitPoint(g);p.route=g.path(p,p.target);if(!p.route?.length)p.route=[{x:p.target.x,y:p.target.y}];p.goal='เดินทางกลับตลาดนอกหุบเขา';g.realm?.speak?.(seller,'ข้าจะนำสินค้าที่รับซื้อกลับไปขายยังตลาดนอกหุบเขา แล้วค่อยกลับมาใหม่','trade');
 }else if(visit.phase==='DEPARTING'){
  const target=exitPoint(g);if(p.route?.length)g.move(seller,dt,54);
  if(Math.hypot(p.x-target.x,p.y-target.y)<=65||!p.route?.length){p.x=target.x;p.y=target.y;p.route=[];const exports=settleCaravanExports(g,seller,s,now);const returned=returnRegionalCargo(g,seller,s,now);p.offmap={externalMerchant:true,phase:'OFFMAP',until:null};p.mode='offmap';p.target=null;p.action=null;p.externalMerchantPhase='OFFMAP';visit.phase='OFFMAP';visit.departedAt=now;visit.exports=exports;visit.returnedRegionalCargo=returned;s.visitorPhase='OFFMAP';s.nextVisitAt=now+40;g.note(`${seller.name} ออกจากหุบเขาแล้ว · ส่งออก ${exports.quantity} หน่วย รับ ${exports.stones} หินวิญญาณ · คืนสินค้าที่ขายไม่ออก ${returned} หน่วยกลับคลังตลาดภายนอก`,seller);}
 }
}
function externalMarket(g){
 const s=externalState(g),now=time(g);tickRegionalMarket(g,s,now);advanceCaravan(g,s,now);root.JianghuSectLibrary?.appoint(g);
 for(const o of s.offers)if(o.status==='PENDING'&&now>=o.expiresAt)o.status='EXPIRED';
 for(const o of s.orders||[])if(o.status==='OPEN'&&now>=o.expiresAt)o.status='EXPIRED';
 if(now>=s.nextVisitAt&&g.built('hall')&&!g.routeBlocked()&&(!s.visitState||s.visitState.phase==='OFFMAP')){
  s.visit++;s.nextVisitAt=now+140;s.offers=[];s.orders=[];
  const index=(s.visit-1)%3,guild=CARAVAN_GUILDS[(s.visit-1)%CARAVAN_GUILDS.length];
  s.guildId=guild.id;s.guildNameTh=guild.labelTh;s.guildSpecialtyTh=guild.specialtyTh;
  let seller=g.world.npcs[s.merchantIds[index]];
  if(!seller){
   seller=g.create(['ลั่วอัน · พ่อค้าสมุนไพร','เฉินถง · พ่อค้าศาสตรา','ซ่งชิง · พ่อค้าพเนจร'][index],{role:'merchant',sectId:'JH_MERCHANT',preserveName:true});
   const at=exitPoint(g);g.initializePerson(seller,at,{role:'merchant',visitor:true,originSectId:'JH_MERCHANT'});E.setSpiritStonesV140(seller,0);s.merchantIds[index]=seller.id;
  }
  const l=seller.jianghu.ledgerV140;
  for(const k of Object.values(keys))if(!Array.isArray(l[k]))l[k]=[];
  const at=exitPoint(g),target=marketPoint(g),p=seller.stageLocal;p.x=at.x;p.y=at.y;p.offmap=null;p.visitor=true;p.externalMerchant=true;p.externalMerchantPhase='APPROACHING';p.mode='travel';p.action='approachMarket';p.target={x:target.x,y:target.y,id:'market'};p.route=g.path(p,p.target);if(!p.route?.length)p.route=[{x:target.x,y:target.y}];p.goal='เดินทางเข้าตลาดสำนัก';
  const tier=Math.min(3,Math.max(1,...g.heroes.filter(x=>x.alive).map(x=>Math.floor(g.progression.tier(x)))));
  const candidates=regionalMaterialIds();
  const matIds=candidates.map((id,rotation)=>({id,rotation,pressure:marketPressure(g,'MATERIAL',id),available:regionalStockValue(s,'MATERIAL',id)})).filter(x=>x.available>0).sort((a,b)=>b.pressure.shortage-a.pressure.shortage||b.available-a.available||a.rotation-b.rotation).slice(0,2).map(x=>x.id);
  function offer(kind,item,quantity,unitStones){const ask=externalAskPrice(g,kind,item,unitStones,guild.id);s.offers.push({id:'outside_offer_'+g.s.nextId++,sellerNpcId:seller.id,sellerNameTh:seller.name,guildId:guild.id,guildNameTh:guild.labelTh,kind,itemId:item.id||item.matId,artId:item.artId||null,nameTh:item.nameTh,quantity,unitStones:ask,totalStones:ask*quantity,tier:item.tier||1,createdAt:now,expiresAt:now+100,status:'PENDING'});}
  for(const id of matIds){
   const qty=Math.min(4,regionalStockValue(s,'MATERIAL',id));if(qty<=0)continue;const d=matDef(id);if(!d)continue;
   const cap=E.PATCH140_CAPS?.materialStacks||24;if(l.materialStacks.length>=cap)continue;
   const item={id:'outside_cargo_'+g.s.nextId++,matId:id,nameTh:d.nameTh||id,category:d.category,tier:Number(d.tier)||1,quality:'STANDARD',count:qty,isTranscendent:false,originType:'OUTSIDE_TRADE',originId:'regional_'+id+'_'+s.visit,originLabelTh:'สินค้าจริงจากคลังตลาดภายนอก',ownerNpcId:seller.id,ownerId:seller.id,regionalOrigin:true,regionalStockKind:'MATERIAL',regionalStockKey:id,provenanceMode:'REGIONAL_SUPPLY'};
   adjustRegionalStock(s,'MATERIAL',id,-qty);l.materialStacks.push(item);seller.jianghu.knownMaterialIds=seller.jianghu.knownMaterialIds||[];if(!seller.jianghu.knownMaterialIds.includes(id))seller.jianghu.knownMaterialIds.push(id);offer('MATERIAL',item,qty,Math.max(3,Math.ceil((d.baseValueStones||8)*.65)));
  }
  const recipeId=s.visit%2?'L14_remedy':'L14_ironblade',r=g.progression.recipe(recipeId),kind=r?(r.effect?.slot?'EQUIPMENT':'PILL'):null;
  if(r&&kind&&regionalStockValue(s,kind,r.id)>0){
   adjustRegionalStock(s,kind,r.id,-1);const item={id:'outside_cargo_'+g.s.nextId++,recipeId:r.id,catalogId:r.id,nameTh:r.name,tier:r.tier,quality:tier>=2?'GOOD':'COMMON',ownerNpcId:seller.id,ownerId:seller.id,count:kind==='PILL'?1:undefined,originLabelTh:'สินค้าจากการผลิตของตลาดภายนอก',provenanceMode:'REGIONAL_SUPPLY',regionalOrigin:true,regionalStockKind:kind,regionalStockKey:r.id};
   if(kind==='PILL'){item.effect=g.progression.normalizePill(r.effect);item.livingEffect=clone(r.effect);}else Object.assign(item,{slot:r.effect.slot,minStageReq:1,durability:100,maxDurability:100,compatiblePath:'ANY',combatMult:r.effect.combat||0,defenseMult:r.effect.defense||0});
   l[keys[kind]].push(item);offer(kind,item,item.count||1,Math.max(12,Math.ceil(quote(g,kind,item).unitDonation*.8)));
  }
  const scripture=s.regionalStock.SCROLL>0?root.JianghuSectLibrary?.visitorOffer(g,s,seller):null;if(scripture){adjustRegionalStock(s,'SCROLL','*',-1);scripture.regionalOrigin=true;scripture.regionalStockKind='SCROLL';scripture.regionalStockKey=scripture.artId;const sc=l.scrolls.find(x=>x.id===scripture.itemId);if(sc)Object.assign(sc,{regionalOrigin:true,regionalStockKind:'SCROLL',regionalStockKey:scripture.artId,provenanceMode:'REGIONAL_SUPPLY'});scripture.guildId=guild.id;scripture.guildNameTh=guild.labelTh;scripture.unitStones=Math.max(1,Number(scripture.unitStones)||Number(scripture.totalStones)||18);scripture.totalStones=scripture.unitStones*Math.max(1,Number(scripture.quantity)||1);s.offers.push(scripture);}
  for(const tpl of guild.orders||[]){const chosen=(tpl.ids||[]).find(id=>tpl.kind==='MATERIAL'?(!matIds.includes(id)&&regionalStockValue(s,'MATERIAL',id)>0):id!==r?.id&&regionalStockValue(s,tpl.kind,id)>0)||tpl.ids?.find(id=>regionalStockValue(s,tpl.kind,id)>0);if(chosen)createPurchaseOrder(g,s,seller,guild,tpl.kind,chosen,tpl,now);}
  E.syncLegacyArraysFromLedgerV140(seller);s.visitState={merchantId:seller.id,guildId:guild.id,guildNameTh:guild.labelTh,phase:'APPROACHING',startedAt:now,departAt:now+100,arrivedAt:null,departedAt:null,exports:null};s.visitorPhase='APPROACHING';s.lastMovementAt=now;
  g.note(seller.name+' ('+guild.labelTh+') กำลังเดินทางเข้าตลาด · สินค้าจากสต็อกภูมิภาค '+s.offers.length+' รายการ · ใบสั่งซื้อ '+s.orders.length+' รายการ · ใช้เงินทุนและสต็อกตลาดจริง');
 }
 return s;
}
function regionalMarketSnapshot(s){return {liquidity:s?.regionalLiquidity||0,liquidityCap:s?.regionalLiquidityCap||3000,stock:clone(s?.regionalStock||{}),totalExports:s?.totalExports||0,totalExportStones:s?.totalExportStones||0,visitorPhase:s?.visitorPhase||'OFFMAP',visitState:s?.visitState?{...s.visitState}:null,exports:(s?.exports||[]).slice(0,10),ledger:(s?.regionalLedger||[]).slice(0,10)};}

function acceptExternalOffer(g,id,authorityNpcId=null){
 const s=externalState(g),o=s.offers.find(x=>x.id===id);
 if(!o||o.status!=='PENDING'||time(g)>=o.expiresAt)return {ok:false,reason:'ข้อเสนอสิ้นสุดหรือซื้อไปแล้ว'};
 const auths=g.storyEvents.authorities(),libraryAuthority=o.kind==='SCROLL'?root.JianghuSectLibrary?.authority(g,authorityNpcId):null;
 const authority=o.kind==='SCROLL'?(libraryAuthority?{npc:libraryAuthority}:null):auths.find(x=>!authorityNpcId||x.npc.id===authorityNpcId);
 if(!authority)return {ok:false,reason:'ต้องมีเจ้าสำนักหรือผู้อาวุโสฝ่ายคลังที่พร้อมเจรจา'};
 if(g.routeBlocked())return {ok:false,reason:'เส้นทางถูกปิด ยังรับสินค้าไม่ได้'};
 if(o.kind==='SCROLL'&&root.JianghuSectLibrary.assess(g,o).score<=0)return {ok:false,reason:'ผู้อาวุโสประเมินว่าคัมภีร์นี้ยังไม่มีผู้เรียนที่เหมาะสมหรือไม่คุ้มค่าต่อสำนัก'};
 if(!Number.isFinite(o.totalStones)||o.totalStones<=0||g.gold<o.totalStones)return {ok:false,reason:'หินวิญญาณกองกลางไม่เพียงพอ'};
 const seller=g.world.npcs[o.sellerNpcId],key=keys[o.kind],sl=seller?.jianghu?.ledgerV140,bl=g.bank.jianghu.ledgerV140;
 const item=sl?.[key]?.find(x=>(x.id||x.matId)===o.itemId);
 if(!seller?.alive||!item||!g.ownsMaterial(seller,item)||(item.count??1)<o.quantity)return {ok:false,reason:'ผู้ขายไม่มีสินค้าตามที่เสนอแล้ว'};
 if(o.kind==='SCROLL'&&(!g.built('shrine')||g.s.growth.scriptureLibrary.length>=(root.JianghuSectLibrary?.capacity(g)||120)||g.s.growth.scriptureLibrary.some(b=>b.artId===o.artId)))return {ok:false,reason:'ต้องมีหอคัมภีร์ที่มีพื้นที่ว่างและยังไม่มีวิชานี้'};
 const max=o.kind==='MATERIAL'?(root.JianghuInfrastructure?.bonuses(g).materialCapacity||640):o.kind==='PILL'?128:240;
 if(o.kind!=='SCROLL'&&bl[key].length>=max)return {ok:false,reason:'คลังสำนักเต็ม จึงยังไม่จ่ายหินวิญญาณ'};
 if(o.kind==='MATERIAL'&&!g.canAcceptMaterial(g.bank,item.matId,item))return {ok:false,reason:'ไม่มีช่องรับสินค้านี้'};
 const metadata={suppliedByNpcId:seller.id,suppliedByNameTh:seller.name,suppliedAt:time(g),provenanceMode:'EXTERNAL_TRADE'};
 if(o.kind==='MATERIAL'){
  const r=depositMaterialLot(g,g.bank,item.matId,o.quantity,item,metadata);if(!r.ok)return {ok:false,reason:'ส่งมอบสินค้าไม่สำเร็จ'};
  item.count-=o.quantity;sl[key]=sl[key].filter(x=>x.count>0);
 }else if(o.kind==='SCROLL'){
  sl[key].splice(sl[key].indexOf(item),1);Object.assign(item,metadata,{ownerNpcId:null,ownerId:null,rights:'SECT_LIBRARY',access:'SECT',sourceType:'SECT_LIBRARY',libraryId:'outside_library_'+g.s.nextId++,originalOwnerNpcId:seller.id,purchasedAt:time(g)});g.s.growth.scriptureLibrary.push(item);
 }else{
  sl[key].splice(sl[key].indexOf(item),1);Object.assign(item,metadata,{ownerNpcId:g.bank.id,ownerId:g.bank.id,sectStore:false,storeCount:0});bl[key].push(item);
 }
 g.money(-o.totalStones,'ซื้อสินค้าคนนอก '+o.nameTh);E.addSpiritStonesV140(seller,o.totalStones);
 o.status='ACCEPTED';o.acceptedAt=time(g);o.authorityNpcId=authority.npc.id;shiftGuildRelation(g,o.guildId,1);
 s.history.unshift({...o});s.history.splice(40);
 E.syncLegacyArraysFromLedgerV140(g.bank);E.syncLegacyArraysFromLedgerV140(seller);invalidateMarketCache(g);
 log(g,authority.npc,'EXTERNAL_BUY',item,o.quantity,0,{stones:-o.totalStones,sellerName:seller.name});
 g.note(`${authority.npc.name} รับข้อเสนอ ${seller.name}: «${o.nameTh}» ×${o.quantity} · จ่ายหินวิญญาณ ${o.totalStones} กองกลาง`,authority.npc);
 return {ok:true,costStones:o.totalStones,quantity:o.quantity,reason:'รับสินค้าเข้าคลังและจ่ายหินวิญญาณแก่ผู้ขายแล้ว'};
}
function memberOfSect(g,n){return !!(n?.alive&&g?.s?.heroIds?.includes(n.id)&&g.world?.npcs?.[n.id]===n);}
function findExternalOfferItem(g,o){
 const seller=g?.world?.npcs?.[o?.sellerNpcId],key=keys[o?.kind],ledger=seller?.jianghu?.ledgerV140;
 const item=key?(ledger?.[key]||[]).find(x=>(x.id||x.matId)===o.itemId):null;
 return {seller,item,key,ledger};
}
function quoteMemberExternalOffer(g,npcId,id,requested=null){
 const s=externalState(g),o=s.offers.find(x=>x.id===id),n=g.world?.npcs?.[npcId];
 if(!o||o.status!=='PENDING'||time(g)>=o.expiresAt)return {ok:false,reason:'ข้อเสนอคนนอกสิ้นสุดหรือสินค้าไม่อยู่แล้ว'};
 if(!memberOfSect(g,n))return {ok:false,reason:'ต้องเลือกศิษย์ที่ยังมีชีวิตอยู่ในสำนัก'};
 if(g.routeBlocked())return {ok:false,reason:'เส้นทางการค้าถูกปิดกั้น'};
 const {seller,item}=findExternalOfferItem(g,o);
 if(!seller?.alive||!item||!owned(seller,item))return {ok:false,reason:'ผู้ขายไม่มีสินค้าจริงตามข้อเสนอแล้ว'};
 const available=Math.max(0,Number(o.quantity)||0),qty=requested===null||requested===undefined?available:Number(requested);
 if(!Number.isInteger(qty)||qty<=0||qty>available)return {ok:false,reason:`จำนวนซื้อไม่ถูกต้อง · เหลือ ${available} หน่วย`};
 if(o.kind!=='MATERIAL'&&o.kind!=='PILL'&&qty!==1)return {ok:false,reason:'ศาสตราและคัมภีร์ซื้อได้ครั้งละหนึ่งชิ้น'};
 if(o.kind==='MATERIAL'){
  if((Number(item.count)||0)<qty)return {ok:false,reason:'จำนวนวัตถุดิบของผู้ขายไม่พอ'};
  if(H.load(n)+qty>H.carryLimit(n))return {ok:false,reason:'สัมภาระของศิษย์เต็ม'};
  if(!g.canAcceptMaterial(n,item.matId,item))return {ok:false,reason:'คลังส่วนตัวไม่มีช่องรับวัตถุดิบนี้'};
 }else if(o.kind==='PILL'){
  if((Number(item.count)||1)<qty)return {ok:false,reason:'จำนวนโอสถของผู้ขายไม่พอ'};
  const existing=(n.jianghu.ledgerV140.pillStacks||[]).some(x=>g.ownsMaterial(n,x)&&(x.recipeId||x.catalogId)===(item.recipeId||item.catalogId)&&x.quality===(item.quality||'COMMON'));
  if(!existing&&(n.jianghu.ledgerV140.pillStacks||[]).length>=(E.PATCH140_CAPS?.pillStacks||128))return {ok:false,reason:'ช่องเก็บโอสถส่วนตัวเต็ม'};
 }else if(o.kind==='EQUIPMENT'){
  if((n.jianghu.ledgerV140.equipmentItems||[]).length>=(E.PATCH140_CAPS?.equipmentItems||12))return {ok:false,reason:'ช่องเก็บศาสตราส่วนตัวเต็ม'};
 }else if(o.kind==='SCROLL'){
  const art=g.progression?.artMap?.get(o.artId);
  if(!art||!g.progression.compatible(n,art)||!g.progression.canStudyArtTier(n,art)||(g.discovery&&!g.discovery.canStudy(n,art)))return {ok:false,reason:'คัมภีร์นี้ยังไม่สอดคล้องกับมรรคาหรือขอบเขตของศิษย์'};
  if((n.jianghu.ledgerV140.scrolls||[]).some(x=>x.artId===o.artId))return {ok:false,reason:'ศิษย์มีคัมภีร์วิชานี้อยู่แล้ว'};
  if((n.jianghu.ledgerV140.scrolls||[]).length>=(E.PATCH140_CAPS?.scrolls||24))return {ok:false,reason:'ช่องเก็บคัมภีร์ส่วนตัวเต็ม'};
 }else return {ok:false,reason:'สินค้าประเภทนี้ยังไม่รองรับการซื้อส่วนตัว'};
 const unit=Math.max(1,Math.ceil(Number(o.unitStones)||Number(o.totalStones)/Math.max(1,available)));
 const stones=unit*qty,balance=E.getSpiritStonesV140(n);
 if(!Number.isFinite(stones)||stones<=0)return {ok:false,reason:'ราคาข้อเสนอไม่ถูกต้อง'};
 if(balance<stones)return {ok:false,quantity:qty,stones,balance,reason:`หินวิญญาณส่วนตัวไม่พอ · ต้องใช้ ${stones} แต่มี ${balance}`};
 return {ok:true,npcId:n.id,offerId:o.id,kind:o.kind,itemId:o.itemId,itemNameTh:o.nameTh,quantity:qty,available,unitStones:unit,stones,balance,balanceAfter:balance-stones,sellerNpcId:seller.id,sellerNameTh:seller.name,guildId:o.guildId||null,reason:`ซื้อ «${o.nameTh}» ×${qty} ด้วยหินวิญญาณส่วนตัว ${stones}`};
}
function buyExternalOffer(g,npcId,id,requested=null){
 const s=externalState(g),o=s.offers.find(x=>x.id===id),q=quoteMemberExternalOffer(g,npcId,id,requested);
 if(!q.ok)return q;
 const n=g.world.npcs[npcId],{seller,item,key,ledger:sl}=findExternalOfferItem(g,o),nl=n.jianghu.ledgerV140;
 const debit=E.addSpiritStonesV140(n,-q.stones);if(!debit?.ok)return {ok:false,reason:'หินวิญญาณส่วนตัวไม่พอ'};
 const metadata={ownerNpcId:n.id,ownerId:n.id,suppliedByNpcId:seller.id,suppliedByNameTh:seller.name,suppliedAt:time(g),purchasedAt:time(g),provenanceMode:'MEMBER_EXTERNAL_TRADE',sectStore:false,storeCount:0};
 let moved=false;
 try{
  if(o.kind==='MATERIAL'){
   const dep=depositMaterialLot(g,n,item.matId,q.quantity,item,metadata);if(!dep.ok)throw Error('ส่งมอบวัตถุดิบเข้าคลังส่วนตัวไม่สำเร็จ');
   item.count-=q.quantity;moved=true;
  }else if(o.kind==='PILL'){
   const peer=(nl.pillStacks||[]).find(x=>g.ownsMaterial(seller,x)&&(x.id||x.matId)===o.itemId);
   if(!peer||peer.count<q.quantity)throw Error('โอสถของผู้ขายเปลี่ยนแปลงแล้ว');
   const existing=(nl.pillStacks||[]).find(x=>g.ownsMaterial(n,x)&&(x.recipeId||x.catalogId)===(peer.recipeId||peer.catalogId)&&x.quality===(peer.quality||'COMMON'));
   if(existing)existing.count=(existing.count||0)+q.quantity;
   else nl.pillStacks.push({...clone(peer),...metadata,id:'member_bought_'+g.s.nextId++,count:q.quantity,ownerNpcId:n.id,ownerId:n.id});
   peer.count-=q.quantity;if(peer.count<=0)sl[keys.PILL]=sl[keys.PILL].filter(x=>x!==peer);moved=true;
  }else{
   const index=(sl[key]||[]).indexOf(item);if(index<0)throw Error('สินค้าออกจากสัมภาระผู้ขายไปแล้ว');
   sl[key].splice(index,1);
   if(o.kind==='EQUIPMENT')nl.equipmentItems.push({...clone(item),...metadata,id:'member_bought_'+g.s.nextId++,ownerNpcId:n.id,ownerId:n.id,rights:'OWNER'});
   else nl.scrolls.push({...clone(item),...metadata,id:'member_bought_'+g.s.nextId++,ownerNpcId:n.id,ownerId:n.id,rights:'OWNER',access:'PRIVATE',originalOwnerNpcId:seller.id});
   moved=true;
  }
 }catch(err){E.addSpiritStonesV140(n,q.stones);return {ok:false,reason:err.message||'โอนสินค้าไม่สำเร็จ'};}
 if(!moved){E.addSpiritStonesV140(n,q.stones);return {ok:false,reason:'โอนสินค้าไม่สำเร็จ'};}
 if(o.kind==='MATERIAL'&&item.count<=0)sl[keys.MATERIAL]=sl[keys.MATERIAL].filter(x=>x!==item);
 const credit=E.addSpiritStonesV140(seller,q.stones);if(!credit?.ok){E.addSpiritStonesV140(n,q.stones);return {ok:false,reason:'ไม่สามารถรับชำระเข้ากระเป๋าผู้ขายได้'};}
 o.quantity-=q.quantity;o.totalStones=Math.max(0,o.quantity*o.unitStones);if(o.quantity<=0)o.status='ACCEPTED_MEMBER';
 const receipt={id:'outside_member_buy_'+g.s.nextId++,t:time(g),status:'ACCEPTED_MEMBER',buyerType:'DISCIPLE',buyerNpcId:n.id,buyerNameTh:n.name,sellerNpcId:seller.id,sellerNameTh:seller.name,guildId:o.guildId||null,kind:o.kind,itemId:o.itemId,nameTh:o.nameTh,quantity:q.quantity,unitStones:q.unitStones,totalStones:q.stones};
 s.history.unshift(receipt);s.history.splice(40);shiftGuildRelation(g,o.guildId,1);
 E.syncLegacyArraysFromLedgerV140(n);E.syncLegacyArraysFromLedgerV140(seller);invalidateMarketCache(g);
 log(g,n,'MEMBER_EXTERNAL_BUY',item,q.quantity,0,{stones:-q.stones,sellerNameTh:seller.name,guildId:o.guildId||null,currency:'SPIRIT_STONES'});
 g.note(`🪙 ${n.name} ซื้อ «${o.nameTh}» ×${q.quantity} จาก ${seller.name} · จ่ายหินวิญญาณส่วนตัว ${q.stones}`,n);
 return {ok:true,...q,offerRemaining:o.quantity,offerStatus:o.status,reason:`ซื้อ «${o.nameTh}» ×${q.quantity} สำเร็จ · ใช้หินวิญญาณส่วนตัว ${q.stones}`};
}
function personalOrderLots(g,n,o){
 if(!memberOfSect(g,n)||!o||!['MATERIAL','PILL'].includes(o.kind))return [];
 const l=n.jianghu?.ledgerV140;if(!l)return [];
 if(o.kind==='MATERIAL')return (l.materialStacks||[]).filter(x=>owned(n,x)&&x.matId===o.targetId&&(x.count||0)>0&&x.contributionCreditAllowed!==false&&!x.sectGrant&&isOrdinarySurplusLot(x)).sort((a,b)=>(b.count||0)-(a.count||0));
 return (l.pillStacks||[]).filter(x=>owned(n,x)&&(x.recipeId||x.catalogId)===o.targetId&&(x.count||0)>0&&x.contributionCreditAllowed!==false&&!x.sectGrant&&isOrdinarySurplusLot(x)).sort((a,b)=>(b.count||0)-(a.count||0));
}
function quotePersonalPurchaseOrder(g,npcId,id,requested=null){
 const s=externalState(g),o=(s.orders||[]).find(x=>x.id===id),n=g.world?.npcs?.[npcId];
 if(!o)return {ok:false,reason:'ไม่พบใบสั่งซื้อจากพ่อค้าคนนอก'};
 if(!memberOfSect(g,n))return {ok:false,reason:'ต้องเลือกศิษย์ที่ยังมีชีวิตอยู่ในสำนัก'};
 if(g.routeBlocked())return {ok:false,reason:'เส้นทางการค้าถูกปิดกั้น'};
 if(o.status!=='OPEN'||time(g)>=o.expiresAt)return {ok:false,reason:'ใบสั่งซื้อสิ้นสุดหรือรับซื้อครบจำนวนแล้ว'};
 const lots=personalOrderLots(g,n,o),totalStock=lots.reduce((sum,x)=>sum+(Number(x.count)||0),0);
 const reserveQty=o.kind==='MATERIAL'?Math.min(totalStock,reserve(g,n,o.targetId)):Math.min(totalStock,1);
 const surplusQty=Math.max(0,totalStock-reserveQty),remainingDemand=Math.max(0,o.wantQuantity-(o.filled||0));
 const buyer=g.world?.npcs?.[o.buyerNpcId],purseLeft=Math.max(0,Math.min((o.purseStones||0)-(o.stonesPaid||0),E.getSpiritStonesV140(buyer)));
 const bonusPerUnit=o.bonusPerUnit!==undefined?o.bonusPerUnit:Math.floor(o.unitStones*(o.bonusPct||0)/100),bonusLeft=Math.max(0,(o.bonusQuota||0)-(o.filled||0));
 let maxAffordable=0,runningCost=0;for(let i=1;i<=Math.min(surplusQty,remainingDemand);i++){const c=o.unitStones+(i<=bonusLeft?bonusPerUnit:0);if(runningCost+c>purseLeft)break;runningCost+=c;maxAffordable=i;}
 const maxSellable=Math.min(surplusQty,remainingDemand,maxAffordable),qty=requested===null||requested===undefined?maxSellable:Number(requested);
 const base={orderId:o.id,npcId:n.id,totalStock,reserve:reserveQty,surplusQty,remainingDemand,bonusLeft,maxSellable,unitStones:o.unitStones};
 if(!Number.isInteger(qty)||qty<=0)return {ok:false,...base,quantity:0,stones:0,reason:surplusQty<=0?`สัมภาระของศิษย์มี ${totalStock} หน่วย ต้องเก็บสำรอง ${reserveQty} หน่วย`:remainingDemand<=0?'พ่อค้ารับซื้อครบจำนวนแล้ว':maxSellable<=0?'พ่อค้ามีหินวิญญาณไม่พอหรือไม่มีของส่วนเกิน':'จำนวนขายไม่ถูกต้อง'};
 if(qty>maxSellable)return {ok:false,...base,reason:`ขายได้สูงสุด ${maxSellable} หน่วย โดยต้องเก็บสำรอง ${reserveQty} หน่วย`};
 const bonusUnits=Math.min(qty,bonusLeft),baseStones=qty*o.unitStones,bonusStones=bonusUnits*bonusPerUnit,stones=baseStones+bonusStones;
 if(stones>purseLeft)return {ok:false,...base,reason:'หินวิญญาณของพ่อค้าไม่พอรับซื้อจำนวนนี้'};
 return {ok:true,...base,quantity:qty,bonusUnits,baseStones,bonusStones,stones,reserveReasons:[`เก็บวัตถุดิบส่วนตัว ${reserveQty} หน่วย`],reason:`พร้อมขาย «${o.nameTh}» ×${qty} รับ ${stones} หินวิญญาณ`};
}
function sellPersonalToPurchaseOrder(g,npcId,id,quantity=null){
 const s=externalState(g),o=(s.orders||[]).find(x=>x.id===id),n=g.world?.npcs?.[npcId];
 if(!o)return {ok:false,reason:'ไม่พบใบสั่งซื้อจากพ่อค้าคนนอก'};
 const q=quotePersonalPurchaseOrder(g,npcId,id,quantity);if(!q.ok)return q;
 const buyer=g.world.npcs[o.buyerNpcId];if(!buyer?.alive)return {ok:false,reason:'พ่อค้าผู้รับซื้อไม่อยู่ในพื้นที่แล้ว'};
 if(E.getSpiritStonesV140(buyer)<q.stones)return {ok:false,reason:'พ่อค้ามีหินวิญญาณจริงไม่พอรับซื้อ'};
 const lots=personalOrderLots(g,n,o);let rem=q.quantity;const plan=[];for(const lot of lots){if(rem<=0)break;const take=Math.min(rem,Number(lot.count)||0);if(take>0){plan.push({lot,quantity:take});rem-=take;}}
 if(rem>0)return {ok:false,reason:'สินค้าส่วนเกินเปลี่ยนแปลงระหว่างเสนอขาย'};
 const sample=plan[0]?.lot;if(!sample)return {ok:false,reason:'ไม่พบสินค้าส่วนเกินที่เป็นของศิษย์'};
 const bl=buyer.jianghu.ledgerV140;
 if(o.kind==='MATERIAL'&&!g.canAcceptMaterial(buyer,o.targetId,sample))return {ok:false,reason:'สัมภาระพ่อค้าเต็ม ไม่สามารถรับวัตถุดิบเพิ่มได้'};
 if(o.kind==='PILL'&&!bl.pillStacks.some(x=>g.ownsMaterial(buyer,x)&&(x.recipeId||x.catalogId)===o.targetId&&x.quality===(sample.quality||'COMMON'))&&bl.pillStacks.length>=(E.PATCH140_CAPS?.pillStacks||128))return {ok:false,reason:'ช่องเก็บโอสถของพ่อค้าเต็ม'};
 const debit=E.addSpiritStonesV140(buyer,-q.stones);if(!debit?.ok)return {ok:false,reason:'พ่อค้ามีหินวิญญาณจริงไม่พอรับซื้อ'};
 const metadata={ownerNpcId:buyer.id,ownerId:buyer.id,suppliedByNpcId:n.id,suppliedByNameTh:n.name,purchasedAt:time(g),provenanceMode:'MEMBER_EXTERNAL_TRADE',regionalExportEligible:true,outsidePurchaseCostPerUnit:Math.ceil(q.stones/Math.max(1,q.quantity)),sectStore:false,storeCount:0};
 try{
  if(o.kind==='MATERIAL'){
   const dep=depositMaterialLot(g,buyer,o.targetId,q.quantity,sample,metadata);if(!dep.ok)throw Error('ส่งมอบวัตถุดิบให้พ่อค้าไม่สำเร็จ');
  }else{
   const existing=bl.pillStacks.find(x=>g.ownsMaterial(buyer,x)&&(x.recipeId||x.catalogId)===o.targetId&&x.quality===(sample.quality||'COMMON')&&x.provenanceMode==='MEMBER_EXTERNAL_TRADE'&&Number(x.outsidePurchaseCostPerUnit||0)===metadata.outsidePurchaseCostPerUnit);
   if(existing)existing.count=(existing.count||0)+q.quantity;
   else bl.pillStacks.push({...clone(sample),...metadata,id:'outside_member_stock_'+g.s.nextId++,ownerNpcId:buyer.id,ownerId:buyer.id,count:q.quantity,storeCount:0,sectStore:false});
  }
 }catch(err){E.addSpiritStonesV140(buyer,q.stones);return {ok:false,reason:err.message||'ส่งมอบสินค้าไม่สำเร็จ'};}
 for(const p of plan){p.lot.count-=p.quantity;if(p.lot.count<=0){const arr=n.jianghu.ledgerV140[keys[o.kind]];const idx=arr.indexOf(p.lot);if(idx>=0)arr.splice(idx,1);}}
 const credit=E.addSpiritStonesV140(n,q.stones);if(!credit?.ok){E.addSpiritStonesV140(buyer,q.stones);return {ok:false,reason:'ไม่สามารถจ่ายหินวิญญาณให้ศิษย์ได้'};}
 o.filled=(o.filled||0)+q.quantity;o.stonesPaid=(o.stonesPaid||0)+q.stones;o.bonusUsed=(o.bonusUsed||0)+q.bonusUnits;if(o.filled>=o.wantQuantity)o.status='FILLED';
 const sale={id:'outside_member_sale_'+g.s.nextId++,t:time(g),orderId:o.id,sellerType:'DISCIPLE',sellerNpcId:n.id,sellerNameTh:n.name,buyerNpcId:buyer.id,buyerNameTh:buyer.name,guildId:o.guildId||null,guildNameTh:o.guildNameTh||'',kind:o.kind,targetId:o.targetId,nameTh:o.nameTh,quantity:q.quantity,unitStones:q.unitStones,bonusUnits:q.bonusUnits,baseStones:q.baseStones,bonusStones:q.bonusStones,stones:q.stones,reserveKept:q.reserve};
 s.sales.unshift(sale);s.sales.splice(40);shiftGuildRelation(g,o.guildId,1);E.syncLegacyArraysFromLedgerV140(n);E.syncLegacyArraysFromLedgerV140(buyer);invalidateMarketCache(g);
 log(g,n,'MEMBER_EXTERNAL_SELL',sample,q.quantity,0,{stones:q.stones,buyerNameTh:buyer.name,guildId:o.guildId||null,orderId:o.id,currency:'SPIRIT_STONES'});
 g.note(`💰 ${n.name} ขายส่วนเกิน «${o.nameTh}» ×${q.quantity} ให้ ${buyer.name} · รับหินวิญญาณส่วนตัว +${q.stones}`,n);
 return {ok:true,...q,orderStatus:o.status,sale,reason:`ขาย «${o.nameTh}» ×${q.quantity} ให้ ${buyer.name} · รับหินวิญญาณส่วนตัว +${q.stones}`};
}
function memberOfferNeed(g,n,o){
 const {item}=findExternalOfferItem(g,o);if(!item)return null;
 if(o.kind==='MATERIAL'){
  const held=g.count(n,item.matId),wish=n.stageLocal?.storeWish;
  let desired=wish?.kind==='MATERIAL'&&(wish.id===item.matId||wish.id===item.id)?2:0;
  for(const id of n.stageLocal?.growth?.knownRecipes||[]){const r=g.progression?.recipe?.(id);if(!r)continue;const input=(r.inputs||[]).find(x=>x.matId===item.matId);if(input)desired=Math.max(desired,input.count*2);}
  return desired>held?{score:54+(desired-held)*4+(wish?.kind==='MATERIAL'?8:0),quantity:Math.min(o.quantity,desired-held),reason:'วัตถุดิบขาดสำหรับตำรับ/เป้าหมายส่วนตัว'}:null;
 }
 if(o.kind==='PILL'){
  const effect=item.effect||item.livingEffect||{},hurt=(100-(n.health||0)),qi=Number(n.stageLocal?.combatState?.qi||0);
  const need=(effect.healHealth&&hurt>=18)||(effect.restoreQi&&qi<35)||(effect.cleansePoison&&(n.jianghu?.poisonAccumulated||0)>0);
  return need?{score:62+Math.min(20,hurt*.2),quantity:1,reason:'ต้องการโอสถจากบาดแผล/ปราณ/พิษ'}:null;
 }
 return null;
}
function tickMemberMarket(g,s){
 if(s.autoMemberTrade===false||g.routeBlocked())return null;
 const members=(g.heroes||[]).filter(n=>memberOfSect(g,n)&&!n.stageLocal?.offmap&&['idle','waiting'].includes(n.stageLocal?.mode||'idle')).sort((a,b)=>a.id.localeCompare(b.id));
 const buys=[];
 for(const n of members){const balance=E.getSpiritStonesV140(n);for(const o of s.offers||[]){if(o.status!=='PENDING'||time(g)>=o.expiresAt)continue;const need=memberOfferNeed(g,n,o);if(!need)continue;const qty=Math.max(1,Math.min(o.quantity,need.quantity||1)),q=quoteMemberExternalOffer(g,n.id,o.id,qty);if(!q.ok||q.balanceAfter<4)continue;const wealth=n.core?.values?.wealthResource||50;buys.push({n,o,q,score:need.score+(wealth-50)*.08-q.stones*.02,reason:need.reason});}}
 buys.sort((a,b)=>b.score-a.score||a.q.stones-b.q.stones||a.n.id.localeCompare(b.n.id));
 if(buys.length){const x=buys[0],r=buyExternalOffer(g,x.n.id,x.o.id,x.q.quantity);if(r.ok)return {kind:'BUY',npcId:x.n.id,result:r};}
 const sells=[];
 for(const n of members){const balance=E.getSpiritStonesV140(n);for(const o of s.orders||[]){if(o.status!=='OPEN'||time(g)>=o.expiresAt)continue;const q=quotePersonalPurchaseOrder(g,n.id,o.id,1);if(!q.ok)continue;const wish=n.stageLocal?.storeWish;if(wish&&wish.kind===o.kind&&(wish.id===o.targetId||wish.id===o.nameTh))continue;if(o.kind==='PILL'&&((n.health||100)<85||((n.stageLocal?.combatState?.qi||100)<45)))continue;const surplus=q.surplusQty||0;if(balance>=90&&surplus<4)continue;const wealth=n.core?.values?.wealthResource||50;const score=(90-balance)*.22+surplus*2+(50-wealth)*.04+q.stones*.03;sells.push({n,o,q,score});}}
 sells.sort((a,b)=>b.score-a.score||b.q.stones-a.q.stones||a.n.id.localeCompare(b.n.id));
 if(sells.length){const x=sells[0],r=sellPersonalToPurchaseOrder(g,x.n.id,x.o.id,1);if(r.ok)return {kind:'SELL',npcId:x.n.id,result:r};}
 return null;
}

function rejectExternalOffer(g,id){
 const o=externalState(g).offers.find(x=>x.id===id&&x.status==='PENDING');
 if(!o||time(g)>=o.expiresAt)return {ok:false,reason:'ไม่พบข้อเสนอที่ยังเปิดอยู่'};
 o.status='REJECTED';return {ok:true,reason:'ปฏิเสธข้อเสนอแล้ว คงหินวิญญาณไว้ในกองกลาง'};
}
function tickExternalMarket(g){
 const s=externalMarket(g);if(time(g)<s.nextDecisionAt)return;
 s.nextDecisionAt=time(g)+20;
 if(s.autoMemberTrade!==false&&time(g)>=(s.nextMemberDecisionAt||0)){s.nextMemberDecisionAt=time(g)+60;tickMemberMarket(g,s);/* A member's private trade must not suppress an independent sect-treasury sale in this same market tick. */}
 const auth=g.storyEvents.authorities()[0]?.npc,libAuth=root.JianghuSectLibrary?.authority(g);if(!auth&&!libAuth)return;
 if(s.autoProcure){
  const reserveStones=Math.max(100,Math.ceil(g.gold*.35));
  const proposals=s.offers.filter(o=>o.status==='PENDING'&&time(g)<o.expiresAt&&g.gold-o.totalStones>=reserveStones);
  const needs=proposals.map(o=>{
   if(o.kind==='SCROLL'){const evaluation=root.JianghuSectLibrary.assess(g,o);return {o,...evaluation};}
   if(!auth)return {o,score:-999};
   const count=o.kind==='MATERIAL'?g.count(g.bank,g.world.npcs[o.sellerNpcId].jianghu.ledgerV140.materialStacks.find(x=>x.id===o.itemId)?.matId):o.kind==='PILL'?g.bank.jianghu.ledgerV140.pillStacks.filter(p=>p.recipeId==='L14_remedy').reduce((s,p)=>s+p.count,0):g.bank.jianghu.ledgerV140.equipmentItems.length;
   const target=o.kind==='MATERIAL'?8:Math.max(2,g.heroes.filter(x=>x.alive).length);
   const thrift=((auth.core?.values?.wealthResource||50)-50)*.15;
   return {o,score:(target-count)*8-thrift-o.totalStones*.06};
  }).filter(x=>x.score>8).sort((a,b)=>b.score-a.score||a.o.totalStones-b.o.totalStones);
  if(needs.length)acceptExternalOffer(g,needs[0].o.id,needs[0].actor?.id||auth?.id);
 }
 if(s.autoSell!==false&&auth)autoSellSurplus(g,s,auth);
}

function tick(g){
 if(!g.s.storyEvents?.active)return;
 const s=state(g),now=time(g);
 tickExternalMarket(g);
 for(const n of g.heroes)if(g.life.member(n))account(g,n);
 if(now>=(s.storeCuratedAt||0)+15){
  if(!g.s.storyEvents?.sidequests?.active&&(g.built('alchemy')||g.built('forge')))ensureBasicSectRecipes(g);
  curateStore(g);
 }
}

function inspect(g){
 const s=g.s.storyEvents?.treasury?.contributions||{accounts:{},history:[]};
 const wishes=new Map((g.heroes||[]).filter(n=>n.alive).map(n=>[n.id,evaluateStoreDesires(g,n,false).topWish]));
 const store=storeInventory(g);
 const treasury=treasuryInventory(g);
 const flywheel=computeMarketFlywheel(g);
 for(const item of store.all){
  const w=(g?.heroes||[]).filter(h=>h?.alive&&h.stageLocal?.storeWish?.kind===item.kind&&h.stageLocal?.storeWish?.id===item.id).map(h=>({npcId:h.id,name:h.name,canAfford:h.stageLocal.storeWish.canAfford,deficit:h.stageLocal.storeWish.deficit}));
  item.wantedBy=w;
  item.demandCount=w.length;
 }
 const visibleRecipes=new Set([...FREE_SECT_RECIPES,...FORTUITOUS_RECIPES,...g.heroes.filter(n=>n.alive).flatMap(n=>n.stageLocal?.growth?.knownRecipes||[])]);
 const craftableRecipes=(g.progression?.allRecipes?.()||[]).filter(r=>visibleRecipes.has(r.id)&&['alchemy','forge'].includes(r.workshop)&&!r.effect?.beastItem).map(r=>{
  const estItem={recipeId:r.id,tier:r.tier,quality:'COMMON'};
  const kind=r.effect?.slot?'EQUIPMENT':'PILL';
  const q=quote(g,kind,estItem,1);
  const bonusPct=flywheel.bonusByCategory?.[kind]||0;
  const baseLabor=Math.max(5*r.tier,Math.round(q.donation*0.65));
  const laborPts=baseLabor+Math.round(baseLabor*(bonusPct/100));
  const inputsRequired=new Map();for(const inp of r.inputs)inputsRequired.set(inp.matId,(inputsRequired.get(inp.matId)||0)+inp.count);
  const hasInputs=[...inputsRequired].every(([matId,count])=>treasuryMaterialAvailable(g,matId)>=count);
  return {
   id:r.id,
   nameTh:r.name,
   workshop:r.workshop,
   tier:r.tier,
   minMastery:r.min,
   isFreeBasic:FREE_SECT_RECIPES.includes(r.id),
   inputs:r.inputs.map(inp=>({matId:inp.matId,count:inp.count,inBank:treasuryMaterialAvailable(g,inp.matId)})),
   hasInputs,
   laborPoints:laborPts,
   demandBonusPct:bonusPct,
   storePrice:q.storePrice
  };
 });
 return {
  accounts:g.heroes.map(n=>({
   npcId:n.id,
   name:n.name,
   ...accountView(g,n),
   merit:g.life.member(n)?.merit||0,
   knownRecipes:n.stageLocal?.growth?.knownRecipes||[],
   storeWish:wishes.get(n.id)?{...wishes.get(n.id),balance:accountView(g,n).balance,canAfford:accountView(g,n).balance>=wishes.get(n.id).price}:null
  })),
  history:s.history,
  pointEconomy:Object.values(s.accounts).reduce((r,a)=>({issued:r.issued+(a.earned||0),retired:r.retired+(a.spent||0),circulating:r.circulating+(a.balance||0)}),{issued:0,retired:0,circulating:0}),
  externalTrade:s.externalTrade?{
   ...s.externalTrade,
   regionalMarket:regionalMarketSnapshot(s.externalTrade),
   purchaseOrders:(s.externalTrade.orders||[]).map(o=>({...o,quote:quotePurchaseOrder(g,o.id)}))
  }:{autoProcure:true,autoSell:true,autoMemberTrade:true,offers:[],orders:[],purchaseOrders:[],sales:[],history:[],guildRelations:{},nextVisitAt:null,regionalMarket:null},
  marketPulse:computeMarketPulse(g),
  storeInventory:store,
  treasuryInventory:treasury,
  sectWorkshopRecipes:craftableRecipes,
  flywheel
 };
}

root.JianghuSectContributions={
 VERSION:2,
 FREE_SECT_RECIPES,
 FORTUITOUS_RECIPES,
 CARAVAN_GUILDS,
 colorMeta,
 recordTransaction:log,
 quote,
 supplyQuote,
 prepareStock,
 transferStock,
 externalMarket,
 advanceCaravan,
 tickRegionalMarket,
 regionalMarketSnapshot,
 acceptExternalOffer,
 quoteMemberExternalOffer,
 buyExternalOffer,
 rejectExternalOffer,
 orderReserve,
 quotePurchaseOrder,
 sellToPurchaseOrder,
 quotePersonalPurchaseOrder,
 sellPersonalToPurchaseOrder,
 computeMarketPulse,
 marketPressure,
 externalAskPrice,
 account,
 ensureBasicSectRecipes,
 tryFortuitousRecipeDiscovery,
 curateStore,
 transferToStore,
 returnToTreasury,
 storeInventory,
 treasuryInventory,
 computeMarketFlywheel,
 buyFromStore,
 canCraftForSect,
 craftForSect,
 evaluateStoreDesires,
 economicWorkload,
 acquire,
 autoMethod,
 grantEligibility,
 transferFlags,
 creditWork,
 donate,
 creditLibraryDonation,
 reserve,
 prepareRedemption,
 commitRedemption,
 options,
 finish,
 tick,
 inspect,
 actionLabel,
 workActivity
};
})(typeof globalThis!=='undefined'?globalThis:this);
