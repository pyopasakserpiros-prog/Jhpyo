# QA Report — Jianghu v2.08.6

## Verified in this run

| Check | Result | Coverage |
|---|---|---|
| Inter-sect trade | PASS | 12 cases: buy/sell settlement, spirit-stone-only accounting, relation-sensitive prices, invalid input, low funds/stock, capacity, store/operational reserve, bounded production, save/load migration and UI rendering |
| Member-to-outsider trade | PASS | 9 cases: personal wallets, partial purchase, scripture ownership, reserves, autonomous member trade and persistence |
| Caravan / regional market | PASS | 7 cases: visible arrival/departure, finite liquidity/cargo, unsold cargo return, export settlement, bounded production and save/load |
| Economy UI | PASS | 11 UI checks, including an actual sect-to-sect click handler that transfers goods and spirit stones |
| Sect economy | PASS | 22 cases |
| Scripture/library economy | PASS | 6 cases |
| Economy integration | PASS | 9 cases |
| Infrastructure | PASS | 16 cases |
| Offline build | PASS | 32 inline modules; source hashes match embedded scripts; no external script or stylesheet references; `human.js` foundation locked |

Exact evidence is stored in `evidence/sect-trade-v2086.json`, `evidence/member-external-trade-v2084.json`, `evidence/caravan-ecology-v2085.json`, `evidence/economy-ui-v207.json`, `evidence/economy-v207.json`, `evidence/library-economy-v207.json`, `evidence/economy-integration-v207.json`, `evidence/qa-build-v2.08.6.json`, and `evidence/qa-v2086-targeted.json`.

## Incomplete verification

The long-running `tests/economy_simulation_v207.cjs` did not complete within the 300-second execution limit. It simulates four seeds for 40 in-game days each and performs save-continuation comparisons; this run therefore has **no pass/fail conclusion** for that long-run test. The complete legacy `npm test` suite was not claimed as passing.

## Compatibility / limitations

- Save envelope v11 is preserved; `s.realm.sectTrade` is initialized lazily for existing saves.
- `human.js` and `legacy.bundle.js` remain byte-identical to their locked baselines.
- Inter-sect trade currently covers common non-transcendent materials only. Pills, unique equipment, scriptures, and direct private disciple-to-other-sect trade are outside this patch.
- No physical Android device or real-browser layout playtest was available; offscreen UI tests do not establish touch behavior or device performance.
