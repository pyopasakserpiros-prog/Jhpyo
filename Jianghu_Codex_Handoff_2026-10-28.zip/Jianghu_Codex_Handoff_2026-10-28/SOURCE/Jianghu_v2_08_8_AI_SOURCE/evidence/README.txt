Generated QA results and fixtures go here. They are not bundled in the AI source ZIP.
Run `node tests/run_v208.cjs` to regenerate the audit fixtures and full suite evidence.
