# Jianghu v2.08.8 — Full Economy Long-Run Readiness

## Intent

Make the existing living-economy simulation practical to validate at realistic sect sizes (20–34 disciples), then add reproducible integrated simulations that exercise disciple autonomy, contribution accounting, personal and sect external trade, caravan ecology, and the inter-sect spirit-stone network together.

## Goals

- Reduce repeated combat-stat projection cost without changing any combat-stat values or NPC identity foundations.
- Keep the existing currency boundaries: contribution points for internal sect purchases; spirit stones for sect-to-outsider, disciple-to-outsider, and inter-sect trade.
- Validate nonnegative balances and inventories, bounded market wallets/stocks/history, contribution-point ledger conservation, deterministic same-version save continuation, and an end-to-end caravan export funded by regional liquidity.
- Run seeded integrated simulations with 20 and 34 disciples over long horizons, report duration and market/economy activity, and preserve reproducibility.
- Produce an offline v2.08.8 build and evidence artifacts.

## Non-goals

- No new save migration; fresh games are acceptable for this patch, while same-version save/load must remain deterministic.
- No changes to `source/scripts/human.js` or `source/scripts/legacy.bundle.js`.
- No new currency conversion, new market categories, or new rare-item inter-sect trading in this patch.
- No claim of Android device compatibility without a physical-device test.

## Approach

Use the already-defined batched effective-dimension projection in `combat-stats.js` instead of invoking `HumanCore.effective` separately for every dimension. Keep the fallback path for incomplete actor data safe and non-recursive. Add a focused regression that verifies the batch path does not repeatedly call the Human Foundation, then add a seeded full-economy simulation harness at 20–34 disciples. Fix only issues reproduced by these tests.

## Acceptance criteria

- Combat-stat outputs remain finite and behaviorally consistent for healthy, fatigued, injured, and hungry actors.
- Normal human combat-stat derivation uses a single batched projection and does not call `HumanCore.effective` once per dimension.
- The integrated simulation reports all seeds, days, trade counts, balances, stocks, point-ledger totals, and save-continuation checks. A separate route test must confirm a caravan can buy disciple surplus, depart, export it, and receive payment from regional liquidity after replenishment accounting.
- No negative money or item counts, no inventory stack exceeds its count/store count, no faction wallet or stock exceeds its cap, and contribution points satisfy `issued - retired = circulating`.
- The new test suites, existing focused economy/market suites, build, and build verifier pass. The broad legacy suite is reported honestly if incomplete.
- The final HTML embeds the exact source hashes; `human.js` and `legacy.bundle.js` remain byte-for-byte unchanged.
