# Sect Network Market — Design

## Intent
Extend v2.08.6's player-facing trade between the main sect and six external sects into a living regional economy where external sects autonomously exchange common materials with one another. All inter-sect settlements use real spirit-stone wallets and real material ledgers; contribution points are never involved.

## Goals
- Let external sects buy needed stock from other sects and sell genuine surplus.
- Make supply, demand, specialty production, and periodic material use create recurring but bounded trade.
- Keep trades deterministic, saveable, capped, and cheap enough to process once per in-game day.
- Show recent network activity in the existing Diplomacy / Sect Delegates screen.
- Preserve the current main-sect buy/sell interface and the locked Human Foundation files.

## Non-goals
- No trade in pills, equipment, unique items, or scriptures in this patch.
- No direct disciple-to-foreign-sect transactions beyond the existing disciple-to-caravan system.
- No new global currency or conversion from contribution points.
- No requirement to migrate historical saves; same-version save/load must preserve network state.

## Approaches
1. Keep trade manual between the main sect and each external sect. This is lowest risk but leaves the external world economically static.
2. Build a multi-city route simulation with travel time and caravan pathfinding. This is too broad for the current six-faction cache model and would add runtime complexity before long-run stability is known.
3. **Chosen: bounded daily bilateral trade among existing external sect caches.** It reuses real faction caches and spirit-stone wallets, adds limited production/consumption and a maximum of three deals per day, and is observable in the existing diplomacy screen.

## Rules
- Only common, non-transcendent materials with a positive base spirit-stone value may trade.
- Every trade transfers one unit at a price derived from base value, buyer shortage, and seller surplus; buyer stones decrease by exactly the seller's increase.
- The main sect bank and disciple contribution accounts are untouched by external-to-external transactions.
- A seller must retain a material reserve; a buyer must be below its stock target and have enough stones; the destination must accept the material; seller wallet must remain under its cap.
- Failed transfers do not change balances or inventory. A given day can be processed at most once; at most three successful deals occur per day.
- Network history is bounded and stored in `s.realm.sectTrade.networkHistory`; summary counters and cursor are persisted.
- Current-patch save/load preserves inventory, wallets, cursor, day guard, history, and counters.

## Verification
Add focused transaction tests first, then a deterministic 4-seed / 120-day market-only simulation with wallet/stock bounds, no partial settlement, non-player account isolation, and save-continuation equivalence. Re-run existing sect trade, caravan, personal trade, economy, UI, and offline build checks.
