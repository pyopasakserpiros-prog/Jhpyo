# Jianghu v2.08.6 — Sect-to-Sect Spirit-Stone Trade Design

## Intent
Connect the six existing external sects in `game.s.realm.factions` to the main sect treasury through a real two-way trade system. The main sect can buy common materials from another sect or sell its surplus materials to that sect. All inter-sect settlement uses spirit stones; contribution points remain an internal disciple currency and are never converted.

## Goals
- Use each faction's existing persistent `cache` inventory and spirit-stone wallet; do not create a parallel fake market inventory.
- Quote and execute bounded material trades with inventory, capacity, wallet, and treasury checks.
- Make prices respond to faction relations and actual stock scarcity/abundance.
- Keep faction money and common-material stock bounded by hard caps and replenish materials on the existing daily simulation tick.
- Persist a short transaction history in the existing realm save state and show it in the Diplomacy UI.
- Keep internal disciple trading on contribution points and existing sect/outsider trades on spirit stones.

## Non-goals
- No inter-sect trading of unique/transcendent items, equipment, or scriptures in this release; their ownership, rights, and storage rules need a separate design.
- No direct disciple-to-other-sect private trading; this release models institutional treasury-to-treasury trade.
- No changes to `human.js`, `legacy.bundle.js`, save envelope v11, or external dependencies.

## Approaches
1. **New disconnected regional market:** rejected because it would duplicate inventory and currency state already held by the six factions.
2. **Reuse envoy NPC inventory only:** rejected because it makes trade depend on a visiting delegate and can desync goods from the faction's actual treasury.
3. **Use each faction's persistent cache and wallet (chosen):** quotes, delivery, payment, relation, and history all operate on existing faction records. This keeps accounting consistent with diplomacy and save/load.

## Behavior
- Tradeable goods are common, non-transcendent materials from the material registry, only when real stock exists.
- Main sect BUY: deduct spirit stones from the sect treasury, transfer material from faction cache to sect bank, and credit the faction wallet.
- Main sect SELL: transfer eligible surplus from sect bank to faction cache, deduct the faction's spirit stones, and credit the sect treasury.
- Trades are limited to 1–10 units per transaction. Selling excludes internal store stock and an operational reserve. No trade may overdraw a wallet or exceed stock/capacity.
- Buy price rises when the other sect's stock is scarce and falls with positive relations. Sell price improves with high relations and the buyer's need for stock. Successful trade modestly improves relations.
- Faction spirit-stone balances have a hard cap; daily production is bounded. Faction material stock is replenished gradually up to per-material caps.
- Receipts and the latest 40 trades persist in `s.realm.sectTrade`.

## UI
Add a trade area to the existing `Diplomacy` section. Each faction card shows relation, wallet, actual stock, buy-one and sell-one quotes for available common materials, plus a compact recent trade history. Existing envoy invitations and diplomacy behavior remain available.

## Constraints
- Maintain standalone offline HTML output.
- Preserve `human.js` and `legacy.bundle.js` byte-for-byte.
- Preserve save envelope v11 and initialize new `sectTrade` state lazily for existing same-version saves.
- Tests must cover real balances and inventory transfer, insufficient funds/stock/capacity, price response, history/save-load, and UI actions.
