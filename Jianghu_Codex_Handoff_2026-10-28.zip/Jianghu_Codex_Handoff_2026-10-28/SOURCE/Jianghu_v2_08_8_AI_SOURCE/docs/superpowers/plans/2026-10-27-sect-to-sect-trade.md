# Sect-to-Sect Trade Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** Add two-way institution-level trade between the main sect and six existing external sects, with spirit stones as the only currency.

**Architecture:** Extend `LivingJianghu` to quote and settle trades against existing faction cache ledgers and wallets, then expose the market in the existing Diplomacy UI. Use real material transfers, bounded production and wallet caps, persistent receipts, and focused integration tests.

**Tech Stack:** Existing vanilla JavaScript simulation, Node.js `assert` test harness, Python standalone build script.

**Spec:** `docs/superpowers/specs/2026-10-27-sect-to-sect-trade-design.md`

## Global Constraints
- Preserve `source/scripts/human.js` and `source/scripts/legacy.bundle.js` byte-for-byte.
- Keep simulation save envelope v11 and add lazy migration for `s.realm.sectTrade`.
- All main-sect ↔ external-sect transactions use spirit stones; contribution points are not converted.
- Trade only common non-transcendent materials in this release; transaction size is 1–10 units.
- Deliver a standalone offline HTML and ZIP source/player packages.

## Review Focus
- Insufficient buyer funds or recipient capacity must not change either inventory or wallet.
- Main-sect sales must never consume materials reserved for the internal store or minimum operations.
- A missing/invalid faction, material, direction, or quantity must fail without mutation.
- Relation-driven prices must stay positive and bounded at extreme relations and stock values.
- Save/load must preserve balances, stock, faction relations, and trade history.

---

### Task 1: Core quote and trade settlement

**Files:**
- Modify: `source/scripts/jianghu.js`
- Test: `tests/sect_trade_v2086.cjs`

**Interfaces:**
- Consumes: `Frontier` inventory methods, `World2026Engine` spirit-stone ledger, `LivingJianghu.data.factions`.
- Produces: `quoteSectTrade(factionId, direction, matId, quantity)`, `buyFromFaction(factionId, matId, quantity)`, `sellToFaction(factionId, matId, quantity)`, `sectTradeSnapshot()`.

- [ ] Write tests for both trade directions, wallet/stock/capacity guards, relation-sensitive prices, invalid requests, and save/load.
- [ ] Run `node tests/sect_trade_v2086.cjs` and confirm it fails because the API is missing.
- [ ] Implement bounded quote and transaction methods using existing caches, real material transfer, spirit-stone settlement, relation shifts, and persisted receipts.
- [ ] Re-run `node tests/sect_trade_v2086.cjs`; expect all core cases to pass.

### Task 2: Bounded faction supply and wallet ecology

**Files:**
- Modify: `source/scripts/jianghu.js`
- Test: `tests/sect_trade_v2086.cjs`

**Interfaces:**
- Consumes: Task 1 `sectTrade` state and faction caches.
- Produces: capped faction liquidity and specialty material replenishment on the existing daily tick.

- [ ] Add assertions that daily production raises depleted stocks but never exceeds stock or wallet caps.
- [ ] Run the new tests and confirm the cap/production assertions fail before implementation.
- [ ] Implement bounded initial specialty stock and daily production for each faction, with wallet cap enforcement.
- [ ] Re-run the focused suite and verify stock and currency caps.

### Task 3: Diplomacy trade UI and event handlers

**Files:**
- Modify: `source/scripts/jianghu-ui.js`
- Modify: `source/scripts/ui.js`
- Test: `tests/sect_trade_v2086.cjs`

**Interfaces:**
- Consumes: `game.realm.sectTradeSnapshot()`, `quoteSectTrade`, `buyFromFaction`, `sellToFaction`.
- Produces: visible buy/sell controls in the Diplomacy section and delegated click handling.

- [ ] Add tests that Diplomacy UI shows faction wallet/stock and emits buy/sell action attributes with spirit-stone quotes.
- [ ] Run the UI assertions and confirm they fail before the UI change.
- [ ] Add one-unit trade controls, balances, stock, and recent history; wire action parsing to the core methods.
- [ ] Re-run the focused tests and existing economy UI test.

### Task 4: Versioned build and documentation

**Files:**
- Modify: `package.json`, `VERSION.txt`, `tools/build.py`, `source/scripts/stage.js`, README and patch notes.
- Create: `PATCH_NOTES_v2086_TH.md`, `V2086_HANDOFF_TH.md`.

- [ ] Bump release metadata to v2.08.6 without changing the save envelope.
- [ ] Run targeted trade tests, existing market tests, economy tests, and build/hash checks.
- [ ] Package COMPLETE, PLAYER, and AI_SOURCE ZIPs; inspect ZIP integrity and file hashes.
