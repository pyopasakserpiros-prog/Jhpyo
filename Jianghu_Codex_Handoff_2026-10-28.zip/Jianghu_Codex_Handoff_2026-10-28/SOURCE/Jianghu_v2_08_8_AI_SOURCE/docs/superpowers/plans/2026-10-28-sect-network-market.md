# Sect Network Market Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add bounded autonomous spirit-stone trade between external sects and verify long-run market stability.

**Architecture:** Extend `LivingJianghu` daily market processing in `source/scripts/jianghu.js`, expose bounded network history through `sectTradeSnapshot()`, and render it in the existing diplomacy UI. Keep all settlement in the existing faction caches and ledgers.

**Tech Stack:** Browser-first JavaScript, Node.js regression tests, existing Python offline build.

**Spec:** `docs/superpowers/specs/2026-10-28-sect-network-market-design.md`

## Global Constraints
- Preserve `source/scripts/human.js` and `source/scripts/legacy.bundle.js` byte-for-byte.
- Inter-sect trade uses `SPIRIT_STONES` only; contribution points never convert.
- Keep external wallet cap 1,000, per-material stock cap 24, and maximum 3 autonomous trades per in-game day.
- Preserve offline single-file HTML and same-version save/load.
- Only common, non-transcendent materials are eligible.

## Review Focus
- A buyer has insufficient stones or a seller wallet is capped: no inventory or wallet changes.
- Destination cache has no capacity: no partial transfer.
- A day is ticked more than once: no duplicate trades or consumption.
- Large time jumps occur: catch-up work remains bounded and balances stay under caps.
- Save/load occurs between days: next trade sequence remains deterministic.

---

### Task 1: Network trade regression tests

**Files:**
- Create: `tests/sect_network_trade_v2087.cjs`
- Test: existing `tests/inspect-engine.cjs` fixture

**Interfaces:**
- Consumes: `Frontier`, `LivingJianghu`, `World2026Engine`, and existing faction cache ledgers.
- Produces: behavior contract for `processSectNetworkTrade(day)`, `sectTrade.networkHistory`, and persisted market summary.

- [ ] Write tests for real material + spirit-stone transfer, no contribution/main-bank mutation, bounded daily transactions/idempotence, insufficient funds/capacity, same-version save/load, and diplomacy UI.
- [ ] Run `node tests/sect_network_trade_v2087.cjs` and confirm expected failures because the network API is absent.

### Task 2: Daily bounded market simulation

**Files:**
- Modify: `source/scripts/jianghu.js`
- Test: `tests/sect_network_trade_v2087.cjs`

**Interfaces:**
- Produces: `processSectNetworkTrade(day)`, `tickSectNetworkConsumption(day)`, `tickSectMarketDay(day)`, and `sectTradeSnapshot().network`.

- [ ] Implement persisted network cursor, last-processed day, counters, and bounded history.
- [ ] Implement deterministic one-unit bilateral settlement using existing material transfer and spirit-stone APIs; cap successful trades at 3 per day.
- [ ] Add modest specialty production and periodic consumption so demand recurs without unbounded stock.
- [ ] Integrate with daily tick and make large catch-up jumps bounded.
- [ ] Run focused test and confirm it passes.

### Task 3: Diplomacy UI

**Files:**
- Modify: `source/scripts/jianghu-ui.js`
- Test: `tests/sect_network_trade_v2087.cjs`

**Interfaces:**
- Consumes: `sectTradeSnapshot().network = { totalTrades, totalStones, lastDay, history }`.

- [ ] Render the network summary and recent bilateral transactions with seller, buyer, material, quantity, and spirit-stone price.
- [ ] Run UI assertion and existing `tests/sect_trade_v2086.cjs`.

### Task 4: Long-run simulation and release

**Files:**
- Create: `tests/sect_network_simulation_v2087.cjs`
- Modify: `tests/run_v208.cjs`, `tools/build.py`, `package.json`, `source/index.html`, `VERSION.txt`, `ROADMAP_TH.md`, `README_TH.md`
- Create: `PATCH_NOTES_v2087_TH.md`, `V2087_HANDOFF_TH.md`, `evidence/sect-network-simulation-v2087.json`

- [ ] Simulate four seeds for 120 days using realm-only ticks and assert wallet/stock bounds, at least some successful network trades, and save-continuation equivalence.
- [ ] Run focused regressions for sect-to-sect, caravan, personal trade, economy UI, and existing economy tests.
- [ ] Build the offline HTML, verify embedded hashes and locked foundation, package COMPLETE / PLAYER / AI SOURCE ZIPs, and run `unzip -t` on every archive.
- [ ] Update roadmap done/pending scope and QA limitations truthfully.
