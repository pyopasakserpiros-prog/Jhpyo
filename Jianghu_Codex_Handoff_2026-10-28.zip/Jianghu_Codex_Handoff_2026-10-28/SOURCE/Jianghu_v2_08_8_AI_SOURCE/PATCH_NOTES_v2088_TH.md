# Jianghu v2.08.8 — Full Economy Readiness

## เปลี่ยนแปลงหลัก

- `CombatStats201` ใช้การคำนวณ effective dimensions แบบรวมผ่าน `fillEffectiveMap` สำหรับข้อมูลตัวละครปกติ ลดการเรียก `HumanCore.effective` ทีละมิติ
- แก้ fallback ที่เคยวนเรียก `fillEffectiveMap` ซ้ำ เมื่อข้อมูล human record ไม่ครบ โดยเปลี่ยนเป็น fallback ต่อมิติที่ปลอดภัย
- เพิ่ม `tests/combat_stats_batch_v2088.cjs`: ตรวจว่า normal projection ไม่เรียก `HumanCore.effective` ซ้ำทีละมิติ, ค่าสถานะเป็นตัวเลข, ความเหนื่อย/เจ็บปวด/หิวลดพลังโจมตีและการฟื้นปราณตามเดิม และข้อมูลไม่ครบไม่ทำให้ล้ม
- เพิ่ม simulation harness แยก process เพื่อหลีกเลี่ยงการปะปนของ state ระหว่างหลายโลกใน process เดียว
- เพิ่ม `tests/caravan_route_economy_v2088.cjs` ยืนยันคาราวานเดินทางเข้าตลาด ซื้อสินค้าส่วนเกินจากศิษย์ เดินทางออก และส่งออกต่อ โดยเงินจ่ายออกจากกองทุนภูมิภาคจริงหลังหักเงินที่ตลาดผลิตเติมเข้ามา
- ทดสอบ 4 scenarios (2 seeds × 20/34 ศิษย์) 10 วันในเกมต่อ scenario; ตรวจยอดบัญชีแต้มคุณูปการ, เงินและคลัง, เพดานเงิน/สต็อกตลาด, และการทำงานของตลาดระหว่างสำนัก
- คงแกน `human.js` และ `legacy.bundle.js` แบบ byte-for-byte

## หลักฐาน

- `evidence/full-economy-simulation-v2088.json`
- `evidence/full-economy-scenario-20882001-20.json`
- `evidence/full-economy-scenario-20882001-34.json`
- `evidence/full-economy-scenario-20882002-20.json`
- `evidence/full-economy-scenario-20882002-34.json`
- `evidence/qa-build-v2.08.8.json`

## ข้อจำกัด

การจำลองตลาดระหว่างสำนักแบบแยกส่วนครอบคลุม 120 วัน แต่การจำลองเต็มโลกในรุ่นนี้ทดสอบ 10 วันต่อ scenario เท่านั้น การรันเต็มโลกยาวกว่านี้ที่ศิษย์ 34 คนบางครั้งใช้เวลานานเกินกรอบทดสอบ จึงยังไม่รับรองความสมดุลหลายร้อยวันหรือสมรรถนะ Android จริง
