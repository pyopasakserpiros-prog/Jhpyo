# Handoff v2.08.6 — Inter-Sect Spirit-Stone Trade

## Implemented
- Real two-way main-sect ↔ six external sect trades against existing faction cache ledgers and wallets.
- Spirit-stone-only settlement; contribution-point balances are unchanged.
- Price sensitivity to faction relation and available stock, bounded transaction sizes, and checks for funds, inventory, capacity, store stock, and operational reserves.
- Bounded specialty-material replenishment and wallet growth; persisted history and transaction receipts.
- Diplomacy UI now shows faction wallets, stock, one-unit buy/sell quotes, and recent trade history.
- Lazy migration creates `s.realm.sectTrade` and specialty stock for existing same-version saves without changing the save envelope.

## Verification
- `node tests/sect_trade_v2086.cjs`
- `node tests/economy_ui_v207.cjs`
- `npm run test:market`
- `python3 tools/build.py`
- `node tests/verify_build_v205.cjs`

## Scope / caveats
- Inter-sect trade covers common non-transcendent materials only; unique equipment, pills, scriptures, and direct private disciple-to-other-sect trade remain future work.
- No physical Android device test was available; existing offscreen UI harness is not a substitute for touch/layout playtesting.
- Keep a backup of the previous save before changing builds. The save envelope remains v11, but always validate a copied save before overwriting the only copy.
