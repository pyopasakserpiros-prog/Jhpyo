# รายงานสถานะงาน Jianghu — สำหรับส่งต่อ Codex

วันที่ตรวจ: 2026-10-28  
ฐานโค้ดที่ปล่อยได้ล่าสุด: **v2.08.8**  
สถานะงานถัดไป: **v2.08.9 กำลังทำ / ยังไม่ใช่ release**

## สรุป

แพ็กนี้เก็บซอร์สครบจากรุ่น v2.08.8 พร้อม HTML ออฟไลน์ที่ build ล่าสุด เอกสารเดิม ชุดทดสอบ และ regression test ที่เพิ่มระหว่างไล่ปัญหาความเร็วในรุ่นถัดไป จุดสำคัญคืออย่าเข้าใจผิดว่าแคชอุปกรณ์หรือปัญหาจำลองเต็มโลกแก้เสร็จแล้ว

## สิ่งที่มีอยู่และตรวจยืนยันได้

- ตลาดระหว่างสำนักภายนอกใช้คลังสินค้าและบัญชีหินวิญญาณจริง; ไม่แตะเงินสำนักเมฆาครามโดยตรง
- ตลาดเครือข่ายระหว่างสำนักผ่าน 120 วันใน 4 seeds: 345 ธุรกรรมต่อ seed, จำกัด history 60 รายการ และบันทึก/โหลดแล้วเล่นต่อแบบ deterministic
- คาราวาน: เส้นทางเข้าตลาด รับ/ส่งสินค้า และออกจากพื้นที่ผ่าน integration test (803 steps; export 1 หน่วยเป็น 6 หินวิญญาณ)
- Combat-stat batch test ผ่าน; ค่าสถานะยังสะท้อนสภาพร่างกาย/ความเหนื่อยตาม test fixture
- Build HTML ออฟไลน์ผ่าน: 32 โมดูล inline, CSS/asset ฝังในไฟล์, hash ของ embedded scripts ตรงกับซอร์ส
- `source/scripts/human.js` และ `source/scripts/legacy.bundle.js` ตรงกับ hash baseline ที่ล็อกไว้
- full-world scenario ศิษย์ 20 คน / 10 วัน ผ่านใน 10.97 วินาที พร้อม save continuation; minimum contribution balance = 0 (ไม่ติดลบ)

## ปัญหาที่ยังเปิดอยู่

### P1 — Full-world simulation ช้ามาก/ค้างในฉาก 34 ศิษย์

คำสั่ง `node tests/full_economy_scenario_v2088.cjs 20882001 34 10 0` หมดเวลาตามกรอบ execution 90 วินาที โดย log ไปถึงแค่วันที่ 5/10 และไม่มี `SCENARIO_RESULT`.

คำสั่ง `timeout 125s node tests/full_economy_scenario_v2088.cjs 20882001 34 30 0` ถูกตัดหลัง log ไปถึงวันที่ 20/30 และไม่มีผลสรุปสุดท้าย. นี่ไม่ใช่ PASS.

งานก่อนหน้าได้ปรับ `source/scripts/combat-stats.js` ให้คำนวณ effective dimensions แบบ batch แล้ว และผล focused test ผ่าน แต่ไม่เพียงพอแก้คอขวดในทุกฉาก. ต้อง profile การเปลี่ยนวันและหาตัวที่กินเวลา เช่น `stage.js`, `progression.js`, `jianghu.js`, `sect-contributions.js`, movement/AI, scheduled jobs. อย่าข้ามวันหรือปิดระบบจำลองเพื่อทำให้ test ผ่าน.

### P2 — Equipment validation cache เป็น regression test ที่ยัง fail

ไฟล์ `tests/equipped_validation_cache_v2089.cjs` เพิ่มการทดสอบว่า loadout และ cultivation state ที่ไม่เปลี่ยนต้อง reuse validation; เมื่อ durability เปลี่ยนเป็น 0 ต้อง revalidate และถอดอุปกรณ์ที่เสียทันที โดย item ยังอยู่ใน inventory.

คำสั่งนี้ปัจจุบัน FAIL ที่ `validations` เป็น 2 แต่คาดหวัง 1 เพราะ `source/scripts/progression.js::sanitizeEquippedItems()` ยังตรวจ `canEquipItem()` ซ้ำทุกครั้งและยังไม่มี cache implementation. Test นี้ตั้งใจเป็นจุดเริ่ม TDD; อย่าลบ assertion เพื่อให้ผ่าน. Cache key/invalidation ต้องครอบคลุม slot/item id, durability, compatibility/path, tier/minStageReq, actor realizationBand/trackOrdinal/path และ mutation ของ equipment. อย่าทำให้ item หายจาก inventory หรือปล่อยให้อุปกรณ์เสียค้างบนตัว.

## ผลตรวจคำสั่งล่าสุด

| คำสั่ง/ชุดทดสอบ | ผล |
|---|---|
| `python3 tools/build.py` | PASS; 32 scripts, standalone HTML 26,969,876 bytes |
| `node tests/verify_build_v205.cjs` | PASS |
| `node tests/combat_stats_batch_v2088.cjs` | PASS |
| `node tests/sect_network_trade_v2087.cjs` | PASS 8/8 |
| `node tests/sect_network_simulation_v2087.cjs` | PASS; 4 seeds × 120 market days |
| `node tests/caravan_route_economy_v2088.cjs` | PASS |
| `node tests/full_economy_scenario_v2088.cjs 20882001 20 10 1` | PASS; 10.97 s; save continuation PASS |
| `node tests/full_economy_scenario_v2088.cjs 20882001 34 10 0` | TIMEOUT; only day 5/10 logged |
| `timeout 125s node tests/full_economy_scenario_v2088.cjs 20882001 34 30 0` | TIMEOUT; progressed to day 20/30, no final result |
| `node tests/equipped_validation_cache_v2089.cjs` | FAIL as expected; cache not implemented |
| Full `npm test` | ยังไม่ได้ยืนยันครบใน handoff นี้ |
| Android device playtest | ยังไม่ได้ทำ |

## ข้อกำหนดสกุลเงินที่ต้องคงไว้

- ศิษย์ซื้อขายภายในสำนัก: แต้มคุณูปการ
- สำนักกับคนนอก/สำนักอื่น: หินวิญญาณจากบัญชีสำนัก
- ศิษย์ซื้อขายกับคนนอก: หินวิญญาณส่วนตัว
- สำนักภายนอกซื้อขายกัน: หินวิญญาณในบัญชีของสำนักคู่ค้า
- ห้ามใช้แต้มคุณูปการในธุรกรรมภายนอก และห้ามทำให้ธุรกรรมระหว่างสำนักภายนอกไปแตะบัญชีสำนักเมฆาคราม

## ขั้นตอนต่อไปที่แนะนำ

1. เปิด `CODEX_HANDOFF.md` และรัน test สองตัวที่เกี่ยวกับปัญหาก่อนแก้
2. เพิ่ม instrumentation แบบต่อเฟส/ต่อวันใน full-world simulation เพื่อจับจุดชะลอที่ทำซ้ำได้
3. แก้ต้นเหตุด้าน performance พร้อม regression test; ห้ามเปลี่ยนความหมายการจำลองเพื่อซ่อน timeout
4. ทำ TDD ให้ `equipped_validation_cache_v2089.cjs` จาก RED → GREEN พร้อม invalidation tests
5. รัน focused tests, full suite, 20/34-disciple scenarios, build และ build verifier อีกครั้ง
6. ค่อยเปลี่ยน version เป็น v2.08.9 เมื่อผลยืนยันครบ; จนกว่าจะถึงตอนนั้นให้ใช้ HTML v2.08.8 เป็น last-known-good player build
